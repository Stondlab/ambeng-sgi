import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

// Visão consolidada de Notas Fiscais emitidas + parcelas.
// RESTRITA AO ADMINISTRADOR. Valida o perfil no backend — mesmo que a rota seja
// acessada diretamente, os dados não são retornados a outro perfil.
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const perfil = user.perfil || (user.role === 'admin' ? 'Administrador' : null);
    if (perfil !== 'Administrador') {
      return Response.json({ error: 'Acesso restrito ao Administrador' }, { status: 403 });
    }
    const notas = await base44.asServiceRole.entities.NotasFiscais.list('-data_emissao', 500);
    const parcelas = await base44.asServiceRole.entities.ParcelasNF.list('-data_prevista', 2000);
    return Response.json({ notas, parcelas });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}