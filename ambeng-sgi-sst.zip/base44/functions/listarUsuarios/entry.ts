import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';

// Diretório de usuários para seletores de responsável/membros/solicitante.
// Executa como service role para garantir a MESMA lista para todo usuário logado
// (independente de role/perfil), eliminando diferenças por RLS entre logins.
// Retorna apenas campos de exibição — NUNCA expõe e-mail.
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const users = await base44.asServiceRole.entities.User.list('-created_date', 500);
    const dir = users.map((u) => ({
      id: u.id,
      nome_exibicao: u.nome_exibicao || '',
      full_name: u.full_name || '',
      role: u.role || 'user',
      perfil: u.perfil || '',
      status: u.status || 'Ativo',
    }));
    return Response.json(dir);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}