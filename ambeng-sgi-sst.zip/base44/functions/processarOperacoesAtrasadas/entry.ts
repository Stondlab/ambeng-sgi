import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const terminal = new Set(['Concluído', 'Cancelado']);
const displayName = (user) => String(user?.nome_exibicao || user?.full_name || user?.email || '').trim().toUpperCase();
const parseHistory = (value) => { try { const parsed = JSON.parse(value || '[]'); return Array.isArray(parsed) ? parsed : []; } catch { return []; } };

export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });
    const now = new Date(); const today = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12);
    const [demands, logs, users] = await Promise.all([
      base44.asServiceRole.entities.Demandas.list('-created_date', 2000),
      base44.asServiceRole.entities.LogAutomacoes.filter({ regra: 'Escalonamento de atraso' }, '-data_hora', 5000),
      base44.asServiceRole.entities.User.list('-created_date', 500),
    ]);
    const logged = new Set(logs.map((log) => log.resultado)); const updates = []; const notifications = []; const newLogs = [];
    const managers = users.filter((item) => item.role === 'admin' || ['ADMINISTRADOR', 'GESTOR', 'CEO'].includes(String(item.perfil || '').toUpperCase())).map(displayName).filter(Boolean);
    for (const demand of demands) {
      if (!demand.prazo || terminal.has(demand.status) || demand.arquivada) continue;
      const due = new Date(`${demand.prazo}T12:00:00`); const days = Math.floor((today.getTime() - due.getTime()) / 86400000); if (days <= 0) continue;
      if (demand.status !== 'Atrasado') updates.push({ id: demand.id, status: 'Atrasado', historico: JSON.stringify([...parseHistory(demand.historico), { evento: 'Status → Atrasado por automação', data: now.toISOString(), usuario: 'AUTOMAÇÃO' }]) });
      const stage = days >= 5 ? '5d' : days >= 2 ? '2d' : 'inicio'; const marker = `atraso:${demand.id}:${stage}`; if (logged.has(marker)) continue;
      const recipients = new Set([demand.responsavel, ...(days >= 2 ? managers : [])].filter(Boolean));
      for (const recipient of recipients) notifications.push({ usuario: recipient, titulo: days >= 5 ? 'Tarefa crítica atrasada' : 'Tarefa atrasada', descricao: `${demand.titulo} · ${days} dia(s) de atraso · prazo ${demand.prazo}`, lida: false, data: now.toISOString(), demanda_id: demand.id, link: '/operacoes' });
      newLogs.push({ regra: 'Escalonamento de atraso', modulo: 'Geral', severidade: days >= 5 ? 'Crítica' : days >= 2 ? 'Alta' : 'Média', registro_afetado: demand.id, resultado: marker, mensagem: `${days} dia(s) de atraso; ${recipients.size} destinatário(s) notificado(s)`, usuario: 'AUTOMAÇÃO', data_hora: now.toISOString() });
    }
    if (updates.length) await base44.asServiceRole.entities.Demandas.bulkUpdate(updates);
    if (notifications.length) await base44.asServiceRole.entities.Notificacoes.bulkCreate(notifications);
    if (newLogs.length) await base44.asServiceRole.entities.LogAutomacoes.bulkCreate(newLogs);
    return Response.json({ atualizadas: updates.length, notificacoes: notifications.length, escalonamentos: newLogs.length });
  } catch (error) { return Response.json({ error: error.message }, { status: 500 }); }
}