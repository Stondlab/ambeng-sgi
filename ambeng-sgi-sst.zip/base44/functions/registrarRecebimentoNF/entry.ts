import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { appendHist } from '../../shared/fiscal.ts';

// Registra/estorna recebimento de uma parcela (ParcelasNF).
// Atualiza em cascata: ParcelasNF -> NotasFiscais.status -> Receita vinculada.
// Tudo service role (Receita é admin-only por RLS). Não duplica registros.
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const perfil = user.perfil || (user.role === 'admin' ? 'Administrador' : null);
    if (perfil !== 'Administrador' && perfil !== 'Administrativo') {
      return Response.json({ error: 'Acesso restrito: Administrador ou Administrativo.' }, { status: 403 });
    }

    const body = await req.json();
    const parcela_id = body.parcela_id;
    const acao = body.acao || 'registrar'; // 'registrar' | 'estornar' | 'editar'
    const userNome = body.userNome || (user.full_name || user.email || '—');
    const now = new Date().toISOString();

    if (!parcela_id) return Response.json({ error: 'parcela_id obrigatório.' }, { status: 400 });

    const parcela = await base44.asServiceRole.entities.ParcelasNF.get(parcela_id);
    if (!parcela) return Response.json({ error: 'Parcela não encontrada.' }, { status: 404 });
    const notaId = parcela.nota_fiscal_id;

    let payload: any;
    if (acao === 'estornar') {
      payload = {
        data_recebida: null, forma_recebimento: null, status: 'Previsto',
        observacoes: body.observacao || parcela.observacoes || '',
        historico: appendHist(parcela.historico || '', [{ usuario: userNome, acao: 'Estorno de recebimento' }]),
      };
    } else {
      if (!body.data_recebida || !body.forma_recebimento) {
        return Response.json({ error: 'Informe data e forma de recebimento.' }, { status: 400 });
      }
      payload = {
        data_recebida: body.data_recebida, forma_recebimento: body.forma_recebimento,
        status: 'Recebido',
        observacoes: body.observacao || '',
        historico: appendHist(parcela.historico || '', [{
          usuario: userNome, acao: acao === 'editar' ? 'Recebimento editado' : 'Recebimento registrado',
          campo: 'Recebimento', anterior: parcela.data_recebida || '—', novo: body.data_recebida,
        }]),
      };
    }
    await base44.asServiceRole.entities.ParcelasNF.update(parcela_id, payload);

    // Recalcula status da nota
    const todas = await base44.asServiceRole.entities.ParcelasNF.filter({ nota_fiscal_id: notaId });
    const recebidas = todas.filter((p) => p.status === 'Recebido' || p.data_recebida).length;
    let novoStatusNota = 'Emitida';
    if (recebidas === 0) novoStatusNota = 'Emitida';
    else if (recebidas === todas.length) novoStatusNota = 'Recebida totalmente';
    else novoStatusNota = 'Recebida parcialmente';

    const nota = await base44.asServiceRole.entities.NotasFiscais.get(notaId);
    if (nota && nota.status !== novoStatusNota) {
      await base44.asServiceRole.entities.NotasFiscais.update(notaId, {
        status: novoStatusNota,
        historico: appendHist(nota.historico || '', [{ usuario: userNome, acao: 'Status da nota atualizado',           campo: 'Status', anterior: nota.status, novo: novoStatusNota }]),
      });
    }

    // Atualiza Receita vinculada (Contas a Receber)
    const receitaId = parcela.receita_id || (todas[0] && todas[0].receita_id);
    if (receitaId) {
      const rec = await base44.asServiceRole.entities.Receitas.get(receitaId).catch(() => null);
      if (rec) {
        const tudoRecebido = recebidas === todas.length;
        const recPayload: any = {
          parcela_atual: recebidas,
          status: tudoRecebido ? 'Recebida' : 'Prevista',
        };
        if (tudoRecebido) {
          const ultimaRecebida = todas.filter((p) => p.data_recebida).sort((a, b) => (a.data_recebida < b.data_recebida ? 1 : -1))[0];
          recPayload.data_recebimento = ultimaRecebida?.data_recebida || null;
        } else {
          recPayload.data_recebimento = null;
        }
        recPayload.historico = appendHist(rec.historico || '', [{
          usuario: userNome, acao: acao === 'estornar' ? 'Estorno de recebimento' : 'Recebimento de parcela registrado',
          campo: 'Recebimento', anterior: String(rec.parcela_atual || 0), novo: String(recebidas),
        }]);
        await base44.asServiceRole.entities.Receitas.update(receitaId, recPayload);
      }
    }

    return Response.json({ ok: true, nota_status: novoStatusNota, parcelas_recebidas: recebidas, total_parcelas: todas.length });
  } catch (error) {
    return Response.json({ error: (error as Error).message }, { status: 500 });
  }
}