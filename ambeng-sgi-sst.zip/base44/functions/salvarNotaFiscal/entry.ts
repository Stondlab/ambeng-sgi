import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { calcularImpostos, calcParcelas, addMeses, appendHist, CAMPOS_HIST } from '../../shared/fiscal.ts';

// Salva ou atualiza a Nota Fiscal. Novas notas permanecem pendentes e não geram
// lançamentos financeiros antes da conferência. A integração idempotente é feita
// exclusivamente por conferirNotaFiscal.
export default async function(req: Request): Promise<Response> {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    const perfil = user.perfil || (user.role === 'admin' ? 'Administrador' : null);
    if (perfil !== 'Administrador' && perfil !== 'Administrativo') {
      return Response.json({ error: 'Acesso restrito: Administrador ou Administrativo.' }, { status: 403 });
    }

    const body = await req.json();
    const id = body.id || null;
    const form = body.form || {};
    const userNome = body.userNome || (user.full_name || user.email || '—');
    const isRascunho = !!body.isRascunho;

    // Validação mínima
    if (!form.cliente_id || !form.numero || !form.data_emissao || !form.valor_bruto) {
      return Response.json({ error: 'Preencha cliente, número, emissão e valor.' }, { status: 400 });
    }

    // Dados de apoio
    const [clientesAll, tiposAll, municipiosAll, paramsAll, obrasAll] = await Promise.all([
      base44.asServiceRole.entities.ClientesTomadores.list('razao_social', 500),
      base44.asServiceRole.entities.TiposServico.list('nome', 200),
      base44.asServiceRole.entities.MunicipiosISS.list('municipio', 200),
      base44.asServiceRole.entities.ParametrosFiscais.list('-vigencia_inicio', 200),
      base44.asServiceRole.entities.Obras.list('nome', 500),
    ]);
    const cl = clientesAll.find((c) => c.id === form.cliente_id) || {};
    const ts = tiposAll.find((t) => t.id === form.tipo_servico_id) || {};
    const mu = municipiosAll.find((m) => m.id === form.municipio_id) || {};
    const ob = obrasAll.find((o) => o.id === form.obra_id) || {};

    const valorBruto = Number(form.valor_bruto) || 0;
    const valorMaterial = Number(form.valor_material) || 0;
    const nParc = Math.max(1, parseInt(form.numero_parcelas) || 1);
    const comp = form.competencia || (form.data_emissao ? form.data_emissao.slice(0, 7) : '');
    const imp = calcularImpostos(valorBruto, valorMaterial, ts, mu, paramsAll, {
      iss_retido: !!form.iss_retido, retencao_inss: !!form.retencao_inss,
    });
    const now = new Date().toISOString();

    const baseFields = {
      tipo: form.tipo || 'Emitida', numero: String(form.numero), serie: String(form.serie || '1'),
      data_emissao: form.data_emissao, competencia: comp,
      cliente_id: cl.id || '', cliente_nome: cl.razao_social || '', cliente_cnpj_cpf: cl.cnpj_cpf || '',
      municipio_id: mu.id || '', municipio_execucao: mu.municipio || '', uf_execucao: mu.uf || '',
      tipo_servico_id: ts.id || '', tipo_servico_nome: ts.nome || '', codigo_servico: ts.codigo_servico || '',
      obra_id: ob.id || '', obra_nome: ob.nome || '',
      valor_bruto: valorBruto, valor_material: valorMaterial,
      discriminacao: form.discriminacao || '',
      forma_pagamento: nParc > 1 ? 'Parcelado' : 'À vista', numero_parcelas: nParc,
      data_primeira_parcela: nParc > 1 ? (form.data_primeira_parcela || form.data_emissao) : '',
      observacoes: form.observacoes || '',
      documentos: form.documentos || '',
      ...imp,
    };

    const notasMesmoNumero = await base44.asServiceRole.entities.NotasFiscais.filter({ numero: String(form.numero) });
    const duplicada = notasMesmoNumero.find((nota) => nota.id !== id && String(nota.serie || '1') === String(form.serie || '1') && (nota.cliente_id === cl.id || nota.cliente_cnpj_cpf === cl.cnpj_cpf));
    if (duplicada) return Response.json({ error: 'Já existe uma nota com este número, série e fornecedor/cliente.' }, { status: 409 });

    if (!id) {
      // ===== CRIAÇÃO =====
      const statusInicial = isRascunho ? 'Rascunho' : 'Pendente de conferência';
      const nota = await base44.asServiceRole.entities.NotasFiscais.create({
        ...baseFields,
        status: statusInicial, conferido: false,
        responsavel_lancamento: userNome,
        historico: JSON.stringify([{ usuario: userNome, data_hora: now, acao: isRascunho ? 'Rascunho criado' : 'Lançamento administrativo — pendente de conferência' }]),
      });

      return Response.json({ id: nota.id, parcelas: 0, acao: 'criado', pendente_conferencia: !isRascunho });
    }

    // ===== EDIÇÃO (UPDATE do registro existente) =====
    const existing = await base44.asServiceRole.entities.NotasFiscais.get(id);
    if (!existing) return Response.json({ error: 'Nota não encontrada.' }, { status: 404 });

    // Diff para histórico
    const diffs: any[] = [];
    const novoObj: any = { ...baseFields };
    Object.keys(CAMPOS_HIST).forEach((k) => {
      const ant = (existing as any)[k]; const nv = novoObj[k];
      if (String(ant ?? '') !== String(nv ?? '')) {
        diffs.push({ usuario: userNome, campo: CAMPOS_HIST[k], campoKey: k, anterior: ant ?? '—', novo: nv ?? '—' });
      }
    });

    const histNota = diffs.length
      ? appendHist(existing.historico || '', diffs.map(({ campo, ...x }) => ({ ...x, acao: 'Alteração', campo })))
      : existing.historico || '';

    const updated = await base44.asServiceRole.entities.NotasFiscais.update(id, {
      ...baseFields,
      historico: histNota,
    });

    // Regeneração de parcelas: só se valor/parcelas mudaram E nenhuma recebida.
    const parcelasAtuais = await base44.asServiceRole.entities.ParcelasNF.filter({ nota_fiscal_id: id });
    const algumaRecebida = parcelasAtuais.some((p) => p.status === 'Recebido' || p.data_recebida);
    const valorMudou = Number(existing.valor_bruto) !== valorBruto;
    const parcMudou = Number(existing.numero_parcelas) !== nParc;

    let receitaId = parcelasAtuais[0]?.receita_id || '';
    if ((valorMudou || parcMudou) && !algumaRecebida) {
      // Apaga parcelas antigas e recria (mantém o vínculo com a receita existente).
      if (parcelasAtuais.length) {
        await base44.asServiceRole.entities.ParcelasNF.deleteMany({ nota_fiscal_id: id });
      }
      const baseVenc = form.data_primeira_parcela || form.data_emissao;
      const arr = calcParcelas(valorBruto, nParc);
      const novas = await base44.asServiceRole.entities.ParcelasNF.bulkCreate(arr.map((v, i) => ({
        nota_fiscal_id: id, nota_numero: String(form.numero),
        receita_id: receitaId,
        numero_parcela: i + 1, total_parcelas: nParc, valor: v,
        data_prevista: addMeses(baseVenc, i),
        competencia: addMeses(baseVenc, i).slice(0, 7),
        status: 'Previsto',
        historico: JSON.stringify([{ usuario: userNome, data_hora: now, acao: 'Parcela regenerada na edição' }]),
      })));
      receitaId = receitaId || (novas[0] && novas[0].receita_id) || '';
    }

    // Atualiza a Receita vinculada (se existir)
    const receitas = await base44.asServiceRole.entities.Receitas.filter({ nota_fiscal_id: id });
    if (receitas.length) {
      const rec = receitas[0];
      const baseVenc = form.data_primeira_parcela || form.data_emissao;
      const valorParcela = calcParcelas(valorBruto, nParc)[0];
      const recDiffs: any[] = [];
      const recCampos: Record<string, string> = {
        descricao: 'Descrição', valor: 'Valor total', valor_parcela: 'Valor da parcela',
        total_parcelas: 'Total de parcelas', data_prevista: 'Vencimento', cliente: 'Cliente',
        obra: 'Obra', data_emissao: 'Data de emissão',
      };
      const recNovo: any = {
        descricao: `NF ${form.numero} — ${cl.razao_social || ''}`.trim(),
        valor: valorBruto, valor_parcela: valorParcela, total_parcelas: nParc,
        data_prevista: addMeses(baseVenc, 0), cliente: cl.razao_social || '',
        obra: ob.nome || '', data_emissao: form.data_emissao,
      };
      Object.keys(recCampos).forEach((k) => {
        const ant = rec[k]; const nv = recNovo[k];
        if (String(ant ?? '') !== String(nv ?? '')) recDiffs.push({ usuario: userNome, campo: recCampos[k], anterior: ant ?? '—', novo: nv ?? '—' });
      });
      const recHist = recDiffs.length ? appendHist(rec.historico || '', recDiffs.map((x) => ({ ...x, acao: 'Alteração' }))) : rec.historico || '';
      await base44.asServiceRole.entities.Receitas.update(rec.id, { ...recNovo, historico: recHist });
      receitaId = receitaId || rec.id;
    }

    return Response.json({ id: updated.id, receita_id: receitaId, acao: 'atualizado', parcelas_regeneradas: (valorMudou || parcMudou) && !algumaRecebida });
  } catch (error) {
    return Response.json({ error: (error as Error).message }, { status: 500 });
  }
}