import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { BellRing, AlertOctagon, AlertTriangle, ArrowRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useSstData } from '@/hooks/useSstEntitiesData';
import { alertasSst, alertasRh } from '@/lib/alertas';
import { alertasOrcamento } from '@/lib/orcamento';

const DOT = { red: 'bg-red-500', amber: 'bg-amber-500' };
const HDR = {
  red: { c: 'text-red-700 bg-red-50', Icon: AlertOctagon, l: 'Crítico' },
  amber: { c: 'text-amber-700 bg-amber-50', Icon: AlertTriangle, l: 'Atenção' },
};

export default function CentralAlertas() {
  const data = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis', 'inspecoes', 'ocorrencias', 'dds']);
  const [open, setOpen] = useState(false);
  const [orcamentos, setOrcamentos] = useState([]);
  const [usuarios, setUsuarios] = useState([]);
  useEffect(() => {
    (async () => {
      try { setOrcamentos(await base44.entities.Orcamentos.list('-created_date', 200)); } catch {}
      try { setUsuarios(await base44.entities.User.list()); } catch {}
    })();
  }, []);
  const list = useMemo(() => [...alertasSst(data), ...alertasRh(data), ...alertasOrcamento(orcamentos, usuarios)], [data, orcamentos, usuarios]);
  const groups = ['red', 'amber'].map((t) => ({ tone: t, items: list.filter((p) => p.tone === t) })).filter((g) => g.items.length > 0);
  const criticos = list.filter((p) => p.tone === 'red').length;

  return (
    <div className="relative">
      <button onClick={() => setOpen(true)} className="relative w-10 h-10 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-500 transition-colors" title="Central de Alertas">
        <BellRing className="w-5 h-5" />
        {criticos > 0 && <span className="absolute top-1.5 right-1.5 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-white">{criticos > 9 ? '9+' : criticos}</span>}
      </button>
      <Dialog open={open} onOpenChange={(o) => !o && setOpen(false)}>
        <DialogContent className="max-w-lg p-0 max-h-[80vh] overflow-hidden">
          <DialogHeader className="px-4 py-3 border-b border-slate-100">
            <DialogTitle className="flex items-center gap-2 text-base"><BellRing className="w-4 h-4 text-amber-500" />Central de Alertas — SST + RH</DialogTitle>
          </DialogHeader>
          <div className="overflow-y-auto max-h-[64vh] p-3 space-y-3">
            {groups.length === 0 ? (
              <p className="text-sm text-emerald-700 text-center py-10">Nenhum alerta ativo. Sistema em conformidade.</p>
            ) : groups.map((g) => {
              const h = HDR[g.tone];
              return (
                <div key={g.tone}>
                  <div className={`flex items-center gap-2 rounded-lg px-3 py-2 mb-2 ${h.c}`}>
                    <h.Icon className="w-4 h-4" /><span className="text-sm font-semibold">{h.l}</span>
                    <span className="ml-auto text-xs opacity-70">{g.items.length}</span>
                  </div>
                  <div className="space-y-1.5">
                    {g.items.map((a, i) => {
                      const to = a.funcionario_id ? `/funcionarios/${a.funcionario_id}` : a.link;
                      return (
                        <div key={i} className="flex items-center gap-2 border border-slate-100 rounded-lg p-2">
                          <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${DOT[a.tone]}`} />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-slate-700 truncate">{a.label}</p>
                            <p className="text-xs text-slate-400">{a.detalhe}</p>
                          </div>
                          <Link to={to} onClick={() => setOpen(false)} className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-md bg-[#0b2545] text-white hover:bg-[#0b2545]/90 shrink-0">Abrir <ArrowRight className="w-3 h-3" /></Link>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}