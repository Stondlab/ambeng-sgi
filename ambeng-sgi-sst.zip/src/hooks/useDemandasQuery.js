import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { DEMANDAS_QUERY_KEY, garantirSincronizacaoDashboards } from '@/lib/dashboardQueries';

export default function useDemandasQuery() {
  useEffect(() => garantirSincronizacaoDashboards(), []);
  const query = useQuery({
    queryKey: DEMANDAS_QUERY_KEY,
    queryFn: () => base44.entities.Demandas.list('-created_date', 500),
    staleTime: 30_000,
  });
  return {
    demandas: query.data || [],
    loading: query.isPending,
    refresh: query.refetch,
  };
}