import { useEffect } from 'react';
import { useQueries } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { queryClientInstance } from '@/lib/query-client';
import { sincronizarAutomacoes } from '@/lib/regrasEngine';
import { garantirAssinaturasSst } from '@/lib/sstQuerySync';

const ENTITIES = {
  funcionarios: ['Funcionarios', 'nome'], asos: ['ASOs', '-data_validade'], treinamentos: ['Treinamentos', '-data_validade'],
  epis: ['EPIs', '-data_validade'], ocorrencias: ['Ocorrencias', '-data'], integracoes: ['Integracoes', '-created_date'],
  documentos: ['Documentos', '-created_date'], pendencias: ['Pendencias', '-created_date'], dds: ['DDS', '-data'],
  inspecoes: ['Inspecoes', '-data_proxima'], maquinas: ['Maquinas', '-created_date'], alocacoes: ['Alocacoes', '-data_inicio'], obras: ['Obras', 'nome'],
};
let ultimaSincronizacao = 0;

export function useSstData(keys, sincronizar = false, options = {}) {
  const specs = keys.map((key) => ({ key, entity: ENTITIES[key][0], sort: ENTITIES[key][1], filter: options.filters?.[key], limit: options.limits?.[key] || 500 }));
  const signature = specs.map((s) => `${s.key}:${JSON.stringify(s.filter || {})}:${s.limit}`).join('|');
  const result = useQueries({
    queries: specs.map((spec) => ({
      queryKey: ['sst-entity', spec.entity, spec.filter || null, spec.limit],
      queryFn: () => spec.filter
        ? base44.entities[spec.entity].filter(spec.filter, spec.sort, spec.limit).catch(() => [])
        : base44.entities[spec.entity].list(spec.sort, spec.limit).catch(() => []),
      staleTime: 5 * 60_000,
    })),
    combine: (results) => ({
      data: Object.fromEntries(results.map((query, index) => [specs[index].key, query.data || []])),
      pending: results.some((query) => query.isPending),
      updatedAt: Math.max(0, ...results.map((query) => query.dataUpdatedAt)),
    }),
  });

  useEffect(() => {
    garantirAssinaturasSst(specs.map((spec) => spec.entity));
  }, [signature]);
  useEffect(() => {
    if (sincronizar && !result.pending && result.updatedAt > ultimaSincronizacao) {
      ultimaSincronizacao = result.updatedAt;
      sincronizarAutomacoes(result.data, 'Sistema');
    }
  }, [sincronizar, result]);
  return result.pending ? null : result.data;
}

export function refreshSstData() {
  return queryClientInstance.invalidateQueries({ queryKey: ['sst-entity'] });
}