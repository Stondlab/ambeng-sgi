import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { SAUDE_OBRAS_QUERY_KEY, garantirSincronizacaoDashboards } from '@/lib/dashboardQueries';
import { normalizarDespesa } from '@/lib/financeiro';

const vazio = { obras: [], receitas: [], despesas: [], funcionarios: [], apontamentos: [], ponto: [], vigencias: [], parametros: [], horasExtras: [] };
const listar = (entidade, ordem, limite) => base44.entities[entidade].list(ordem, limite).catch(() => []);

async function carregarSaudeObras() {
  const [obras, receitas, despesas, funcionarios, apontamentos, ponto, vigencias, parametros, horasExtras] = await Promise.all([
    listar('Obras', 'nome', 500), listar('Receitas', '-created_date', 2000), listar('Despesas', '-created_date', 3000),
    listar('Funcionarios', '-created_date', 1000), listar('Apontamentos', '-data', 5000), listar('Ponto', '-data', 5000),
    listar('EncargosVigencias', '-data_inicio', 500), listar('ParametrosCustoMO', 'data_inicio', 500), listar('HorasExtras', '-data', 3000),
  ]);
  return { obras, receitas, despesas: despesas.map(normalizarDespesa), funcionarios, apontamentos, ponto, vigencias, parametros, horasExtras };
}

export default function useSaudeObrasData() {
  useEffect(() => garantirSincronizacaoDashboards(), []);
  const { data, isPending, isFetching } = useQuery({
    queryKey: SAUDE_OBRAS_QUERY_KEY,
    queryFn: carregarSaudeObras,
    staleTime: 60_000,
  });
  return { data: data || vazio, loading: isPending, refreshing: isFetching && !isPending };
}