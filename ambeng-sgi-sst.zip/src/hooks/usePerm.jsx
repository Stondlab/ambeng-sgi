import { usePermissoes } from '@/lib/PermissoesContext';
import { pode } from '@/lib/permissoes';

// Mecanismo central de autorização por módulo. Todas as telas devem usar este hook.
// Consulta a matriz viva (ConfigPermissoes) — a mesma fonte usada por menus, rotas e backend (RLS).
export function usePerm(moduloId) {
  const { perfilEfetivo, simulando } = usePermissoes();
  const perfil = perfilEfetivo;
  // Pré-visualização = somente leitura: nenhum perfil simulado pode criar/editar/excluir dados reais.
  if (!moduloId) return { perfil, simulando, podeVer: !simulando, podeCriar: false, podeEditar: false, podeExcluir: false, readOnly: simulando };
  if (simulando) {
    return {
      perfil,
      simulando,
      podeVer: pode(perfil, moduloId, 'visualizar'),
      podeCriar: false,
      podeEditar: false,
      podeExcluir: false,
      readOnly: true,
    };
  }
  return {
    perfil,
    simulando,
    podeVer: pode(perfil, moduloId, 'visualizar'),
    podeCriar: pode(perfil, moduloId, 'criar'),
    podeEditar: pode(perfil, moduloId, 'editar'),
    podeExcluir: pode(perfil, moduloId, 'excluir'),
    readOnly: !pode(perfil, moduloId, 'editar'),
  };
}