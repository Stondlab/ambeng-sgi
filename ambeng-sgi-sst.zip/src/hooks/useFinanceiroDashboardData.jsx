import { useEffect } from 'react';
import { useQueries } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { normalizarDespesa } from '@/lib/financeiro';
import { garantirSincronizacaoDashboards } from '@/lib/dashboardQueries';

const SOURCES = [{ key: 'receitas', entity: 'Receitas', sort: '-created_date', limit: 2000 }, { key: 'despesas', entity: 'Despesas', sort: '-created_date', limit: 3000 }, { key: 'obras', entity: 'Obras', sort: 'nome', limit: 500 }, { key: 'cartoes', entity: 'Cartoes', sort: '-created_date', limit: 500 }, { key: 'notas', entity: 'NotasFiscais', sort: '-data_emissao', limit: 1000 }, { key: 'parcelas', entity: 'ParcelasNF', sort: '-data_prevista', limit: 3000 }, { key: 'vinculos', entity: 'VinculosFiscais', sort: '-created_date', limit: 1500 }, { key: 'funcionarios', entity: 'Funcionarios', sort: 'nome', limit: 1000 }, { key: 'apontamentos', entity: 'Apontamentos', sort: '-data', limit: 5000 }, { key: 'ponto', entity: 'Ponto', sort: '-data', limit: 5000 }, { key: 'vigencias', entity: 'EncargosVigencias', sort: '-data_inicio', limit: 500 }, { key: 'parametros', entity: 'ParametrosCustoMO', sort: 'data_inicio', limit: 500 }, { key: 'horasExtras', entity: 'HorasExtras', sort: '-data', limit: 3000 }];
export default function useFinanceiroDashboardData() {
  useEffect(() => garantirSincronizacaoDashboards(), []);
  const queries = useQueries({ queries: SOURCES.map((source) => ({ queryKey: ['financeiro-dashboard', source.key], queryFn: () => base44.entities[source.entity].list(source.sort, source.limit).catch(() => []), staleTime: 60000 })) });
  const data = Object.fromEntries(SOURCES.map((source, index) => [source.key, queries[index].data || []]));
  data.despesas = data.despesas.map(normalizarDespesa);
  return { data, loading: queries.some((query) => query.isPending) };
}