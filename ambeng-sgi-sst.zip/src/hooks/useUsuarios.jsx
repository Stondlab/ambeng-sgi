import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';

// Fonte única de usuários para todos os seletores (responsável, membros, solicitante, etc.).
// Carrega via função de backend listarUsuarios (service role) — mesma lista para qualquer
// usuário logado, sem depender de RLS. Sem e-mail exposto.
export function useUsuarios() {
  const [usuarios, setUsuarios] = useState([]);
  useEffect(() => {
    let alive = true;
    base44.functions.invoke('listarUsuarios', {})
      .then((res) => { if (alive) setUsuarios(res.data || []); })
      .catch(() => { if (alive) setUsuarios([]); });
    return () => { alive = false; };
  }, []);
  return usuarios;
}

export default useUsuarios;