import { useQueries } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { normalizarDespesa } from '@/lib/financeiro';

const SOURCES = [
  ['receitas','Receitas',2000], ['despesas','Despesas',3000], ['obras','Obras',500], ['notas','NotasFiscais',1500],
  ['parcelas','ParcelasNF',3000], ['vinculos','VinculosFiscais',1500], ['clientes','ClientesTomadores',1000], ['cartoes','Cartoes',500],
  ['funcionarios','Funcionarios',1000], ['apontamentos','Apontamentos',5000], ['ponto','Ponto',5000],
  ['vigencias','EncargosVigencias',500], ['parametros','ParametrosCustoMO',500], ['horasExtras','HorasExtras',3000],
];
export default function useAuditoriaFinanceira() {
  const queries = useQueries({ queries: SOURCES.map(([key, entity, limit]) => ({ queryKey: ['auditoria-financeira', key], queryFn: () => base44.entities[entity].list('-created_date', limit), staleTime: 30000 })) });
  const data = Object.fromEntries(SOURCES.map(([key], index) => [key, queries[index].data || []]));
  data.despesas = data.despesas.map(normalizarDespesa);
  return { data, loading: queries.some((query) => query.isPending) };
}