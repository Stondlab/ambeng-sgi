import { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';

export default function useResumo360Data(func, fd, podeVerRH) {
  const [extras, setExtras] = useState({ documentos: [], advertencias: [], suspensoes: [], afastamentos: [], ferias: [] });

  useEffect(() => {
    if (!func?.id) return;
    let active = true;
    const load = async (name) => base44.entities[name].filter({ funcionario_id: func.id }, '-created_date', 200).catch(() => []);
    (async () => {
      const documentos = await load('ConformidadeDocumentacao');
      const rh = podeVerRH
        ? await Promise.all(['Advertencias', 'Suspensoes', 'Afastamentos', 'Ferias'].map(load))
        : [[], [], [], []];
      if (active) setExtras({ documentos, advertencias: rh[0], suspensoes: rh[1], afastamentos: rh[2], ferias: rh[3] });
    })();
    return () => { active = false; };
  }, [func?.id, podeVerRH]);

  const events = useMemo(() => {
    if (!func) return [];
    const list = func.data_admissao ? [{ tipo: 'admissao', date: func.data_admissao, label: 'Admissão na empresa' }] : [];
    (fd.asos || []).forEach((a) => list.push({ tipo: 'aso', date: a.data_exame, label: `ASO ${a.tipo || ''}`.trim() }));
    (fd.treinamentos || []).forEach((t) => list.push({ tipo: 'treinamento', date: t.data_realizacao, label: `Treinamento: ${t.norma_curso || t.nome_curso || ''}`.trim() }));
    (fd.epis || []).forEach((e) => list.push({ tipo: 'epi', date: e.data_entrega, label: `Entrega de EPI: ${e.item || ''}`.trim() }));
    extras.advertencias.forEach((a) => list.push({ tipo: 'advertencia', date: a.data, label: `Advertência${a.motivo ? `: ${a.motivo}` : ''}` }));
    extras.suspensoes.forEach((s) => list.push({ tipo: 'suspenso', date: s.data, label: `Suspensão${s.motivo ? `: ${s.motivo}` : ''}` }));
    extras.afastamentos.forEach((a) => list.push({ tipo: 'afastamento', date: a.data_inicio, label: `Afastamento: ${a.tipo || ''}` }));
    extras.ferias.forEach((f) => list.push({ tipo: 'ferias', date: f.inicio, label: 'Férias' }));
    return list;
  }, [func, fd, extras]);

  return { documentos: extras.documentos, events };
}