import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';

const SUB = {
  quadro: 'Quadro de Demandas',
  calendario: 'Calendário SST',
  inteligencia: 'SGI Inteligência',
  asos: 'ASOs',
  almoxarifado: 'Almoxarifado',
  auditoria: 'Auditoria',
};

const ROOT = {
  '': 'Painel',
  funcionarios: 'Funcionários',
  treinamentos: 'Treinamentos',
  epis: 'EPIs',
  ocorrencias: 'Ocorrências',
  formularios: 'Formulários',
  relatorios: 'Relatórios',
  configuracoes: 'Configurações',
};

export default function Breadcrumb() {
  const { pathname } = useLocation();
  const parts = pathname.split('/').filter(Boolean);
  const rootKey = parts[0] || '';
  const rootLabel = ROOT[rootKey] || 'Painel';
  const subKey = parts[1];
  const subLabel = subKey ? SUB[subKey] : null;

  return (
    <nav className="flex items-center gap-1 text-xs text-slate-400 mb-4">
      <Link to="/" className="flex items-center gap-1 hover:text-[#0b2545]"><Home className="w-3.5 h-3.5" />Início</Link>
      <ChevronRight className="w-3.5 h-3.5" />
      {subLabel ? (
        <Link to={`/${rootKey}`} className="hover:text-[#0b2545]">{rootLabel}</Link>
      ) : (
        <span className="text-[#0b2545] font-medium">{rootLabel}</span>
      )}
      {subLabel && (<><ChevronRight className="w-3.5 h-3.5" /><span className="text-[#0b2545] font-medium">{subLabel}</span></>)}
    </nav>
  );
}