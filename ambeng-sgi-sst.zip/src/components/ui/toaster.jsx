import { useToast } from "@/components/ui/use-toast";
import {
  Toast,
  ToastClose,
  ToastDescription,
  ToastProvider,
  ToastTitle,
  ToastViewport,
} from "@/components/ui/toast";
import { CheckCircle2, AlertTriangle, XCircle, Info } from "lucide-react";

const ICONS = {
  success: CheckCircle2,
  warning: AlertTriangle,
  destructive: XCircle,
  default: Info,
};

export function Toaster() {
  const { toasts, dismiss } = useToast();

  return (
    <ToastProvider>
      {toasts.filter((t) => t.open !== false).map(function ({ id, title, description, action, variant = "default", ...props }) {
        const Icon = ICONS[variant] || Info;
        return (
          <Toast key={id} variant={variant} {...props}>
            <div className="flex items-start gap-3 w-full">
              <Icon className="w-5 h-5 shrink-0 mt-0.5" />
              <div className="grid gap-1 flex-1">
                {title && <ToastTitle>{title}</ToastTitle>}
                {description && (
                  <ToastDescription>{description}</ToastDescription>
                )}
              </div>
            </div>
            {action}
            <ToastClose onClick={() => dismiss(id)} />
          </Toast>
        );
      })}
      <ToastViewport />
    </ToastProvider>
  );
}