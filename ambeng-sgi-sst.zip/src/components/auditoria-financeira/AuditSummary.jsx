import React from 'react';
import { fmtMoney } from '@/lib/financeiro';

export default function AuditSummary({ rows }) {
  const financeiros = rows.filter((row) => ['Receitas','Despesas','Recebimentos','Notas fiscais','Vínculos fiscais'].includes(row.origem));
  const problemas = rows.filter((row) => row.situacao !== 'OK');
  const items = [['Registros localizados', rows.length], ['Lançamentos financeiros', financeiros.length], ['Valor financeiro', fmtMoney(financeiros.reduce((sum, row) => sum + row.valor, 0))], ['Situações para análise', problemas.length]];
  return <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{items.map(([label, value]) => <div key={label} className="rounded-xl border bg-card p-4"><p className="text-xs text-muted-foreground">{label}</p><strong className="mt-1 block text-lg">{value}</strong></div>)}</div>;
}