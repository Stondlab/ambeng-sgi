import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function AuditFilters({ filtros, setFiltros }) {
  const field = (key, placeholder, type = 'text') => <Input type={type} value={filtros[key]} placeholder={placeholder} onChange={(e) => setFiltros((old) => ({ ...old, [key]: e.target.value }))} />;
  return <section className="rounded-xl border bg-card p-4"><div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">{field('busca','Busca global')}{field('cliente','Cliente/Fornecedor')}{field('obra','Obra')}{field('id','ID do lançamento')}{field('valor','Valor','number')}{field('documento','Documento')}</div><div className="mt-3 flex justify-end"><Button variant="outline" onClick={() => setFiltros({ busca: '', cliente: '', obra: '', id: '', valor: '', documento: '' })}>Limpar filtros</Button></div></section>;
}