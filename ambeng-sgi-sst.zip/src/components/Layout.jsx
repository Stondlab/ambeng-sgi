import React, { useState, useEffect } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Users, BarChart3, Settings, ShieldAlert,
  LogOut, Menu, X, PanelLeftClose, PanelLeft, ChevronRight, Home,
  Building2, Rocket, Search, ClipboardList, Wallet, Eye,
  Clock, CalendarCheck, ShieldCheck,
  FileText, ArrowDownCircle, ArrowUpCircle, CreditCard, Package,
} from 'lucide-react';
import NotificacoesUnificadas from '@/components/operacoes/NotificacoesUnificadas';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { perfilUsuario, podeAcessar, menuVisivel } from '@/lib/permissoes';
import { usePermissoes } from '@/lib/PermissoesContext';
import { registrarAcao } from '@/lib/historico';
import { nomeUsuario } from '@/lib/usuarioNome';
import Logo from '@/components/Logo';
import ThemeWidget from '@/components/ThemeWidget';

const MENU = [
  { kind: 'item', to: '/', label: 'Painel', icon: LayoutDashboard },
  { kind: 'item', to: '/operacoes', label: 'Operações', icon: Rocket },
  { kind: 'section', label: 'Pessoas', icon: Users, items: [
    { to: '/funcionarios', label: 'Funcionários e Prontuário 360°', icon: Users },
    { to: '/colaboradores/ponto', label: 'Jornada e Ponto', icon: Clock },
    { to: '/rh/fechamento', label: 'Fechamento Mensal', icon: CalendarCheck },
  ] },
  { kind: 'item', to: '/sst', label: 'SST', icon: ShieldCheck },
  { kind: 'section', label: 'Obras', icon: Building2, items: [
    { to: '/obras', label: 'Obras', icon: Building2 },
    { to: '/obras/almoxarifado', label: 'Almoxarifado', icon: Package },
  ] },
  { kind: 'section', label: 'Financeiro', icon: Wallet, items: [
    { to: '/dashboards/financeiro', label: 'Dashboard Financeiro', icon: BarChart3 },
    { to: '/financeiro/receitas', label: 'Receitas', icon: ArrowDownCircle },
    { to: '/financeiro/despesas', label: 'Despesas', icon: ArrowUpCircle },
    { to: '/financeiro/cartoes', label: 'Cartões', icon: CreditCard },
    { to: '/financeiro/fiscal', label: 'Notas Fiscais', icon: FileText },
  ] },
  { kind: 'item', to: '/configuracoes', label: 'Configurações', icon: Settings },
];

const BOTTOM = [
  { to: '/', label: 'Painel', icon: LayoutDashboard },
  { to: '/operacoes', label: 'Operações', icon: Rocket },
  { to: '/sst', label: 'SST', icon: ShieldCheck },
  { to: '/funcionarios', label: 'RH', icon: Users },
];

function routeActive(to, pathname, search = '', hash = '') {
  const [beforeHash, targetHash = ''] = to.split('#');
  const [targetPath, targetQuery = ''] = beforeHash.split('?');
  if (targetHash) return pathname === targetPath && hash === `#${targetHash}`;
  if (targetQuery) return pathname === targetPath && search === `?${targetQuery}`;
  if (hash && pathname === targetPath) return false;
  return targetPath === '/' ? pathname === '/' : pathname === targetPath || pathname.startsWith(`${targetPath}/`);
}

const SECTION_LABEL = {
  '': 'Painel',
  painel: 'Central de Operações',
  dashboards: 'Dashboards',
  sst: 'Saúde e Segurança no Trabalho',
  'saude-obras': 'Saúde das Obras',
  inteligencia: 'Inteligência',
  funcionarios: 'RH',
  colaboradores: 'RH',
  rh: 'RH',
  obras: 'Obras',
  financeiro: 'Financeiro',
  treinamentos: 'Treinamentos',
  epis: 'EPIs',
  ocorrencias: 'Ocorrências',
  inspecoes: 'Inspeções',
  formularios: 'Formulários',
  relatorios: 'Relatórios',
  configuracoes: 'Configurações',
  asos: 'ASOs',
  auditoria: 'Auditoria',
};

function NavItem({ item, pathname, collapsed, onNavigate, search, hash, isPrimary = false }) {
  const Icon = item.icon;
  const itemPath = item.to.split(/[?#]/)[0];
  const hasChildren = item.children?.length;
  const childActive = hasChildren && item.children.some(
    (c) => pathname === c.to.split('?')[0] || pathname.startsWith(c.to.split('?')[0] + '/')
  );
  const active = routeActive(item.to, pathname, search, hash) || childActive;
  const [open, setOpen] = useState(childActive);

  useEffect(() => {
    if (childActive) setOpen(true);
  }, [childActive]);

  const visibleChildren = item.children || [];
  const groupTo = item.to;

  const baseLink = (extra) => `relative flex items-center gap-3 ${isPrimary && !collapsed ? 'min-h-[48px]' : 'min-h-[40px]'} rounded-md transition-colors ${collapsed ? 'justify-center px-2' : 'px-3'} ${active ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-muted hover:text-foreground'} ${extra || ''}`;
  const indicator = null;

  if (hasChildren && !collapsed && visibleChildren.length > 0) {
    return (
      <div>
        <div className="flex items-center gap-1">
          <Link to={groupTo} onClick={onNavigate} className={baseLink('flex-1')}>
            {indicator}
            <Icon className={`h-6 w-6 shrink-0 ${active ? 'text-primary' : ''}`} />
            <span className="text-sm font-medium">{item.label}</span>
          </Link>
          <button
            onClick={() => setOpen((o) => !o)}
            className="flex min-h-9 min-w-9 items-center justify-center rounded-md p-2 text-muted-foreground hover:bg-muted hover:text-foreground"
            title={open ? 'Recolher' : 'Expandir'}
          >
            <ChevronRight className={`w-4 h-4 transition-transform ${open ? 'rotate-90' : ''}`} />
          </button>
        </div>
        {open && (
          <div className="ml-4 mt-1 space-y-2 border-l border-border pl-3">
            {item.groups ? (
              item.groups.map((g) => {
                const gItems = g.tos.map((to) => visibleChildren.find((c) => c.to === to)).filter(Boolean);
                if (!gItems.length) return null;
                return (
                  <div key={g.label} className="space-y-0.5">
                    <div className="px-3 pt-1 pb-0.5 text-[10px] font-semibold tracking-wider text-white/35">{g.label}</div>
                    {gItems.map((c) => {
                      const cActive = pathname === c.to || pathname.startsWith(c.to + '/');
                      const CIcon = c.icon;
                      return (
                        <Link
                          key={c.to}
                          to={c.to}
                          onClick={onNavigate}
                          className={`flex items-center gap-2 min-h-[40px] rounded-lg px-3 text-sm transition-colors ${cActive ? 'bg-primary/10 text-primary font-semibold' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}
                        >
                          {CIcon ? <CIcon className="w-4 h-4 shrink-0 opacity-70" /> : <span className={`w-1.5 h-1.5 rounded-full ${cActive ? 'bg-success' : 'bg-current opacity-40'}`} />}
                          {c.label}
                        </Link>
                      );
                    })}
                  </div>
                );
              })
            ) : (
              visibleChildren.map((c) => {
                const cActive = pathname === c.to || pathname.startsWith(c.to + '/');
                const CIcon = c.icon;
                return (
                  <Link
                    key={c.to}
                    to={c.to}
                    onClick={onNavigate}
                    className={`flex items-center gap-2 min-h-[40px] rounded-lg px-3 text-sm transition-colors ${cActive ? 'bg-primary/10 text-primary font-semibold' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}
                  >
                    {CIcon ? <CIcon className="w-4 h-4 shrink-0 opacity-70" /> : <span className={`w-1.5 h-1.5 rounded-full ${cActive ? 'bg-success' : 'bg-current opacity-40'}`} />}
                    {c.label}
                  </Link>
                );
              })
            )}
          </div>
        )}
      </div>
    );
  }

  return (
    <Link
      to={groupTo}
      onClick={onNavigate}
      title={collapsed ? item.label : undefined}
      className={baseLink(collapsed && active ? 'bg-white/10' : '')}
    >
      {indicator}
      <Icon className="h-6 w-6 shrink-0" />
      {!collapsed && <span className={isPrimary ? 'flex-1 whitespace-normal text-left text-base font-semibold leading-[22px]' : 'text-[15px] font-medium leading-[21px]'}>{item.label}</span>}
    </Link>
  );
}

function SectionGroup({ section, expanded, onToggle, pathname, search, hash, onNavigate }) {
  const SIcon = section.icon;
  const active = section.items.some((item) => routeActive(item.to, pathname, search, hash));
  return <div>
    <button onClick={onToggle} className={`flex min-h-12 w-full items-center gap-3 rounded-md px-3 transition-colors ${expanded ? 'bg-muted/60' : 'hover:bg-muted'} ${active ? 'text-primary' : 'text-foreground'}`}>
      {SIcon && <SIcon className="h-6 w-6 shrink-0" />}
      <span className="flex-1 text-left text-base font-semibold">{section.label}</span>
      <ChevronRight className={`h-4 w-4 transition-transform ${expanded ? 'rotate-90' : ''}`} />
    </button>
    {expanded && <div className="ml-5 mt-1 space-y-0.5 border-l border-border pl-2">
      {section.items.map((item) => <NavItem key={item.to} item={item} pathname={pathname} search={search} hash={hash} collapsed={false} onNavigate={onNavigate} />)}
    </div>}
  </div>;
}

export default function Layout() {
  const { pathname, search, hash } = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [expanded, setExpanded] = useState(() => {
    const active = MENU.find((e) => e.kind === 'section' && e.items.some((it) => pathname === it.to || (it.to !== '/' && pathname.startsWith(it.to + '/'))));
    return active ? new Set([active.label]) : new Set();
  });
  useEffect(() => {
    const active = MENU.find((e) => e.kind === 'section' && e.items.some((it) => pathname === it.to || (it.to !== '/' && pathname.startsWith(it.to + '/'))));
    if (active) setExpanded((prev) => (prev.has(active.label) ? prev : new Set(prev).add(active.label)));
  }, [pathname]);
  const toggleSection = (label) => setExpanded((prev) => { const n = new Set(prev); n.has(label) ? n.delete(label) : n.add(label); return n; });

  const { perfilEfetivo, simulando, limparSimulacao, perfilPreviewLabel } = usePermissoes();
  const perfil = perfilEfetivo || perfilUsuario(user);
  const permitido = podeAcessar(perfil, pathname);
  const menuEntries = MENU.map((entry) => entry.kind === 'section'
    ? { ...entry, items: entry.items.filter((item) => menuVisivel(perfil, item.to)) }
    : entry
  ).filter((entry) => entry.kind === 'section' ? entry.items.length > 0 : menuVisivel(perfil, entry.to));
  const initials = nomeUsuario(user).split(' ').map((s) => s[0]).filter(Boolean).slice(0, 2).join('') || '?';

  useEffect(() => {
    if (user?.id) {
      registrarAcao('Entrou no sistema', '', user);
      base44.auth.updateMe({ ultimo_acesso: new Date().toISOString() }).catch(() => {});
    }
  }, [user?.id]);

  useEffect(() => {
    if (user && !permitido) {
      const destino = perfil === 'Técnico' ? '/sst' : '/';
      const t = setTimeout(() => navigate(destino, { replace: true }), 2200);
      return () => clearTimeout(t);
    }
  }, [user, permitido, pathname, navigate]);

  const sectionKey = pathname.split('/')[1] || '';
  const sectionLabel = SECTION_LABEL[sectionKey] || 'Painel';

  const bottomItems = BOTTOM.filter((item) => menuVisivel(perfil, item.to));
  const isActiveBottom = (to) => (to === '/' ? pathname === '/' : pathname === to || pathname.startsWith(to + '/'));

  return (
    <div className="min-h-screen bg-background font-body">
      {/* Desktop sidebar */}
      <aside
        className={`hidden lg:flex flex-col fixed inset-y-0 left-0 z-40 bg-sidebar border-r border-sidebar-border transition-all duration-300 ${collapsed ? 'w-20' : 'w-[280px]'}`}
      >
        <div className="h-16 flex items-center justify-between px-4 border-b border-border">
          <Logo collapsed={collapsed} tone="dark" />
          <button
            onClick={() => setCollapsed((c) => !c)}
            className="flex min-h-10 min-w-10 items-center justify-center rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            title={collapsed ? 'Expandir' : 'Recolher'}
          >
            {collapsed ? <PanelLeft className="w-5 h-5" /> : <PanelLeftClose className="w-5 h-5" />}
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto py-3 px-2.5 space-y-0.5">
          {collapsed ? (
            menuEntries.flatMap((e) => (e.kind === 'item' ? [e] : e.items)).map((item) => (
              <NavItem key={item.to} item={item} pathname={pathname} search={search} hash={hash} collapsed={collapsed} isPrimary />
            ))
          ) : (
            menuEntries.map((entry) =>
              entry.kind === 'item' ? (
                <NavItem key={entry.to} item={entry} pathname={pathname} search={search} hash={hash} collapsed={false} isPrimary />
              ) : (
                <SectionGroup key={entry.label} section={entry} expanded={expanded.has(entry.label)} onToggle={() => toggleSection(entry.label)} pathname={pathname} search={search} hash={hash} />
              )
            )
          )}
        </nav>
        <div className="border-t border-border p-2.5">
          <div className={`flex items-center gap-3 rounded-lg p-2 ${collapsed ? 'justify-center' : ''}`}>
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">{initials}</div>
            {!collapsed && <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-foreground">{nomeUsuario(user)}</p><p className="truncate text-xs text-muted-foreground">{perfil}</p></div>}
            {!collapsed && <button onClick={() => base44.auth.logout()} className="flex min-h-10 min-w-10 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground" title="Sair"><LogOut className="h-5 w-5" /></button>}
          </div>
        </div>
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 bg-sidebar text-sidebar-foreground flex flex-col animate-slide-in">
            <div className="h-16 flex items-center justify-between px-4 border-b border-border">
              <Logo onClick={() => setMobileOpen(false)} tone="dark" />
              <button onClick={() => setMobileOpen(false)} className="flex min-h-10 min-w-10 items-center justify-center p-2 text-muted-foreground hover:text-foreground">
                <X className="w-6 h-6" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto py-3 px-2.5 space-y-0.5">
              {MENU.map((entry) =>
                entry.kind === 'item' ? (
                  <NavItem key={entry.to} item={entry} pathname={pathname} search={search} hash={hash} collapsed={false} onNavigate={() => setMobileOpen(false)} isPrimary />
                ) : (
                  <SectionGroup key={entry.label} section={entry} expanded={expanded.has(entry.label)} onToggle={() => toggleSection(entry.label)} pathname={pathname} search={search} hash={hash} onNavigate={() => setMobileOpen(false)} />
                )
              )}
            </nav>
            <div className="border-t border-border p-2.5"><div className="flex items-center gap-3 p-2"><div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">{initials}</div><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-foreground">{nomeUsuario(user)}</p><p className="text-xs text-muted-foreground">{perfil}</p></div><button onClick={() => base44.auth.logout()} className="flex min-h-10 min-w-10 items-center justify-center rounded-md text-muted-foreground hover:bg-muted" title="Sair"><LogOut className="h-5 w-5" /></button></div></div>
          </aside>
        </div>
      )}

      {/* Main column */}
      <div className={`lg:transition-all lg:duration-300 ${collapsed ? 'lg:pl-20' : 'lg:pl-[280px]'}`}>
        <header className="sticky top-0 z-30 border-b border-border bg-card/85 backdrop-blur">
          <div className="h-16 px-4 flex items-center gap-3">
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden text-slate-600 p-2 -ml-2 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg hover:bg-slate-100"
            >
              <Menu className="w-6 h-6" />
            </button>

            <div className="lg:hidden">
              <Logo size={32} variant="icon" />
            </div>

            <nav className="hidden lg:flex items-center gap-1.5 text-sm text-slate-500">
              <Home className="w-3.5 h-3.5" />
              <ChevronRight className="w-3.5 h-3.5 text-slate-300" />
              <span className="font-medium text-foreground truncate max-w-[220px]">{sectionLabel}</span>
            </nav>

            <div className="flex-1 max-w-md mx-auto hidden sm:block">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                <input
                  className="w-full h-10 rounded-lg bg-muted/70 border border-transparent pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:bg-card focus:border-primary/30 focus:outline-none focus:ring-2 focus:ring-primary/10 transition"
                  placeholder="Buscar no sistema..."
                />
              </div>
            </div>

            <div className="flex items-center gap-1 ml-auto">
              <NotificacoesUnificadas user={user} />
              <ThemeWidget />
              <div className="ml-1 flex items-center gap-2 border-l border-border pl-2">
                <div className="w-9 h-9 rounded-full bg-primary text-white flex items-center justify-center text-xs font-heading font-semibold shrink-0">
                  {initials || '?'}
                </div>
                <div className="hidden md:flex flex-col leading-tight">
                  <span className="text-sm font-medium text-foreground truncate max-w-[150px]">{nomeUsuario(user)}</span>
                  <span className="text-[11px] text-slate-400">{perfil}</span>
                </div>
                <button
                  onClick={() => base44.auth.logout()}
                  className="flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted"
                  title="Sair"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </header>

        {simulando && (
          <div className="sticky top-16 z-30 bg-amber-400/95 backdrop-blur border-b border-amber-500/40 px-4 py-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex flex-col">
              <div className="flex items-center gap-2 text-[#0b2545] text-sm font-semibold">
                <Eye className="w-4 h-4" />PRÉ-VISUALIZAÇÃO DO PERFIL: {perfilPreviewLabel || perfil}
              </div>
              <span className="text-[11px] text-[#0b2545]/80">Você está visualizando o sistema exatamente como este perfil.</span>
            </div>
            <button
              onClick={limparSimulacao}
              className="text-xs font-semibold bg-[#0b2545] text-white px-3 py-1.5 rounded-lg hover:bg-[#0b2545]/90 min-h-[36px] shrink-0"
            >
              Sair da pré-visualização
            </button>
          </div>
        )}

        <main className="px-4 py-5 pb-24 lg:pb-10 max-w-6xl mx-auto">
          {user && !permitido ? (
            <div className="flex flex-col items-center justify-center text-center py-24 animate-fade-in">
              <ShieldAlert className="w-12 h-12 text-destructive mb-4" />
              <h2 className="text-xl font-heading font-semibold text-primary">Acesso não autorizado</h2>
              <p className="text-sm text-slate-500 mt-2">Seu perfil não tem permissão para acessar esta página. Retornando ao Painel...</p>
            </div>
          ) : (
            <Outlet />
          )}
        </main>
      </div>

      {/* Mobile bottom nav */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-card border-t border-border flex">
        {bottomItems.map((item) => {
          const active = isActiveBottom(item.to);
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={`flex-1 flex flex-col items-center justify-center gap-0.5 py-2 min-h-[60px] transition-colors ${active ? 'text-primary' : 'text-muted-foreground'}`}
            >
              <Icon className="w-6 h-6" />
              <span className={`text-[11px] ${active ? 'font-semibold' : ''}`}>{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}