import React from 'react';
import { Link } from 'react-router-dom';

const GROUPS = [
  { id: 'visao', label: 'Visão Geral', first: 'visao', tabs: [{ id: 'visao', label: 'Resumo executivo' }, { id: 'pendencias', label: 'Alertas e próximos passos' }] },
  { id: 'equipe', label: 'Equipe & Operação', first: 'colaboradores', tabs: [{ id: 'colaboradores', label: 'Funcionários alocados' }, { label: 'Apontamentos diários', to: '/rh/apontamento' }, { id: 'tarefas', label: 'Tarefas' }] },
  { id: 'seguranca', label: 'Segurança', first: 'asos', tabs: [{ id: 'asos', label: 'ASOs' }, { id: 'treinamentos', label: 'Treinamentos' }, { id: 'epis', label: 'EPIs' }, { id: 'ocorrencias', label: 'Ocorrências' }, { id: 'inspecoes', label: 'Inspeções' }, { id: 'dds', label: 'DDS' }, { id: 'aprs', label: 'APRs' }] },
  { id: 'financeiro', label: 'Financeiro', first: 'custo', tabs: [{ label: 'Receitas', to: '/financeiro/receitas' }, { label: 'Despesas', to: '/financeiro/despesas' }, { id: 'custo', label: 'Composição do Custo' }] },
  { id: 'documentos', label: 'Documentos', first: 'documentos', tabs: [{ id: 'documentos', label: 'Arquivos/Upload' }, { label: 'Auditoria', to: '/relatorios/auditoria' }, { id: 'relatorios', label: 'Relatórios' }] },
];

const itemClass = 'inline-flex min-h-11 shrink-0 items-center rounded-lg px-3 text-sm font-medium transition-colors';

export default function ObraSectionNav({ section, tab, onSection, onTab }) {
  const current = GROUPS.find((group) => group.id === section) || GROUPS[0];
  return <div className="mb-4 space-y-3">
    <div className="grid grid-cols-2 gap-2 rounded-xl border border-border bg-card p-2 md:grid-cols-5">
      {GROUPS.map((group) => <button key={group.id} onClick={() => { onSection(group.id); onTab(group.first); }} className={`${itemClass} justify-center text-xs uppercase tracking-wide ${section === group.id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}>{group.label}</button>)}
    </div>
    <div className="flex gap-1 overflow-x-auto border-b border-border pb-px">
      {current.tabs.map((item) => item.to
        ? <Link key={item.label} to={item.to} className={`${itemClass} text-muted-foreground hover:bg-muted hover:text-foreground`}>{item.label}</Link>
        : <button key={item.id} onClick={() => onTab(item.id)} className={`${itemClass} border-b-2 ${tab === item.id ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>{item.label}</button>)}
    </div>
  </div>;
}