import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, Pencil } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { fmt } from '@/lib/sst';
import { isAtrasada } from '@/lib/acoes';

const STATUS = ['Novo', 'A Fazer', 'Em Andamento', 'Aguardando', 'Concluído', 'Cancelado', 'Atrasado', 'Solicitado'];
const PRIO = ['Baixa', 'Média', 'Alta', 'Crítica'];
const empty = { titulo: '', descricao: '', prioridade: 'Média', prazo: '', status: 'A Fazer', responsavel: '' };

export default function ObraTarefas({ nome, L, onRefresh, podeEditar, podeExcluir }) {
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState(empty);

  const abrirNovo = () => { setEditId(null); setForm(empty); setOpen(true); };
  const abrirEdit = (d) => { setEditId(d.id); setForm({ titulo: d.titulo, descricao: d.descricao || '', prioridade: d.prioridade || 'Média', prazo: d.prazo || '', status: d.status || 'A Fazer', responsavel: d.responsavel || '' }); setOpen(true); };
  const salvar = async () => {
    if (!form.titulo?.trim()) return;
    const payload = { ...form, obra: nome, origem: 'Manual' };
    if (editId) await base44.entities.Demandas.update(editId, payload);
    else await base44.entities.Demandas.create(payload);
    setOpen(false); onRefresh?.();
  };
  const excluir = async (id) => { if (!confirm('Excluir esta tarefa?')) return; await base44.entities.Demandas.delete(id); onRefresh?.(); };
  const mudarStatus = async (id, status) => { await base44.entities.Demandas.update(id, { status }); onRefresh?.(); };

  const rows = L.demandas;

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        {podeEditar && <Button onClick={abrirNovo}><Plus className="w-4 h-4" /> Nova tarefa</Button>}
        <span className="text-xs text-slate-400 ml-auto">{rows.length} tarefa(s) · {rows.filter((d) => isAtrasada(d)).length} atrasada(s)</span>
      </div>

      {rows.length === 0 ? (
        <p className="text-sm text-slate-400 py-6">Nenhuma tarefa vinculada a esta obra.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs uppercase text-slate-500 border-b border-slate-100">
              <tr>
                <th className="px-3 py-2 text-left font-semibold">Tarefa</th>
                <th className="px-3 py-2 text-left font-semibold">Responsável</th>
                <th className="px-3 py-2 text-left font-semibold">Prazo</th>
                <th className="px-3 py-2 text-left font-semibold">Prioridade</th>
                <th className="px-3 py-2 text-left font-semibold">Status</th>
                <th className="px-3 py-2 text-right font-semibold">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map((d) => (
                <tr key={d.id} className="hover:bg-slate-50/60">
                  <td className="px-3 py-2.5 font-medium text-[#0b2545]">{d.titulo}</td>
                  <td className="px-3 py-2.5">{d.responsavel || '—'}</td>
                  <td className="px-3 py-2.5">{fmt(d.prazo)}{isAtrasada(d) && <span className="text-[11px] text-red-600 ml-1">atrasada</span>}</td>
                  <td className="px-3 py-2.5">{d.prioridade || '—'}</td>
                  <td className="px-3 py-2.5">
                    {podeEditar ? (
                      <select value={d.status || 'A Fazer'} onChange={(e) => mudarStatus(d.id, e.target.value)} className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs">
                        {STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
                      </select>
                    ) : (d.status || '—')}
                  </td>
                  <td className="px-3 py-2.5 text-right whitespace-nowrap">
                    {podeEditar && <button onClick={() => abrirEdit(d)} className="text-xs text-slate-500 hover:text-[#0b2545] mr-2"><Pencil className="w-3.5 h-3.5 inline" /></button>}
                    {podeExcluir && <button onClick={() => excluir(d.id)} className="text-xs text-red-500 hover:text-red-700"><Trash2 className="w-3.5 h-3.5 inline" /></button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editId ? 'Editar tarefa' : 'Nova tarefa'}</DialogTitle></DialogHeader>
          <div className="grid gap-3 py-2">
            <div><Label>Título *</Label><Input value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })} /></div>
            <div><Label>Descrição</Label><Textarea value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} rows={2} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Responsável</Label><Input value={form.responsavel} onChange={(e) => setForm({ ...form, responsavel: e.target.value })} /></div>
              <div><Label>Prazo</Label><Input type="date" value={form.prazo || ''} onChange={(e) => setForm({ ...form, prazo: e.target.value })} /></div>
              <div><Label>Prioridade</Label>
                <Select value={form.prioridade} onValueChange={(v) => setForm({ ...form, prioridade: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PRIO.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Status</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{STATUS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button onClick={salvar} disabled={!form.titulo?.trim()}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}