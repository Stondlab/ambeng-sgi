import React from 'react';
import ObraCrudTab from './ObraCrudTab';
import { getStatus, fmt } from '@/lib/sst';

const fields = [
  { key: 'funcionario_id', label: 'Colaborador', type: 'funcionario', required: true, full: true },
  { key: 'nome_curso', label: 'Curso', full: true },
  { key: 'norma_curso', label: 'Norma' },
  { key: 'instrutor', label: 'Instrutor' },
  { key: 'empresa', label: 'Empresa' },
  { key: 'carga_horaria', label: 'Carga horária', type: 'number' },
  { key: 'data_realizacao', label: 'Realização', type: 'date' },
  { key: 'data_validade', label: 'Validade', type: 'date', required: true },
  { key: 'certificado_url', label: 'Certificado (URL)', full: true },
];
const defaultForm = { funcionario_id: '', nome_curso: '', norma_curso: '', instrutor: '', empresa: '', carga_horaria: 0, data_realizacao: '', data_validade: '', certificado_url: '' };

export default function ObraTreinamentos({ L, data, onRefresh, podeEditar, podeExcluir }) {
  const funcById = Object.fromEntries((data?.funcionarios || []).map((f) => [f.id, f]));
  const columns = [
    { key: 'f', label: 'Colaborador', value: (r) => funcById[r.funcionario_id]?.nome || '—' },
    { key: 'c', label: 'Curso', value: (r) => r.nome_curso || r.norma_curso || '—' },
    { key: 'v', label: 'Validade', value: (r) => fmt(r.data_validade) },
    { key: 's', label: 'Status', render: (r) => <span className="text-xs">{getStatus(r.data_validade)}</span> },
  ];
  return <ObraCrudTab entity="Treinamentos" label="Treinamento" rows={L.treinamentos} columns={columns} fields={fields} defaultForm={defaultForm} data={data} L={L} onRefresh={onRefresh} podeEditar={podeEditar} podeExcluir={podeExcluir} />;
}