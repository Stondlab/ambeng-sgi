import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { UserPlus, UserMinus, Pencil, ArrowRight } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { fmt } from '@/lib/sst';

export default function ObraColaboradores({ nome, L, data, onRefresh, podeEditar }) {
  const [busca, setBusca] = useState('');
  const [addOpen, setAddOpen] = useState(false);
  const [addId, setAddId] = useState('');
  const [editId, setEditId] = useState(null);
  const [edit, setEdit] = useState({});

  const todos = data?.funcionarios || [];
  const naObraIds = new Set(L.funcs.map((f) => f.id));
  const disponiveis = todos.filter((f) => !naObraIds.has(f.id) && (f.nome || '').toLowerCase().includes(busca.toLowerCase()));
  const rows = L.funcs.filter((f) => (f.nome || '').toLowerCase().includes(busca.toLowerCase()));

  const adicionar = async () => {
    if (!addId) return;
    await base44.entities.Funcionarios.update(addId, { obra: nome });
    setAddId(''); setAddOpen(false); onRefresh?.();
  };
  const remover = async (id) => {
    if (!confirm('Remover o colaborador desta obra? O cadastro geral será mantido.')) return;
    await base44.entities.Funcionarios.update(id, { obra: '' });
    onRefresh?.();
  };
  const abrirEdit = (f) => { setEditId(f.id); setEdit({ funcao: f.funcao || '', supervisor: f.supervisor || '', data_admissao: f.data_admissao || '' }); };
  const salvarEdit = async () => {
    await base44.entities.Funcionarios.update(editId, { funcao: edit.funcao, supervisor: edit.supervisor, data_admissao: edit.data_admissao });
    setEditId(null); onRefresh?.();
  };

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <Input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar colaborador..." className="max-w-xs" />
        {podeEditar && <Button onClick={() => setAddOpen(true)}><UserPlus className="w-4 h-4" /> Adicionar colaborador</Button>}
        <span className="text-xs text-slate-400 ml-auto">{L.funcs.length} vinculado(s)</span>
      </div>

      {rows.length === 0 ? (
        <p className="text-sm text-slate-400 py-6">Nenhum colaborador vinculado a esta obra.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs uppercase text-slate-500 border-b border-slate-100">
              <tr>
                <th className="px-3 py-2 text-left font-semibold">Colaborador</th>
                <th className="px-3 py-2 text-left font-semibold">Função</th>
                <th className="px-3 py-2 text-left font-semibold">Supervisor</th>
                <th className="px-3 py-2 text-left font-semibold">Entrada</th>
                <th className="px-3 py-2 text-left font-semibold">Status</th>
                <th className="px-3 py-2 text-right font-semibold">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map((f) => (
                <tr key={f.id} className="hover:bg-slate-50/60">
                  <td className="px-3 py-2.5 font-medium text-[#0b2545]">{f.nome}</td>
                  <td className="px-3 py-2.5">{f.funcao || '—'}</td>
                  <td className="px-3 py-2.5">{f.supervisor || '—'}</td>
                  <td className="px-3 py-2.5">{fmt(f.data_admissao)}</td>
                  <td className="px-3 py-2.5">{f.status || '—'}</td>
                  <td className="px-3 py-2.5 text-right whitespace-nowrap">
                    <Link to={`/funcionarios/${f.id}`} className="text-xs font-semibold text-[#0b2545] hover:underline inline-flex items-center gap-1 mr-2">Ver <ArrowRight className="w-3 h-3" /></Link>
                    {podeEditar && <>
                      <button onClick={() => abrirEdit(f)} className="text-xs text-slate-500 hover:text-[#0b2545] mr-2"><Pencil className="w-3.5 h-3.5 inline" /></button>
                      <button onClick={() => remover(f.id)} className="text-xs text-red-500 hover:text-red-700"><UserMinus className="w-3.5 h-3.5 inline" /></button>
                    </>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Adicionar colaborador à obra</DialogTitle></DialogHeader>
          <div className="py-2 space-y-3">
            <Input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar colaborador..." />
            <div className="max-h-64 overflow-y-auto border border-slate-200 rounded-lg divide-y divide-slate-100">
              {disponiveis.length === 0 ? <p className="text-sm text-slate-400 p-3">Nenhum colaborador disponível.</p> :
                disponiveis.slice(0, 60).map((f) => (
                  <button key={f.id} onClick={() => setAddId(f.id)} className={`w-full text-left px-3 py-2 text-sm hover:bg-slate-50 ${addId === f.id ? 'bg-[#0b2545]/5 font-medium' : ''}`}>
                    {f.nome} <span className="text-xs text-slate-400">· {f.funcao || '—'} · {f.empresa || '—'}</span>
                  </button>
                ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>Cancelar</Button>
            <Button onClick={adicionar} disabled={!addId}>Vincular</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!editId} onOpenChange={(o) => !o && setEditId(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Editar vínculo</DialogTitle></DialogHeader>
          <div className="grid gap-3 py-2">
            <div><Label>Função</Label><Input value={edit.funcao || ''} onChange={(e) => setEdit({ ...edit, funcao: e.target.value })} /></div>
            <div><Label>Supervisor / Responsável</Label><Input value={edit.supervisor || ''} onChange={(e) => setEdit({ ...edit, supervisor: e.target.value })} /></div>
            <div><Label>Data de entrada</Label><Input type="date" value={edit.data_admissao || ''} onChange={(e) => setEdit({ ...edit, data_admissao: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditId(null)}>Cancelar</Button>
            <Button onClick={salvarEdit}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}