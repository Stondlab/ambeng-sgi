import React from 'react';
import ObraCrudTab from './ObraCrudTab';
import { fmt } from '@/lib/sst';

const TIPOS = ['Inspeção de Segurança', 'Inspeção de Máquina', 'Inspeção de Equipamento', 'Inspeção de Rotina'];
const STATUS = ['Conforme', 'Não Conforme', 'Pendente'];

const fields = [
  { key: 'tipo', label: 'Tipo', type: 'select', required: true, options: TIPOS, full: true },
  { key: 'data', label: 'Data', type: 'date' },
  { key: 'data_proxima', label: 'Próxima inspeção', type: 'date', required: true },
  { key: 'responsavel', label: 'Responsável' },
  { key: 'status', label: 'Status', type: 'select', options: STATUS },
  { key: 'funcionario_id', label: 'Colaborador (opcional)', type: 'funcionario', full: true },
  { key: 'observacao', label: 'Observação', type: 'textarea', full: true },
];
const defaultForm = { tipo: 'Inspeção de Segurança', data: '', data_proxima: '', responsavel: '', status: 'Pendente', funcionario_id: '', observacao: '' };

export default function ObraInspecoes({ L, nome, data, onRefresh, podeEditar, podeExcluir }) {
  const columns = [
    { key: 't', label: 'Tipo', value: (r) => r.tipo || '—' },
    { key: 'r', label: 'Responsável', value: (r) => r.responsavel || '—' },
    { key: 'p', label: 'Próxima', value: (r) => fmt(r.data_proxima) },
    { key: 's', label: 'Status', render: (r) => <span className="text-xs">{r.status}</span> },
  ];
  return <ObraCrudTab entity="Inspecoes" label="Inspeção" rows={L.inspecoes} columns={columns} fields={fields} defaultForm={defaultForm} data={data} L={L} onRefresh={onRefresh} podeEditar={podeEditar} podeExcluir={podeExcluir} preset={() => ({ obra: nome })} />;
}