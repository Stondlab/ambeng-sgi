import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Users, KanbanSquare, AlertOctagon, ClipboardCheck, Stethoscope, GraduationCap,
  HardHat, FileWarning, FileCheck, CalendarCheck, AlertTriangle, ShieldCheck, ArrowRight,
} from 'lucide-react';
import DrillDownDialog from '@/components/dashboard/DrillDownDialog';
import { statsObra, pendenciasObraList } from '@/lib/obras';
import { getStatus, fmt } from '@/lib/sst';
import { isAtrasada } from '@/lib/acoes';

function Pill({ status }) {
  const map = {
    'Em dia': 'bg-emerald-100 text-emerald-700', 'A vencer': 'bg-amber-100 text-amber-700', 'Vencido': 'bg-red-100 text-red-700',
    'Pendente': 'bg-amber-100 text-amber-700', 'Conforme': 'bg-emerald-100 text-emerald-700', 'Não Conforme': 'bg-red-100 text-red-700',
    'Aberta': 'bg-amber-100 text-amber-700', 'Em Andamento': 'bg-blue-100 text-blue-700', 'Resolvida': 'bg-emerald-100 text-emerald-700',
    'Ativo': 'bg-emerald-100 text-emerald-700', 'Atrasada': 'bg-red-100 text-red-700', 'Concluída': 'bg-emerald-100 text-emerald-700',
    'A Fazer': 'bg-slate-100 text-slate-600', 'Hoje': 'bg-blue-100 text-blue-700',
  };
  return <span className={`text-[11px] font-medium px-2 py-0.5 rounded ${map[status] || 'bg-slate-100 text-slate-600'}`}>{status || '—'}</span>;
}

function Card({ icon: Icon, label, value, tone, onClick }) {
  const border = { navy: 'border-l-[#0b2545]', green: 'border-l-emerald-500', amber: 'border-l-amber-500', red: 'border-l-red-500', blue: 'border-l-blue-500', gray: 'border-l-slate-300' };
  const ic = { navy: 'text-[#0b2545]', green: 'text-emerald-600', amber: 'text-amber-600', red: 'text-red-600', blue: 'text-blue-600', gray: 'text-slate-500' };
  return (
    <button onClick={onClick} className={`text-left bg-white border border-slate-200 border-l-4 ${border[tone]} rounded-xl p-4 hover:shadow-card-hover transition-shadow min-h-[88px]`}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-slate-500">{label}</span>
        <Icon className={`w-4 h-4 ${ic[tone]}`} />
      </div>
      <p className="text-2xl font-bold text-[#0b2545] mt-1">{value}</p>
    </button>
  );
}

export default function ObraVisaoGeral({ nome, data, demandas }) {
  const s = statsObra(nome, data || {}, demandas);
  const L = s.listas;
  const [active, setActive] = useState(null);
  const funcById = Object.fromEntries((data?.funcionarios || []).map((f) => [f.id, f]));
  const nomeFunc = (id) => funcById[id]?.nome || '—';
  const pends = pendenciasObraList(L);
  const rotaPend = (r) => ({ ASO: '/asos', Treinamento: '/treinamentos', EPI: '/epis', Inspeção: '/formularios', APR: '/formularios', Pendencia: `/funcionarios/${r.funcionario_id}` }[r.origem] || '/painel/quadro');

  const inds = [
    { key: 'ativos', label: 'Colaboradores ativos', value: s.ativos, tone: 'navy', icon: Users, rows: L.funcs.filter((f) => f.status === 'Ativo'), cols: [{ key: 'nome', label: 'Colaborador', value: (r) => r.nome }, { key: 'funcao', label: 'Função', value: (r) => r.funcao || '—' }, { key: 'st', label: 'Status', render: (r) => <Pill status={r.status} /> }], route: (r) => `/funcionarios/${r.id}` },
    { key: 'tarefas', label: 'Tarefas abertas', value: L.demandas.filter((d) => d.status !== 'Concluído' && d.status !== 'Cancelado').length, tone: 'blue', icon: KanbanSquare, rows: L.demandas.filter((d) => d.status !== 'Concluído' && d.status !== 'Cancelado'), cols: [{ key: 't', label: 'Tarefa', value: (r) => r.titulo }, { key: 'r', label: 'Responsável', value: (r) => r.responsavel || '—' }, { key: 'p', label: 'Prazo', value: (r) => fmt(r.prazo) }, { key: 's', label: 'Status', render: (r) => <Pill status={r.status} /> }], route: '/painel/quadro' },
    { key: 'atrasadas', label: 'Tarefas atrasadas', value: s.atrasadas, tone: 'red', icon: AlertOctagon, rows: L.demandas.filter((d) => isAtrasada(d)), cols: [{ key: 't', label: 'Tarefa', value: (r) => r.titulo }, { key: 'p', label: 'Prazo', value: (r) => fmt(r.prazo) }, { key: 's', label: 'Status', render: (r) => <Pill status={r.status} /> }], route: '/painel/quadro' },
    { key: 'pend', label: 'Pendências', value: s.pendencias, tone: 'amber', icon: ClipboardCheck, rows: pends, cols: [{ key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' }, { key: 'd', label: 'Descrição', value: (r) => r.descricao || '—' }, { key: 'p', label: 'Prazo', value: (r) => fmt(r.prazo) }, { key: 's', label: 'Status', render: (r) => <Pill status={r.status} /> }], route: rotaPend },
    { key: 'asos', label: 'ASOs vencendo', value: s.asosVenc, tone: 'amber', icon: Stethoscope, rows: L.asos.filter((r) => getStatus(r.data_validade) !== 'Em dia'), cols: [{ key: 'f', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 't', label: 'Tipo', value: (r) => r.tipo || '—' }, { key: 'v', label: 'Vencimento', value: (r) => fmt(r.data_validade) }, { key: 's', label: 'Status', render: (r) => <Pill status={getStatus(r.data_validade)} /> }], route: '/asos' },
    { key: 'trei', label: 'Treinamentos vencendo', value: s.treiVenc, tone: 'amber', icon: GraduationCap, rows: L.treinamentos.filter((r) => getStatus(r.data_validade) !== 'Em dia'), cols: [{ key: 'f', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 'c', label: 'Curso', value: (r) => r.nome_curso || r.norma_curso || '—' }, { key: 'v', label: 'Vencimento', value: (r) => fmt(r.data_validade) }, { key: 's', label: 'Status', render: (r) => <Pill status={getStatus(r.data_validade)} /> }], route: '/treinamentos' },
    { key: 'epis', label: 'EPIs vencendo', value: s.episVenc, tone: 'amber', icon: HardHat, rows: L.epis.filter((r) => getStatus(r.data_validade) !== 'Em dia'), cols: [{ key: 'f', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 'i', label: 'EPI', value: (r) => r.item || '—' }, { key: 'v', label: 'Vencimento', value: (r) => fmt(r.data_validade) }, { key: 's', label: 'Status', render: (r) => <Pill status={getStatus(r.data_validade)} /> }], route: '/epis' },
    { key: 'insp', label: 'Inspeções pendentes', value: s.inspPend, tone: 'amber', icon: FileWarning, rows: L.inspecoes.filter((r) => r.status === 'Pendente'), cols: [{ key: 't', label: 'Tipo', value: (r) => r.tipo || '—' }, { key: 'o', label: 'Obra', value: (r) => r.obra || '—' }, { key: 'r', label: 'Responsável', value: (r) => r.responsavel || '—' }, { key: 'p', label: 'Data prevista', value: (r) => fmt(r.data_proxima) }, { key: 's', label: 'Status', render: (r) => <Pill status={r.status} /> }], route: '/formularios' },
    { key: 'apr', label: 'APRs pendentes', value: s.aprPend, tone: 'amber', icon: FileCheck, rows: L.aprs.filter((r) => r.status !== 'Concluído' && r.status !== 'Cancelado'), cols: [{ key: 't', label: 'APR', value: (r) => r.titulo || '—' }, { key: 'r', label: 'Responsável', value: (r) => r.responsavel || '—' }, { key: 'p', label: 'Prazo', value: (r) => fmt(r.prazo) }, { key: 's', label: 'Status', render: (r) => <Pill status={r.status} /> }], route: '/formularios' },
    { key: 'dds', label: 'DDS pendentes', value: s.ddsPend, tone: 'blue', icon: CalendarCheck, rows: L.dds.filter((r) => (r.data || '') > new Date().toISOString().slice(0, 10)), cols: [{ key: 'r', label: 'Responsável', value: (r) => r.responsavel || nomeFunc(r.funcionario_id) }, { key: 't', label: 'Tema', value: (r) => r.tema || '—' }, { key: 'd', label: 'Data', value: (r) => fmt(r.data) }], route: '/formularios' },
    { key: 'oco', label: 'Ocorrências abertas', value: s.ocoAbertas, tone: 'red', icon: AlertTriangle, rows: L.ocorrencias.filter((r) => r.situacao !== 'Resolvida' && r.situacao !== 'Cancelada'), cols: [{ key: 't', label: 'Tipo', value: (r) => r.tipo || '—' }, { key: 'f', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 'd', label: 'Data', value: (r) => fmt(r.data) }, { key: 's', label: 'Status', render: (r) => <Pill status={r.situacao} /> }], route: '/ocorrencias' },
    { key: 'ncs', label: 'NCs abertas', value: s.ncs, tone: 'red', icon: ShieldCheck, rows: L.ocorrencias.filter((r) => r.tipo === 'Não Conformidade' && r.situacao !== 'Resolvida' && r.situacao !== 'Cancelada'), cols: [{ key: 'd', label: 'Descrição', value: (r) => r.descricao || '—' }, { key: 'g', label: 'Gravidade', value: (r) => r.gravidade || '—' }, { key: 'r', label: 'Responsável', value: (r) => r.responsavel_tratativa || '—' }, { key: 's', label: 'Status', render: (r) => <Pill status={r.situacao} /> }], route: '/ocorrencias' },
  ];

  return (
    <>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {inds.map((it) => <Card key={it.key} icon={it.icon} label={it.label} value={it.value} tone={it.value > 0 ? it.tone : 'green'} onClick={() => setActive(it.key)} />)}
      </div>
      {inds.map((it) => (
        <DrillDownDialog
          key={it.key}
          open={active === it.key}
          onOpenChange={(o) => !o && setActive(null)}
          title={it.label}
          subtitle={nome}
          icon={it.icon}
          columns={it.cols}
          rows={it.rows}
          emptyMessage="Nenhum registro nesta categoria."
          renderAction={(r) => {
            const to = typeof it.route === 'function' ? it.route(r) : it.route;
            return <Link to={to} className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-md bg-[#0b2545] text-white hover:bg-[#0b2545]/90 whitespace-nowrap">Abrir <ArrowRight className="w-3 h-3" /></Link>;
          }}
        />
      ))}
    </>
  );
}