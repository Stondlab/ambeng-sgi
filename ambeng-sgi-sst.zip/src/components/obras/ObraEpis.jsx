import React from 'react';
import ObraCrudTab from './ObraCrudTab';
import { getStatus, fmt } from '@/lib/sst';

const fields = [
  { key: 'funcionario_id', label: 'Colaborador', type: 'funcionario', required: true, full: true },
  { key: 'item', label: 'EPI', required: true },
  { key: 'certificado_aprovacao', label: 'CA' },
  { key: 'marca', label: 'Marca' },
  { key: 'data_entrega', label: 'Entrega', type: 'date' },
  { key: 'data_validade', label: 'Validade', type: 'date', required: true },
  { key: 'trocas', label: 'Trocas' },
  { key: 'reposicao', label: 'Reposição' },
];
const defaultForm = { funcionario_id: '', item: '', certificado_aprovacao: '', marca: '', data_entrega: '', data_validade: '', trocas: '', reposicao: '' };

export default function ObraEpis({ L, data, onRefresh, podeEditar, podeExcluir }) {
  const funcById = Object.fromEntries((data?.funcionarios || []).map((f) => [f.id, f]));
  const columns = [
    { key: 'f', label: 'Colaborador', value: (r) => funcById[r.funcionario_id]?.nome || '—' },
    { key: 'i', label: 'EPI', value: (r) => r.item || '—' },
    { key: 'ca', label: 'CA', value: (r) => r.certificado_aprovacao || '—' },
    { key: 'v', label: 'Validade', value: (r) => fmt(r.data_validade) },
    { key: 's', label: 'Status', render: (r) => <span className="text-xs">{getStatus(r.data_validade)}</span> },
  ];
  return <ObraCrudTab entity="EPIs" label="EPI" rows={L.epis} columns={columns} fields={fields} defaultForm={defaultForm} data={data} L={L} onRefresh={onRefresh} podeEditar={podeEditar} podeExcluir={podeExcluir} />;
}