import React from 'react';
import ObraCrudTab from './ObraCrudTab';
import { fmt } from '@/lib/sst';

// DDS por obra — registro em grupo: um único registro cobre todos os
// participantes da reunião, com 'obra' preenchido automaticamente (preset).
const fields = [
  { key: 'data', label: 'Data', type: 'date', required: true },
  { key: 'tema', label: 'Tema', full: true },
  { key: 'local', label: 'Local (canteiro/frente de serviço)' },
  { key: 'responsavel', label: 'Responsável' },
  { key: 'participantes', label: 'Participantes', type: 'funcionarios-multi', full: true, countKey: 'qtd_participantes' },
];
const defaultForm = { data: '', tema: '', local: '', responsavel: '', participantes: [] };

export default function ObraDds({ L, data, onRefresh, podeEditar, podeExcluir, obra }) {
  const columns = [
    { key: 'd', label: 'Data', value: (r) => fmt(r.data) },
    { key: 't', label: 'Tema', value: (r) => r.tema || '—' },
    { key: 'p', label: 'Participantes', align: 'right', value: (r) => r.qtd_participantes || (r.participantes ? (JSON.parse(r.participantes || '[]').length) : (r.funcionario_id ? 1 : 0)) },
    { key: 'r', label: 'Responsável', value: (r) => r.responsavel || '—' },
  ];
  return (
    <ObraCrudTab
      entity="DDS" label="DDS" rows={L.dds} columns={columns} fields={fields} defaultForm={defaultForm}
      data={data} L={L} onRefresh={onRefresh} podeEditar={podeEditar} podeExcluir={podeExcluir}
      preset={() => ({ obra_id: obra?.id || '', obra: obra?.nome || L?.obra?.nome || '' })}
    />
  );
}