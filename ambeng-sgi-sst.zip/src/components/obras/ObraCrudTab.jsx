import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Pencil, Trash2, Check } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import ObraListaTab from './ObraListaTab';

// Componente genérico de CRUD para as abas da obra.
// fields: [{ key, label, type, options?, required?, full?, placeholder? }]
//   types: text | date | number | textarea | select | funcionario
// preset(form) => campos fixos a forçar no save (ex.: { obra: nome })
export default function ObraCrudTab({ entity, label, rows, columns, fields, defaultForm, data, L, onRefresh, podeEditar, podeExcluir, preset }) {
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState(defaultForm);

  const funcs = L?.funcs || [];

  const novo = () => { setEditId(null); setForm({ ...defaultForm }); setOpen(true); };
  const editar = (r) => {
    const f = {};
    fields.forEach((fd) => {
      if (fd.type === 'funcionarios-multi') {
        try { f[fd.key] = JSON.parse(r[fd.key] || '[]'); } catch { f[fd.key] = []; }
      } else {
        f[fd.key] = r[fd.key] ?? defaultForm[fd.key];
      }
    });
    setForm(f); setEditId(r.id); setOpen(true);
  };
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const salvar = async () => {
    for (const fd of fields) { if (fd.required && !form[fd.key] && form[fd.key] !== 0) return; }
    let payload = { ...form };
    // Campos multi-seleção (ex.: participantes) vão como array no state e são
    // serializados para JSON string na gravação (formato esperado pela entidade).
    fields.filter((fd) => fd.type === 'funcionarios-multi').forEach((fd) => {
      const arr = Array.isArray(payload[fd.key]) ? payload[fd.key] : [];
      payload[fd.key] = JSON.stringify(arr);
      if (fd.countKey) payload[fd.countKey] = arr.length;
    });
    if (preset) payload = { ...payload, ...preset(payload) };
    if (editId) await base44.entities[entity].update(editId, payload);
    else await base44.entities[entity].create(payload);
    setOpen(false); onRefresh?.();
  };
  const excluir = async (id) => { if (!confirm(`Excluir este ${label}?`)) return; await base44.entities[entity].delete(id); onRefresh?.(); };

  const renderField = (fd) => {
    switch (fd.type) {
      case 'funcionarios-multi': {
        const sel = Array.isArray(form[fd.key]) ? form[fd.key] : [];
        const toggle = (id) => set(fd.key, sel.includes(id) ? sel.filter((x) => x !== id) : [...sel, id]);
        return (
          <div className="border border-slate-200 rounded-lg max-h-40 overflow-y-auto divide-y divide-slate-100">
            {funcs.length === 0 && <p className="text-xs text-slate-400 p-2">Nenhum colaborador cadastrado.</p>}
            {funcs.map((f) => (
              <button type="button" key={f.id} onClick={() => toggle(f.id)} className="w-full flex items-center gap-2 px-2.5 py-1.5 text-sm text-left hover:bg-slate-50">
                <span className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${sel.includes(f.id) ? 'bg-[#0b2545] border-[#0b2545]' : 'border-slate-300'}`}>
                  {sel.includes(f.id) && <Check className="w-3 h-3 text-white" />}
                </span>
                <span className="truncate">{f.nome}</span>
              </button>
            ))}
            {sel.length > 0 && <p className="text-[11px] text-slate-400 px-2.5 py-1">{sel.length} selecionado(s)</p>}
          </div>
        );
      }
      case 'funcionario':
        return (
          <Select value={form[fd.key] || ''} onValueChange={(v) => set(fd.key, v)}>
            <SelectTrigger><SelectValue placeholder="Colaborador" /></SelectTrigger>
            <SelectContent>
              {!fd.required && <SelectItem value={null}>— Nenhum —</SelectItem>}
              {funcs.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}
            </SelectContent>
          </Select>
        );
      case 'select':
        return (
          <Select value={form[fd.key] || ''} onValueChange={(v) => set(fd.key, v)}>
            <SelectTrigger><SelectValue placeholder={fd.label} /></SelectTrigger>
            <SelectContent>{fd.options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
          </Select>
        );
      case 'date': return <Input type="date" value={form[fd.key] || ''} onChange={(e) => set(fd.key, e.target.value)} />;
      case 'number': return <Input type="number" value={form[fd.key] ?? ''} onChange={(e) => set(fd.key, e.target.value)} />;
      case 'textarea': return <Textarea value={form[fd.key] || ''} onChange={(e) => set(fd.key, e.target.value)} rows={2} />;
      default: return <Input value={form[fd.key] || ''} onChange={(e) => set(fd.key, e.target.value)} />;
    }
  };

  const actionCol = (r) => (
    <div className="flex justify-end gap-2 whitespace-nowrap">
      {podeEditar && <button onClick={() => editar(r)} className="text-slate-500 hover:text-[#0b2545]"><Pencil className="w-3.5 h-3.5" /></button>}
      {podeExcluir && <button onClick={() => excluir(r.id)} className="text-red-500 hover:text-red-700"><Trash2 className="w-3.5 h-3.5" /></button>}
    </div>
  );
  const cols = [...columns, { key: '_act', label: 'Ações', align: 'right', render: actionCol }];

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        {podeEditar && <Button onClick={novo}><Plus className="w-4 h-4" /> Novo {label}</Button>}
        <span className="text-xs text-slate-400 ml-auto">{rows.length} registro(s)</span>
      </div>
      <ObraListaTab rows={rows} columns={cols} route={null} emptyMessage={`Nenhum ${label} vinculado a esta obra.`} />
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editId ? `Editar ${label}` : `Novo ${label}`}</DialogTitle></DialogHeader>
          <div className="grid sm:grid-cols-2 gap-3 py-2">
            {fields.map((fd) => (
              <div key={fd.key} className={fd.full ? 'sm:col-span-2' : ''}>
                <Label>{fd.label}{fd.required ? ' *' : ''}</Label>
                {renderField(fd)}
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button onClick={salvar}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}