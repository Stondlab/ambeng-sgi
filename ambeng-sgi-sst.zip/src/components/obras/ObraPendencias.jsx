import React from 'react';
import { pendenciasObraList } from '@/lib/obras';
import { fmt } from '@/lib/sst';
import ObraListaTab from './ObraListaTab';

function Pill({ status }) {
  const map = { 'Vencido': 'bg-red-100 text-red-700', 'A vencer': 'bg-amber-100 text-amber-700', 'Em dia': 'bg-emerald-100 text-emerald-700', 'Pendente': 'bg-amber-100 text-amber-700', 'Atrasada': 'bg-red-100 text-red-700', 'Concluída': 'bg-emerald-100 text-emerald-700' };
  return <span className={`text-[11px] font-medium px-2 py-0.5 rounded ${map[status] || 'bg-slate-100 text-slate-600'}`}>{status || '—'}</span>;
}

export default function ObraPendencias({ L }) {
  const pends = pendenciasObraList(L);
  const rota = (r) => ({ ASO: '/asos', Treinamento: '/treinamentos', EPI: '/epis', Inspeção: '/formularios', APR: '/formularios', Pendencia: `/funcionarios/${r.funcionario_id}` }[r.origem] || '/painel/quadro');
  const columns = [
    { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' },
    { key: 'desc', label: 'Descrição', value: (r) => r.descricao || '—' },
    { key: 'resp', label: 'Responsável', value: (r) => r.responsavel || '—' },
    { key: 'prazo', label: 'Prazo', value: (r) => fmt(r.prazo) },
    { key: 'status', label: 'Status', render: (r) => <Pill status={r.status} /> },
    { key: 'prio', label: 'Prioridade', value: (r) => r.prioridade || '—' },
  ];
  return <ObraListaTab rows={pends} columns={columns} route={rota} emptyMessage="Nenhuma pendência nesta obra — tudo conforme." />;
}