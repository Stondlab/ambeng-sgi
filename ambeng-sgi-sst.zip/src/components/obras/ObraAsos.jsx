import React from 'react';
import ObraCrudTab from './ObraCrudTab';
import { getStatus, fmt } from '@/lib/sst';

const fields = [
  { key: 'funcionario_id', label: 'Colaborador', type: 'funcionario', required: true, full: true },
  { key: 'tipo', label: 'Tipo', type: 'select', required: true, options: ['Admissional', 'Periódico', 'Mudança de Função', 'Retorno ao Trabalho', 'Demissional'] },
  { key: 'data_exame', label: 'Data do exame', type: 'date' },
  { key: 'data_validade', label: 'Validade', type: 'date', required: true },
  { key: 'medico', label: 'Médico' },
  { key: 'clinica', label: 'Clínica' },
  { key: 'restricoes_medicas', label: 'Restrições médicas', type: 'textarea', full: true },
  { key: 'arquivo_url', label: 'Arquivo (URL)', full: true },
];
const defaultForm = { funcionario_id: '', tipo: 'Admissional', data_exame: '', data_validade: '', medico: '', clinica: '', restricoes_medicas: '', arquivo_url: '' };

export default function ObraAsos({ L, data, onRefresh, podeEditar, podeExcluir }) {
  const funcById = Object.fromEntries((data?.funcionarios || []).map((f) => [f.id, f]));
  const columns = [
    { key: 'f', label: 'Colaborador', value: (r) => funcById[r.funcionario_id]?.nome || '—' },
    { key: 't', label: 'Tipo', value: (r) => r.tipo || '—' },
    { key: 'v', label: 'Validade', value: (r) => fmt(r.data_validade) },
    { key: 's', label: 'Status', render: (r) => <span className="text-xs">{getStatus(r.data_validade)}</span> },
  ];
  return <ObraCrudTab entity="ASOs" label="ASO" rows={L.asos} columns={columns} fields={fields} defaultForm={defaultForm} data={data} L={L} onRefresh={onRefresh} podeEditar={podeEditar} podeExcluir={podeExcluir} />;
}