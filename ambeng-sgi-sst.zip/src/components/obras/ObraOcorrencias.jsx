import React from 'react';
import ObraCrudTab from './ObraCrudTab';
import { fmt } from '@/lib/sst';

const TIPOS = ['Quase Acidente', 'Acidente', 'Não Conformidade', 'Observação de Segurança'];
const GRAV = ['Baixa', 'Média', 'Alta'];
const SIT = ['Aberta', 'Em Andamento', 'Resolvida', 'Cancelada'];

const fields = [
  { key: 'funcionario_id', label: 'Colaborador', type: 'funcionario', full: true },
  { key: 'data', label: 'Data', type: 'date', required: true },
  { key: 'tipo', label: 'Tipo', type: 'select', required: true, options: TIPOS },
  { key: 'gravidade', label: 'Gravidade', type: 'select', required: true, options: GRAV },
  { key: 'situacao', label: 'Situação', type: 'select', options: SIT },
  { key: 'responsavel_tratativa', label: 'Responsável tratativa' },
  { key: 'prazo_tratativa', label: 'Prazo tratativa', type: 'date' },
  { key: 'descricao', label: 'Descrição', type: 'textarea', full: true },
  { key: 'acao_tomada', label: 'Providências', type: 'textarea', full: true },
];
const defaultForm = { funcionario_id: '', data: '', tipo: 'Acidente', gravidade: 'Média', situacao: 'Aberta', responsavel_tratativa: '', prazo_tratativa: '', descricao: '', acao_tomada: '' };

export default function ObraOcorrencias({ L, data, onRefresh, podeEditar, podeExcluir }) {
  const funcById = Object.fromEntries((data?.funcionarios || []).map((f) => [f.id, f]));
  const columns = [
    { key: 't', label: 'Tipo', value: (r) => r.tipo || '—' },
    { key: 'f', label: 'Colaborador', value: (r) => funcById[r.funcionario_id]?.nome || '—' },
    { key: 'd', label: 'Data', value: (r) => fmt(r.data) },
    { key: 'g', label: 'Gravidade', value: (r) => r.gravidade || '—' },
    { key: 's', label: 'Situação', render: (r) => <span className="text-xs">{r.situacao}</span> },
  ];
  return <ObraCrudTab entity="Ocorrencias" label="Ocorrência" rows={L.ocorrencias} columns={columns} fields={fields} defaultForm={defaultForm} data={data} L={L} onRefresh={onRefresh} podeEditar={podeEditar} podeExcluir={podeExcluir} />;
}