import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

// Tabela genérica para as abas de leitura da obra.
// columns: [{ key, label, align?, value?(r), render?(r) }]
// route: string | (row) => string
export default function ObraListaTab({ rows, columns, route, actionLabel = 'Abrir', emptyMessage = 'Nenhum registro vinculado a esta obra.' }) {
  if (!rows || rows.length === 0) return <p className="text-sm text-slate-400 py-6">{emptyMessage}</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-xs uppercase text-slate-500 border-b border-slate-100">
          <tr>
            {columns.map((c) => <th key={c.key} className={`px-3 py-2 font-semibold ${c.align === 'right' ? 'text-right' : 'text-left'}`}>{c.label}</th>)}
            {route && <th className="px-3 py-2 text-right font-semibold">Ação</th>}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {rows.map((r, i) => (
            <tr key={r.id ?? i} className="hover:bg-slate-50/60">
              {columns.map((c) => <td key={c.key} className={`px-3 py-2.5 align-top ${c.align === 'right' ? 'text-right' : ''}`}>{c.render ? c.render(r) : c.value ? c.value(r) : '—'}</td>)}
              {route && (
                <td className="px-3 py-2.5 text-right whitespace-nowrap">
                  {typeof route === 'function' ? (
                    <Link to={route(r)} className="text-xs font-semibold text-[#0b2545] hover:underline inline-flex items-center gap-1">{actionLabel}<ArrowRight className="w-3 h-3" /></Link>
                  ) : (
                    <Link to={route} className="text-xs font-semibold text-[#0b2545] hover:underline inline-flex items-center gap-1">{actionLabel}<ArrowRight className="w-3 h-3" /></Link>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}