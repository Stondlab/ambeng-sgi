import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { base44 } from '@/api/base44Client';
import { STATUS_OBRA, UF } from '@/lib/obras';
import { applyTitleCaseAll } from '@/lib/titleCase';
import { mensagemAmigavelErro, validarCNPJ, validarDataOpcional, validarEmailOpcional, validarNumeroOpcional, validarTelefoneOpcional } from '@/lib/validacao';

const empty = {
  nome: '', codigo: '', cliente: '', cnpj: '', endereco: '', numero: '', complemento: '',
  bairro: '', cidade: '', estado: '', cep: '', orcamento: 0, data_inicio: '',
  data_prevista_termino: '', data_real_termino: '', status: 'Planejamento', responsavel: '',
  responsavel_sst: '', telefone: '', email: '', cor: '#2563eb', descricao: '', observacoes: '',
};

export default function ObraForm({ open, onOpenChange, obra, onSaved }) {
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [erro, setErro] = useState('');
  const editing = !!obra;

  useEffect(() => { if (open) setForm(obra ? { ...empty, ...obra } : empty); }, [open, obra]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const salvar = async () => {
    if (!form.nome?.trim()) return setErro('Informe o nome da obra.');
    if (!validarCNPJ(form.cnpj)) return setErro('Informe um CNPJ válido.');
    if (!validarEmailOpcional(form.email)) return setErro('Informe um e-mail válido.');
    if (!validarTelefoneOpcional(form.telefone)) return setErro('Informe um telefone com DDD e 10 ou 11 dígitos.');
    if ([form.data_inicio, form.data_prevista_termino, form.data_real_termino].some((v) => !validarDataOpcional(v))) return setErro('Informe datas válidas.');
    if (form.data_inicio && form.data_prevista_termino && form.data_prevista_termino < form.data_inicio) return setErro('A previsão de término não pode ser anterior ao início.');
    if (!validarNumeroOpcional(form.orcamento)) return setErro('Informe um orçamento numérico válido e não negativo.');
    setErro(''); setSaving(true);
    try {
      const payload = applyTitleCaseAll({ ...form, orcamento: form.orcamento === '' ? null : Number(form.orcamento) });
      if (editing) await base44.entities.Obras.update(obra.id, payload);
      else await base44.entities.Obras.create(payload);
      onSaved?.(); onOpenChange?.(false);
    } catch (e) { setErro(mensagemAmigavelErro(e)); }
    finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{editing ? 'Editar Obra' : 'Nova Obra'}</DialogTitle></DialogHeader>
        <div className="grid sm:grid-cols-2 gap-3 py-2">
          <div className="sm:col-span-2"><Label>Nome da obra *</Label><Input value={form.nome} onChange={(e) => set('nome', e.target.value)} /></div>
          <div><Label>Código</Label><Input value={form.codigo} onChange={(e) => set('codigo', e.target.value)} /></div>
          <div><Label>Empresa/Cliente</Label><Input value={form.cliente} onChange={(e) => set('cliente', e.target.value)} /></div>
          <div><Label>CNPJ</Label><Input value={form.cnpj} onChange={(e) => set('cnpj', e.target.value)} /></div>
          <div>
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => set('status', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{STATUS_OBRA.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Cor na Jornada e Ponto</Label><div className="flex items-center gap-2"><Input type="color" className="w-16 p-1" value={form.cor || '#2563eb'} onChange={(e) => set('cor', e.target.value)} /><span className="text-xs text-muted-foreground">Identificação da obra na matriz</span></div></div>
          <div><Label>Endereço</Label><Input value={form.endereco} onChange={(e) => set('endereco', e.target.value)} /></div>
          <div><Label>Número</Label><Input value={form.numero} onChange={(e) => set('numero', e.target.value)} /></div>
          <div><Label>Complemento</Label><Input value={form.complemento} onChange={(e) => set('complemento', e.target.value)} /></div>
          <div><Label>Bairro</Label><Input value={form.bairro} onChange={(e) => set('bairro', e.target.value)} /></div>
          <div><Label>Cidade</Label><Input value={form.cidade} onChange={(e) => set('cidade', e.target.value)} /></div>
          <div>
            <Label>Estado</Label>
            <Select value={form.estado || ''} onValueChange={(v) => set('estado', v)}>
              <SelectTrigger><SelectValue placeholder="UF" /></SelectTrigger>
              <SelectContent>{UF.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>CEP</Label><Input value={form.cep} onChange={(e) => set('cep', e.target.value)} /></div>
          <div><Label>Data de início</Label><Input type="date" value={form.data_inicio || ''} onChange={(e) => set('data_inicio', e.target.value)} /></div>
          <div><Label>Previsão de término</Label><Input type="date" value={form.data_prevista_termino || ''} onChange={(e) => set('data_prevista_termino', e.target.value)} /></div>
          <div><Label>Término real</Label><Input type="date" value={form.data_real_termino || ''} onChange={(e) => set('data_real_termino', e.target.value)} /></div>
          <div><Label>Orçamento</Label><Input type="number" value={form.orcamento} onChange={(e) => set('orcamento', e.target.value)} /></div>
          <div><Label>Responsável pela obra</Label><Input value={form.responsavel} onChange={(e) => set('responsavel', e.target.value)} /></div>
          <div><Label>Responsável SST</Label><Input value={form.responsavel_sst} onChange={(e) => set('responsavel_sst', e.target.value)} /></div>
          <div><Label>Telefone</Label><Input value={form.telefone} onChange={(e) => set('telefone', e.target.value)} /></div>
          <div><Label>E-mail</Label><Input value={form.email} onChange={(e) => set('email', e.target.value)} /></div>
          <div className="sm:col-span-2"><Label>Descrição</Label><Textarea value={form.descricao} onChange={(e) => set('descricao', e.target.value)} rows={2} /></div>
          <div className="sm:col-span-2"><Label>Observações</Label><Textarea value={form.observacoes} onChange={(e) => set('observacoes', e.target.value)} rows={2} /></div>
        </div>
        {erro && <p className="text-sm text-red-600">{erro}</p>}
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange?.(false)} disabled={saving}>Cancelar</Button>
          <Button onClick={salvar} disabled={saving || !form.nome?.trim()}>{saving ? 'Salvando...' : 'Salvar'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}