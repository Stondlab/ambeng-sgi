import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { custoGeral, vigenciaAtiva } from '@/lib/custoMO';
import { formatHoras } from '@/lib/apontamento';
import { fmtMoney } from '@/lib/financeiro';
import { Label } from '@/components/ui/label';

// Custo de Mão de Obra por Obra (spec §21). Consome o MESMO motor (custoMO) do
// RH/Financeiro — garante consistência (RH = Financeiro = Obra).
export default function ObraCustoMO({ obraNome }) {
  const [funcs, setFuncs] = useState([]);
  const [aps, setAps] = useState([]);
  const [ponto, setPonto] = useState([]);
  const [vigencias, setVigencias] = useState([]);
  const [params, setParams] = useState([]);
  const [horasExtras, setHorasExtras] = useState([]);
  const [anoMesSel, setAnoMesSel] = useState(new Date().toISOString().slice(0, 7));

  useEffect(() => {
    (async () => {
      const [f, a, p, v, pr, he] = await Promise.all([
        base44.entities.Funcionarios.list('-created_date', 1000).catch(() => []),
        base44.entities.Apontamentos.list('-data', 3000).catch(() => []),
        base44.entities.Ponto.list('-data', 3000).catch(() => []),
        base44.entities.EncargosVigencias.list('-data_inicio', 500).catch(() => []),
        base44.entities.ParametrosCustoMO.list('data_inicio', 500).catch(() => []),
        base44.entities.HorasExtras.list('-data', 3000).catch(() => []),
      ]);
      setFuncs(f); setAps(a); setPonto(p); setVigencias(v); setParams(pr); setHorasExtras(he);
    })();
  }, []);

  const encPct = useMemo(() => vigenciaAtiva(vigencias, anoMesSel), [vigencias, anoMesSel]);
  const geral = useMemo(() => custoGeral(funcs, aps, encPct, anoMesSel, ponto, horasExtras, params), [funcs, aps, encPct, anoMesSel, ponto, horasExtras, params]);

  const valor = geral.porObra[obraNome] || 0;
  const conferido = geral.porObraConf[obraNome] || 0;
  const pendente = geral.porObraPend[obraNome] || 0;

  // Composição gerencial da obra = soma das frações de cada funcionário nela.
  const composicao = useMemo(() => {
    let rem = 0, ben = 0, enc = 0, prov = 0;
    geral.porFunc.forEach((pf) => {
      const frac = valor > 0 ? ((pf.porObra[obraNome] || 0) / valor) : 0;
      if (frac > 0) { rem += pf.remuneracao * frac; ben += pf.beneficios * frac; enc += pf.encargos * frac; prov += pf.provisoes * frac; }
    });
    return { rem, ben, enc, prov };
  }, [geral, valor, obraNome]);

  const funcsObra = useMemo(() => geral.porFunc
    .map((pf) => ({ nome: pf.f.nome, matricula: pf.f.matricula, funcao: pf.f.funcao, valor: pf.porObra[obraNome] || 0, custoHora: pf.custoHora || 0, conf: pf.porObraConf[obraNome] || 0, pend: pf.porObraPend[obraNome] || 0, horas: (pf.horasPorObraConf[obraNome] || 0) + (pf.horasPorObraPend[obraNome] || 0) }))
    .filter((c) => c.valor > 0.005)
    .sort((a, b) => b.valor - a.valor), [geral, obraNome]);

  const cards = [
    { l: 'Salários / Remuneração', v: fmtMoney(composicao.rem) },
    { l: 'Benefícios', v: fmtMoney(composicao.ben) },
    { l: 'Encargos', v: fmtMoney(composicao.enc) },
    { l: 'Provisões', v: fmtMoney(composicao.prov) },
    { l: 'Custo Conferido', v: fmtMoney(conferido) },
    { l: 'Custo Pendente', v: fmtMoney(pendente) },
    { l: 'Custo Total', v: fmtMoney(valor) },
  ];

  return (
    <div>
      <div className="mb-3 max-w-[12rem]">
        <Label>Competência</Label>
        <input type="month" value={anoMesSel} onChange={(e) => setAnoMesSel(e.target.value)} className="mt-1 h-11 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm" />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 mb-4">
        {cards.map((c, i) => (
          <div key={c.l} className={`rounded-xl p-3 ${i === 6 ? 'bg-[#0b2545] text-white' : 'bg-white border border-slate-200'}`}>
            <p className="text-lg font-bold leading-none">{c.v}</p>
            <p className={`text-xs mt-2 ${i === 6 ? 'opacity-80' : 'text-slate-500'}`}>{c.l}</p>
          </div>
        ))}
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-4">
        <div className="text-sm font-semibold text-[#0b2545] mb-3">Colaboradores apropriados nesta obra — {obraNome}</div>
        {funcsObra.length === 0 ? <p className="text-sm text-slate-400 py-6 text-center">Sem apontamento nesta obra na competência. O custo é apropriado conforme as horas apontadas e conferidas.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[520px]">
              <thead className="bg-slate-50 text-slate-500 text-xs"><tr>
                <th className="text-left px-3 py-2 font-medium">Colaborador</th>
                <th className="text-left px-3 py-2 font-medium">Função</th>
                <th className="text-right px-3 py-2 font-medium">Horas</th>
                <th className="text-right px-3 py-2 font-medium">Custo/hora</th>
                <th className="text-right px-3 py-2 font-medium">Conferido</th>
                <th className="text-right px-3 py-2 font-medium">Pendente</th>
                <th className="text-right px-3 py-2 font-medium">Custo</th>
              </tr></thead>
              <tbody className="divide-y divide-slate-100">
                {funcsObra.map((c) => (
                  <tr key={c.matricula + c.nome}>
                    <td className="px-3 py-2 font-medium text-[#0b2545]">{c.nome}{c.matricula ? ` · ${c.matricula}` : ''}</td>
                    <td className="px-3 py-2 text-slate-600">{c.funcao || '—'}</td>
                    <td className="px-3 py-2 text-right text-slate-600">{formatHoras(c.horas)}</td>
                    <td className="px-3 py-2 text-right text-slate-600">{fmtMoney(c.custoHora)}</td>
                    <td className="px-3 py-2 text-right text-emerald-600">{fmtMoney(c.conf)}</td>
                    <td className="px-3 py-2 text-right text-amber-600">{fmtMoney(c.pend)}</td>
                    <td className="px-3 py-2 text-right font-semibold text-[#0b2545]">{fmtMoney(c.valor)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot><tr className="bg-slate-50"><td className="px-3 py-3 font-semibold text-[#0b2545]" colSpan={2}>Total</td><td className="px-3 py-3 text-right font-bold text-[#0b2545]">{formatHoras(funcsObra.reduce((s, item) => s + item.horas, 0))}</td><td className="px-3 py-3 text-right text-slate-400">—</td><td colSpan={2} /><td className="px-3 py-3 text-right font-bold text-[#0b2545]">{fmtMoney(valor)}</td></tr></tfoot>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}