import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useSstData } from '@/hooks/useSstEntitiesData';
import { useAuth } from '@/lib/AuthContext';
import { usePermissoes } from '@/lib/PermissoesContext';
import { isTecnico } from '@/lib/permissoes';
import { getStatus, fmt } from '@/lib/sst';
import { format, parseISO, differenceInCalendarDays } from 'date-fns';
import {
  Users, ClipboardCheck, AlertTriangle, GraduationCap, Stethoscope,
  CalendarCheck, ShieldCheck, HardHat, FileWarning, FileCheck, TrendingUp, ArrowRight, UserX, MapPinOff,
} from 'lucide-react';
import DrillDownDialog from './DrillDownDialog';
import FiltrosDashboard from './FiltrosDashboard';
import { avaliarDdsAusente } from '@/lib/regrasEngine';
import { obrasDisponiveisNoPeriodo } from '@/lib/obraDisponibilidade';

const todayStr = format(new Date(), 'yyyy-MM-dd');
const today = new Date(); today.setHours(0, 0, 0, 0);

const TIPO_ROUTE = {
  ASO: '/asos', Treinamento: '/treinamentos', EPI: '/epis', Inspeção: '/ocorrencias',
  Integração: '/funcionarios', Documento: '/funcionarios', Liberação: '/funcionarios', CNH: '/funcionarios',
  Máquina: '/funcionarios', Outro: '/funcionarios',
};

function passe(rec, g, filtros) {
  if (filtros.empresa && g.empresa && g.empresa(rec) !== filtros.empresa) return false;
  if (filtros.obra && g.obra && g.obra(rec) !== filtros.obra) return false;
  if (filtros.responsavel && g.responsavel && g.responsavel(rec) !== filtros.responsavel) return false;
  if (filtros.status && g.status && g.status(rec) !== filtros.status) return false;
  if ((filtros.inicio || filtros.fim) && g.data) {
    const d = g.data(rec);
    if (d) {
      if (filtros.inicio && d < filtros.inicio) return false;
      if (filtros.fim && d > filtros.fim) return false;
    }
  }
  return true;
}

function diasAtraso(prazo) {
  if (!prazo) return 0;
  return Math.max(0, differenceInCalendarDays(today, parseISO(prazo)));
}

function Pill({ status }) {
  const map = {
    'Em dia': 'bg-emerald-100 text-emerald-700', 'A vencer': 'bg-amber-100 text-amber-700',
    'Vencido': 'bg-red-100 text-red-700', 'Conforme': 'bg-emerald-100 text-emerald-700',
    'Pendente': 'bg-amber-100 text-amber-700', 'Não Conforme': 'bg-red-100 text-red-700',
    'Aberta': 'bg-amber-100 text-amber-700', 'Em Andamento': 'bg-blue-100 text-blue-700',
    'Resolvida': 'bg-emerald-100 text-emerald-700', 'Ativo': 'bg-emerald-100 text-emerald-700',
    'Afastado': 'bg-amber-100 text-amber-700', 'Demitido': 'bg-slate-200 text-slate-600',
    'Atrasada': 'bg-red-100 text-red-700', 'Concluída': 'bg-emerald-100 text-emerald-700',
    'Hoje': 'bg-blue-100 text-blue-700', 'Agendado': 'bg-blue-100 text-blue-700',
  };
  return <span className={`text-[11px] font-medium px-2 py-0.5 rounded ${map[status] || 'bg-slate-100 text-slate-600'}`}>{status || '—'}</span>;
}

function ActLink({ to, children, variant = 'primary' }) {
  return (
    <Link to={to} className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-md whitespace-nowrap ${
      variant === 'primary' ? 'bg-[#0b2545] text-white hover:bg-[#0b2545]/90' : 'border border-slate-200 text-[#0b2545] hover:bg-slate-50'
    }`}>
      {children}
    </Link>
  );
}

function Card({ icon: Icon, label, value, tone, onClick, hint }) {
  const border = { navy: 'border-l-[#0b2545]', green: 'border-l-emerald-500', amber: 'border-l-amber-500', red: 'border-l-red-500', blue: 'border-l-blue-500', gray: 'border-l-slate-300' };
  const ic = { navy: 'text-[#0b2545]', green: 'text-emerald-600', amber: 'text-amber-600', red: 'text-red-600', blue: 'text-blue-600', gray: 'text-slate-500' };
  return (
    <button onClick={onClick} className={`text-left bg-white border border-slate-200 border-l-4 ${border[tone]} rounded-xl p-4 hover:shadow-card-hover transition-shadow min-h-[96px]`}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-slate-500">{label}</span>
        <Icon className={`w-4 h-4 ${ic[tone]}`} />
      </div>
      <p className="text-2xl font-bold text-[#0b2545] mt-1">{value}</p>
      {hint && <p className="text-[11px] text-slate-400 mt-0.5">{hint}</p>}
    </button>
  );
}

export default function PainelIndicadores({ demands = [] }) {
  const data = useSstData(['funcionarios', 'obras', 'pendencias', 'ocorrencias', 'treinamentos', 'asos', 'epis', 'dds', 'inspecoes']);
  const { user } = useAuth();
  const { perfilEfetivo } = usePermissoes();
  const [filtros, setFiltros] = useState({ empresa: '', obra: '', responsavel: '', status: '', inicio: '', fim: '' });
  const [active, setActive] = useState(null);
  const [subDrill, setSubDrill] = useState(null);

  const eu = user?.full_name || user?.email || '';
  const tecnico = isTecnico(perfilEfetivo);

  const funcById = useMemo(() => {
    if (!data) return {};
    return Object.fromEntries(data.funcionarios.map((f) => [f.id, f]));
  }, [data]);

  const obrasDisponiveis = useMemo(() => {
    if (!data) return [];
    return obrasDisponiveisNoPeriodo(data.obras || [], filtros.inicio || todayStr, filtros.fim || todayStr);
  }, [data, filtros.inicio, filtros.fim]);
  const nomesObrasDisponiveis = useMemo(() => new Set(obrasDisponiveis.map((obra) => obra.nome)), [obrasDisponiveis]);

  const nomeFunc = (id) => funcById[id]?.nome || '—';
  const obraFunc = (id) => funcById[id]?.obra || '—';
  const empFunc = (id) => funcById[id]?.empresa || '—';

  // Escopo Técnico: limita a seus registros responsáveis
  const scopeTec = (rec, g) => !tecnico || !g.responsavel || g.responsavel(rec) === eu;

  const listas = useMemo(() => {
    if (!data) return null;
    const gFunc = { empresa: (r) => r.empresa, obra: (r) => r.obra, responsavel: (r) => r.supervisor, data: (r) => r.data_admissao, status: (r) => r.status };
    const gPend = { empresa: (r) => r.empresa, obra: (r) => r.obra, responsavel: (r) => r.responsavel, data: (r) => r.data, status: (r) => r.status };
    const gOco = { empresa: (r) => empFunc(r.funcionario_id), obra: (r) => obraFunc(r.funcionario_id), responsavel: (r) => r.responsavel_tratativa, data: (r) => r.data, status: (r) => r.situacao };
    const gTrei = { empresa: (r) => empFunc(r.funcionario_id), obra: (r) => obraFunc(r.funcionario_id), responsavel: () => '', data: (r) => r.data_validade, status: (r) => getStatus(r.data_validade) };
    const gAso = { empresa: (r) => empFunc(r.funcionario_id), obra: (r) => obraFunc(r.funcionario_id), responsavel: () => '', data: (r) => r.data_validade, status: (r) => getStatus(r.data_validade) };
    const gEpi = { empresa: (r) => empFunc(r.funcionario_id), obra: (r) => obraFunc(r.funcionario_id), responsavel: () => '', data: (r) => r.data_validade, status: (r) => getStatus(r.data_validade) };
    const gDds = { empresa: (r) => empFunc(r.funcionario_id), obra: (r) => obraFunc(r.funcionario_id), responsavel: (r) => r.responsavel, data: (r) => r.data, status: (r) => (r.data < todayStr ? 'Pendente' : 'Hoje') };
    const gInsp = { empresa: () => '', obra: (r) => r.obra, responsavel: (r) => r.responsavel, data: (r) => r.data_proxima, status: (r) => r.status };

    const f = (arr, g, extraScope) => (arr || []).filter((r) => {
      const nomeObra = g.obra ? g.obra(r) : '';
      if (nomeObra && nomeObra !== '—' && !nomesObrasDisponiveis.has(nomeObra)) return false;
      return passe(r, g, filtros) && scopeTec(r, g) && (extraScope ? extraScope(r) : true);
    });

    return {
      func: f(data.funcionarios, gFunc, (r) => r.status === 'Ativo'),
      pend: f(data.pendencias, gPend, (r) => r.status !== 'Concluída'),
      nc: f(data.ocorrencias, gOco, (r) => r.tipo === 'Não Conformidade' && r.situacao !== 'Resolvida' && r.situacao !== 'Cancelada'),
      acidentes: f(data.ocorrencias, gOco, (r) => r.tipo === 'Acidente'),
      trei: f(data.treinamentos, gTrei, (r) => getStatus(r.data_validade) !== 'Em dia'),
      asos: f(data.asos, gAso, (r) => getStatus(r.data_validade) !== 'Em dia'),
      epis: f(data.epis, gEpi, (r) => getStatus(r.data_validade) !== 'Em dia'),
      ddsHoje: f(data.dds, gDds, (r) => r.data === todayStr),
      insp: f(data.inspecoes, gInsp, (r) => r.status === 'Pendente'),
      inspAll: f(data.inspecoes, gInsp),
      ddsAll: f(data.dds, gDds),
      apr: f(demands, { empresa: (r) => r.empresa, obra: (r) => r.obra, responsavel: (r) => r.responsavel, data: (r) => r.prazo, status: (r) => r.status }, (r) => r.origem === 'APR' && r.status !== 'Concluído' && r.status !== 'Cancelado'),
      ocoAll: f(data.ocorrencias, gOco),
      treiAll: f(data.treinamentos, gTrei),
      asosAll: f(data.asos, gAso),
      episAll: f(data.epis, gEpi),
      semAso: f(data.funcionarios, gFunc, (r) => r.status === 'Ativo' && !data.asos.some((a) => a.funcionario_id === r.id)),
      semTrei: f(data.funcionarios, gFunc, (r) => r.status === 'Ativo' && !data.treinamentos.some((t) => t.funcionario_id === r.id)),
    };
  }, [data, demands, filtros, tecnico, eu, funcById, nomesObrasDisponiveis]);

  // Agregado de pendências — junta ASO/Treinamento/EPI/Inspeção/APR + entidade Pendências
  const pendAgg = useMemo(() => {
    if (!listas) return [];
    const prio = (s) => (s === 'Vencido' ? 'Alta' : 'Média');
    return [
      ...listas.asos.map((r) => ({ id: 'aso-' + r.id, origem: 'ASO', tipo: 'ASO', descricao: `ASO ${r.tipo || ''}`.trim(), funcionario_id: r.funcionario_id, obra: obraFunc(r.funcionario_id), responsavel: '', data: r.data_exame, prazo: r.data_validade, status: getStatus(r.data_validade), prioridade: prio(getStatus(r.data_validade)) })),
      ...listas.trei.map((r) => ({ id: 'trei-' + r.id, origem: 'Treinamento', tipo: 'Treinamento', descricao: r.nome_curso || r.norma_curso || 'Treinamento', funcionario_id: r.funcionario_id, obra: obraFunc(r.funcionario_id), responsavel: '', data: r.data_realizacao, prazo: r.data_validade, status: getStatus(r.data_validade), prioridade: prio(getStatus(r.data_validade)) })),
      ...listas.epis.map((r) => ({ id: 'epi-' + r.id, origem: 'EPI', tipo: 'EPI', descricao: r.item || 'EPI', funcionario_id: r.funcionario_id, obra: obraFunc(r.funcionario_id), responsavel: '', data: r.data_entrega, prazo: r.data_validade, status: getStatus(r.data_validade), prioridade: prio(getStatus(r.data_validade)) })),
      ...listas.insp.map((r) => ({ id: 'insp-' + r.id, origem: 'Inspeção', tipo: 'Inspeção', descricao: r.tipo || 'Inspeção', funcionario_id: r.funcionario_id, obra: r.obra, responsavel: r.responsavel, data: r.data, prazo: r.data_proxima, status: r.status, prioridade: 'Média' })),
      ...listas.pend.map((r) => ({ id: 'pend-' + r.id, origem: 'Pendencia', tipo: r.tipo, descricao: r.descricao || r.item, funcionario_id: r.funcionario_id, obra: r.obra, responsavel: r.responsavel, data: r.data, prazo: r.prazo, status: r.prazo && r.prazo < todayStr ? 'Atrasada' : r.status, prioridade: r.prioridade })),
      ...listas.apr.map((r) => ({ id: 'apr-' + r.id, origem: 'APR', tipo: 'APR', descricao: r.titulo || 'APR', funcionario_id: '', obra: r.obra, responsavel: r.responsavel, data: '', prazo: r.prazo, status: r.prazo && r.prazo < todayStr ? 'Atrasada' : r.status, prioridade: r.prioridade })),
    ];
  }, [listas, funcById]);

  const opciones = useMemo(() => {
    if (!data) return { empresas: [], obras: [], responsaveis: [] };
    const uniq = (arr) => [...new Set(arr.filter(Boolean))].sort();
    return {
      empresas: uniq(data.funcionarios.map((f) => f.empresa)),
      obras: uniq(obrasDisponiveis.map((obra) => obra.nome)),
      responsaveis: uniq([
        ...data.pendencias.map((p) => p.responsavel),
        ...data.inspecoes.map((i) => i.responsavel),
        ...data.dds.map((d) => d.responsavel),
        ...data.ocorrencias.map((o) => o.responsavel_tratativa),
      ]),
    };
  }, [data, obrasDisponiveis]);

  // Obras (com colaboradores ativos) sem DDS recente
  const obrasSemDds = useMemo(() => (data ? avaliarDdsAusente(data).filter((item) => nomesObrasDisponiveis.has(item.obra)) : []), [data, nomesObrasDisponiveis]);

  // Índice de conformidade
  const indice = useMemo(() => {
    if (!listas) return null;
    const cat = (nome, arr, conf, pend, venc) => {
      const c = arr.filter(conf).length;
      const p = arr.filter(pend).length;
      const v = arr.filter(venc).length;
      return { nome, conforme: c, pendente: p, vencido: v, total: c + p + v };
    };
    const cats = [
      cat('ASO', listas.asosAll, (r) => getStatus(r.data_validade) === 'Em dia', (r) => getStatus(r.data_validade) === 'A vencer', (r) => getStatus(r.data_validade) === 'Vencido'),
      cat('Treinamentos', listas.treiAll, (r) => getStatus(r.data_validade) === 'Em dia', (r) => getStatus(r.data_validade) === 'A vencer', (r) => getStatus(r.data_validade) === 'Vencido'),
      cat('EPI', listas.episAll, (r) => getStatus(r.data_validade) === 'Em dia', (r) => getStatus(r.data_validade) === 'A vencer', (r) => getStatus(r.data_validade) === 'Vencido'),
      cat('Inspeções', listas.inspAll, (r) => r.status === 'Conforme', (r) => r.status === 'Pendente', (r) => r.status === 'Não Conforme'),
      cat('DDS', listas.ddsAll, (r) => r.data <= todayStr, (r) => r.data > todayStr, () => false),
      cat('Ocorrências', listas.ocoAll, (r) => r.situacao === 'Resolvida', (r) => r.situacao === 'Aberta' || r.situacao === 'Em Andamento', () => false),
    ];
    const tot = cats.reduce((a, c) => ({ c: a.c + c.conforme, t: a.t + c.total }), { c: 0, t: 0 });
    return { cats, pct: tot.t ? Math.round((tot.c / tot.t) * 100) : null, total: tot.t, conforme: tot.c };
  }, [listas]);

  if (!data || !listas) {
    return (
      <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-4">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="h-[96px] rounded-xl bg-slate-100 animate-pulse" />
        ))}
      </section>
    );
  }

  const filtroObra = (arr) => [...new Set(arr.map((r) => r.obra).filter(Boolean))].map((v) => ({ value: v, label: v }));
  const filtroResp = (arr) => [...new Set(arr.map((r) => r.responsavel).filter(Boolean))].map((v) => ({ value: v, label: v }));

  // Sub-drill do Semáforo — registros reais da categoria selecionada no Índice de Conformidade
  const nivelValidade = (r) => { const s = getStatus(r.data_validade); return s === 'Em dia' ? 'Conforme' : s === 'A vencer' ? 'Pendente' : 'Vencido'; };
  const subDrillMap = subDrill ? {
    ASO: { title: 'ASOs — Semáforo de Conformidade', icon: Stethoscope, rows: listas.asosAll, route: '/asos', nivel: nivelValidade, columns: [ { key: 'colab', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' }, { key: 'venc', label: 'Vencimento', value: (r) => fmt(r.data_validade) }, { key: 'st', label: 'Nível', render: (r) => <Pill status={nivelValidade(r)} /> } ] },
    Treinamentos: { title: 'Treinamentos — Semáforo de Conformidade', icon: GraduationCap, rows: listas.treiAll, route: '/treinamentos', nivel: nivelValidade, columns: [ { key: 'colab', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 'curso', label: 'Curso', value: (r) => r.nome_curso || r.norma_curso || '—' }, { key: 'venc', label: 'Vencimento', value: (r) => fmt(r.data_validade) }, { key: 'st', label: 'Nível', render: (r) => <Pill status={nivelValidade(r)} /> } ] },
    EPI: { title: 'EPIs — Semáforo de Conformidade', icon: HardHat, rows: listas.episAll, route: '/epis', nivel: nivelValidade, columns: [ { key: 'colab', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 'item', label: 'EPI', value: (r) => r.item || '—' }, { key: 'venc', label: 'Vencimento', value: (r) => fmt(r.data_validade) }, { key: 'st', label: 'Nível', render: (r) => <Pill status={nivelValidade(r)} /> } ] },
    'Inspeções': { title: 'Inspeções — Semáforo de Conformidade', icon: FileWarning, rows: listas.inspAll, route: '/formularios', nivel: (r) => r.status === 'Conforme' ? 'Conforme' : r.status === 'Pendente' ? 'Pendente' : 'Vencido', columns: [ { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' }, { key: 'obra', label: 'Obra', value: (r) => r.obra || '—' }, { key: 'resp', label: 'Responsável', value: (r) => r.responsavel || '—' }, { key: 'prox', label: 'Data prevista', value: (r) => fmt(r.data_proxima) }, { key: 'st', label: 'Nível', render: (r) => <Pill status={r.status} /> }, { key: 'obs', label: 'Obs.', value: (r) => r.observacao || '—' } ] },
    DDS: { title: 'DDS — Semáforo de Conformidade', icon: CalendarCheck, rows: listas.ddsAll, route: '/formularios', nivel: (r) => r.data <= todayStr ? 'Conforme' : 'Pendente', columns: [ { key: 'resp', label: 'Responsável', value: (r) => r.responsavel || nomeFunc(r.funcionario_id) }, { key: 'tema', label: 'Tema', value: (r) => r.tema || '—' }, { key: 'data', label: 'Data', value: (r) => fmt(r.data) }, { key: 'st', label: 'Nível', render: (r) => <Pill status={r.data <= todayStr ? 'Conforme' : 'Pendente'} /> } ] },
    'Ocorrências': { title: 'Ocorrências — Semáforo de Conformidade', icon: AlertTriangle, rows: listas.ocoAll, route: '/ocorrencias', nivel: (r) => r.situacao === 'Resolvida' ? 'Conforme' : 'Pendente', columns: [ { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' }, { key: 'colab', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 'obra', label: 'Obra', value: (r) => obraFunc(r.funcionario_id) }, { key: 'data', label: 'Data', value: (r) => fmt(r.data) }, { key: 'st', label: 'Nível', render: (r) => <Pill status={r.situacao} /> }, { key: 'grav', label: 'Gravidade', value: (r) => r.gravidade || '—' } ] },
  } : null;
  const subDrillCfg = subDrillMap && subDrillMap[subDrill] ? (() => {
    const cfg = subDrillMap[subDrill];
    return {
      open: true,
      onOpenChange: (o) => !o && setSubDrill(null),
      title: cfg.title,
      subtitle: 'Conforme / Pendente / Vencido — use o filtro de nível para isolar cada faixa',
      icon: cfg.icon,
      columns: cfg.columns,
      rows: cfg.rows,
      filterDefs: [{ id: 'nivel', label: 'Nível', allLabel: 'Todos', options: [{ value: 'Conforme', label: 'Conforme' }, { value: 'Pendente', label: 'Pendente' }, { value: 'Vencido', label: 'Vencido' }], apply: (r, v) => cfg.nivel(r) === v }],
      renderAction: (r) => <ActLink to={cfg.route}>Abrir <ArrowRight className="w-3 h-3" /></ActLink>,
    };
  })() : null;

  return (
    <>
      <FiltrosDashboard empresas={opciones.empresas} obras={opciones.obras} responsaveis={opciones.responsaveis} filtros={filtros} setFiltros={setFiltros} />

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-4">
        <Card icon={Users} label="Funcionários Ativos" value={listas.func.length} tone="navy" hint="Clique para ver a lista" onClick={() => setActive('func')} />
        <Card icon={UserX} label="Sem ASO Cadastrado" value={listas.semAso.length} tone={listas.semAso.length ? 'red' : 'green'} hint="Risco invisível — nenhum ASO no cadastro" onClick={() => setActive('semAso')} />
        <Card icon={UserX} label="Sem NR Cadastrada" value={listas.semTrei.length} tone={listas.semTrei.length ? 'red' : 'green'} hint="Risco invisível — nenhum treinamento no cadastro" onClick={() => setActive('semTrei')} />
        <Card icon={MapPinOff} label="Obras sem DDS" value={obrasSemDds.length} tone={obrasSemDds.length ? 'red' : 'green'} hint="Sem registro nos últimos 7 dias" onClick={() => setActive('semDds')} />
        <Card icon={TrendingUp} label="Índice de Conformidade" value={indice.pct == null ? '—' : `${indice.pct}%`} tone={indice.pct == null ? 'gray' : indice.pct >= 80 ? 'green' : indice.pct >= 60 ? 'amber' : 'red'} hint={`${indice.conforme}/${indice.total} itens conformes`} onClick={() => setActive('indice')} />
        <Card icon={ClipboardCheck} label="Pendências" value={pendAgg.length} tone={pendAgg.length ? 'amber' : 'green'} hint="ASO/Treino/EPI/Inspeção/APR em aberto" onClick={() => setActive('pend')} />
        <Card icon={AlertTriangle} label="NC Abertas" value={listas.nc.length} tone={listas.nc.length ? 'red' : 'green'} hint="Não conformidades" onClick={() => setActive('nc')} />
        <Card icon={FileWarning} label="Inspeções Pendentes" value={listas.insp.length} tone={listas.insp.length ? 'amber' : 'green'} hint="Aguardando execução" onClick={() => setActive('insp')} />
        <Card icon={GraduationCap} label="Treinamentos Vencendo" value={listas.trei.length} tone={listas.trei.length ? 'amber' : 'green'} hint="Vencido ou ≤ 30 dias" onClick={() => setActive('trei')} />
        <Card icon={Stethoscope} label="ASOs Vencendo" value={listas.asos.length} tone={listas.asos.length ? 'amber' : 'green'} hint="Vencido ou ≤ 30 dias" onClick={() => setActive('asos')} />
        <Card icon={CalendarCheck} label="DDS Hoje" value={listas.ddsHoje.length} tone="blue" hint="Previstos para hoje" onClick={() => setActive('dds')} />
        <Card icon={ShieldCheck} label="Dias Sem Acidente" value={listas.acidentes.length ? differenceInCalendarDays(today, parseISO([...listas.acidentes].sort((a, b) => (a.data < b.data ? 1 : -1))[0].data)) : '—'} tone="green" hint={listas.acidentes.length ? 'Desde o último acidente' : 'Nenhum acidente registrado'} onClick={() => setActive('dias')} />
        <Card icon={HardHat} label="EPIs Vencendo" value={listas.epis.length} tone={listas.epis.length ? 'amber' : 'green'} hint="Vencido ou ≤ 30 dias" onClick={() => setActive('epis')} />
        <Card icon={FileCheck} label="APR Pendentes" value={listas.apr.length} tone={listas.apr.length ? 'amber' : 'green'} hint="Análises Preliminares de Risco" onClick={() => setActive('apr')} />
      </div>

      {/* Funcionários Ativos */}
      <DrillDownDialog
        open={active === 'func'} onOpenChange={(o) => !o && setActive(null)}
        title="Funcionários Ativos" subtitle="Colaboradores com situação ativa e status de ASO/Treinamento/EPI" icon={Users}
        columns={[
          { key: 'nome', label: 'Colaborador', value: (r) => r.nome },
          { key: 'funcao', label: 'Cargo', value: (r) => r.funcao || '—' },
          { key: 'empresa', label: 'Empresa', value: (r) => r.empresa || '—' },
          { key: 'obra', label: 'Obra', value: (r) => r.obra || '—' },
          { key: 'admissao', label: 'Admissão', value: (r) => fmt(r.data_admissao) },
          { key: 'aso', label: 'ASO', render: (r) => <Pill status={getStatus([...data.asos].filter((a) => a.funcionario_id === r.id).sort((a, b) => (a.data_validade < b.data_validade ? 1 : -1))[0]?.data_validade) || 'Em dia'} /> },
          { key: 'trei', label: 'Trein.', render: (r) => <Pill status={getStatus([...data.treinamentos].filter((t) => t.funcionario_id === r.id).sort((a, b) => (a.data_validade < b.data_validade ? 1 : -1))[0]?.data_validade) || 'Em dia'} /> },
          { key: 'epi', label: 'EPI', render: (r) => <Pill status={getStatus([...data.epis].filter((e) => e.funcionario_id === r.id).sort((a, b) => (a.data_validade < b.data_validade ? 1 : -1))[0]?.data_validade) || 'Em dia'} /> },
        ]}
        rows={listas.func}
        renderAction={(r) => <ActLink to={`/funcionarios/${r.id}`}>Ver cadastro <ArrowRight className="w-3 h-3" /></ActLink>}
      />

      {/* Sem ASO cadastrado */}
      <DrillDownDialog
        open={active === 'semAso'} onOpenChange={(o) => !o && setActive(null)}
        title="Colaboradores sem ASO cadastrado" subtitle="Ativos sem NENHUM registro de ASO — risco de admissão/permanência irregular" icon={UserX}
        columns={[
          { key: 'nome', label: 'Colaborador', value: (r) => r.nome },
          { key: 'funcao', label: 'Cargo', value: (r) => r.funcao || '—' },
          { key: 'empresa', label: 'Empresa', value: (r) => r.empresa || '—' },
          { key: 'obra', label: 'Obra', value: (r) => r.obra || '—' },
          { key: 'admissao', label: 'Admissão', value: (r) => fmt(r.data_admissao) },
        ]}
        rows={listas.semAso}
        emptyMessage="Todos os colaboradores ativos têm ao menos um ASO cadastrado."
        renderAction={(r) => <ActLink to={`/funcionarios/${r.id}`}>Cadastrar ASO <ArrowRight className="w-3 h-3" /></ActLink>}
      />

      {/* Sem NR cadastrada */}
      <DrillDownDialog
        open={active === 'semTrei'} onOpenChange={(o) => !o && setActive(null)}
        title="Colaboradores sem treinamento (NR) cadastrado" subtitle="Ativos sem NENHUM registro de treinamento — risco de operação sem capacitação" icon={UserX}
        columns={[
          { key: 'nome', label: 'Colaborador', value: (r) => r.nome },
          { key: 'funcao', label: 'Cargo', value: (r) => r.funcao || '—' },
          { key: 'empresa', label: 'Empresa', value: (r) => r.empresa || '—' },
          { key: 'obra', label: 'Obra', value: (r) => r.obra || '—' },
          { key: 'admissao', label: 'Admissão', value: (r) => fmt(r.data_admissao) },
        ]}
        rows={listas.semTrei}
        emptyMessage="Todos os colaboradores ativos têm ao menos um treinamento cadastrado."
        renderAction={(r) => <ActLink to={`/funcionarios/${r.id}`}>Cadastrar NR <ArrowRight className="w-3 h-3" /></ActLink>}
      />

      {/* Obras sem DDS */}
      <DrillDownDialog
        open={active === 'semDds'} onOpenChange={(o) => !o && setActive(null)}
        title="Obras sem DDS recente" subtitle="Obras com colaboradores ativos sem DDS registrado nos últimos 7 dias" icon={MapPinOff}
        columns={[
          { key: 'obra', label: 'Obra', value: (r) => r.obra },
          { key: 'ultima', label: 'Último DDS', value: (r) => r.ultimaData ? fmt(r.ultimaData) : 'Nunca registrado' },
          { key: 'dias', label: 'Dias sem DDS', align: 'right', value: (r) => r.dias == null ? '—' : r.dias },
        ]}
        rows={obrasSemDds}
        emptyMessage="Todas as obras com colaboradores ativos têm DDS recente."
        renderAction={() => <ActLink to="/obras">Registrar DDS <ArrowRight className="w-3 h-3" /></ActLink>}
      />

      {/* Pendências */}
      <DrillDownDialog
        open={active === 'pend'} onOpenChange={(o) => !o && setActive(null)}
        title="Pendências do SGI SST" subtitle="ASOs, Treinamentos, EPIs, Inspeções, APRs e pendências em aberto" icon={ClipboardCheck}
        filterDefs={[
          { id: 'rapido', label: 'Filtro', allLabel: 'Todas', options: [{ value: 'hoje', label: 'Vence hoje' }, { value: 'atrasada', label: 'Atrasadas' }, { value: 'alta', label: 'Alta prioridade' }], apply: (r, v) => v === 'hoje' ? r.prazo === todayStr : v === 'atrasada' ? (r.prazo && r.prazo < todayStr) : v === 'alta' ? r.prioridade === 'Alta' || r.prioridade === 'Crítica' : true },
          { id: 'tipo', label: 'Tipo', allLabel: 'Todos', options: [...new Set(pendAgg.map((r) => r.tipo).filter(Boolean))].map((v) => ({ value: v, label: v })), apply: (r, v) => r.tipo === v },
          { id: 'obra', label: 'Obra', allLabel: 'Todas', options: [...new Set(pendAgg.map((r) => r.obra).filter(Boolean))].map((v) => ({ value: v, label: v })), apply: (r, v) => r.obra === v },
          { id: 'resp', label: 'Responsável', allLabel: 'Todos', options: [...new Set(pendAgg.map((r) => r.responsavel).filter(Boolean))].map((v) => ({ value: v, label: v })), apply: (r, v) => r.responsavel === v },
        ]}
        columns={[
          { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' },
          { key: 'desc', label: 'Descrição', value: (r) => r.descricao || '—' },
          { key: 'colab', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) },
          { key: 'obra', label: 'Obra', value: (r) => r.obra || '—' },
          { key: 'resp', label: 'Responsável', value: (r) => r.responsavel || '—' },
          { key: 'prazo', label: 'Prazo', value: (r) => fmt(r.prazo) },
          { key: 'status', label: 'Status', render: (r) => <Pill status={r.prazo && r.prazo < todayStr ? 'Atrasada' : r.status} /> },
          { key: 'prio', label: 'Prioridade', value: (r) => r.prioridade || '—' },
          { key: 'atraso', label: 'Dias atraso', align: 'right', value: (r) => diasAtraso(r.prazo) },
        ]}
        rows={pendAgg}
        emptyMessage="Nenhuma pendência em aberto — tudo conforme."
        renderAction={(r) => {
          const rota = { ASO: '/asos', Treinamento: '/treinamentos', EPI: '/epis', Inspeção: '/formularios', APR: '/formularios', Pendencia: `/funcionarios/${r.funcionario_id}` };
          return (
            <div className="flex justify-end gap-1.5">
              {r.funcionario_id && <ActLink to={`/funcionarios/${r.funcionario_id}`} variant="outline">Ver detalhes</ActLink>}
              <ActLink to={rota[r.origem] || '/painel/quadro'}>Resolver <ArrowRight className="w-3 h-3" /></ActLink>
            </div>
          );
        }}
      />

      {/* NC Abertas */}
      <DrillDownDialog
        open={active === 'nc'} onOpenChange={(o) => !o && setActive(null)}
        title="Não Conformidades Abertas" subtitle="NCs em aberto ou em tratamento" icon={AlertTriangle}
        filterDefs={[
          { id: 'sit', label: 'Status', allLabel: 'Todos', options: [...new Set(listas.nc.map((r) => r.situacao))].map((v) => ({ value: v, label: v })), apply: (r, v) => r.situacao === v },
          { id: 'grav', label: 'Gravidade', allLabel: 'Todas', options: [...new Set(listas.nc.map((r) => r.gravidade))].map((v) => ({ value: v, label: v })), apply: (r, v) => r.gravidade === v },
        ]}
        columns={[
          { key: 'id', label: 'NC', value: (r) => `#${(r.id || '').slice(-6)}` },
          { key: 'desc', label: 'Descrição', value: (r) => r.descricao || '—' },
          { key: 'colab', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) },
          { key: 'obra', label: 'Obra', value: (r) => obraFunc(r.funcionario_id) },
          { key: 'resp', label: 'Responsável', value: (r) => r.responsavel_tratativa || '—' },
          { key: 'abert', label: 'Abertura', value: (r) => fmt(r.data) },
          { key: 'prazo', label: 'Prazo', value: (r) => fmt(r.prazo_tratativa) },
          { key: 'grav', label: 'Gravidade', value: (r) => r.gravidade || '—' },
          { key: 'sit', label: 'Status', render: (r) => <Pill status={r.situacao} /> },
          { key: 'dias', label: 'Dias aberto', align: 'right', value: (r) => r.data ? differenceInCalendarDays(today, parseISO(r.data)) : 0 },
        ]}
        rows={listas.nc}
        renderAction={(r) => <ActLink to="/ocorrencias">Abrir NC <ArrowRight className="w-3 h-3" /></ActLink>}
      />

      {/* Treinamentos Vencendo */}
      <DrillDownDialog
        open={active === 'trei'} onOpenChange={(o) => !o && setActive(null)}
        title="Treinamentos Vencendo" subtitle="Vencidos ou com vencimento em até 30 dias" icon={GraduationCap}
        filterDefs={[
          { id: 'fx', label: 'Faixa', allLabel: 'Todas', options: [{ value: 'vencido', label: 'Vencido' }, { value: '7', label: 'Vence em até 7 dias' }, { value: '15', label: 'Vence em até 15 dias' }, { value: '30', label: 'Vence em até 30 dias' }], apply: (r, v) => { const d = differenceInCalendarDays(parseISO(r.data_validade), today); if (v === 'vencido') return d < 0; if (v === '7') return d >= 0 && d <= 7; if (v === '15') return d >= 0 && d <= 15; if (v === '30') return d >= 0 && d <= 30; return true; } },
        ]}
        columns={[
          { key: 'colab', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) },
          { key: 'curso', label: 'Treinamento', value: (r) => r.nome_curso || r.norma_curso || '—' },
          { key: 'real', label: 'Realização', value: (r) => fmt(r.data_realizacao) },
          { key: 'venc', label: 'Vencimento', value: (r) => fmt(r.data_validade) },
          { key: 'dias', label: 'Dias restantes', align: 'right', value: (r) => differenceInCalendarDays(parseISO(r.data_validade), today) },
          { key: 'obra', label: 'Obra', value: (r) => obraFunc(r.funcionario_id) },
          { key: 'status', label: 'Status', render: (r) => <Pill status={getStatus(r.data_validade)} /> },
        ]}
        rows={listas.trei}
        renderAction={(r) => <ActLink to="/treinamentos">Ver treinamento <ArrowRight className="w-3 h-3" /></ActLink>}
      />

      {/* ASOs Vencendo */}
      <DrillDownDialog
        open={active === 'asos'} onOpenChange={(o) => !o && setActive(null)}
        title="ASOs Vencendo" subtitle="Exames vencidos ou com vencimento em até 30 dias" icon={Stethoscope}
        filterDefs={[
          { id: 'fx', label: 'Faixa', allLabel: 'Todas', options: [{ value: 'vencido', label: 'Vencido' }, { value: '7', label: 'Vence em até 7 dias' }, { value: '15', label: 'Vence em até 15 dias' }, { value: '30', label: 'Vence em até 30 dias' }], apply: (r, v) => { const d = differenceInCalendarDays(parseISO(r.data_validade), today); if (v === 'vencido') return d < 0; if (v === '7') return d >= 0 && d <= 7; if (v === '15') return d >= 0 && d <= 15; if (v === '30') return d >= 0 && d <= 30; return true; } },
        ]}
        columns={[
          { key: 'colab', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) },
          { key: 'tipo', label: 'Tipo ASO', value: (r) => r.tipo || '—' },
          { key: 'exame', label: 'Exame', value: (r) => fmt(r.data_exame) },
          { key: 'venc', label: 'Vencimento', value: (r) => fmt(r.data_validade) },
          { key: 'dias', label: 'Dias restantes', align: 'right', value: (r) => differenceInCalendarDays(parseISO(r.data_validade), today) },
          { key: 'obra', label: 'Obra', value: (r) => obraFunc(r.funcionario_id) },
          { key: 'status', label: 'Status', render: (r) => <Pill status={getStatus(r.data_validade)} /> },
        ]}
        rows={listas.asos}
        renderAction={(r) => <ActLink to="/asos">Ver ASO <ArrowRight className="w-3 h-3" /></ActLink>}
      />

      {/* DDS Hoje */}
      <DrillDownDialog
        open={active === 'dds'} onOpenChange={(o) => !o && setActive(null)}
        title="DDS Previstos para Hoje" subtitle="Diálogos Diários de Segurança agendados para a data de hoje" icon={CalendarCheck}
        columns={[
          { key: 'colab', label: 'Responsável', value: (r) => r.responsavel || nomeFunc(r.funcionario_id) },
          { key: 'tema', label: 'Tema', value: (r) => r.tema || '—' },
          { key: 'obra', label: 'Obra', value: (r) => obraFunc(r.funcionario_id) },
          { key: 'data', label: 'Data', value: (r) => fmt(r.data) },
          { key: 'status', label: 'Status', render: (r) => <Pill status={r.data < todayStr ? 'Pendente' : 'Agendado'} /> },
        ]}
        rows={listas.ddsHoje}
        emptyMessage="Nenhum DDS previsto para hoje."
        renderAction={(r) => <ActLink to="/formularios">Abrir DDS <ArrowRight className="w-3 h-3" /></ActLink>}
      />

      {/* Inspeções Pendentes */}
      <DrillDownDialog
        open={active === 'insp'} onOpenChange={(o) => !o && setActive(null)}
        title="Inspeções Pendentes" subtitle="Inspeções aguardando execução" icon={FileWarning}
        filterDefs={[
          { id: 'obra', label: 'Obra', allLabel: 'Todas', options: filtroObra(listas.insp), apply: (r, v) => r.obra === v },
          { id: 'resp', label: 'Responsável', allLabel: 'Todos', options: filtroResp(listas.insp), apply: (r, v) => r.responsavel === v },
        ]}
        columns={[
          { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' },
          { key: 'obra', label: 'Obra', value: (r) => r.obra || '—' },
          { key: 'resp', label: 'Responsável', value: (r) => r.responsavel || '—' },
          { key: 'prox', label: 'Data prevista', value: (r) => fmt(r.data_proxima) },
          { key: 'status', label: 'Status', render: (r) => <Pill status={r.status} /> },
        ]}
        rows={listas.insp}
        renderAction={(r) => <ActLink to="/formularios">Executar <ArrowRight className="w-3 h-3" /></ActLink>}
      />

      {/* EPIs Vencendo */}
      <DrillDownDialog
        open={active === 'epis'} onOpenChange={(o) => !o && setActive(null)}
        title="EPIs Vencendo" subtitle="EPIs vencidos ou com vencimento em até 30 dias" icon={HardHat}
        columns={[
          { key: 'colab', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) },
          { key: 'item', label: 'EPI', value: (r) => r.item || '—' },
          { key: 'entrega', label: 'Entrega', value: (r) => fmt(r.data_entrega) },
          { key: 'venc', label: 'Vencimento', value: (r) => fmt(r.data_validade) },
          { key: 'dias', label: 'Dias restantes', align: 'right', value: (r) => differenceInCalendarDays(parseISO(r.data_validade), today) },
          { key: 'obra', label: 'Obra', value: (r) => obraFunc(r.funcionario_id) },
          { key: 'status', label: 'Status', render: (r) => <Pill status={getStatus(r.data_validade)} /> },
        ]}
        rows={listas.epis}
        renderAction={(r) => <ActLink to="/epis">Ver EPI <ArrowRight className="w-3 h-3" /></ActLink>}
      />

      {/* Dias Sem Acidente */}
      <DrillDownDialog
        open={active === 'dias'} onOpenChange={(o) => !o && setActive(null)}
        title="Dias Sem Acidente" subtitle={listas.acidentes.length ? `Último acidente registrado — ${listas.acidentes.length} acidente(s) no histórico` : 'Nenhum acidente registrado no sistema.'} icon={ShieldCheck}
        columns={[
          { key: 'data', label: 'Data', value: (r) => fmt(r.data) },
          { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' },
          { key: 'obra', label: 'Obra', value: (r) => obraFunc(r.funcionario_id) },
          { key: 'grav', label: 'Gravidade', value: (r) => r.gravidade || '—' },
          { key: 'desc', label: 'Descrição', value: (r) => r.descricao || '—' },
        ]}
        rows={[...listas.acidentes].sort((a, b) => (a.data < b.data ? 1 : -1))}
        emptyMessage="Nenhum acidente registrado no sistema."
        renderAction={(r) => <ActLink to="/ocorrencias">Ver ocorrência <ArrowRight className="w-3 h-3" /></ActLink>}
      />

      {/* APR Pendentes */}
      <DrillDownDialog
        open={active === 'apr'} onOpenChange={(o) => !o && setActive(null)}
        title="APR Pendentes" subtitle="Análises Preliminares de Risco em aberto" icon={FileCheck}
        filterDefs={[
          { id: 'rapido', label: 'Filtro', allLabel: 'Todas', options: [{ value: 'hoje', label: 'Vence hoje' }, { value: 'atrasada', label: 'Atrasadas' }, { value: 'alta', label: 'Alta prioridade' }], apply: (r, v) => v === 'hoje' ? r.prazo === todayStr : v === 'atrasada' ? (r.prazo && r.prazo < todayStr) : v === 'alta' ? r.prioridade === 'Alta' || r.prioridade === 'Crítica' : true },
          { id: 'obra', label: 'Obra', allLabel: 'Todas', options: filtroObra(listas.apr), apply: (r, v) => r.obra === v },
          { id: 'resp', label: 'Responsável', allLabel: 'Todos', options: filtroResp(listas.apr), apply: (r, v) => r.responsavel === v },
          { id: 'prio', label: 'Prioridade', allLabel: 'Todas', options: [{ value: 'Baixa', label: 'Baixa' }, { value: 'Média', label: 'Média' }, { value: 'Alta', label: 'Alta' }, { value: 'Crítica', label: 'Crítica' }], apply: (r, v) => r.prioridade === v },
        ]}
        columns={[
          { key: 'titulo', label: 'APR', value: (r) => r.titulo || '—' },
          { key: 'obra', label: 'Obra', value: (r) => r.obra || '—' },
          { key: 'resp', label: 'Responsável', value: (r) => r.responsavel || '—' },
          { key: 'prazo', label: 'Prazo', value: (r) => fmt(r.prazo) },
          { key: 'status', label: 'Status', render: (r) => <Pill status={r.prazo && r.prazo < todayStr ? 'Atrasada' : r.status} /> },
          { key: 'prio', label: 'Prioridade', value: (r) => r.prioridade || '—' },
          { key: 'atraso', label: 'Dias atraso', align: 'right', value: (r) => diasAtraso(r.prazo) },
        ]}
        rows={listas.apr}
        emptyMessage="Nenhuma APR pendente."
        renderAction={(r) => (
          <div className="flex justify-end gap-1.5">
            <ActLink to="/formularios" variant="outline">Ver detalhes</ActLink>
            <ActLink to="/painel/quadro">Resolver <ArrowRight className="w-3 h-3" /></ActLink>
          </div>
        )}
      />

      {/* Índice de Conformidade */}
      <DrillDownDialog
        open={active === 'indice'} onOpenChange={(o) => !o && setActive(null)}
        title="Índice de Conformidade" subtitle={`Conformidade geral: ${indice.pct == null ? '— (sem registros)' : indice.pct + '%'} (${indice.conforme} conformes de ${indice.total} analisados)`} icon={TrendingUp}
        columns={[
          { key: 'cat', label: 'Categoria', value: (r) => r.nome },
          { key: 'conf', label: 'Conforme', align: 'right', render: (r) => <Pill status="Conforme" /> },
          { key: 'c', label: 'Qtd', align: 'right', value: (r) => r.conforme },
          { key: 'pend', label: 'Pendente', render: (r) => <Pill status="Pendente" /> },
          { key: 'p', label: 'Qtd', align: 'right', value: (r) => r.pendente },
          { key: 'venc', label: 'Vencido/Crítico', render: (r) => <Pill status="Vencido" /> },
          { key: 'v', label: 'Qtd', align: 'right', value: (r) => r.vencido },
        ]}
        rows={indice.cats}
        footer={<span className="text-xs">Clique em uma categoria para abrir o módulo correspondente</span>}
        renderAction={(r) => {
          const rota = { ASO: '/asos', Treinamentos: '/treinamentos', EPI: '/epis', Inspeções: '/formularios', DDS: '/formularios', Ocorrências: '/ocorrencias' };
          return (
            <div className="flex justify-end gap-1.5">
              <button onClick={() => setSubDrill(r.nome)} className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-md bg-[#0b2545] text-white hover:bg-[#0b2545]/90 whitespace-nowrap">Ver registros <ArrowRight className="w-3 h-3" /></button>
              <ActLink to={rota[r.nome] || '/inteligencia'} variant="outline">Módulo</ActLink>
            </div>
          );
        }}
      />

      {subDrillCfg && <DrillDownDialog {...subDrillCfg} />}
    </>
  );
}