import React from 'react';
import { Building2, HardHat, UserCircle, Filter, X } from 'lucide-react';

// Barra de filtros global do Dashboard — recalcula todos os indicadores.
export default function FiltrosDashboard({ empresas, obras, responsaveis, filtros, setFiltros }) {
  const set = (k, v) => setFiltros((f) => ({ ...f, [k]: v || '' }));
  const limpar = () => setFiltros({ empresa: '', obra: '', responsavel: '', status: '', inicio: '', fim: '' });
  const ativos = Object.values(filtros).some(Boolean);

  const sel = 'h-9 rounded-lg border border-slate-200 bg-white px-2.5 text-sm text-[#0b2545] focus:outline-none focus:border-primary/40';

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-3 mb-4">
      <div className="flex items-center gap-2 mb-2">
        <Filter className="w-4 h-4 text-slate-400" />
        <h2 className="text-sm font-semibold text-[#0b2545]">Filtros do Painel</h2>
        {ativos && (
          <button onClick={limpar} className="ml-auto inline-flex items-center gap-1 text-xs text-slate-500 hover:text-red-600">
            <X className="w-3.5 h-3.5" /> Limpar
          </button>
        )}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <label className="flex items-center gap-1.5">
          <Building2 className="w-4 h-4 text-slate-400" />
          <select value={filtros.empresa} onChange={(e) => set('empresa', e.target.value)} className={sel}>
            <option value="">Todas as empresas</option>
            {empresas.map((e) => <option key={e} value={e}>{e}</option>)}
          </select>
        </label>
        <label className="flex items-center gap-1.5">
          <HardHat className="w-4 h-4 text-slate-400" />
          <select value={filtros.obra} onChange={(e) => set('obra', e.target.value)} className={sel}>
            <option value="">Todas as obras</option>
            {obras.map((o) => <option key={o} value={o}>{o}</option>)}
          </select>
        </label>
        <label className="flex items-center gap-1.5">
          <UserCircle className="w-4 h-4 text-slate-400" />
          <select value={filtros.responsavel} onChange={(e) => set('responsavel', e.target.value)} className={sel}>
            <option value="">Todos os responsáveis</option>
            {responsaveis.map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
        </label>
        <label className="flex items-center gap-1.5">
          <span className="text-xs text-slate-500">Status</span>
          <select value={filtros.status} onChange={(e) => set('status', e.target.value)} className={sel}>
            <option value="">Todos</option>
            <option value="Ativo">Ativo</option>
            <option value="Pendente">Pendente</option>
            <option value="Atrasado">Atrasado</option>
            <option value="Atrasada">Atrasada</option>
            <option value="Concluída">Concluída</option>
            <option value="Vencido">Vencido</option>
            <option value="A vencer">A vencer</option>
            <option value="Em dia">Em dia</option>
            <option value="Conforme">Conforme</option>
            <option value="Não Conforme">Não Conforme</option>
          </select>
        </label>
        <label className="flex items-center gap-1.5">
          <span className="text-xs text-slate-500">De</span>
          <input type="date" value={filtros.inicio} onChange={(e) => set('inicio', e.target.value)} className={sel} />
          <span className="text-xs text-slate-500">até</span>
          <input type="date" value={filtros.fim} onChange={(e) => set('fim', e.target.value)} className={sel} />
        </label>
      </div>
      {ativos && (
        <p className="text-[11px] text-slate-400 mt-2">Os indicadores abaixo estão recalculados conforme os filtros aplicados.</p>
      )}
    </section>
  );
}