import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, GraduationCap, HardHat } from 'lucide-react';
import { useSstData } from '@/hooks/useSstEntitiesData';
import useDemandasQuery from '@/hooks/useDemandasQuery';
import { conformidade } from '@/lib/relatorios';
import PainelIndicadores from './PainelIndicadores';
import VisaoPorObra from './VisaoPorObra';
import AgendaSST from '@/components/agenda/AgendaSST';
import SemoforoConformidade from '@/components/relatorios/SemoforoConformidade';
import SaudeObra from '@/components/relatorios/SaudeObra';
import IndicadoresGerais from '@/components/relatorios/IndicadoresGerais';
import GraficosPainel from '@/components/relatorios/GraficosPainel';
import RankingObras from '@/components/relatorios/RankingObras';
import RankingEmpresas from '@/components/relatorios/RankingEmpresas';

const noop = () => {};
export default function DashboardAnaliseExecutiva() {
  const [visao, setVisao] = useState('geral');
  const data = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis', 'integracoes', 'documentos', 'dds', 'ocorrencias', 'inspecoes', 'maquinas', 'obras'], true);
  const { demandas } = useDemandasQuery();
  const resultado = useMemo(() => data ? conformidade(data) : null, [data]);
  return <div className="space-y-4">
    <div className="flex justify-end"><div className="inline-flex rounded-lg border border-border bg-card p-1"><button onClick={() => setVisao('geral')} className={`min-h-10 rounded-md px-3 text-sm font-medium ${visao === 'geral' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}>Visão Geral</button><button onClick={() => setVisao('obra')} className={`min-h-10 rounded-md px-3 text-sm font-medium ${visao === 'obra' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}>Por Obra</button></div></div>
    {visao === 'geral' ? <PainelIndicadores demands={demandas} /> : <VisaoPorObra />}
    <div className="grid gap-3 sm:grid-cols-2">
      <Link to="/treinamentos" className="flex items-center gap-3 rounded-xl border border-border bg-card p-4"><GraduationCap className="h-5 w-5 text-emerald-600" /><div className="flex-1"><p className="text-sm font-semibold">Matriz de Treinamentos (NR)</p><p className="text-xs text-muted-foreground">Colaborador × norma, com status de validade</p></div><ArrowRight className="h-4 w-4" /></Link>
      <Link to="/epis" className="flex items-center gap-3 rounded-xl border border-border bg-card p-4"><HardHat className="h-5 w-5 text-amber-600" /><div className="flex-1"><p className="text-sm font-semibold">Matriz de EPIs</p><p className="text-xs text-muted-foreground">Colaborador × item, com status de validade</p></div><ArrowRight className="h-4 w-4" /></Link>
    </div>
    <AgendaSST />
    {data ? <div className="space-y-4"><div className="grid gap-4 lg:grid-cols-2"><SemoforoConformidade data={data} resultadoConformidade={resultado} onNav={noop} /><SaudeObra data={data} resultadoConformidade={resultado} /></div><IndicadoresGerais data={data} /><GraficosPainel data={data} resultadoConformidade={resultado} /><div className="grid gap-4 lg:grid-cols-2"><RankingObras data={data} /><RankingEmpresas data={data} /></div></div> : <p className="py-10 text-center text-sm text-muted-foreground">Carregando análise detalhada…</p>}
  </div>;
}