import React, { useMemo } from 'react';
import { AlertTriangle, ArrowRight, CalendarClock, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useSstData } from '@/hooks/useSstEntitiesData';
import { conformidade, pendencias } from '@/lib/relatorios';
import { diasRestantes, fmt } from '@/lib/sst';

export default function DashboardExecutivoResumo({ onDetalhes }) {
  const data = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis', 'integracoes', 'documentos', 'dds', 'ocorrencias']);
  const resumo = useMemo(() => {
    if (!data) return null;
    const conf = conformidade(data);
    const alertas = pendencias(data).filter((item) => item.tone === 'red').slice(0, 5);
    const vencimentos = [
      ...data.asos.map((item) => ({ tipo: 'ASO', nome: item.tipo || 'ASO', data: item.data_validade })),
      ...data.treinamentos.map((item) => ({ tipo: 'Treinamento', nome: item.norma_curso || item.nome_curso || 'Treinamento', data: item.data_validade })),
      ...data.epis.map((item) => ({ tipo: 'EPI', nome: item.item || 'EPI', data: item.data_validade })),
      ...data.documentos.map((item) => ({ tipo: 'Documento', nome: item.nome || 'Documento', data: item.data_validade })),
    ].filter((item) => { const dias = diasRestantes(item.data); return dias >= 0 && dias <= 30; }).sort((a, b) => a.data.localeCompare(b.data)).slice(0, 5);
    return { conf, alertas, vencimentos };
  }, [data]);
  if (!resumo) return <p className="py-10 text-center text-sm text-muted-foreground">Carregando indicadores críticos…</p>;
  return <div className="space-y-4">
    <div className="grid gap-4 lg:grid-cols-3">
      <section className="rounded-xl border border-border bg-card p-6 text-center"><ShieldCheck className="mx-auto h-8 w-8 text-primary" /><p className="mt-3 text-sm text-muted-foreground">Conformidade geral</p><p className="mt-1 text-5xl font-bold text-primary">{resumo.conf.indice == null ? '—' : `${resumo.conf.indice}%`}</p></section>
      <section className="rounded-xl border border-border bg-card p-5"><div className="mb-3 flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-destructive" /><h2 className="font-semibold text-foreground">Alertas críticos</h2></div>{resumo.alertas.length ? <div className="space-y-2">{resumo.alertas.map((item, index) => <div key={`${item.tipo}-${index}`} className="rounded-lg bg-destructive/5 p-2"><p className="text-sm font-medium text-destructive">{item.label}</p><p className="text-xs text-muted-foreground">{item.detalhe}</p></div>)}</div> : <p className="text-sm text-success">Nenhum alerta crítico.</p>}</section>
      <section className="rounded-xl border border-border bg-card p-5"><div className="mb-3 flex items-center gap-2"><CalendarClock className="h-5 w-5 text-primary" /><h2 className="font-semibold text-foreground">Próximos vencimentos</h2></div>{resumo.vencimentos.length ? <div className="space-y-2">{resumo.vencimentos.map((item, index) => <div key={`${item.tipo}-${index}`} className="flex justify-between gap-3 text-sm"><span className="truncate">{item.tipo} · {item.nome}</span><span className="shrink-0 text-muted-foreground">{fmt(item.data)}</span></div>)}</div> : <p className="text-sm text-muted-foreground">Nenhum vencimento nos próximos 30 dias.</p>}</section>
    </div>
    <div className="flex justify-end"><Button onClick={onDetalhes} className="min-h-11">Ver análise detalhada<ArrowRight className="h-4 w-4" /></Button></div>
  </div>;
}