import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useSstData } from '@/hooks/useSstEntitiesData';
import { getStatus } from '@/lib/sst';
import { indiceColaborador } from '@/lib/relatorios';
import { Building2 } from 'lucide-react';
import { obrasAtivasParaLancamento } from '@/lib/obraDisponibilidade';

export default function VisaoPorObra() {
  const data = useSstData(['obras', 'funcionarios', 'asos', 'treinamentos', 'epis', 'ocorrencias', 'inspecoes']);
  const obras = useMemo(() => {
    if (!data) return [];
    const map = {};
    const nomesAtivos = new Set(obrasAtivasParaLancamento(data.obras || []).map((obra) => obra.nome));
    (data.funcionarios || []).filter((f) => !f.obra || nomesAtivos.has(f.obra)).forEach((f) => {
      const o = f.obra || 'Sem obra';
      if (!map[o]) map[o] = { obra: o, fids: [] };
      map[o].fids.push(f.id);
    });
    return Object.values(map).map((m) => {
      const fids = m.fids;
      const asos = (data.asos || []).filter((a) => fids.includes(a.funcionario_id));
      const trei = (data.treinamentos || []).filter((t) => fids.includes(t.funcionario_id));
      const epis = (data.epis || []).filter((e) => fids.includes(e.funcionario_id));
      const oco = (data.ocorrencias || []).filter((o) => fids.includes(o.funcionario_id));
      const insp = (data.inspecoes || []).filter((i) => i.obra === m.obra);
      const idxs = fids.map((f) => indiceColaborador({
        asos: asos.filter((a) => a.funcionario_id === f),
        treinamentos: trei.filter((t) => t.funcionario_id === f),
        epis: epis.filter((e) => e.funcionario_id === f),
        ocorrencias: oco.filter((o) => o.funcionario_id === f),
      }).indice).filter((x) => x != null);
      return {
        obra: m.obra, fids: fids.length,
        indice: idxs.length ? Math.round(idxs.reduce((s, x) => s + x, 0) / idxs.length) : null,
        asoVenc: asos.filter((a) => getStatus(a.data_validade) === 'Vencido').length,
        treVenc: trei.filter((t) => getStatus(t.data_validade) === 'Vencido').length,
        nc: oco.filter((o) => o.tipo === 'Não Conformidade' && o.situacao !== 'Resolvida' && o.situacao !== 'Cancelada' && o.situacao !== 'Encerrada').length,
        inspPend: insp.filter((i) => i.status !== 'Conforme').length,
      };
    }).sort((a, b) => b.fids - a.fids);
  }, [data]);

  const idxColor = (p) => (p == null ? 'text-slate-400' : p >= 90 ? 'text-emerald-600' : p >= 70 ? 'text-amber-600' : 'text-red-600');

  if (!data) return <p className="text-sm text-slate-400">Carregando...</p>;
  if (obras.length === 0) return <p className="text-sm text-slate-400">Sem obras para exibir.</p>;

  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {obras.map((o) => (
        <Link key={o.obra} to="/obras" className="block bg-white border border-slate-200 rounded-xl p-4 hover:shadow-sm hover:border-amber-300 transition">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#0b2545] text-amber-400 flex items-center justify-center shrink-0"><Building2 className="w-5 h-5" /></div>
            <div className="min-w-0 flex-1">
              <p className="font-semibold text-[#0b2545] truncate">{o.obra}</p>
              <p className="text-xs text-slate-400">{o.fids} colaborador(es)</p>
            </div>
            <div className="text-right shrink-0">
              <p className={`text-lg font-bold ${idxColor(o.indice)}`}>{o.indice == null ? '—' : `${o.indice}%`}</p>
              <p className="text-[10px] text-slate-400">conformidade</p>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-4 gap-2 text-center text-xs">
            <div className="rounded-lg bg-red-50 p-1.5"><p className="font-bold text-red-700">{o.asoVenc}</p><p className="text-[10px] text-slate-500">ASO venc.</p></div>
            <div className="rounded-lg bg-red-50 p-1.5"><p className="font-bold text-red-700">{o.treVenc}</p><p className="text-[10px] text-slate-500">Trein. venc.</p></div>
            <div className="rounded-lg bg-red-50 p-1.5"><p className="font-bold text-red-700">{o.nc}</p><p className="text-[10px] text-slate-500">NC abertas</p></div>
            <div className="rounded-lg bg-amber-50 p-1.5"><p className="font-bold text-amber-700">{o.inspPend}</p><p className="text-[10px] text-slate-500">Inspec.</p></div>
          </div>
        </Link>
      ))}
    </div>
  );
}