import React, { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';

// Diálogo reutilizável de detalhamento de indicador.
// columns: [{ key, label, align?, value?(row), render?(row), cellClass? }]
// filterDefs: [{ id, label, options:[{value,label}], apply:(row,value)=>boolean }]
// renderAction: (row) => ReactNode
export default function DrillDownDialog({
  open,
  onOpenChange,
  title,
  subtitle,
  icon: Icon,
  columns,
  rows,
  filterDefs = [],
  renderAction,
  footer,
  emptyMessage = 'Nenhum registro encontrado.',
}) {
  const [filters, setFilters] = useState({});
  const [busca, setBusca] = useState('');

  const setF = (id, value) =>
    setFilters((f) => ({ ...f, [id]: value === '__all' ? null : value }));

  const filtered = useMemo(() => {
    let r = rows || [];
    for (const def of filterDefs) {
      const v = filters[def.id];
      if (v != null) r = r.filter((row) => def.apply(row, v));
    }
    if (busca.trim()) {
      const q = busca.toLowerCase();
      r = r.filter((row) =>
        columns.some((c) => String(c.value ? c.value(row) : '').toLowerCase().includes(q))
      );
    }
    return r;
  }, [rows, filters, busca, columns, filterDefs]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[88vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[#0b2545]">
            {Icon && <Icon className="w-5 h-5" />}
            {title}
          </DialogTitle>
          {subtitle && <DialogDescription>{subtitle}</DialogDescription>}
        </DialogHeader>

        {(filterDefs.length > 0 || true) && (
          <div className="flex flex-wrap items-center gap-2 pb-2 border-b border-slate-100">
            {filterDefs.map((def) => (
              <div key={def.id} className="flex items-center gap-1.5">
                <span className="text-xs text-slate-500">{def.label}:</span>
                <select
                  value={filters[def.id] ?? '__all'}
                  onChange={(e) => setF(def.id, e.target.value)}
                  className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs"
                >
                  <option value="__all">{def.allLabel || 'Todas'}</option>
                  {def.options.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </div>
            ))}
            <div className="relative ml-auto">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-1/2 -translate-y-1/2" />
              <Input
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
                placeholder="Buscar..."
                className="h-8 max-w-[220px] pl-7 text-xs"
              />
            </div>
          </div>
        )}

        <ScrollArea className="flex-1 min-h-0">
          {filtered.length === 0 ? (
            <p className="text-sm text-slate-400 py-10 text-center">{emptyMessage}</p>
          ) : (
            <table className="w-full text-sm">
              <thead className="text-xs uppercase text-slate-500 sticky top-0 bg-white z-10">
                <tr>
                  {columns.map((c) => (
                    <th
                      key={c.key}
                      className={`px-3 py-2 font-semibold whitespace-nowrap ${
                        c.align === 'right' ? 'text-right' : 'text-left'
                      }`}
                    >
                      {c.label}
                    </th>
                  ))}
                  {renderAction && <th className="px-3 py-2 text-right font-semibold">Ação</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((row, i) => (
                  <tr key={row.id ?? i} className="hover:bg-slate-50/60">
                    {columns.map((c) => (
                      <td
                        key={c.key}
                        className={`px-3 py-2.5 align-top ${c.align === 'right' ? 'text-right' : ''} ${
                          c.cellClass || ''
                        }`}
                      >
                        {c.render ? c.render(row) : c.value ? c.value(row) : '—'}
                      </td>
                    ))}
                    {renderAction && <td className="px-3 py-2.5 text-right whitespace-nowrap">{renderAction(row)}</td>}
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </ScrollArea>

        <div className="pt-2 flex items-center justify-between text-xs text-slate-400">
          <span>{filtered.length} registro(s)</span>
          {footer}
        </div>
      </DialogContent>
    </Dialog>
  );
}