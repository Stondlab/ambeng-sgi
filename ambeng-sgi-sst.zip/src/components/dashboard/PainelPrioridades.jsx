import React from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, ArrowRight } from 'lucide-react';

const rank = { Crítica: 0, Alta: 1, Média: 2, Baixa: 3 };
export default function PainelPrioridades({ demandas }) {
  const abertas = demandas.filter((item) => !['Concluído', 'Cancelado'].includes(item.status)).sort((a, b) => (rank[a.prioridade] ?? 4) - (rank[b.prioridade] ?? 4)).slice(0, 8);
  return <section className="rounded-lg border border-border bg-card shadow-card">
    <div className="border-b border-border p-4"><h2 className="text-2xl font-semibold text-foreground">Próximas prioridades</h2></div>
    <div className="space-y-2 p-4">{abertas.length ? abertas.map((item) => <div key={item.id} className="flex flex-col gap-3 rounded-lg border border-border p-4 sm:flex-row sm:items-center"><AlertTriangle className={`h-5 w-5 shrink-0 ${item.prioridade === 'Crítica' ? 'text-destructive' : 'text-warning'}`} /><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-foreground">{item.titulo}</p><p className="text-xs text-muted-foreground">{item.obra || 'Sem obra'} · {item.prioridade || 'Sem prioridade'} · {item.status}</p></div><Link to="/painel/quadro" className="inline-flex min-h-11 items-center justify-center gap-2 rounded-md border border-border bg-muted px-4 text-sm font-medium text-foreground">Abrir <ArrowRight className="h-4 w-4" /></Link></div>) : <p className="py-8 text-center text-sm text-muted-foreground">Nenhuma prioridade em aberto.</p>}</div>
  </section>;
}