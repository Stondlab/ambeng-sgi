import React, { useEffect, useMemo, useState } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { FileText, Save, Clock, FilePlus2, Upload, Trash2 } from 'lucide-react';
import { calcParcelas, fmtMoney, addMeses } from '@/lib/financeiro';
import { nomeUsuario } from '@/lib/usuarioNome';
import { applyTitleCaseAll } from '@/lib/titleCase';

export default function LancarNotaModal({ open, onClose, onSaved }) {
  const { toast } = useToast();
  const [clientes, setClientes] = useState([]);
  const [obras, setObras] = useState([]);
  const [tipos, setTipos] = useState([]);
  const [municipios, setMunicipios] = useState([]);
  const [saving, setSaving] = useState(false);
  const [rascunho, setRascunho] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState({
    tipo: 'Emitida', cliente_id: '', obra_id: '', numero: '', serie: '1', data_emissao: '', competencia: '',
    valor_bruto: '', valor_material: '', tipo_servico_id: '', municipio_id: '',
    discriminacao: '', iss_retido: false, retencao_inss: false,
    numero_parcelas: 1, data_primeira_parcela: '', observacoes: '', documentos: '',
  });

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  useEffect(() => {
    if (!open) return;
    Promise.all([
      base44.entities.ClientesTomadores.list('razao_social', 500).catch(() => []),
      base44.entities.Obras.list('nome', 500).catch(() => []),
      base44.entities.TiposServico.list('nome', 200).catch(() => []),
      base44.entities.MunicipiosISS.list('municipio', 200).catch(() => []),
    ]).then(([cl, ob, tp, mu]) => { setClientes(cl); setObras(ob); setTipos(tp); setMunicipios(mu); });
  }, [open]);

  useEffect(() => {
    if (form.data_emissao && !form.competencia) set('competencia', form.data_emissao.slice(0, 7));
  }, [form.data_emissao]);

  const valorBruto = Number(form.valor_bruto) || 0;
  const nParc = Math.max(1, parseInt(form.numero_parcelas) || 1);
  const parcelas = useMemo(() => calcParcelas(valorBruto, nParc), [valorBruto, nParc]);

  const documentos = (() => { try { return form.documentos ? JSON.parse(form.documentos) : []; } catch { return []; } })();

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const novo = { url: file_url, nome: file.name, tipo: 'Anexo', data: new Date().toISOString() };
      set('documentos', JSON.stringify([...documentos, novo]));
    } catch { /* ignore */ } finally { setUploading(false); e.target.value = ''; }
  };

  const removeDoc = (idx) => {
    const novos = documentos.filter((_, i) => i !== idx);
    set('documentos', novos.length ? JSON.stringify(novos) : '');
  };

  const salvar = async (isRascunho = false) => {
    if (!isRascunho && (!form.cliente_id || !form.numero || !form.data_emissao || !valorBruto)) {
      toast({ title: 'Preencha cliente, número, emissão e valor.', variant: 'destructive' });
      return;
    }
    setSaving(true); setRascunho(isRascunho);
    try {
      const userNome = nomeUsuario(await base44.auth.me());
      const res = await base44.functions.invoke('salvarNotaFiscal', { form: applyTitleCaseAll(form), userNome, isRascunho });
      toast({
        title: isRascunho ? 'Rascunho salvo.' : 'Nota lançada — pendente de conferência.',
        description: isRascunho ? 'A nota ainda não afeta o Financeiro.' : 'A integração financeira será criada somente após a conferência.',
      });
      setForm({ tipo: 'Emitida', cliente_id: '', obra_id: '', numero: '', serie: '1', data_emissao: '', competencia: '', valor_bruto: '', valor_material: '', tipo_servico_id: '', municipio_id: '', discriminacao: '', iss_retido: false, retencao_inss: false, numero_parcelas: 1, data_primeira_parcela: '', observacoes: '', documentos: '' });
      onSaved?.(); onClose();
    } catch (e) {
      toast({ title: 'Erro ao lançar nota.', description: e.response?.data?.error || e.message, variant: 'destructive' });
    } finally { setSaving(false); setRascunho(false); }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl w-[94vw] max-h-[92vh] p-0 gap-0 overflow-hidden flex flex-col">
        <div className="px-6 py-4 border-b border-slate-200 bg-gradient-to-r from-[#0b2545] to-[#16365f] text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center"><FilePlus2 className="w-5 h-5" /></div>
            <div>
              <h2 className="text-lg font-bold">LANÇAR NOTA FISCAL</h2>
              <p className="text-sm text-white/80">Lançamento operacional — a nota fica pendente de conferência.</p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50/60">
          <div className="flex items-center gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 text-sm">
            <Clock className="w-4 h-4" /> Status inicial: <b>Pendente de conferência</b> — o lançamento administrativo não confere a nota.
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {/* 1. Tipo */}
            <div><Label>Tipo *</Label>
              <Select value={form.tipo} onValueChange={(v) => set('tipo', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="Emitida">Emitida</SelectItem><SelectItem value="Recebida">Recebida</SelectItem></SelectContent></Select>
            </div>
            {/* 2. Número */}
            <div><Label>Número da NF *</Label><Input className="mt-1" value={form.numero} onChange={(e) => set('numero', e.target.value)} /></div>
            {/* 3. Série */}
            <div><Label>Série</Label><Input className="mt-1" value={form.serie} onChange={(e) => set('serie', e.target.value)} /></div>
            {/* 4. Data Emissão */}
            <div><Label>Data de emissão *</Label><Input type="date" className="mt-1" value={form.data_emissao} onChange={(e) => set('data_emissao', e.target.value)} /></div>
            {/* 5. Cliente / Fornecedor */}
            <div><Label>{form.tipo === 'Recebida' ? 'Fornecedor *' : 'Cliente / Tomador *'}</Label>
              <Select value={form.cliente_id} onValueChange={(v) => set('cliente_id', v)}><SelectTrigger className="mt-1"><SelectValue placeholder={form.tipo === 'Recebida' ? 'Selecionar fornecedor' : 'Selecionar cliente'} /></SelectTrigger>
                <SelectContent>{clientes.map((c) => <SelectItem key={c.id} value={c.id}>{c.razao_social}</SelectItem>)}</SelectContent></Select>
            </div>
            {/* 6. Descrição/Natureza */}
            <div className="sm:col-span-2"><Label>Descrição / Natureza</Label><Textarea className="mt-1" rows={2} value={form.discriminacao} onChange={(e) => set('discriminacao', e.target.value)} /></div>
            {/* 7. Valor Total */}
            <div><Label>Valor total (R$) *</Label><Input type="number" step="0.01" className="mt-1" value={form.valor_bruto} onChange={(e) => set('valor_bruto', e.target.value)} /></div>
            {/* Obra */}
            <div><Label>Obra</Label>
              <Select value={form.obra_id} onValueChange={(v) => set('obra_id', v)}><SelectTrigger className="mt-1"><SelectValue placeholder="(opcional)" /></SelectTrigger>
                <SelectContent>{obras.map((o) => <SelectItem key={o.id} value={o.id}>{o.nome}</SelectItem>)}</SelectContent></Select>
            </div>
            {/* Competência */}
            <div><Label>Competência (YYYY-MM)</Label><Input className="mt-1" value={form.competencia} onChange={(e) => set('competencia', e.target.value)} placeholder="Automático" /></div>
            {/* Material dedutível */}
            <div><Label>Material dedutível (R$)</Label><Input type="number" step="0.01" className="mt-1" value={form.valor_material} onChange={(e) => set('valor_material', e.target.value)} /></div>
            {/* Tipo de serviço */}
            <div><Label>Tipo de serviço</Label>
              <Select value={form.tipo_servico_id} onValueChange={(v) => set('tipo_servico_id', v)}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecionar" /></SelectTrigger>
                <SelectContent>{tipos.map((t) => <SelectItem key={t.id} value={t.id}>{t.nome}</SelectItem>)}</SelectContent></Select>
            </div>
            {/* Município */}
            <div><Label>Município (ISS)</Label>
              <Select value={form.municipio_id} onValueChange={(v) => set('municipio_id', v)}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecionar" /></SelectTrigger>
                <SelectContent>{municipios.map((m) => <SelectItem key={m.id} value={m.id}>{m.municipio}/{m.uf}</SelectItem>)}</SelectContent></Select>
            </div>
            {/* Nº parcelas */}
            <div><Label>Nº parcelas</Label><Input type="number" min="1" max="48" className="mt-1" value={form.numero_parcelas} onChange={(e) => set('numero_parcelas', e.target.value)} /></div>
            {/* 1ª parcela */}
            <div><Label>1ª parcela vence em</Label><Input type="date" className="mt-1" value={form.data_primeira_parcela} onChange={(e) => set('data_primeira_parcela', e.target.value)} /></div>
          </div>
          <div className="flex flex-wrap items-center gap-6">
            <label className="flex items-center gap-2 text-sm"><Switch checked={form.iss_retido} onCheckedChange={(v) => set('iss_retido', v)} /> ISS retido na fonte</label>
            <label className="flex items-center gap-2 text-sm"><Switch checked={form.retencao_inss} onCheckedChange={(v) => set('retencao_inss', v)} /> Reter INSS</label>
          </div>
          {/* 9. Observação */}
          <div><Label>Observação</Label><Textarea className="mt-1" rows={2} value={form.observacoes} onChange={(e) => set('observacoes', e.target.value)} /></div>
          {/* 10. Anexo */}
          <div><Label>Anexo</Label>
            <div className="mt-1 space-y-2">
              {documentos.map((d, i) => (
                <div key={i} className="flex items-center gap-2 p-2 rounded-lg border border-slate-200 bg-slate-50">
                  <FileText className="w-4 h-4 text-slate-500" />
                  <a href={d.url} target="_blank" rel="noreferrer" className="text-sm text-[#0b2545] hover:underline flex-1 truncate">{d.nome}</a>
                  <button type="button" onClick={() => removeDoc(i)} className="text-red-500 hover:text-red-700"><Trash2 className="w-4 h-4" /></button>
                </div>
              ))}
              <label className="flex items-center gap-2 cursor-pointer text-sm text-[#0b2545]">
                <Upload className="w-4 h-4" />
                {uploading ? 'Enviando...' : 'Adicionar anexo'}
                <input type="file" className="hidden" onChange={handleUpload} disabled={uploading} />
              </label>
            </div>
          </div>

          {nParc > 1 && (
            <div className="rounded-lg bg-white border border-slate-200 px-3 py-3 text-xs text-slate-600">
              <div className="font-semibold text-[#0b2545] mb-1">Parcelamento — soma = valor total</div>
              <div className="flex flex-wrap gap-x-4 gap-y-1">
                {parcelas.map((v, i) => <span key={i}>{i + 1}/{nParc}: <b className="text-[#0b2545]">{fmtMoney(v)}</b> · venc. {addMeses(form.data_primeira_parcela || form.data_emissao, i)}</span>)}
              </div>
              <div className="mt-2 pt-2 border-t border-slate-100 flex justify-between"><span>Total</span><b className="text-[#0b2545]">{fmtMoney(parcelas.reduce((s, v) => s + v, 0))}</b></div>
            </div>
          )}
        </div>

        <div className="px-6 py-3 border-t border-slate-200 bg-white flex items-center justify-end gap-2 shrink-0">
          <Button variant="ghost" onClick={onClose} className="min-h-[44px]">Cancelar</Button>
          <Button variant="outline" onClick={() => salvar(true)} disabled={saving} className="min-h-[44px]">
            <Save className="w-4 h-4" />{rascunho ? 'Salvando…' : 'Salvar rascunho'}
          </Button>
          <Button onClick={() => salvar(false)} disabled={saving} className="bg-[#0b2545] hover:bg-[#16365f] min-h-[44px]">
            <FileText className="w-4 h-4" />{saving ? 'Salvando…' : 'Salvar'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}