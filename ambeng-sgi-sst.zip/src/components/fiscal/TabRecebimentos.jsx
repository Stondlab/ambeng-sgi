import React, { useMemo, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { usePerm } from '@/hooks/usePerm';
import { fmtMoney } from '@/lib/financeiro';
import { statusEfetivo, ST_PARCELA, fmtDate, totalRecebido, totalAReceber } from '@/lib/fiscal';
import RecebimentoModal from '@/components/fiscal/RecebimentoModal';
import { Wallet, Clock, AlertTriangle, CheckCircle2 } from 'lucide-react';

const STATUS_OPTS = [
  { v: 'todos', l: 'Todos' },
  { v: 'previstos', l: 'Previstos' },
  { v: 'a_vencer', l: 'A vencer' },
  { v: 'atraso', l: 'Em atraso' },
  { v: 'recebidos', l: 'Recebidos' },
];

// Aba Recebimentos — tela operacional. Mostra o VALOR DA PARCELA (nunca o total).
export default function TabRecebimentos({ parcelas, notas, onReload }) {
  const { podeEditar } = usePerm('fis_recebimentos');
  const [sel, setSel] = useState(null);
  const [filtros, setFiltros] = useState({ periodo: '', cliente: '', obra: '', status: 'todos' });

  const notaMap = useMemo(() => Object.fromEntries(notas.map((n) => [n.id, n])), [notas]);

  const clientes = useMemo(() => [...new Set(notas.map((n) => n.cliente_nome).filter(Boolean))], [notas]);
  const obras = useMemo(() => [...new Set(notas.map((n) => n.obra_nome).filter(Boolean))], [notas]);

  const hoje = new Date().toISOString().slice(0, 10);
  const visiveis = parcelas.filter((p) => {
    const n = notaMap[p.nota_fiscal_id] || {};
    if (filtros.cliente && n.cliente_nome !== filtros.cliente) return false;
    if (filtros.obra && n.obra_nome !== filtros.obra) return false;
    const st = statusEfetivo(p);
    if (filtros.status === 'previstos' && st !== 'Previsto') return false;
    if (filtros.status === 'a_vencer' && !(st === 'Previsto' && p.data_prevista)) return false;
    if (filtros.status === 'atraso' && st !== 'Em atraso') return false;
    if (filtros.status === 'recebidos' && st !== 'Recebido') return false;
    if (filtros.periodo) {
      const [i, f] = filtros.periodo.split('|');
      if (p.data_prevista < i || p.data_prevista > f) return false;
    }
    return true;
  });

  const totalAReceberV = totalAReceber(parcelas);
  const recebidoV = totalRecebido(parcelas);
  const vencendoV = parcelas.filter((p) => statusEfetivo(p) === 'Previsto' && p.data_prevista && p.data_prevista >= hoje).reduce((s, p) => s + (Number(p.valor) || 0), 0);
  const atrasoV = parcelas.filter((p) => statusEfetivo(p) === 'Em atraso').reduce((s, p) => s + (Number(p.valor) || 0), 0);

  const setF = (k, v) => setFiltros((p) => ({ ...p, [k]: v }));

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-bold uppercase tracking-wider text-[#0b2545]">Recebimentos</h3>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card label="Total a receber" value={fmtMoney(totalAReceberV)} icon={Wallet} accent="border-amber-300 bg-amber-50" />
        <Card label="Vencendo" value={fmtMoney(vencendoV)} icon={Clock} accent="border-sky-200" />
        <Card label="Em atraso" value={fmtMoney(atrasoV)} icon={AlertTriangle} accent="border-rose-200 bg-rose-50" />
        <Card label="Recebido" value={fmtMoney(recebidoV)} icon={CheckCircle2} accent="border-emerald-300 bg-emerald-50" />
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-3 grid sm:grid-cols-2 lg:grid-cols-4 gap-2">
        <Input type="month" value={filtros.periodo ? filtros.periodo.split('|')[0] : ''} onChange={(e) => setF('periodo', e.target.value ? `${e.target.value}-01|${e.target.value}-28` : '')} placeholder="Período" />
        <Select value={filtros.cliente} onValueChange={(v) => setF('cliente', v)}><SelectTrigger><SelectValue placeholder="Cliente" /></SelectTrigger><SelectContent>{clientes.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select>
        <Select value={filtros.obra} onValueChange={(v) => setF('obra', v)}><SelectTrigger><SelectValue placeholder="Obra" /></SelectTrigger><SelectContent>{obras.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
        <Select value={filtros.status} onValueChange={(v) => setF('status', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{STATUS_OPTS.map((s) => <SelectItem key={s.v} value={s.v}>{s.l}</SelectItem>)}</SelectContent></Select>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
              <tr>
                <th className="text-left px-4 py-3">NF</th><th className="text-left px-4 py-3">Cliente</th><th className="text-left px-4 py-3">Obra</th>
                <th className="text-left px-4 py-3">Parcela</th><th className="text-right px-4 py-3">Valor da parcela</th>
                <th className="text-left px-4 py-3">Vencimento</th><th className="text-left px-4 py-3">Status</th><th className="text-left px-4 py-3">Recebimento</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {visiveis.length === 0 && <tr><td colSpan={8} className="px-4 py-10 text-center text-slate-400">Nenhuma parcela.</td></tr>}
              {visiveis.map((p) => {
                const n = notaMap[p.nota_fiscal_id] || {};
                const st = statusEfetivo(p);
                return (
                  <tr key={p.id} className="cursor-pointer hover:bg-slate-50" onClick={() => setSel(p)}>
                    <td className="px-4 py-3 font-medium text-[#0b2545]">{p.nota_numero || '—'}</td>
                    <td className="px-4 py-3 text-slate-700">{n.cliente_nome || '—'}</td>
                    <td className="px-4 py-3 text-slate-700">{n.obra_nome || '—'}</td>
                    <td className="px-4 py-3 text-slate-500">{p.numero_parcela}/{p.total_parcelas}</td>
                    <td className="px-4 py-3 text-right font-semibold">{fmtMoney(p.valor)}</td>
                    <td className="px-4 py-3 text-slate-700">{fmtDate(p.data_prevista)}</td>
                    <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${ST_PARCELA[st]}`}>{st}</span></td>
                    <td className="px-4 py-3 text-slate-700">{p.data_recebida ? `${fmtDate(p.data_recebida)}${p.forma_recebimento ? ' · ' + p.forma_recebimento : ''}` : '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      <p className="text-[11px] text-slate-400">Cada linha mostra o valor da parcela — a soma das parcelas da nota = valor total.</p>

      {sel && (
        <RecebimentoModal parcela={sel} nota={notaMap[sel.nota_fiscal_id]} open={!!sel} onClose={() => setSel(null)} onSaved={onReload} podeEditar={podeEditar} />
      )}
    </div>
  );
}

function Card({ label, value, icon: Icon, accent }) {
  return (
    <div className={`rounded-xl border p-4 ${accent || 'border-slate-200 bg-white'}`}>
      <div className="flex items-center justify-between"><span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">{label}</span><Icon className="w-4 h-4 text-slate-400" /></div>
      <div className="text-xl font-bold text-[#0b2545] mt-1 leading-tight">{value}</div>
    </div>
  );
}