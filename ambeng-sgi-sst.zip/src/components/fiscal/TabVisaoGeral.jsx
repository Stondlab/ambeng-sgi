import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { statusEfetivo, totalRecebido, totalAReceber } from '@/lib/fiscal';
import { TrendingUp, Wallet, Clock, AlertTriangle, Percent, FileWarning } from 'lucide-react';

// Aba Visão Geral — cards clicáveis. Impostos/Retenções só para quem vê apuração (Admin).
export default function TabVisaoGeral({ notas, parcelas, podeApurar, onTab }) {
  const faturamento = notas.reduce((s, n) => s + (Number(n.valor_bruto) || 0), 0);
  const recebido = totalRecebido(parcelas);
  const aReceber = totalAReceber(parcelas);
  const pendencias = notas.filter((n) => (n.status || '').includes('Pendente')).length;
  const impostos = notas.reduce((s, n) => s + (Number(n.valor_iss) || 0) + (Number(n.valor_inss_retido) || 0) + (Number(n.valor_pis) || 0) + (Number(n.valor_cofins) || 0) + (Number(n.valor_irpj) || 0) + (Number(n.valor_csll) || 0), 0);
  const retencoes = notas.reduce((s, n) => s + (Number(n.valor_iss_retido) || 0) + (Number(n.valor_inss_retido) || 0), 0);
  const vencendo = parcelas.filter((p) => statusEfetivo(p) === 'Previsto' && p.data_prevista).length;

  const cards = [
    { label: 'Faturamento', value: fmtMoney(faturamento), icon: TrendingUp, tab: 'notas', accent: 'border-slate-200' },
    { label: 'Recebido', value: fmtMoney(recebido), icon: Wallet, tab: 'recebimentos', accent: 'border-emerald-300 bg-emerald-50' },
    { label: 'A Receber', value: fmtMoney(aReceber), icon: Clock, tab: 'recebimentos', accent: 'border-amber-300 bg-amber-50' },
    ...(podeApurar ? [
      { label: 'Impostos', value: fmtMoney(impostos), icon: Percent, tab: 'apuracao', accent: 'border-indigo-300 bg-indigo-50' },
      { label: 'Retenções', value: fmtMoney(retencoes), icon: AlertTriangle, tab: 'apuracao', accent: 'border-rose-200' },
    ] : []),
    { label: 'Pendências', value: String(pendencias), icon: FileWarning, tab: 'notas', accent: 'border-amber-200' },
  ];

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <button key={c.label} onClick={() => onTab(c.tab)} className={`text-left rounded-xl border p-4 transition hover:shadow-card-hover ${c.accent}`}>
              <div className="flex items-center justify-between"><span className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">{c.label}</span><Icon className="w-4 h-4 text-slate-400" /></div>
              <div className="text-xl font-bold text-[#0b2545] mt-1 leading-tight">{c.value}</div>
            </button>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <SummaryCard title="Notas" desc={`${notas.length} nota(s)`} onClick={() => onTab('notas')} />
        <SummaryCard title="Recebimentos" desc={`${vencendo} vencendo · ${parcelas.length} parcelas`} onClick={() => onTab('recebimentos')} />
        {podeApurar
          ? <SummaryCard title="Apuração" desc="Mensal e trimestral" onClick={() => onTab('apuracao')} />
          : <SummaryCard title="Cadastros" desc="Clientes, municípios, serviços" onClick={() => onTab('cadastros')} />}
      </div>
    </div>
  );
}

function SummaryCard({ title, desc, onClick }) {
  return (
    <button onClick={onClick} className="text-left bg-white border border-slate-200 rounded-xl p-4 hover:shadow-card-hover transition">
      <h4 className="text-xs font-bold uppercase tracking-wider text-[#0b2545]">{title}</h4>
      <p className="text-sm text-slate-500 mt-1">{desc}</p>
    </button>
  );
}