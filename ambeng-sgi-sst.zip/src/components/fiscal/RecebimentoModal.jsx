import React, { useEffect, useState } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { Wallet, CheckCircle2, Undo2, Save } from 'lucide-react';
import { fmtMoney } from '@/lib/financeiro';
import { nomeUsuario } from '@/lib/usuarioNome';
import { statusEfetivo, ST_PARCELA, fmtDate } from '@/lib/fiscal';

// Modal de recebimento de parcela (ParcelasNF). Persiste via função backend
// registrarRecebimentoNF, que atualiza em cascata parcela → nota → receita.
export default function RecebimentoModal({ parcela, nota, open, onClose, onSaved, podeEditar }) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [data, setData] = useState('');
  const [forma, setForma] = useState('');
  const [obs, setObs] = useState('');

  useEffect(() => {
    if (parcela) {
      setData(parcela.data_recebida || new Date().toISOString().slice(0, 10));
      setForma(parcela.forma_recebimento || '');
      setObs(parcela.observacoes || '');
    }
  }, [parcela]);

  if (!parcela) return null;
  const st = statusEfetivo(parcela);
  const jaRecebido = st === 'Recebido';

  const salvar = async (acao) => {
    if (acao !== 'estornar' && (!data || !forma)) {
      toast({ title: 'Informe data e forma de recebimento.', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      const userNome = nomeUsuario(await base44.auth.me());
      const payload = { parcela_id: parcela.id, acao, userNome, data_recebida: data, forma_recebimento: forma, observacao: obs };
      await base44.functions.invoke('registrarRecebimentoNF', payload);
      toast({ title: acao === 'estornar' ? 'Recebimento estornado.' : 'Recebimento registrado.' });
      onSaved?.();
      onClose();
    } catch (e) {
      toast({ title: 'Erro ao registrar.', description: e.response?.data?.error || e.message, variant: 'destructive' });
    } finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg w-[94vw] max-h-[92vh] p-0 gap-0 overflow-hidden flex flex-col">
        <div className="px-6 py-4 border-b border-slate-200 bg-gradient-to-r from-emerald-700 to-emerald-600 text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center"><Wallet className="w-5 h-5" /></div>
            <div>
              <h2 className="text-lg font-bold">RECEBIMENTO — {jaRecebido ? 'Editado' : 'Registrar'}</h2>
              <p className="text-sm text-white/80">NF {parcela.nota_numero} · Parcela {parcela.numero_parcela}/{parcela.total_parcelas}</p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50/60">
          <div className="grid grid-cols-2 gap-3">
            <Info label="Cliente" value={nota?.cliente_nome} />
            <Info label="Obra" value={nota?.obra_nome} />
            <Info label="NF" value={parcela.nota_numero} />
            <Info label="Parcela" value={`${parcela.numero_parcela}/${parcela.total_parcelas}`} />
            <Info label="Valor da parcela" value={fmtMoney(parcela.valor)} />
            <Info label="Vencimento" value={fmtDate(parcela.data_prevista)} />
            <Info label="Status" value={st} badge />
          </div>

          {podeEditar ? (
            <>
              <div><Label>Data do recebimento *</Label><Input type="date" className="mt-1" value={data} onChange={(e) => setData(e.target.value)} /></div>
              <div><Label>Forma de recebimento *</Label>
                <Select value={forma} onValueChange={setForma}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecionar" /></SelectTrigger>
                  <SelectContent>{['Pix', 'Boleto', 'Transferência', 'Outros'].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
              </div>
              <div><Label>Observação</Label><Textarea className="mt-1" rows={2} value={obs} onChange={(e) => setObs(e.target.value)} /></div>
              <p className="text-[11px] text-slate-400">O recebimento reflete automaticamente na Receita (Contas a Receber) e no status da nota.</p>
            </>
          ) : (
            <div className="text-sm text-slate-500 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">Você não tem permissão para registrar recebimentos.</div>
          )}
        </div>

        <div className="px-6 py-3 border-t border-slate-200 bg-white flex items-center justify-end gap-2 shrink-0">
          <Button variant="ghost" onClick={onClose} className="min-h-[44px]">Cancelar</Button>
          {podeEditar && jaRecebido && (
            <Button variant="outline" onClick={() => salvar('estornar')} disabled={saving} className="min-h-[44px] text-amber-700 border-amber-300 hover:bg-amber-50"><Undo2 className="w-4 h-4" />Estornar</Button>
          )}
          {podeEditar && (
            <Button onClick={() => salvar(jaRecebido ? 'editar' : 'registrar')} disabled={saving} className="bg-emerald-600 hover:bg-emerald-700 min-h-[44px]">
              {jaRecebido ? <><Save className="w-4 h-4" />Salvar</> : <><CheckCircle2 className="w-4 h-4" />Registrar recebimento</>}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Info({ label, value, badge }) {
  return (<div className="py-1"><div className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">{label}</div>{badge ? <span className={`inline-block mt-1 px-2 py-0.5 rounded-full text-[11px] font-medium ${ST_PARCELA[value] || 'bg-slate-100 text-slate-500'}`}>{value}</span> : <div className="text-sm mt-0.5 text-slate-700">{value || '—'}</div>}</div>);
}