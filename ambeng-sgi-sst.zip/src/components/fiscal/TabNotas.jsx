import React, { useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileUp, Plus, Search } from 'lucide-react';
import { usePerm } from '@/hooks/usePerm';
import { fmtMoney } from '@/lib/financeiro';
import { ST_NOTA, fmtDate } from '@/lib/fiscal';
import LancarNotaModal from '@/components/fiscal/LancarNotaModal';
import NotaFiscalModal from '@/components/fiscal/NotaFiscalModal';
import SortableTh from '@/components/financeiro/SortableTh';
import { useColumnSort } from '@/lib/useColumnSort';
import { useFiltrosFinanceiro } from '@/lib/FiltrosFinanceiroContext';
import ImportarXmlNfDialog from '@/components/fiscal/ImportarXmlNfDialog';


// Aba Notas — lista operacional de notas + lançar + abrir (modal central) + editar.
export default function TabNotas({ notas, parcelas, onReload }) {
  const { podeCriar, podeEditar } = usePerm('fis_lancar');
  const { obra: obraGlobal } = useFiltrosFinanceiro();
  const [lancar, setLancar] = useState(false);
  const [importarXml, setImportarXml] = useState(false);
  const [sel, setSel] = useState(null);
  const [filtros, setFiltros] = useState({ competencia: '', cliente: '', obra: '', status: '', busca: '' });
  const { sortField, sortDir, toggleSort, sortRows } = useColumnSort();

  const parcPorNota = useMemo(() => {
    const m = {};
    for (const p of parcelas) (m[p.nota_fiscal_id] = m[p.nota_fiscal_id] || []).push(p);
    return m;
  }, [parcelas]);

  const clientes = useMemo(() => [...new Set(notas.map((n) => n.cliente_nome).filter(Boolean))], [notas]);
  const obras = useMemo(() => [...new Set(notas.map((n) => n.obra_nome).filter(Boolean))], [notas]);
  const comps = useMemo(() => [...new Set(notas.map((n) => n.competencia).filter(Boolean))].sort().reverse(), [notas]);
  const stats = useMemo(() => [...new Set(notas.map((n) => n.status).filter(Boolean))], [notas]);

  const paramsPeriodo = new URLSearchParams(window.location.search); const inicioPeriodo = paramsPeriodo.get('inicio'), fimPeriodo = paramsPeriodo.get('fim');
  const visiveisRaw = notas.filter((n) => {
    if (inicioPeriodo && fimPeriodo && (!n.data_emissao || n.data_emissao < inicioPeriodo || n.data_emissao > fimPeriodo)) return false;
    if (obraGlobal !== 'geral' && n.obra_nome !== obraGlobal) return false;
    if (filtros.competencia && n.competencia !== filtros.competencia) return false;
    if (filtros.cliente && n.cliente_nome !== filtros.cliente) return false;
    if (filtros.obra && n.obra_nome !== filtros.obra) return false;
    if (filtros.status && n.status !== filtros.status) return false;
    if (filtros.busca) {
      const q = filtros.busca.toLowerCase();
      if (!(`${n.numero} ${n.cliente_nome || ''} ${n.obra_nome || ''}`.toLowerCase().includes(q))) return false;
    }
    return true;
  });
  const visiveis = useMemo(() => sortRows(visiveisRaw, {
    numero: (a, b) => (a.numero || '').localeCompare(b.numero || ''),
    data: (a, b) => (a.data_emissao || '').localeCompare(b.data_emissao || ''),
    fornecedor: (a, b) => (a.cliente_nome || '').localeCompare(b.cliente_nome || ''),
    valor: (a, b) => (a.valor_bruto || 0) - (b.valor_bruto || 0),
    status: (a, b) => (a.status || '').localeCompare(b.status || ''),
  }), [visiveisRaw, sortField, sortDir]);

  const setF = (k, v) => setFiltros((p) => ({ ...p, [k]: v }));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <h3 className="text-sm font-bold uppercase tracking-wider text-[#0b2545]">Notas Fiscais</h3>
        {podeCriar && <div className="flex gap-2"><Button variant="outline" onClick={() => setImportarXml(true)} className="min-h-[44px]"><FileUp className="w-4 h-4" />Importar Nota Fiscal</Button><Button onClick={() => setLancar(true)} className="bg-[#0b2545] hover:bg-[#16365f] min-h-[44px]"><Plus className="w-4 h-4" />Lançar Nota</Button></div>}
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-3 grid sm:grid-cols-2 lg:grid-cols-5 gap-2">
        <div className="relative lg:col-span-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <Input className="pl-9" placeholder="Buscar NF/cliente..." value={filtros.busca} onChange={(e) => setF('busca', e.target.value)} />
        </div>
        <Input type="month" value={filtros.competencia} onChange={(e) => setF('competencia', e.target.value)} placeholder="Competência" />
        <Select value={filtros.cliente} onValueChange={(v) => setF('cliente', v)}><SelectTrigger><SelectValue placeholder="Cliente" /></SelectTrigger><SelectContent>{clientes.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select>
        <Select value={filtros.obra} onValueChange={(v) => setF('obra', v)}><SelectTrigger><SelectValue placeholder="Obra" /></SelectTrigger><SelectContent>{obras.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
        <Select value={filtros.status} onValueChange={(v) => setF('status', v)}><SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger><SelectContent>{stats.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
              <tr>
                <SortableTh field="numero" label="Número" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-4 py-3" />
                <th className="text-left px-4 py-3">Cliente</th>
                <th className="text-left px-4 py-3">Obra</th>
                <SortableTh field="data" label="Data" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-4 py-3" />
                <th className="text-left px-4 py-3">Competência</th>
                <SortableTh field="valor" label="Valor" align="right" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-4 py-3" />
                <SortableTh field="status" label="Status" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-4 py-3" />
                <th className="text-center px-4 py-3">Recebimento</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {visiveis.length === 0 && <tr><td colSpan={8} className="px-4 py-10 text-center text-slate-400">{obraGlobal !== 'geral' ? 'Sem notas para a obra selecionada.' : 'Nenhuma nota.'}</td></tr>}
              {visiveis.map((n) => {
                const ps = parcPorNota[n.id] || [];
                const recebido = ps.filter((p) => p.status === 'Recebido' || p.data_recebida).length;
                return (
                  <tr key={n.id} className="cursor-pointer hover:bg-slate-50" onClick={() => setSel(n)}>
                    <td className="px-4 py-3 font-medium text-[#0b2545]">{n.numero}</td>
                    <td className="px-4 py-3 text-slate-700">{n.cliente_nome || '—'}</td>
                    <td className="px-4 py-3 text-slate-700">{n.obra_nome || '—'}</td>
                    <td className="px-4 py-3 text-slate-500">{fmtDate(n.data_emissao)}</td>
                    <td className="px-4 py-3 text-slate-500">{n.competencia || '—'}</td>
                    <td className="px-4 py-3 text-right font-semibold">{fmtMoney(n.valor_bruto)}</td>
                    <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${ST_NOTA[n.status] || 'bg-slate-100 text-slate-500'}`}>{n.status || '—'}</span></td>
                    <td className="px-4 py-3 text-center text-slate-500">{ps.length ? `${recebido}/${ps.length}` : '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {importarXml && <ImportarXmlNfDialog open={importarXml} onClose={() => setImportarXml(false)} onImported={onReload} />}
      {lancar && <LancarNotaModal open={lancar} onClose={() => setLancar(false)} onSaved={onReload} />}
      {sel && (
        <NotaFiscalModal nota={sel} parcelas={parcPorNota[sel.id] || []} open={!!sel} onClose={() => setSel(null)} onSaved={onReload} podeEditar={podeEditar} />
      )}
    </div>
  );
}