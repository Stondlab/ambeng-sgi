import React, { useEffect, useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { fmtMoney } from '@/lib/financeiro';
import { ShieldAlert } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { usePerm } from '@/hooks/usePerm';

// Aba Apuração — consolidada por competência. RESTRITA AO ADMINISTRADOR.
// Dados via função backend listarApuracaoFiscal (valida perfil novamente).
export default function TabApuracao() {
  const { podeVer } = usePerm('fis_apuracao');
  const [data, setData] = useState(null);
  const [erro, setErro] = useState(null);
  const [modo, setModo] = useState('mensal');

  useEffect(() => {
    if (!podeVer) return;
    base44.functions.invoke('listarApuracaoFiscal', {})
      .then((res) => setData(res.data))
      .catch((e) => setErro(e.response?.data?.error || e.message));
  }, [podeVer]);

  const mensal = data?.apuracao || [];
  // Agrega trimestralmente (T1=jan-mar, etc.) a partir das linhas mensais.
  const trimestral = useMemo(() => {
    const m = {};
    for (const l of mensal) {
      const [y, mo] = l.competencia.split('-');
      const t = Math.ceil(Number(mo) / 3);
      const k = `${y}/T${t}`;
      if (!m[k]) m[k] = { competencia: k, base: 0, pis: 0, cofins: 0, iss: 0, inss_retido: 0, irpj: 0, csll: 0, notas: 0 };
      const a = m[k];
      a.base += l.base; a.pis += l.pis; a.cofins += l.cofins; a.iss += l.iss; a.inss_retido += l.inss_retido; a.irpj += l.irpj; a.csll += l.csll; a.notas += l.notas;
    }
    return Object.values(m).sort((x, y) => (x.competencia < y.competencia ? 1 : -1));
  }, [mensal]);

  if (!podeVer) return <AcessoRestrito texto="Apuração Fiscal restrita ao Administrador." />;
  if (erro) return <AcessoRestrito texto={erro} />;
  if (!data) return <div className="py-20 text-center text-slate-400">Carregando…</div>;

  const linhas = modo === 'mensal' ? mensal : trimestral;
  const totais = linhas.reduce((a, l) => ({ base: a.base + l.base, pis: a.pis + l.pis, cofins: a.cofins + l.cofins, iss: a.iss + l.iss, inss: a.inss + l.inss_retido, irpj: a.irpj + l.irpj, csll: a.csll + l.csll }), { base: 0, pis: 0, cofins: 0, iss: 0, inss: 0, irpj: 0, csll: 0 });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold uppercase tracking-wider text-[#0b2545]">Apuração Fiscal</h3>
        <div className="flex gap-2">
          <Button size="sm" variant={modo === 'mensal' ? 'default' : 'outline'} onClick={() => setModo('mensal')} className={modo === 'mensal' ? 'bg-[#0b2545] hover:bg-[#16365f]' : ''}>Mensal</Button>
          <Button size="sm" variant={modo === 'trimestral' ? 'default' : 'outline'} onClick={() => setModo('trimestral')} className={modo === 'trimestral' ? 'bg-[#0b2545] hover:bg-[#16365f]' : ''}>Trimestral</Button>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { l: 'Base de receita', v: totais.base }, { l: 'ISS', v: totais.iss },
          { l: 'INSS retido', v: totais.inss }, { l: 'PIS + COFINS', v: totais.pis + totais.cofins },
          { l: 'IRPJ', v: totais.irpj }, { l: 'CSLL', v: totais.csll },
        ].map((k) => (
          <div key={k.l} className="bg-white border border-slate-200 rounded-xl p-4">
            <div className="text-xs text-slate-500 uppercase tracking-wide">{k.l}</div>
            <div className="text-lg font-bold text-[#0b2545] mt-1">{fmtMoney(k.v)}</div>
          </div>
        ))}
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
              <tr>
                <th className="text-left px-4 py-3">{modo === 'mensal' ? 'Competência' : 'Período'}</th><th className="text-right px-4 py-3">Notas</th>
                <th className="text-right px-4 py-3">Base</th><th className="text-right px-4 py-3">PIS</th><th className="text-right px-4 py-3">COFINS</th>
                <th className="text-right px-4 py-3">ISS</th><th className="text-right px-4 py-3">INSS ret.</th><th className="text-right px-4 py-3">IRPJ</th><th className="text-right px-4 py-3">CSLL</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {linhas.length === 0 && <tr><td colSpan={9} className="px-4 py-10 text-center text-slate-400">Sem apuração.</td></tr>}
              {linhas.map((l) => (
                <tr key={l.competencia}>
                  <td className="px-4 py-3 font-medium">{l.competencia}</td>
                  <td className="px-4 py-3 text-right text-slate-500">{l.notas}</td>
                  <td className="px-4 py-3 text-right">{fmtMoney(l.base)}</td>
                  <td className="px-4 py-3 text-right">{fmtMoney(l.pis)}</td>
                  <td className="px-4 py-3 text-right">{fmtMoney(l.cofins)}</td>
                  <td className="px-4 py-3 text-right">{fmtMoney(l.iss)}</td>
                  <td className="px-4 py-3 text-right">{fmtMoney(l.inss_retido)}</td>
                  <td className="px-4 py-3 text-right">{fmtMoney(l.irpj)}</td>
                  <td className="px-4 py-3 text-right">{fmtMoney(l.csll)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function AcessoRestrito({ texto }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <ShieldAlert className="w-12 h-12 text-amber-500 mb-3" />
      <h2 className="text-lg font-semibold text-[#0b2545]">Acesso restrito ao Administrador.</h2>
      <p className="text-sm text-slate-500 mt-1">{texto}</p>
    </div>
  );
}