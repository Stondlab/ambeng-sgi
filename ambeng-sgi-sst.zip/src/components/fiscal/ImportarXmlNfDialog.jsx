import React, { useState } from 'react';
import { FileUp, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { nomeUsuario } from '@/lib/usuarioNome';
import { extrairNotaArquivo } from '@/lib/notaImportacao';

export default function ImportarXmlNfDialog({ open, onClose, onImported }) {
  const [tipo, setTipo] = useState('Recebida'); const [files, setFiles] = useState([]); const [loading, setLoading] = useState(false); const { toast } = useToast();
  const importar = async () => {
    if (!files.length) return; setLoading(true);
    try {
      const existentes = await base44.entities.NotasFiscais.list('-data_emissao', 3000); const usuario = nomeUsuario(await base44.auth.me()); let criadas = 0; let duplicadas = 0;
      for (const file of files) {
        const { dados, file_url } = await extrairNotaArquivo(file, tipo); const repetida = existentes.some((nota) => nota.numero === dados.numero && (nota.serie || '1') === dados.serie && nota.cliente_cnpj_cpf === dados.cliente_cnpj_cpf);
        if (repetida) { duplicadas++; continue; }
        const criada = await base44.entities.NotasFiscais.create({ ...dados, documentos: JSON.stringify([{ url: file_url, nome: file.name, tipo: file.name.split('.').pop()?.toUpperCase() || 'Arquivo', data: new Date().toISOString() }]), responsavel_lancamento: usuario, historico: JSON.stringify([{ usuario, data_hora: new Date().toISOString(), acao: 'Documento importado — pendente de conferência' }]) }); existentes.push(criada); criadas++;
      }
      toast({ title: `${criadas} nota(s) importada(s).`, description: duplicadas ? `${duplicadas} duplicada(s) ignorada(s).` : 'Confira os dados antes de integrar ao Financeiro.' }); onImported?.(); onClose();
    } catch (error) { toast({ title: 'Não foi possível importar as notas.', description: error.message, variant: 'destructive' }); } finally { setLoading(false); }
  };
  return <Dialog open={open} onOpenChange={(value) => !value && !loading && onClose()}><DialogContent className="max-w-lg"><DialogHeader><DialogTitle className="flex items-center gap-2"><FileUp className="h-5 w-5" />Importar Nota Fiscal</DialogTitle><DialogDescription>Importe XML, PDF ou imagem. A nota ficará pendente e não afetará o Financeiro antes da conferência.</DialogDescription></DialogHeader><div><Label>Tipo das notas</Label><Select value={tipo} onValueChange={setTipo}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Recebida">Notas recebidas</SelectItem><SelectItem value="Emitida">Notas emitidas</SelectItem></SelectContent></Select></div><label className="flex min-h-28 cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-border bg-muted/30 p-4 text-center"><FileUp className="mb-2 h-6 w-6 text-primary" /><span className="text-sm font-semibold">Selecionar notas</span><span className="mt-1 text-xs text-muted-foreground">XML, PDF ou imagem · seleção múltipla</span><input type="file" accept=".xml,.pdf,.png,.jpg,.jpeg,text/xml,application/xml,application/pdf,image/*" multiple className="hidden" onChange={(event) => setFiles([...event.target.files])} /></label>{files.length > 0 && <p className="text-sm text-muted-foreground">{files.length} arquivo(s) selecionado(s).</p>}<DialogFooter><Button variant="ghost" onClick={onClose} disabled={loading}>Cancelar</Button><Button onClick={importar} disabled={!files.length || loading}>{loading && <Loader2 className="animate-spin" />}{loading ? 'Importando...' : 'Importar notas'}</Button></DialogFooter></DialogContent></Dialog>;
}