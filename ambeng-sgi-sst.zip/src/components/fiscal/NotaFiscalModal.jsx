import React, { useEffect, useMemo, useState } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { Receipt, Pencil, Save, FileText, BadgeCheck, Ban } from 'lucide-react';
import ConferirNotaDialog from '@/components/fiscal/ConferirNotaDialog';
import { calcParcelas, fmtMoney } from '@/lib/financeiro';
import { nomeUsuario } from '@/lib/usuarioNome';
import { statusEfetivo, ST_PARCELA, ST_NOTA, fmtDate, totalRecebido, totalAReceber } from '@/lib/fiscal';

// Modal CENTRAL de Nota Fiscal — visualização + edição (UPDATE do registro existente).
// Estrutura: Cabeçalho, Resumo, Dados da Nota, Impostos, Recebimentos, Documentos, Histórico.
// Editar => habilita formulário; Salvar => persiste via salvarNotaFiscal (id) — nunca cria nova nota.
export default function NotaFiscalModal({ nota, parcelas, open, onClose, onSaved, podeEditar }) {
  const { toast } = useToast();
  const [editando, setEditando] = useState(false);
  const [saving, setSaving] = useState(false);
  const [conferir, setConferir] = useState(false);
  const [clientes, setClientes] = useState([]);
  const [obras, setObras] = useState([]);
  const [tipos, setTipos] = useState([]);
  const [municipios, setMunicipios] = useState([]);
  const [form, setForm] = useState({});

  useEffect(() => {
    if (!open) return;
    Promise.all([
      base44.entities.ClientesTomadores.list('razao_social', 500).catch(() => []),
      base44.entities.Obras.list('nome', 500).catch(() => []),
      base44.entities.TiposServico.list('nome', 200).catch(() => []),
      base44.entities.MunicipiosISS.list('municipio', 200).catch(() => []),
    ]).then(([cl, ob, tp, mu]) => { setClientes(cl); setObras(ob); setTipos(tp); setMunicipios(mu); });
  }, [open]);

  useEffect(() => {
    if (nota) {
      setForm({
        tipo: nota.tipo || 'Emitida', cliente_id: nota.cliente_id || '', obra_id: nota.obra_id || '', numero: nota.numero || '', serie: nota.serie || '1',
        data_emissao: nota.data_emissao || '', competencia: nota.competencia || '',
        valor_bruto: nota.valor_bruto || '', valor_material: nota.valor_material || 0,
        tipo_servico_id: nota.tipo_servico_id || '', municipio_id: nota.municipio_id || '',
        discriminacao: nota.discriminacao || '', iss_retido: !!nota.iss_retido, retencao_inss: !!nota.retencao_inss_aplicada,
        numero_parcelas: nota.numero_parcelas || 1, data_primeira_parcela: nota.data_primeira_parcela || nota.data_emissao || '',
        observacoes: nota.observacoes || '',
      });
      setEditando(false);
    }
  }, [nota]);

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const nParc = editando ? Math.max(1, parseInt(form.numero_parcelas) || 1) : (nota?.numero_parcelas || 1);
  const valorBrutoEdit = editando ? (Number(form.valor_bruto) || 0) : (Number(nota?.valor_bruto) || 0);
  const parcelasPreview = useMemo(() => editando ? calcParcelas(valorBrutoEdit, nParc) : [], [editando, valorBrutoEdit, nParc]);

  if (!nota) return null;

  const hist = (() => { try { return nota.historico ? JSON.parse(nota.historico) : []; } catch { return []; } })();
  const docs = (() => { try { return nota.documentos ? JSON.parse(nota.documentos) : []; } catch { return []; } })();
  const ps = parcelas || [];
  const recebidoValor = totalRecebido(ps);
  const saldoValor = totalAReceber(ps);
  const valorCompetencia = ps.length ? ps[0].valor : (Number(nota.valor_bruto) || 0);

  const salvarEdicao = async () => {
    if (!form.cliente_id || !form.numero || !form.data_emissao || !form.valor_bruto) {
      toast({ title: 'Preencha cliente, número, emissão e valor.', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      const userNome = nomeUsuario(await base44.auth.me());
      const res = await base44.functions.invoke('salvarNotaFiscal', { id: nota.id, form, userNome });
      toast({ title: 'Alterações salvas.', description: res.data?.parcelas_regeneradas ? 'Parcelas regeneradas.' : undefined });
      setEditando(false);
      onSaved?.();
    } catch (e) {
      toast({ title: 'Erro ao salvar.', description: e.response?.data?.error || e.message, variant: 'destructive' });
    } finally { setSaving(false); }
  };

  const cancelarPendente = async () => {
    if (!window.confirm('Cancelar esta nota pendente? Nenhum lançamento financeiro será criado.')) return;
    setSaving(true); try { const usuario = nomeUsuario(await base44.auth.me()); await base44.entities.NotasFiscais.update(nota.id, { status: 'Cancelada', conferido: false, historico: JSON.stringify([...hist, { usuario, data_hora: new Date().toISOString(), acao: 'Nota cancelada antes da integração financeira' }]) }); onSaved?.(); onClose(); } catch (error) { toast({ title: 'Não foi possível cancelar a nota.', description: error.message, variant: 'destructive' }); } finally { setSaving(false); }
  };

  const stNota = nota.status || 'Pendente de conferência';

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-5xl w-[94vw] max-h-[92vh] p-0 gap-0 overflow-hidden flex flex-col">
        {/* Cabeçalho */}
        <div className="px-6 py-4 border-b border-slate-200 bg-gradient-to-r from-[#0b2545] to-[#16365f] text-white shrink-0">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0"><Receipt className="w-5 h-5" /></div>
              <div className="min-w-0">
                <h2 className="text-lg font-bold leading-tight truncate">NOTA FISCAL — {nota.numero}{nota.serie ? ` (série ${nota.serie})` : ''}</h2>
                <p className="text-sm text-white/80 mt-0.5 truncate">{[nota.cliente_nome, nota.obra_nome].filter(Boolean).join(' · ') || 'Sem dados'}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {podeEditar && stNota === 'Pendente de conferência' && <><Button size="sm" variant="secondary" onClick={() => setConferir(true)}><BadgeCheck className="h-4 w-4" />Conferir</Button><Button size="sm" variant="destructive" onClick={cancelarPendente} disabled={saving}><Ban className="h-4 w-4" />Cancelar nota</Button></>}<span className={`px-2.5 py-1 rounded-full text-[11px] font-semibold ${ST_NOTA[stNota] || 'bg-slate-100 text-slate-500'}`}>{stNota}</span>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-5 bg-slate-50/60">
          {/* Resumo */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <ResumoCard label="Valor total" value={fmtMoney(nota.valor_bruto)} />
            <ResumoCard label="Competência" value={nota.competencia || '—'} />
            <ResumoCard label="Recebido" value={fmtMoney(recebidoValor)} accent={recebidoValor > 0 ? 'border-emerald-300 bg-emerald-50' : ''} />
            <ResumoCard label="Saldo a receber" value={fmtMoney(saldoValor)} accent={saldoValor > 0 ? 'border-amber-300 bg-amber-50' : ''} />
          </div>

          {/* Dados da Nota */}
          <Card title="Dados da Nota" action={podeEditar && !editando && (
            <Button size="sm" variant="outline" onClick={() => setEditando(true)} className="h-8"><Pencil className="w-3.5 h-3.5" />Editar</Button>
          )}>
            {editando ? (
              <div className="space-y-3">
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <div><Label>Tipo *</Label>
                    <Select value={form.tipo} onValueChange={(v) => set('tipo', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent><SelectItem value="Emitida">Emitida</SelectItem><SelectItem value="Recebida">Recebida</SelectItem></SelectContent></Select>
                  </div>
                  <div><Label>Número *</Label><Input className="mt-1" value={form.numero} onChange={(e) => set('numero', e.target.value)} /></div>
                  <div><Label>Série</Label><Input className="mt-1" value={form.serie} onChange={(e) => set('serie', e.target.value)} /></div>
                  <div><Label>Data Emissão *</Label><Input type="date" className="mt-1" value={form.data_emissao} onChange={(e) => set('data_emissao', e.target.value)} /></div>
                  <div><Label>{form.tipo === 'Recebida' ? 'Fornecedor *' : 'Cliente *'}</Label>
                    <Select value={form.cliente_id} onValueChange={(v) => set('cliente_id', v)}><SelectTrigger className="mt-1"><SelectValue placeholder={form.tipo === 'Recebida' ? 'Selecionar fornecedor' : 'Selecionar cliente'} /></SelectTrigger>
                      <SelectContent>{clientes.map((c) => <SelectItem key={c.id} value={c.id}>{c.razao_social}</SelectItem>)}</SelectContent></Select>
                  </div>
                  <div className="sm:col-span-2"><Label>Descrição / Natureza</Label><Textarea className="mt-1" rows={2} value={form.discriminacao} onChange={(e) => set('discriminacao', e.target.value)} /></div>
                  <div><Label>Valor Total *</Label><Input type="number" step="0.01" className="mt-1" value={form.valor_bruto} onChange={(e) => set('valor_bruto', e.target.value)} /></div>
                  <div><Label>Obra</Label>
                    <Select value={form.obra_id} onValueChange={(v) => set('obra_id', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>{obras.map((o) => <SelectItem key={o.id} value={o.id}>{o.nome}</SelectItem>)}</SelectContent></Select>
                  </div>
                  <div><Label>Competência</Label><Input className="mt-1" value={form.competencia} onChange={(e) => set('competencia', e.target.value)} /></div>
                  <div><Label>Material dedut.</Label><Input type="number" step="0.01" className="mt-1" value={form.valor_material} onChange={(e) => set('valor_material', e.target.value)} /></div>
                  <div><Label>Tipo de serviço</Label>
                    <Select value={form.tipo_servico_id} onValueChange={(v) => set('tipo_servico_id', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>{tipos.map((t) => <SelectItem key={t.id} value={t.id}>{t.nome}</SelectItem>)}</SelectContent></Select>
                  </div>
                  <div><Label>Município</Label>
                    <Select value={form.municipio_id} onValueChange={(v) => set('municipio_id', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>{municipios.map((m) => <SelectItem key={m.id} value={m.id}>{m.municipio}/{m.uf}</SelectItem>)}</SelectContent></Select>
                  </div>
                  <div><Label>Nº parcelas</Label><Input type="number" min="1" max="48" className="mt-1" value={form.numero_parcelas} onChange={(e) => set('numero_parcelas', e.target.value)} /></div>
                  <div><Label>1ª parcela</Label><Input type="date" className="mt-1" value={form.data_primeira_parcela} onChange={(e) => set('data_primeira_parcela', e.target.value)} /></div>
                </div>
                <div className="flex flex-wrap items-center gap-6">
                  <label className="flex items-center gap-2 text-sm"><Switch checked={form.iss_retido} onCheckedChange={(v) => set('iss_retido', v)} /> ISS retido</label>
                  <label className="flex items-center gap-2 text-sm"><Switch checked={form.retencao_inss} onCheckedChange={(v) => set('retencao_inss', v)} /> Reter INSS</label>
                </div>
                <div><Label>Discriminação</Label><Textarea className="mt-1" rows={2} value={form.discriminacao} onChange={(e) => set('discriminacao', e.target.value)} /></div>
                <div><Label>Observação</Label><Textarea className="mt-1" rows={2} value={form.observacoes} onChange={(e) => set('observacoes', e.target.value)} /></div>
                {nParc > 1 && (
                  <div className="rounded-lg bg-white border border-slate-200 px-3 py-2 text-xs text-slate-600">
                    <div className="font-semibold text-[#0b2545] mb-1">Novo parcelamento — soma = {fmtMoney(parcelasPreview.reduce((s, v) => s + v, 0))}</div>
                    <div className="flex flex-wrap gap-x-4 gap-y-1">
                      {parcelasPreview.map((v, i) => <span key={i}>{i + 1}/{nParc}: <b className="text-[#0b2545]">{fmtMoney(v)}</b></span>)}
                    </div>
                    {ps.some((p) => p.status === 'Recebido' || p.data_recebida) && (
                      <div className="mt-2 text-amber-700">Existem parcelas já recebidas — o parcelamento não será regenerado.</div>
                    )}
                  </div>
                )}
                <div className="flex justify-end gap-2 pt-2">
                  <Button variant="ghost" onClick={() => setEditando(false)} className="min-h-[44px]">Cancelar</Button>
                  <Button onClick={salvarEdicao} disabled={saving} className="bg-[#0b2545] hover:bg-[#16365f] min-h-[44px]"><Save className="w-4 h-4" />{saving ? 'Salvando…' : 'Salvar alterações'}</Button>
                </div>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-1">
                <Campo label="Tipo" value={nota.tipo || 'Emitida'} />
                <Campo label={nota.tipo === 'Recebida' ? 'Fornecedor' : 'Cliente'} value={nota.cliente_nome} />
                <Campo label="Obra" value={nota.obra_nome} />
                <Campo label="Número" value={nota.numero} />
                <Campo label="Série" value={nota.serie} />
                <Campo label="Emissão" value={fmtDate(nota.data_emissao)} />
                <Campo label="Competência" value={nota.competencia} />
                <Campo label="Valor total" value={fmtMoney(nota.valor_bruto)} />
                <Campo label="Material dedut." value={fmtMoney(nota.valor_material)} />
                <Campo label="Tipo de serviço" value={nota.tipo_servico_nome} />
                <Campo label="Município" value={nota.municipio_execucao ? `${nota.municipio_execucao}/${nota.uf_execucao || ''}` : '—'} />
                <Campo label="Parcelamento" value={nota.numero_parcelas > 1 ? `${nota.numero_parcelas}x de ${fmtMoney(valorCompetencia)}` : 'À vista'} />
                <Campo label="1ª parcela" value={fmtDate(nota.data_primeira_parcela)} />
                <Campo label="ISS retido" value={nota.iss_retido ? 'Sim' : 'Não'} />
                <Campo label="Retenção INSS" value={nota.retencao_inss_aplicada ? 'Sim' : 'Não'} />
                <div className="sm:col-span-2 lg:col-span-3"><Campo label="Discriminação" value={nota.discriminacao} /></div>
                <div className="sm:col-span-2 lg:col-span-3"><Campo label="Observação" value={nota.observacoes} /></div>
              </div>
            )}
          </Card>

          {/* Impostos */}
          <Card title="Impostos">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-x-4 gap-y-1">
              <Campo label="Base ISS" value={fmtMoney(nota.base_iss)} /><Campo label="Alíq. ISS" value={`${nota.aliquota_iss || 0}%`} /><Campo label="Valor ISS" value={fmtMoney(nota.valor_iss)} /><Campo label="ISS retido" value={fmtMoney(nota.valor_iss_retido)} />
              <Campo label="Base INSS" value={fmtMoney(nota.base_inss)} /><Campo label="INSS retido" value={fmtMoney(nota.valor_inss_retido)} />
              <Campo label="PIS" value={fmtMoney(nota.valor_pis)} /><Campo label="COFINS" value={fmtMoney(nota.valor_cofins)} />
              <Campo label="Base IRPJ" value={fmtMoney(nota.base_presumida_irpj)} /><Campo label="IRPJ" value={fmtMoney(nota.valor_irpj)} />
              <Campo label="Base CSLL" value={fmtMoney(nota.base_presumida_csll)} /><Campo label="CSLL" value={fmtMoney(nota.valor_csll)} />
            </div>
          </Card>

          {/* Recebimentos (parcelas) */}
          <Card title="Recebimentos">
            {ps.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-4">Nenhuma parcela.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-xs uppercase text-slate-500 bg-slate-50"><tr>
                    <th className="text-left px-3 py-2">Parcela</th><th className="text-left px-3 py-2">Vencimento</th>
                    <th className="text-right px-3 py-2">Valor</th><th className="text-left px-3 py-2">Status</th>
                    <th className="text-left px-3 py-2">Recebido em</th>
                  </tr></thead>
                  <tbody className="divide-y divide-slate-100">
                    {ps.map((p) => {
                      const st = statusEfetivo(p);
                      return (
                        <tr key={p.id}>
                          <td className="px-3 py-2 font-medium text-[#0b2545]">{p.numero_parcela}/{p.total_parcelas}</td>
                          <td className="px-3 py-2 text-slate-600">{fmtDate(p.data_prevista)}</td>
                          <td className="px-3 py-2 text-right font-semibold text-slate-700">{fmtMoney(p.valor)}</td>
                          <td className="px-3 py-2"><span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${ST_PARCELA[st]}`}>{st}</span></td>
                          <td className="px-3 py-2 text-slate-600">{p.data_recebida ? `${fmtDate(p.data_recebida)}${p.forma_recebimento ? ' · ' + p.forma_recebimento : ''}` : '—'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot><tr className="border-t border-slate-200"><td className="px-3 py-2 font-semibold text-slate-500" colSpan={2}>Total</td><td className="px-3 py-2 text-right font-bold text-[#0b2545]">{fmtMoney(ps.reduce((s, p) => s + (Number(p.valor) || 0), 0))}</td><td colSpan={2} /></tr></tfoot>
                </table>
                <p className="text-[11px] text-slate-400 mt-2">Cada parcela mostra seu valor próprio — a soma das parcelas = valor total da nota.</p>
              </div>
            )}
          </Card>

          {/* Documentos */}
          <Card title="Documentos">
            {docs.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-4">Nenhum documento.</p>
            ) : (
              <div className="space-y-2">
                {docs.map((d, i) => (
                  <div key={i} className="flex items-center gap-3 p-2 rounded-lg border border-slate-200 bg-slate-50/60">
                    <FileText className="w-4 h-4 text-slate-500" />
                    <div className="min-w-0 flex-1"><div className="text-sm font-medium text-slate-700 truncate">{d.nome}</div><div className="text-[11px] text-slate-500">{d.tipo} · {fmtDate(d.data)}</div></div>
                    <a href={d.url} target="_blank" rel="noreferrer" className="text-xs text-[#0b2545] font-medium hover:underline">Abrir</a>
                  </div>
                ))}
              </div>
            )}
          </Card>

          {/* Histórico */}
          <Card title="Histórico">
            {hist.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-4">Sem alterações registradas.</p>
            ) : (
              <div className="space-y-1.5">
                {hist.slice().reverse().map((h, i) => {
                  const dt = new Date(h.data_hora);
                  return (
                    <div key={i} className="flex items-start gap-3 text-sm py-1 border-b border-slate-50 last:border-0">
                      <div className="w-20 shrink-0 text-xs font-bold text-[#0b2545] uppercase truncate">{h.usuario || '—'}</div>
                      <div className="text-xs text-slate-400 w-36 shrink-0">{dt.toLocaleDateString('pt-BR')} {dt.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                      <div className="min-w-0 flex-1">
                        <span className="text-slate-600">{h.acao}</span>
                        {h.campo && <span className="text-slate-500"> — {h.campo}: </span>}
                        {h.anterior != null && <span className="text-slate-400 line-through"> {h.anterior}</span>}
                        {h.novo != null && <span className="text-slate-400"> → </span>}
                        {h.novo != null && <span className="text-slate-700 font-medium">{h.novo}</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>
      </DialogContent>
      <ConferirNotaDialog nota={nota} open={conferir} onClose={() => setConferir(false)} onSaved={() => { onSaved?.(); onClose(); }} />
    </Dialog>
  );
}

function Card({ title, action, children }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-card">
      <div className="px-4 py-2.5 border-b border-slate-100 flex items-center justify-between">
        <h4 className="text-xs font-bold uppercase tracking-wider text-[#0b2545]">{title}</h4>
        {action}
      </div>
      <div className="p-4">{children}</div>
    </div>
  );
}
function ResumoCard({ label, value, accent }) {
  return (
    <div className={`rounded-xl border p-3 ${accent || 'border-slate-200 bg-white'}`}>
      <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">{label}</div>
      <div className="text-lg font-bold text-[#0b2545] mt-0.5 leading-tight">{value}</div>
    </div>
  );
}
function Campo({ label, value }) {
  return (<div className="py-1.5"><div className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">{label}</div><div className="text-sm mt-0.5 text-slate-700">{value || <span className="text-slate-300 italic">Não informado</span>}</div></div>);
}