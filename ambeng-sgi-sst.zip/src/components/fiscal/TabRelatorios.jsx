import React, { useEffect, useMemo, useState } from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { ShieldAlert } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { usePerm } from '@/hooks/usePerm';

// Aba Relatórios — consolidados fiscais. RESTRITA AO ADMINISTRADOR.
export default function TabRelatorios() {
  const { podeVer } = usePerm('fis_relatorios');
  const [data, setData] = useState(null);
  useEffect(() => {
    if (!podeVer) return;
    base44.functions.invoke('listarNotasEmitidas', {}).then((res) => setData(res.data)).catch(() => setData({ notas: [], parcelas: [] }));
  }, [podeVer]);

  const notas = data?.notas || [];
  const porCliente = useMemo(() => {
    const m = {};
    for (const n of notas) { const k = n.cliente_nome || '—'; (m[k] = m[k] || { base: 0, iss: 0, inss: 0, count: 0 }); m[k].base += Number(n.valor_bruto) || 0; m[k].iss += Number(n.valor_iss) || 0; m[k].inss += Number(n.valor_inss_retido) || 0; m[k].count += 1; }
    return Object.entries(m).sort((a, b) => b[1].base - a[1].base);
  }, [notas]);
  const porCompetencia = useMemo(() => {
    const m = {};
    for (const n of notas) { const k = n.competencia || '—'; (m[k] = m[k] || { base: 0, iss: 0, count: 0 }); m[k].base += Number(n.valor_bruto) || 0; m[k].iss += Number(n.valor_iss) || 0; m[k].count += 1; }
    return Object.entries(m).sort((a, b) => (a[0] < b[0] ? 1 : -1));
  }, [notas]);
  const porStatus = useMemo(() => { const m = {}; for (const n of notas) { const k = n.status || '—'; m[k] = (m[k] || 0) + 1; } return Object.entries(m); }, [notas]);

  if (!podeVer) return <Restrito texto="Relatórios fiscais restritos ao Administrador." />;

  if (!data) return <div className="py-20 text-center text-slate-400">Carregando…</div>;

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-bold uppercase tracking-wider text-[#0b2545]">Relatórios Fiscais</h3>
      <div className="grid lg:grid-cols-2 gap-4">
        <Bloco title="Faturamento por cliente">
          <table className="w-full text-sm"><thead className="text-xs text-slate-500 uppercase"><tr><th className="text-left py-2">Cliente</th><th className="text-right py-2">Notas</th><th className="text-right py-2">Base</th><th className="text-right py-2">ISS</th></tr></thead>
            <tbody className="divide-y divide-slate-100">
              {porCliente.length === 0 && <tr><td colSpan={4} className="py-6 text-center text-slate-400">Sem dados.</td></tr>}
              {porCliente.map(([k, v]) => <tr key={k}><td className="py-2">{k}</td><td className="text-right">{v.count}</td><td className="text-right">{fmtMoney(v.base)}</td><td className="text-right">{fmtMoney(v.iss)}</td></tr>)}
            </tbody>
          </table>
        </Bloco>
        <Bloco title="Faturamento por competência">
          <table className="w-full text-sm"><thead className="text-xs text-slate-500 uppercase"><tr><th className="text-left py-2">Competência</th><th className="text-right py-2">Notas</th><th className="text-right py-2">Base</th><th className="text-right py-2">ISS</th></tr></thead>
            <tbody className="divide-y divide-slate-100">
              {porCompetencia.length === 0 && <tr><td colSpan={4} className="py-6 text-center text-slate-400">Sem dados.</td></tr>}
              {porCompetencia.map(([k, v]) => <tr key={k}><td className="py-2">{k}</td><td className="text-right">{v.count}</td><td className="text-right">{fmtMoney(v.base)}</td><td className="text-right">{fmtMoney(v.iss)}</td></tr>)}
            </tbody>
          </table>
        </Bloco>
        <Bloco title="Distribuição por status">
          {porStatus.length === 0 ? <div className="text-center text-slate-400 py-6">Sem dados.</div> : (
            <div className="space-y-2">{porStatus.map(([k, v]) => <div key={k} className="flex items-center justify-between text-sm"><span className="text-slate-700">{k}</span><span className="font-semibold text-[#0b2545]">{v}</span></div>)}</div>
          )}
        </Bloco>
      </div>
    </div>
  );
}

function Bloco({ title, children }) {
  return <div className="bg-white border border-slate-200 rounded-xl p-4"><h4 className="text-sm font-semibold text-[#0b2545] mb-3">{title}</h4>{children}</div>;
}
function Restrito({ texto }) {
  return (<div className="flex flex-col items-center justify-center py-20 text-center"><ShieldAlert className="w-12 h-12 text-amber-500 mb-3" /><h2 className="text-lg font-semibold text-[#0b2545]">Acesso restrito ao Administrador.</h2><p className="text-sm text-slate-500 mt-1">{texto}</p></div>);
}