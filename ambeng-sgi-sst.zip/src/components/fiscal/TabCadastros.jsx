import React, { useState } from 'react';
import CrudTab from '@/components/financeiro/CrudTab';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Building2, MapPin, Wrench, Percent } from 'lucide-react';
import { usePerm } from '@/hooks/usePerm';
import { CLIENTES_FIELDS, CLIENTES_COLS, MUNICIPIOS_FIELDS, MUNICIPIOS_COLS, TIPOS_SERVICO_FIELDS, TIPOS_SERVICO_COLS, PARAMETROS_FIELDS, PARAMETROS_COLS } from '@/lib/fiscalCadastros';

// Aba Cadastros — Clientes, Municípios, Serviços, Parâmetros Tributários.
// Parâmetros Tributários: Administrativo só visualiza (fis_cadastros_param visualizar).
export default function TabCadastros() {
  const [tab, setTab] = useState('clientes');
  const { podeVer: podeVerParam, podeCriar: podeCriarParam, podeEditar: podeEditarParam, podeExcluir: podeExcluirParam } = usePerm('fis_cadastros_param');

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-bold uppercase tracking-wider text-[#0b2545]">Cadastros Fiscais</h3>
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="w-full justify-start overflow-x-auto h-auto">
          <TabsTrigger value="clientes" className="min-h-[44px] gap-2"><Building2 className="w-4 h-4" />Clientes / Tomadores</TabsTrigger>
          <TabsTrigger value="municipios" className="min-h-[44px] gap-2"><MapPin className="w-4 h-4" />Municípios ISS</TabsTrigger>
          <TabsTrigger value="servicos" className="min-h-[44px] gap-2"><Wrench className="w-4 h-4" />Tipos de Serviço</TabsTrigger>
          {podeVerParam && <TabsTrigger value="parametros" className="min-h-[44px] gap-2"><Percent className="w-4 h-4" />Parâmetros Tributários</TabsTrigger>}
        </TabsList>

        <TabsContent value="clientes" className="mt-5">
          <CrudTab entity="ClientesTomadores" fields={CLIENTES_FIELDS} columns={CLIENTES_COLS} addLabel="Novo Cliente" emptyLabel="Nenhum cliente cadastrado." moduloId="fis_cadastros" />
        </TabsContent>
        <TabsContent value="municipios" className="mt-5">
          <CrudTab entity="MunicipiosISS" fields={MUNICIPIOS_FIELDS} columns={MUNICIPIOS_COLS} addLabel="Novo Município" emptyLabel="Nenhum município cadastrado." moduloId="fis_cadastros" />
        </TabsContent>
        <TabsContent value="servicos" className="mt-5">
          <CrudTab entity="TiposServico" fields={TIPOS_SERVICO_FIELDS} columns={TIPOS_SERVICO_COLS} addLabel="Novo Tipo de Serviço" emptyLabel="Nenhum tipo cadastrado." moduloId="fis_cadastros" />
        </TabsContent>
        {podeVerParam && (
          <TabsContent value="parametros" className="mt-5">
            {podeCriarParam || podeEditarParam ? (
              <CrudTab entity="ParametrosFiscais" fields={PARAMETROS_FIELDS} columns={PARAMETROS_COLS} sortField="-vigencia_inicio" addLabel="Novo Parâmetro" emptyLabel="Nenhum parâmetro cadastrado." moduloId="fis_cadastros_param" />
            ) : (
              <CrudTab entity="ParametrosFiscais" fields={PARAMETROS_FIELDS} columns={PARAMETROS_COLS} sortField="-vigencia_inicio" addLabel="Novo Parâmetro" emptyLabel="Nenhum parâmetro cadastrado." moduloId="fis_cadastros_param" />
            )}
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}