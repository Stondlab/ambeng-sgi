import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Trash2 } from 'lucide-react';

export default function ApontamentoPicker({ data, ap, obraNomes, onClose, onSave }) {
  const [tipo, setTipo] = useState(ap?.tipo || 'Trabalhado');
  const [obra, setObra] = useState(ap?.obra || (ap?.tipo === 'Atestado' ? '' : (obraNomes[0] || '')));
  const submit = () => onSave(data, tipo, obra);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-sm bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">Apontamento — {data}</h3><button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div>
          <Label>Marcação</Label>
          <Select value={tipo} onValueChange={(v) => { setTipo(v); if (v === 'Atestado') setObra(''); }}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Trabalhado">Trabalhado</SelectItem><SelectItem value="Atestado">Atestado</SelectItem></SelectContent></Select>
        </div>
        {tipo === 'Trabalhado' && (
          <div>
            <Label>Obra</Label>
            <Select value={obra} onValueChange={setObra}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{obraNomes.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
          </div>
        )}
        <div className="flex justify-between gap-2 pt-2">
          {ap && <Button variant="ghost" onClick={() => onSave(data, 'limpar', '')} className="text-red-600"><Trash2 className="w-4 h-4 mr-1" />Limpar</Button>}
          <Button onClick={submit} className="bg-[#0b2545] hover:bg-[#16365f] ml-auto">Salvar</Button>
        </div>
      </div>
    </div>
  );
}