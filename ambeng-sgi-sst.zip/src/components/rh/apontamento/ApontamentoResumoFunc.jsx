import React, { useMemo } from 'react';
import { X } from 'lucide-react';
import { parseHoras, formatHoras } from '@/lib/apontamento';
import { siglaObra } from '@/lib/obraCores';

// Resumo mensal de um funcionário (clique no nome na grade).
function Stat({ label, value, tone }) {
  const c = tone === 'emerald' ? 'text-emerald-700' : tone === 'amber' ? 'text-amber-700' : tone === 'rose' ? 'text-rose-700' : 'text-[#0b2545]';
  return (
    <div className="rounded-lg bg-white border border-slate-200 p-3">
      <div className="text-[10px] uppercase tracking-wide text-slate-500">{label}</div>
      <div className={`text-lg font-bold ${c}`}>{value}</div>
    </div>
  );
}

export default function ApontamentoResumoFunc({ func, aps, ponto, onClose }) {
  const mine = useMemo(() => aps.filter((a) => a.funcionario_id === func.id), [aps, func.id]);
  const diasTrab = useMemo(() => new Set(mine.map((a) => a.data)).size, [mine]);
  const horasTotais = mine.filter((a) => a.tipo !== 'Atestado').reduce((s, a) => s + (Number(a.horas) || 0), 0);
  const obrasSet = useMemo(() => [...new Set(mine.map((a) => a.obra).filter(Boolean))], [mine]);

  const { conf, pend, div } = useMemo(() => {
    let conf = 0, pend = 0, div = 0;
    new Set(mine.map((a) => a.data)).forEach((ds) => {
      const apDay = mine.filter((a) => a.data === ds);
      const ap = apDay.filter((a) => a.tipo !== 'Atestado').reduce((s, a) => s + (Number(a.horas) || 0), 0);
      const p = ponto.find((x) => x.funcionario_id === func.id && x.data === ds);
      if (!p) pend++; else if (Math.abs(ap - parseHoras(p.total_horas)) < 0.05) conf++; else div++;
    });
    return { conf, pend, div };
  }, [mine, ponto, func.id]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-card-hover flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <div>
            <h3 className="font-semibold text-[#0b2545]">{func.nome}</h3>
            <p className="text-xs text-slate-500">{func.funcao || '—'}</p>
          </div>
          <button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button>
        </div>
        <div className="px-5 py-4 space-y-3 overflow-y-auto">
          <div className="grid grid-cols-2 gap-3">
            <Stat label="Dias trabalhados" value={diasTrab} />
            <Stat label="Horas totais" value={formatHoras(horasTotais)} />
            <Stat label="Conferidos" value={conf} tone="emerald" />
            <Stat label="Pendências" value={pend} tone="amber" />
            <Stat label="Divergências" value={div} tone="rose" />
            <Stat label="Apontamentos" value={mine.length} />
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Obras</div>
            {obrasSet.length ? (
              <div className="flex flex-wrap gap-1.5">
                {obrasSet.map((o) => <span key={o} className="text-xs px-2 py-1 rounded-md bg-slate-100 text-slate-700"><b>{siglaObra(o)}</b> — {o}</span>)}
              </div>
            ) : <p className="text-xs text-slate-400">Nenhuma obra neste mês.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}