import React, { useMemo } from 'react';
import { AlertTriangle, Check, Clock } from 'lucide-react';
import { parseHoras, formatHoras } from '@/lib/apontamento';
import { siglaObra, corDaObra, textoContraste, corSuave } from '@/lib/obraCores';
import { alertasJornada } from '@/lib/ponto';
import { ehFeriado } from '@/lib/feriados';

// Grade visual FUNCIONÁRIO × DIA. Cor da célula = status (semáforo).
// Conteúdo = sigla da obra. Detalhe fica no modal (clique na célula).
// Coluna Funcionário fixa (scroll horizontal); cabeçalho fixo (scroll vertical).

const WEEK = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];

const STATUS = {
  conferido: { label: 'Conferido' },
  pendente: { label: 'Pendente de conferência' },
  divergencia: { label: 'Divergência' },
};

function statusDe(apDay, p) {
  if (!apDay?.length) return null;
  const ap = apDay.filter((a) => a.tipo !== 'Atestado').reduce((s, a) => s + (Number(a.horas) || 0), 0);
  if (!p) return 'pendente';
  return Math.abs(ap - parseHoras(p.total_horas)) < 0.05 ? 'conferido' : 'divergencia';
}

export default function ApontamentoGrid({ funcs, aps, ponto, anoMes, onCellClick, onFuncClick, readOnly, obras = [] }) {
  const days = useMemo(() => {
    const [y, m] = anoMes.split('-').map(Number);
    const total = new Date(y, m, 0).getDate();
    const arr = [];
    for (let d = 1; d <= total; d++) {
      const ds = `${anoMes}-${String(d).padStart(2, '0')}`;
      const dow = new Date(y, m - 1, d).getDay();
      arr.push({ ds, d, dow, week: WEEK[dow], feriado: ehFeriado(ds) });
    }
    return arr;
  }, [anoMes]);

  const hoje = new Date().toISOString().slice(0, 10);

  const apsMap = useMemo(() => {
    const m = {}; aps.forEach((a) => { (m[`${a.funcionario_id}|${a.data}`] = m[`${a.funcionario_id}|${a.data}`] || []).push(a); });
    return m;
  }, [aps]);
  const pMap = useMemo(() => { const m = {}; ponto.forEach((p) => { m[`${p.funcionario_id}|${p.data}`] = p; }); return m; }, [ponto]);

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div className="overflow-auto max-h-[70vh]">
        <table className="border-separate border-spacing-0 text-sm">
          <thead>
            <tr>
              <th className="sticky left-0 top-0 z-30 bg-slate-100 border-b border-r border-slate-200 text-left px-3 py-2 min-w-[200px] w-[200px]">
                <span className="text-xs font-semibold text-[#0b2545]">Funcionário</span>
              </th>
              {days.map((day) => {
                const isWeekend = day.dow === 0 || day.dow === 6;
                const isHoje = day.ds === hoje;
                const tint = day.feriado ? 'bg-rose-50 text-rose-600' : isWeekend ? 'bg-slate-100 text-slate-400' : 'bg-white text-slate-600';
                return (
                  <th key={day.ds} className={`sticky top-0 z-20 ${tint} border-b border-r border-slate-100 px-0 py-1 min-w-[54px] w-[54px] text-center ${isHoje ? 'ring-2 ring-[#0b2545] ring-inset' : ''}`}>
                    <div className="text-xs font-bold leading-none">{String(day.d).padStart(2, '0')}</div>
                    <div className="text-[10px] leading-none mt-0.5">{day.feriado ? 'F' : day.week}</div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {funcs.map((f) => (
              <tr key={f.id}>
                <td className="sticky left-0 z-10 bg-white border-r border-b border-slate-100 px-3 py-1.5 min-w-[200px] w-[200px]">
                  <button onClick={() => onFuncClick?.(f)} className="text-left max-w-full">
                    <div className="text-xs font-semibold text-[#0b2545] leading-tight truncate">{f.nome}</div>
                    <div className="text-[11px] text-slate-500 truncate">{f.funcao || '—'}</div>
                  </button>
                </td>
                {days.map((day) => {
                  const key = `${f.id}|${day.ds}`;
                  const apDay = apsMap[key] || [];
                  const p = pMap[key] || null;
                  const st = statusDe(apDay, p);
                  const alerts = alertasJornada(p);
                  const isWeekend = day.dow === 0 || day.dow === 6;
                  const cellTint = (isWeekend || day.feriado) ? 'bg-slate-50/70' : '';
                  let content = '', cellStyle = {}, statusBadge = null, cellCls = '';
                  if (st) {
                    const obraNome = apDay[0].obra;
                    const obraCor = corDaObra(obraNome, obras);
                    const sigla = siglaObra(obraNome);
                    content = apDay.length > 1 ? `${sigla}+${apDay.length - 1}` : sigla;
                    if (st === 'conferido') {
                      cellStyle = { backgroundColor: obraCor, color: textoContraste(obraCor) };
                      statusBadge = <span className="absolute top-0.5 right-0.5"><Check className="w-2.5 h-2.5 opacity-80" /></span>;
                      cellCls = 'border border-slate-300';
                    } else if (st === 'pendente') {
                      cellStyle = { backgroundColor: corSuave(obraCor), color: '#0b2545' };
                      statusBadge = <span className="absolute top-0.5 right-0.5"><Clock className="w-2.5 h-2.5 text-amber-600" /></span>;
                      cellCls = 'border border-slate-200';
                    } else {
                      cellStyle = { backgroundColor: corSuave(obraCor), color: '#0b2545' };
                      statusBadge = <span className="absolute top-0.5 right-0.5"><AlertTriangle className="w-2.5 h-2.5 text-rose-600" /></span>;
                      cellCls = 'border border-rose-400 ring-1 ring-rose-300';
                    }
                  }
                  const ap = apDay.filter((a) => a.tipo !== 'Atestado').reduce((s, a) => s + (Number(a.horas) || 0), 0);
                  const alertTxt = alerts.length ? '\n⚠ ' + alerts.map((a) => a.texto).join(' | ') : '';
                  const title = apDay.length
                    ? `${apDay.map((a) => a.obra || 'Sem obra').join(' · ')}\n${day.ds.split('-').reverse().join('/')}\n${f.nome}\n${formatHoras(ap)}${alertTxt}\nStatus: ${st ? STATUS[st].label : '—'}`
                    : `${alerts.length ? '⚠ Alerta de jornada' : 'Sem apontamento'}\n${day.ds.split('-').reverse().join('/')}\n${f.nome}${alertTxt}`;
                  return (
                    <td key={day.ds} className={`border-r border-b border-slate-100 p-0.5 min-w-[54px] w-[54px] text-center ${cellTint}`}>
                      <button
                        onClick={(e) => !readOnly && onCellClick(f, day.ds, e)}
                        style={cellStyle}
                        className={`relative w-full h-10 rounded-md text-[11px] font-bold leading-tight flex items-center justify-center transition ${cellCls} ${readOnly ? 'cursor-default' : 'hover:brightness-110'} ${alerts.length ? 'ring-2 ring-rose-500 ring-offset-1' : ''}`}
                        title={title}
                      >
                        {content}
                        {statusBadge}
                        {alerts.length > 0 && <span className="absolute -top-1 -left-1 w-4 h-4 rounded-full bg-rose-600 text-white flex items-center justify-center shadow" title={alerts.map((a) => a.texto).join(' | ')}><AlertTriangle className="w-2.5 h-2.5" /></span>}
                      </button>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}