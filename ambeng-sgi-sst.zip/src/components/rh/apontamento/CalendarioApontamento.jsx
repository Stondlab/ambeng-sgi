import React from 'react';
import { ehFeriado } from '@/lib/feriados';

const DIAS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

function diasDoMes(anoMes) {
  const [y, m] = anoMes.split('-').map(Number);
  return new Date(y, m, 0).getDate();
}

export default function CalendarioApontamento({ anoMes, apMap, onDayClick }) {
  const [y, m] = anoMes.split('-').map(Number);
  const total = diasDoMes(anoMes);
  const primeiro = new Date(y, m - 1, 1).getDay();
  const celulas = [];
  for (let i = 0; i < primeiro; i++) celulas.push(null);
  for (let d = 1; d <= total; d++) celulas.push(d);

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 overflow-x-auto">
      <div className="grid grid-cols-7 gap-1.5 min-w-[640px]">
        {DIAS.map((d) => <div key={d} className="text-center text-xs font-semibold text-slate-400 py-1">{d}</div>)}
        {celulas.map((d, i) => {
          if (d === null) return <div key={i} />;
          const iso = `${anoMes}-${String(d).padStart(2, '0')}`;
          const ds = new Date(y, m - 1, d).getDay();
          const weekend = ds === 0 || ds === 6;
          const feriado = ehFeriado(iso);
          const ap = apMap[iso];
          const atestado = ap?.tipo === 'Atestado';
          return (
            <button key={i} onClick={() => onDayClick(iso)} className={`min-h-[72px] rounded-lg border p-1.5 text-left transition ${atestado ? 'bg-red-50 border-red-200' : ap ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-slate-200 hover:border-amber-300'} ${!ap && weekend ? 'bg-slate-50' : ''} ${!ap && feriado ? 'bg-amber-50 border-amber-200' : ''}`}>
              <div className="flex items-center justify-between">
                <span className={`text-xs font-semibold ${feriado ? 'text-amber-700' : weekend ? 'text-slate-400' : 'text-[#0b2545]'}`}>{d}</span>
                {feriado && <span className="text-[9px] text-amber-600">feriado</span>}
                {weekend && !feriado && <span className="text-[9px] text-slate-400">fim de sem.</span>}
              </div>
              {ap && (atestado ? <p className="text-[11px] font-medium text-red-700 mt-1 truncate">Atestado</p> : <p className="text-[11px] font-medium text-emerald-800 mt-1 truncate">{ap.obra || 'Trabalhado'}</p>)}
            </button>
          );
        })}
      </div>
    </div>
  );
}