import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Plus, Trash2 } from 'lucide-react';
import { nomeUsuario } from '@/lib/usuarioNome';
import { mensagemAmigavelErro, validarNumeroOpcional } from '@/lib/validacao';

// Modal simplificado: apenas Obra + Horas por obra, com botão "+ Adicionar obra".
export default function ApontamentoModal({ func, data, apsDia, obras, obraPadrao, user, onClose, onSaved }) {
  const [erro, setErro] = useState('');
  const [entries, setEntries] = useState(() => {
    if (apsDia.length) return apsDia.map((a) => ({ id: a.id, obra: a.obra || '', horas: a.horas || 0 }));
    return [{ obra: obraPadrao || '', horas: 0 }];
  });

  const setEntry = (i, patch) => setEntries((p) => p.map((e, idx) => idx === i ? { ...e, ...patch } : e));
  const addEntry = () => setEntries((p) => [...p, { obra: '', horas: 0 }]);
  const removeEntry = (i) => setEntries((p) => p.filter((_, idx) => idx !== i));

  const dataBR = data ? data.split('-').reverse().join('/') : '';

  const salvar = async () => {
    if (entries.some((e) => e.horas !== '' && !validarNumeroOpcional(e.horas, 0.01))) return setErro('Informe horas numéricas maiores que zero.');
    const valid = entries.filter((e) => e.obra && Number(e.horas) > 0);
    if (!valid.length) return setErro('Informe ao menos uma obra com horas válidas.');
    if (valid.reduce((s, e) => s + Number(e.horas), 0) > 24) return setErro('O total diário não pode ultrapassar 24 horas.');
    if (new Set(valid.map((e) => e.obra)).size !== valid.length) return setErro('A mesma obra não pode aparecer duas vezes no dia.');
    setErro('');
    const userNome = nomeUsuario(user);
    const now = new Date().toISOString();
    const keptIds = new Set();
    for (const e of valid) {
      const o = obras.find((x) => x.nome === e.obra);
      if (e.id) {
        keptIds.add(e.id);
        await base44.entities.Apontamentos.update(e.id, {
          obra: e.obra, obra_id: o?.id || '', horas: Number(e.horas), valor_hora: Number(func.valor_hora) || null, custo_total: Number(func.valor_hora) > 0 ? Number(e.horas) * Number(func.valor_hora) : null, tipo: 'Trabalhado',
          usuario_lancamento: userNome, data_hora_lancamento: now, status: 'Conferido',
        });
      } else {
        const created = await base44.entities.Apontamentos.create({
          funcionario_id: func.id, matricula: func.matricula || '', data, obra: e.obra, obra_id: o?.id || '',
          horas: Number(e.horas), valor_hora: Number(func.valor_hora) || null, custo_total: Number(func.valor_hora) > 0 ? Number(e.horas) * Number(func.valor_hora) : null, tipo: 'Trabalhado', observacao: '', usuario_lancamento: userNome,
          data_hora_lancamento: now, status: 'Conferido', origem: 'Manual',
        });
        keptIds.add(created.id);
      }
    }
    try {
      for (const a of apsDia) if (!keptIds.has(a.id)) await base44.entities.Apontamentos.delete(a.id);
      onSaved();
    } catch (error) { setErro(mensagemAmigavelErro(error)); }
  };

  const limpar = async () => {
    for (const a of apsDia) { try { await base44.entities.Apontamentos.delete(a.id); } catch {} }
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-card-hover flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <div>
            <h3 className="font-semibold text-[#0b2545]">{func.nome}</h3>
            <p className="text-xs text-slate-500">{func.funcao || '—'} · {dataBR}</p>
          </div>
          <button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button>
        </div>

        <div className="px-5 py-4 space-y-4 overflow-y-auto">
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-sm font-semibold text-[#0b2545]">Obra(s)</Label>
              <Button type="button" variant="outline" size="sm" onClick={addEntry}><Plus className="w-3.5 h-3.5 mr-1" />Adicionar obra</Button>
            </div>
            <div className="space-y-2">
              {entries.map((e, i) => (
                <div key={i} className="flex items-center gap-2">
                  <Select value={e.obra} onValueChange={(v) => setEntry(i, { obra: v })}>
                    <SelectTrigger className="h-9 flex-1"><SelectValue placeholder="Selecione a obra" /></SelectTrigger>
                    <SelectContent>{obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}</SelectContent>
                  </Select>
                  <Input type="number" step="0.1" min="0" value={e.horas} onChange={(ev) => setEntry(i, { horas: ev.target.value })} className="h-9 w-24 text-right" placeholder="Horas" />
                  <span className="text-xs text-slate-400 w-4">h</span>
                  {entries.length > 1 && <button onClick={() => removeEntry(i)} className="text-slate-300 hover:text-red-500 p-1"><Trash2 className="w-4 h-4" /></button>}
                </div>
              ))}
            </div>
          </div>
        </div>

        {erro && <p className="px-5 pb-2 text-sm text-red-600">{erro}</p>}
        <div className="flex items-center justify-between gap-2 px-5 py-3 border-t border-slate-100">
          {apsDia.length > 0 ? (
            <Button type="button" variant="ghost" onClick={limpar} className="text-red-600 hover:bg-red-50"><Trash2 className="w-4 h-4 mr-1" />Limpar</Button>
          ) : <span />}
          <div className="flex gap-2">
            <Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button>
            <Button type="button" onClick={salvar} disabled={!entries.some((e) => e.obra && Number(e.horas) > 0)} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button>
          </div>
        </div>
      </div>
    </div>
  );
}