import React, { useMemo } from 'react';
import { AlertTriangle } from 'lucide-react';
import { calcularBatidas, batidasDe, statusPonto, alertasJornada } from '@/lib/ponto';
import { ehFeriado } from '@/lib/feriados';

// Grade visual FUNCIONÁRIO × DIA — Controle de Ponto.
// Cor da célula = status (semáforo). Conteúdo = resumo das batidas + horas.
// Coluna Funcionário fixa (scroll horizontal); cabeçalho fixo (scroll vertical).
// Mesma linguagem visual do Apontamento Diário.

const WEEK = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];

const STATUS = {
  conferido: { cls: 'bg-emerald-500 text-white border-emerald-600', label: 'Conferido' },
  pendente: { cls: 'bg-amber-400 text-amber-950 border-amber-500', label: 'Pendente de conferência' },
  divergencia: { cls: 'bg-rose-500 text-white border-rose-600', label: 'Divergência' },
};

export default function PontoGrid({ funcs, ponto, anoMes, onCellClick, readOnly }) {
  const days = useMemo(() => {
    const [y, m] = anoMes.split('-').map(Number);
    const total = new Date(y, m, 0).getDate();
    const arr = [];
    for (let d = 1; d <= total; d++) {
      const ds = `${anoMes}-${String(d).padStart(2, '0')}`;
      const dow = new Date(y, m - 1, d).getDay();
      arr.push({ ds, d, dow, week: WEEK[dow], feriado: ehFeriado(ds) });
    }
    return arr;
  }, [anoMes]);

  const hoje = new Date().toISOString().slice(0, 10);
  const pMap = useMemo(() => { const m = {}; ponto.forEach((p) => { m[`${p.funcionario_id}|${p.data}`] = p; }); return m; }, [ponto]);

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div className="overflow-auto max-h-[70vh]">
        <table className="border-separate border-spacing-0 text-sm">
          <thead>
            <tr>
              <th className="sticky left-0 top-0 z-30 bg-slate-100 border-b border-r border-slate-200 text-left px-3 py-2 min-w-[200px] w-[200px]">
                <span className="text-xs font-semibold text-[#0b2545]">Funcionário</span>
              </th>
              {days.map((day) => {
                const isWeekend = day.dow === 0 || day.dow === 6;
                const isHoje = day.ds === hoje;
                const tint = day.feriado ? 'bg-rose-50 text-rose-600' : isWeekend ? 'bg-slate-100 text-slate-400' : 'bg-white text-slate-600';
                return (
                  <th key={day.ds} className={`sticky top-0 z-20 ${tint} border-b border-r border-slate-100 px-0 py-1 min-w-[54px] w-[54px] text-center ${isHoje ? 'ring-2 ring-[#0b2545] ring-inset' : ''}`}>
                    <div className="text-xs font-bold leading-none">{String(day.d).padStart(2, '0')}</div>
                    <div className="text-[10px] leading-none mt-0.5">{day.feriado ? 'F' : day.week}</div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {funcs.map((f) => (
              <tr key={f.id}>
                <td className="sticky left-0 z-10 bg-white border-r border-b border-slate-100 px-3 py-1.5 min-w-[200px] w-[200px]">
                  <div className="text-xs font-semibold text-[#0b2545] leading-tight truncate">{f.nome}</div>
                  <div className="text-[11px] text-slate-500 truncate">{f.funcao || '—'}</div>
                </td>
                {days.map((day) => {
                  const p = pMap[`${f.id}|${day.ds}`] || null;
                  const st = statusPonto(p);
                  const bts = batidasDe(p);
                  const alerts = alertasJornada(p);
                  const isWeekend = day.dow === 0 || day.dow === 6;
                  const cellTint = (isWeekend || day.feriado) ? 'bg-slate-50/70' : '';
                  let cls = '', content = null;
                  if (st !== 'sem') {
                    cls = `border ${STATUS[st].cls}`;
                    const range = bts.length === 1 ? bts[0] : `${bts[0]}–${bts[bts.length - 1]}`;
                    const calc = calcularBatidas(bts);
                    content = (
                      <div className="flex flex-col items-center justify-center leading-tight px-0.5">
                        <span className="text-[9px] font-mono leading-none truncate max-w-full">{range}</span>
                        <span className="text-[9px] font-semibold leading-none mt-0.5">{calc.totalStr || '—'}{bts.length > 2 ? ` ·${bts.length}` : ''}</span>
                      </div>
                    );
                  }
                  const calcInfo = bts.length ? calcularBatidas(bts) : null;
                  const title = bts.length
                    ? `${f.nome}\n${day.ds.split('-').reverse().join('/')}\n${bts.map((b, i) => `${i % 2 === 0 ? 'Entrada' : 'Saída'} ${b}`).join('\n')}\nHoras: ${calcInfo.totalStr}${alerts.length ? '\n⚠ ' + alerts.map((a) => a.texto).join('\n⚠ ') : ''}\nStatus: ${STATUS[st].label}`
                    : `Sem ponto\n${day.ds.split('-').reverse().join('/')}\n${f.nome}`;
                  return (
                    <td key={day.ds} className={`border-r border-b border-slate-100 p-0.5 min-w-[54px] w-[54px] text-center ${cellTint}`}>
                      <button
                        onClick={() => !readOnly && onCellClick(f, day.ds)}
                        className={`relative w-full h-12 rounded-md border flex items-center justify-center transition ${readOnly ? 'cursor-default' : 'hover:brightness-110'} ${cls} ${alerts.length ? 'ring-2 ring-rose-500 ring-offset-1' : ''}`}
                        title={title}
                      >
                        {content}
                        {alerts.length > 0 && <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 text-white flex items-center justify-center shadow" title={alerts.map((a) => a.texto).join(' | ')}><AlertTriangle className="w-2.5 h-2.5" /></span>}
                      </button>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}