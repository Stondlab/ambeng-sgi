import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, AlertTriangle, CheckCircle2, Clock } from 'lucide-react';
import { calcularBatidas, batidasDe } from '@/lib/ponto';
import BatidasInput from '@/components/rh/BatidasInput';
import { mensagemAmigavelErro, validarDataOpcional } from '@/lib/validacao';

// Modal central do Controle de Ponto (FUNCIONÁRIO + DIA).
// Edita as batidas reais (HH:MM) — o sistema calcula horas e intervalo.
// Jornada do RH = apenas referência. Mesma entidade Ponto usada pelo Apontamento Diário.
function jornadaPrevista(func) {
  const t = (func?.turno || '').toLowerCase();
  if (t.includes('12')) return { entrada: '07:00', saida: '19:00', intervalo: '02:00' };
  if (t.includes('noite')) return { entrada: '22:00', saida: '06:00', intervalo: '01:00' };
  return { entrada: '07:00', saida: '17:00', intervalo: '01:00' };
}

const STATUS_META = {
  Conferido: { label: 'Conferido', cls: 'bg-emerald-100 text-emerald-700 border-emerald-300', Icon: CheckCircle2 },
  Pendente: { label: 'Pendente de conferência', cls: 'bg-amber-100 text-amber-700 border-amber-300', Icon: Clock },
  Divergencia: { label: 'Divergência', cls: 'bg-rose-100 text-rose-700 border-rose-300', Icon: AlertTriangle },
};

function legado(p) {
  if (!p || !p.batidas) return true;
  try { const a = JSON.parse(p.batidas || '[]'); return !(Array.isArray(a) && a.length > 0); } catch { return true; }
}

export default function PontoModal({ func, data, ponto, funcionarios, novo = false, onClose, onSaved }) {
  const [selFunc, setSelFunc] = useState(func?.id || '');
  const [selData, setSelData] = useState(data || '');
  const [erro, setErro] = useState('');
  const [batidas, setBatidas] = useState(() => {
    const arr = batidasDe(ponto);
    return arr.length ? arr : ['', ''];
  });

  const f = novo ? (funcionarios || []).find((x) => x.id === selFunc) : func;
  const jornada = jornadaPrevista(f);
  const calc = calcularBatidas(batidas);
  const limpas = batidas.filter(Boolean);

  let statusKey = null;
  if (limpas.length) {
    if (!calc.completo || calc.total <= 0) statusKey = 'Divergencia';
    else if (legado(ponto)) statusKey = 'Pendente';
    else statusKey = 'Conferido';
  }
  const statusMeta = statusKey ? STATUS_META[statusKey] : null;
  const StatusIcon = statusMeta?.Icon;

  const dataFixa = novo ? selData : data;
  const dataBR = dataFixa ? dataFixa.split('-').reverse().join('/') : '';
  const podeSalvar = (novo ? (selFunc && selData) : true) && calc.completo && limpas.length > 0;

  const salvar = async () => {
    if (!podeSalvar) return setErro('Informe funcionário, data e pares completos de batidas.');
    if (!validarDataOpcional(novo ? selData : data)) return setErro('Informe uma data válida.');
    setErro('');
    const fid = novo ? selFunc : func.id;
    const dt = novo ? selData : data;
    const payload = {
      batidas: JSON.stringify(limpas),
      entrada: limpas[0] || '',
      saida: limpas[limpas.length - 1] || '',
      intervalo: calc.intervaloStr,
      total_horas: calc.totalStr,
      status: 'Presente',
    };
    try {
      if (ponto) await base44.entities.Ponto.update(ponto.id, payload);
      else await base44.entities.Ponto.create({ funcionario_id: fid, matricula: f?.matricula || '', data: dt, ...payload });
      onSaved();
    } catch (error) { setErro(mensagemAmigavelErro(error)); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-card-hover flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <div>
            <h3 className="font-semibold text-[#0b2545]">Controle de Ponto</h3>
            {novo
              ? <p className="text-xs text-slate-500 mt-0.5">Novo registro de ponto</p>
              : <p className="text-xs text-slate-500 mt-0.5">{f?.nome || '—'} · {dataBR}</p>}
          </div>
          <button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button>
        </div>

        <div className="px-5 py-4 space-y-4 overflow-y-auto">
          {novo && (
            <div className="space-y-3">
              <div>
                <Label>Funcionário</Label>
                <Select value={selFunc} onValueChange={setSelFunc}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione o funcionário" /></SelectTrigger><SelectContent>{(funcionarios || []).map((x) => <SelectItem key={x.id} value={x.id}>{x.nome}</SelectItem>)}</SelectContent></Select>
              </div>
              <div>
                <Label>Data</Label>
                <Input type="date" className="mt-1" value={selData} onChange={(e) => setSelData(e.target.value)} />
              </div>
            </div>
          )}

          <div className="rounded-lg bg-slate-50 border border-slate-200 p-3">
            <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Jornada prevista</div>
            <div className="text-sm font-semibold text-[#0b2545] mt-1">{jornada.entrada} às {jornada.saida}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Intervalo {jornada.intervalo} (referência — não substitui o ponto real)</div>
          </div>

          <div>
            <Label className="text-sm font-semibold text-[#0b2545]">Batidas do dia</Label>
            {ponto ? (
              <div className="mt-1 mb-2 flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg px-2.5 py-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" /> Ponto encontrado — batidas carregadas automaticamente.
              </div>
            ) : (
              <div className="mt-1 mb-2 flex items-center gap-1.5 text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5">
                <AlertTriangle className="w-3.5 h-3.5" /> Ponto não encontrado — lançamento manual habilitado.
              </div>
            )}
            <BatidasInput value={batidas} onChange={setBatidas} />
            {legado(ponto) && ponto && <p className="text-[11px] text-amber-700 mt-1">Registro legado — ao salvar, converte para a nova estrutura de batidas.</p>}
          </div>

          <div className="grid grid-cols-2 gap-2 text-center">
            <div className="rounded-lg bg-white border border-slate-200 p-2">
              <div className="text-[10px] uppercase tracking-wide text-slate-500">Horas trabalhadas</div>
              <div className="text-sm font-bold text-emerald-700">{calc.totalStr || '—'}</div>
            </div>
            <div className="rounded-lg bg-white border border-slate-200 p-2">
              <div className="text-[10px] uppercase tracking-wide text-slate-500">Intervalo</div>
              <div className="text-sm font-bold text-[#0b2545]">{calc.intervaloStr || '—'}</div>
            </div>
          </div>

          {!calc.completo && limpas.length > 0 && (
            <p className="text-xs text-rose-600 -mt-2">Divergência: batidas incompletas (quantidade ímpar ou par entrada/saída não fechada).</p>
          )}

          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Status</span>
            {statusMeta ? (
              <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full border ${statusMeta.cls}`}>{StatusIcon && <StatusIcon className="w-3.5 h-3.5" />}{statusMeta.label}</span>
            ) : <span className="text-xs text-slate-400">—</span>}
          </div>
        </div>

        {erro && <p className="px-5 pb-2 text-sm text-red-600">{erro}</p>}
        <div className="flex items-center justify-end gap-2 px-5 py-3 border-t border-slate-100">
          <Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button>
          <Button type="button" onClick={salvar} disabled={!podeSalvar} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button>
        </div>
      </div>
    </div>
  );
}