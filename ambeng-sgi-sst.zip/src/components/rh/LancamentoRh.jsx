import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import PageHeader from '@/components/PageHeader';
import { useSstData, refreshSstData } from '@/hooks/useSstEntitiesData';
import { fmt } from '@/lib/sst';
import { Plus, X, Trash2 } from 'lucide-react';
import { calcularBatidas } from '@/lib/ponto';
import BatidasInput from '@/components/rh/BatidasInput';
import { mensagemAmigavelErro, validarDataOpcional, validarNumeroOpcional } from '@/lib/validacao';

function matchFilter(record, filter) {
  if (!filter) return true;
  return Object.entries(filter).every(([field, vals]) => vals.includes(record[field]));
}

export default function LancamentoRh({ entity, controle, title, subtitle, defaults = {} }) {
  const data = useSstData(['funcionarios']);
  const [records, setRecords] = useState([]);
  const [selFunc, setSelFunc] = useState('todos');
  const [showForm, setShowForm] = useState(false);
  const fields = controle.fields;
  const filter = controle.filter;

  const load = async () => {
    let all = []; try { all = await base44.entities[entity].list('-created_date', 500); } catch { all = []; }
    setRecords(all.filter((r) => matchFilter(r, filter)));
  };
  useEffect(() => { load(); }, [entity]);

  if (!data) return <p className="text-slate-400">Carregando...</p>;

  const funcionarios = data.funcionarios || [];
  const nomeOf = (id) => { const f = funcionarios.find((x) => x.id === id); return f ? f.nome : '—'; };
  const visiveis = selFunc === 'todos' ? records : records.filter((r) => r.funcionario_id === selFunc);
  const cols = fields.slice(0, 5);

  return (
    <div>
      <PageHeader title={title} subtitle={subtitle} action={
        <Button onClick={() => setShowForm(true)} className="bg-amber-400 text-[#0b2545] hover:bg-amber-300 font-semibold min-h-[44px]"><Plus className="w-4 h-4 mr-1" />Novo registro</Button>
      } />

      <div className="bg-white border border-slate-200 rounded-xl p-3 mb-4 flex flex-col sm:flex-row gap-3 sm:items-center">
        <Label className="text-xs text-slate-500 shrink-0">Colaborador</Label>
        <Select value={selFunc} onValueChange={setSelFunc}>
          <SelectTrigger className="sm:max-w-sm"><SelectValue placeholder="Todos os colaboradores" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os colaboradores</SelectItem>
            {funcionarios.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}
          </SelectContent>
        </Select>
        <span className="text-xs text-slate-400 sm:ml-auto">{visiveis.length} registro(s)</span>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
              <tr>
                <th className="text-left px-4 py-3">Colaborador</th>
                {cols.map((f) => <th key={f.name} className="text-left px-4 py-3">{f.label}</th>)}
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {visiveis.length === 0 && <tr><td colSpan={cols.length + 2} className="px-4 py-10 text-center text-slate-400">Nenhum registro.</td></tr>}
              {visiveis.map((r) => (
                <tr key={r.id}>
                  <td className="px-4 py-3 font-medium text-[#0b2545]">{nomeOf(r.funcionario_id)}</td>
                  {cols.map((f) => (
                    <td key={f.name} className="px-4 py-3 text-slate-600">{f.type === 'date' ? fmt(r[f.name]) : (r[f.name] ?? '—')}</td>
                  ))}
                  <td className="px-4 py-3 text-right">
                    <button onClick={async () => { await base44.entities[entity].delete(r.id); load(); refreshSstData(); }} className="text-slate-300 hover:text-red-500 transition-colors" title="Excluir"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && <LancamentoForm entity={entity} fields={fields} funcionarios={funcionarios} defaults={defaults} onClose={() => setShowForm(false)} onSaved={() => { setShowForm(false); load(); refreshSstData(); }} />}
    </div>
  );
}

function LancamentoForm({ entity, fields, funcionarios, defaults = {}, onClose, onSaved }) {
  const [form, setForm] = useState(() => ({ ...defaults, batidas: entity === 'Ponto' ? (Array.isArray(defaults.batidas) ? defaults.batidas : ['','']) : undefined }));
  const [erro, setErro] = useState('');
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  const isPonto = entity === 'Ponto';
  const pontoCalc = isPonto ? calcularBatidas(form.batidas || []) : null;
  const save = async () => {
    if (!form.funcionario_id) return setErro('Selecione o colaborador.');
    const dataInvalida = fields.find((f) => f.type === 'date' && !validarDataOpcional(form[f.name]));
    if (dataInvalida) return setErro(`Informe uma data válida em ${dataInvalida.label}.`);
    const numeroInvalido = fields.find((f) => f.type === 'number' && !validarNumeroOpcional(form[f.name]));
    if (numeroInvalido) return setErro(`Informe um valor numérico válido em ${numeroInvalido.label}.`);
    setErro('');
    const payload = { ...form };
    if (isPonto) {
      const c = calcularBatidas(form.batidas || []);
      const limpas = (form.batidas || []).filter((x) => x);
      payload.batidas = JSON.stringify(limpas);
      payload.total_horas = c.totalStr;
      payload.intervalo = c.intervaloStr;
      payload.entrada = limpas[0] || '';
      payload.saida = limpas[limpas.length - 1] || '';
    }
    fields.forEach((f) => { if (f.type === 'number' && payload[f.name] !== '' && payload[f.name] != null) payload[f.name] = Number(payload[f.name]); });
    try {
      await base44.entities[entity].create({ ...payload, funcionario_id: form.funcionario_id });
      onSaved();
    } catch (error) { setErro(mensagemAmigavelErro(error)); }
  };
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">Novo registro</h3><button type="button" onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div>
          <Label>Colaborador</Label>
          <Select value={form.funcionario_id || ''} onValueChange={(v) => set('funcionario_id', v)}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione o colaborador" /></SelectTrigger><SelectContent>{funcionarios.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}</SelectContent></Select>
        </div>
        {fields.map((f) => {
          if (isPonto && (f.name === 'entrada' || f.name === 'saida' || f.name === 'intervalo' || f.name === 'total_horas')) {
            if (f.name === 'entrada') {
              return (
                <div key="batidas">
                  <Label>Batidas do dia</Label>
                  <BatidasInput value={form.batidas || []} onChange={(arr) => set('batidas', arr)} />
                  <p className="text-[11px] text-slate-400 mt-1">Múltiplas batidas HH:MM — o sistema calcula os períodos trabalhados e o intervalo.</p>
                </div>
              );
            }
            if (f.name === 'total_horas') {
              return (
                <div key={f.name} className="rounded-lg bg-emerald-50 border border-emerald-200 px-3 py-2.5">
                  <div className="text-[11px] font-semibold uppercase tracking-wide text-emerald-700">Horas trabalhadas (calculado)</div>
                  <div className="flex items-center justify-between mt-0.5">
                    <span className="text-lg font-bold text-emerald-800">{pontoCalc?.totalStr || '—'}</span>
                    <span className="text-[11px] text-emerald-600">Intervalo {pontoCalc?.intervaloStr || '—'}</span>
                  </div>
                </div>
              );
            }
            return null;
          }
          return (
            <div key={f.name}>
              <Label>{f.label}</Label>
              {f.type === 'select' ? (
                <Select value={form[f.name] || ''} onValueChange={(v) => set(f.name, v)}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{f.options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
              ) : f.type === 'textarea' ? (
                <Textarea className="mt-1" rows={2} value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
              ) : (
                <Input className="mt-1" type={f.type || 'text'} value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
              )}
            </div>
          );
        })}
        {erro && <p className="text-sm text-red-600">{erro}</p>}
        <div className="flex justify-end gap-2 pt-2"><Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button><Button type="button" onClick={save} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button></div>
      </div>
    </div>
  );
}