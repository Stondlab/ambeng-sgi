import React, { useMemo, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { fmtMoney } from '@/lib/financeiro';
import { formatHoras, statusConferencia, parseHoras } from '@/lib/apontamento';
import { custoApropriadoApontamento } from '@/lib/custoMO';
import { ChevronRight, ChevronDown, CheckCircle2, AlertTriangle } from 'lucide-react';

// Drill-down do Custo de Mão de Obra (spec §22): Custo → Funcionário → Dias →
// Obras → Horas → Cálculo. Permite rastrear a origem de cada valor.
// `obra` pode ser: nome de uma obra | '__sem__' (sem apropriação) | '__conf__' (conferido) | '__pend__' (pendente).
export default function DrillDownCusto({ obra, anoMes, geral, aps, ponto, onClose }) {
  const [expanded, setExpanded] = useState(null);
  const modo = obra === '__sem__' ? 'sem' : obra === '__conf__' ? 'conf' : obra === '__pend__' ? 'pend' : 'obra';
  const titulo = modo === 'sem' ? 'Custo sem apropriação' : modo === 'conf' ? 'Custo Conferido' : modo === 'pend' ? 'Custo Pendente' : obra;

  const contribs = useMemo(() => {
    const arr = geral.porFunc.map((pf) => {
      let valor, conf, pend, horas;
      if (modo === 'sem') { valor = pf.semApontamento; conf = 0; pend = pf.semApontamento; horas = 0; }
      else if (modo === 'conf') { valor = pf.conferido; conf = pf.conferido; pend = 0; horas = pf.totalHorasConf; }
      else if (modo === 'pend') { valor = pf.pendente; conf = 0; pend = pf.pendente; horas = pf.totalHorasPend; }
      else { valor = pf.porObra[obra] || 0; conf = pf.porObraConf[obra] || 0; pend = pf.porObraPend[obra] || 0; horas = (pf.horasPorObraConf[obra] || 0) + (pf.horasPorObraPend[obra] || 0); }
      return { pf, valor, conf, pend, horas };
    }).filter((c) => c.valor > 0.005).sort((a, b) => b.valor - a.valor);
    return arr;
  }, [geral, obra, modo]);

  const diasDoFunc = (funcId) => {
    let ds = aps.filter((a) => a.funcionario_id === funcId && (a.data || '').slice(0, 7) === anoMes);
    if (modo === 'obra') ds = ds.filter((a) => a.obra === obra);
    else if (modo === 'sem') ds = ds.filter((a) => !a.obra);
    else {
      // conf/pend: filtra por status de conferência do dia
      ds = ds.filter((a) => {
        const p = ponto.find((x) => x.funcionario_id === funcId && x.data === a.data);
        const ph = p ? parseHoras(p.total_horas) : null;
        const ah = aps.filter((x) => x.funcionario_id === funcId && x.data === a.data && x.tipo !== 'Atestado').reduce((s, x) => s + (Number(x.horas) || 0), 0);
        const st = statusConferencia(ph, ah);
        return modo === 'conf' ? st === 'Conferido' : st !== 'Conferido';
      });
    }
    const byDay = {};
    ds.forEach((a) => { (byDay[a.data] = byDay[a.data] || []).push(a); });
    return Object.entries(byDay).sort((a, b) => a[0].localeCompare(b[0]));
  };

  return (
    <Dialog open={!!obra} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Drill-down — {titulo}</DialogTitle></DialogHeader>
        <div className="text-xs text-slate-500 mb-2">Competência {anoMes} · {contribs.length} colaborador(es) compõem este valor.</div>
        <div className="space-y-2">
          {contribs.length === 0 && <p className="text-sm text-slate-400 py-6 text-center">Sem composição para este filtro.</p>}
          {contribs.map((c) => {
            const open = expanded === c.pf.f.id;
            return (
              <div key={c.pf.f.id} className="border border-slate-200 rounded-lg">
                <button onClick={() => setExpanded(open ? null : c.pf.f.id)} className="w-full flex items-center gap-2 px-3 py-2.5 text-left">
                  {open ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-[#0b2545]">{c.pf.f.nome}{c.pf.f.matricula ? ` · ${c.pf.f.matricula}` : ''}</div>
                    <div className="text-[11px] text-slate-500">{c.pf.f.funcao || '—'} · {formatHoras(c.horas)} · jornada de referência {c.pf.jornadaMensal || 220}h/mês</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-[#0b2545]">{fmtMoney(c.valor)}</div>
                    {(c.conf > 0 || c.pend > 0) && <div className="text-[11px]">{fmtMoney(c.conf)} conf · {fmtMoney(c.pend)} pend</div>}
                  </div>
                </button>
                {open && (
                  <div className="border-t border-slate-100 p-3 bg-slate-50/40 space-y-2">
                    {diasDoFunc(c.pf.f.id).length === 0 && <p className="text-xs text-slate-400">Sem apropriação na competência.</p>}
                    {diasDoFunc(c.pf.f.id).map(([ds, dayAps]) => {
                      const pRec = ponto.find((p) => p.funcionario_id === c.pf.f.id && p.data === ds);
                      const ph = pRec ? parseHoras(pRec.total_horas) : null;
                      const ah = dayAps.reduce((s, a) => s + (Number(a.horas) || 0), 0);
                      const st = statusConferencia(ph, ah);
                      return (
                        <div key={ds} className="rounded-md bg-white border border-slate-200 p-2">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-medium text-[#0b2545]">{new Date(ds + 'T00:00').toLocaleDateString('pt-BR')}</span>
                            <span className="text-slate-500">Ponto {ph != null ? formatHoras(ph) : '—'} · Apontado {formatHoras(ah)}</span>
                            {st === 'Conferido' ? <span className="inline-flex items-center gap-1 text-emerald-600"><CheckCircle2 className="w-3.5 h-3.5" />Conferido</span> : <span className="inline-flex items-center gap-1 text-amber-600"><AlertTriangle className="w-3.5 h-3.5" />Pendente</span>}
                          </div>
                          <div className="mt-1.5 space-y-1">
                            {dayAps.map((a) => (
                              <div key={a.id} className="flex items-center justify-between text-xs pl-2 border-l-2 border-slate-200">
                                <span className="text-slate-700">{a.obra || 'Sem obra'} · {formatHoras(a.horas)}</span>
                                <span className="text-slate-500">{fmtMoney(custoApropriadoApontamento(c.pf, a, aps))} <span className="text-slate-400">(custo proporcional + benefícios do dia)</span></span>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}