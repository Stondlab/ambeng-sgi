import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { fmtMoney } from '@/lib/financeiro';
import { BarChart3 } from 'lucide-react';

export default function CustoPorObraChart({ porObra }) {
  const data = Object.entries(porObra).map(([obra, valor]) => ({ obra, valor })).sort((a, b) => b.valor - a.valor).slice(0, 8);
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><BarChart3 className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Custo Total por Obra</h3></div>
      {data.length === 0 ? <p className="text-sm text-slate-400">Sem dados de apontamento no mês.</p> : (
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={data} margin={{ top: 8, right: 8, left: 8, bottom: 8 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eef2f7" />
            <XAxis dataKey="obra" tick={{ fontSize: 11, fill: '#64748b' }} interval={0} angle={-15} textAnchor="end" height={64} />
            <YAxis tick={{ fontSize: 11, fill: '#64748b' }} tickFormatter={(v) => `R$ ${(v / 1000).toFixed(0)}k`} />
            <Tooltip formatter={(v) => fmtMoney(v)} contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 12 }} />
            <Bar dataKey="valor" fill="#10b981" radius={[6, 6, 0, 0]} maxBarSize={48} />
          </BarChart>
        </ResponsiveContainer>
      )}
    </section>
  );
}