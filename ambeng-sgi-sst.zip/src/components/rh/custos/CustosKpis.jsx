import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { Wallet, CheckCircle2, AlertTriangle, Banknote, PiggyBank, Coins, Gift } from 'lucide-react';

// KPIs do Custo de Mão de Obra 360° — separa conferido / pendente / total estimado
// e a composição gerencial (remuneração, benefícios, encargos, provisões).
export default function CustosKpis({ geral, onConferido, onPendente }) {
  if (geral.inconsistente) {
    return (
      <div className="rounded-xl border-2 border-red-300 bg-red-50 p-4">
        <div className="flex items-start gap-2">
          <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
          <div>
            <p className="text-sm font-bold text-red-700">Inconsistência nos indicadores de custo</p>
            <p className="text-xs text-red-600 mt-1">Custo Conferido + Custo Pendente ≠ Total Estimado. Diferença: {fmtMoney(geral.diferenca)}. Indicadores não exibidos até restaurar a igualdade.</p>
            <p className="text-[11px] text-red-500 mt-1 font-mono">Conferido {fmtMoney(geral.conferido)} + Pendente {fmtMoney(geral.pendente)} = {fmtMoney(geral.conferido + geral.pendente)} | Total {fmtMoney(geral.totalEstimado)}</p>
          </div>
        </div>
      </div>
    );
  }
  const cards = [
    { label: 'Total Estimado', valor: fmtMoney(geral.totalEstimado), icon: Wallet, tone: 'bg-[#0b2545] text-white' },
    { label: 'Custo Conferido', valor: fmtMoney(geral.conferido), icon: CheckCircle2, tone: 'bg-emerald-50 border border-emerald-200 text-emerald-700', onClick: onConferido },
    { label: 'Custo Pendente', valor: fmtMoney(geral.pendente), icon: AlertTriangle, tone: 'bg-amber-50 border border-amber-200 text-amber-700', onClick: onPendente },
    { label: 'Remuneração', valor: fmtMoney(geral.remuneracao), icon: Banknote, tone: 'bg-sky-50 border border-sky-200 text-sky-700' },
    { label: 'Benefícios', valor: fmtMoney(geral.beneficios), icon: Gift, tone: 'bg-violet-50 border border-violet-200 text-violet-700' },
    { label: 'Encargos', valor: fmtMoney(geral.encargos), icon: PiggyBank, tone: 'bg-amber-50 border border-amber-200 text-amber-700' },
    { label: 'Provisões', valor: fmtMoney(geral.provisoes), icon: Coins, tone: 'bg-rose-50 border border-rose-200 text-rose-700' },
  ];
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
      {cards.map((c) => {
        const Icon = c.icon;
        const Comp = c.onClick ? 'button' : 'div';
        return (
          <Comp key={c.label} onClick={c.onClick} className={`rounded-xl p-4 text-left ${c.tone} ${c.onClick ? 'cursor-pointer hover:opacity-90 transition' : ''}`}>
            <Icon className="w-5 h-5 opacity-70 mb-2" />
            <p className="text-xl font-bold leading-none">{c.valor}</p>
            <p className="text-xs opacity-80 mt-2">{c.label}</p>
          </Comp>
        );
      })}
    </div>
  );
}