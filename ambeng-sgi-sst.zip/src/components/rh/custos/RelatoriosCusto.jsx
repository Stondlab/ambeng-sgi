import React, { useState } from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { BarChart3 } from 'lucide-react';

const TABS = [
  { id: 'adicional', label: 'Custo Adicional' },
  { id: 'obra', label: 'Custo por Obra' },
  { id: 'func', label: 'Custo por Funcionário' },
];

function Tabela({ head, rows, total }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm min-w-[560px]">
        <thead className="bg-slate-50 text-slate-500 text-xs uppercase"><tr>{head.map((h, i) => <th key={h} className={`px-4 py-3 ${i === 0 ? 'text-left' : 'text-right'}`}>{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-slate-100">
          {rows.length === 0 && <tr><td colSpan={head.length} className="px-4 py-8 text-center text-slate-400">Sem dados para o filtro.</td></tr>}
          {rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j} className={`px-4 py-2.5 ${j === 0 ? 'font-medium text-[#0b2545]' : 'text-right text-slate-700'}`}>{c}</td>)}</tr>)}
        </tbody>
        {rows.length > 0 && <tfoot><tr className="bg-slate-50"><td className="px-4 py-3 font-semibold text-[#0b2545]">Total</td><td colSpan={head.length - 1} className="px-4 py-3 text-right font-bold text-[#0b2545]">{total}</td></tr></tfoot>}
      </table>
    </div>
  );
}

export default function RelatoriosCusto({ geral, obrasList }) {
  const [tab, setTab] = useState('adicional');
  const [obraSel, setObraSel] = useState('all');

  const funcsFiltrados = geral.porFunc.filter((pf) => obraSel === 'all' ? true : (pf.porObra[obraSel] || 0) > 0);
  const obrasFiltradas = obraSel === 'all' ? geral.porObra : { [obraSel]: geral.porObra[obraSel] || 0 };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2"><BarChart3 className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Relatórios</h3></div>
        <div className="flex gap-1.5 flex-wrap">
          {TABS.map((t) => <button key={t.id} onClick={() => setTab(t.id)} className={`text-xs px-3 py-1.5 rounded-full border ${tab === t.id ? 'bg-[#0b2545] text-white border-[#0b2545]' : 'bg-white text-slate-600 border-slate-200'}`}>{t.label}</button>)}
        </div>
      </div>
      <div className="mb-4 max-w-xs">
        <Label>Obra (filtro)</Label>
        <Select value={obraSel} onValueChange={setObraSel}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todas as obras</SelectItem>{obrasList.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
      </div>

      {tab === 'adicional' && <Tabela head={['Funcionário', 'VT', 'VR', 'Premiação', 'Adicional']} rows={funcsFiltrados.map((pf) => [pf.f.nome, fmtMoney(pf.vt), fmtMoney(pf.vr), fmtMoney(pf.prem), fmtMoney(pf.adicional)])} total={fmtMoney(funcsFiltrados.reduce((s, pf) => s + pf.adicional, 0))} />}
      {tab === 'obra' && <Tabela head={['Obra', 'Custo Total']} rows={Object.entries(obrasFiltradas).map(([o, v]) => [o, fmtMoney(v)])} total={fmtMoney(Object.values(obrasFiltradas).reduce((s, v) => s + v, 0))} />}
      {tab === 'func' && <Tabela head={['Funcionário', 'Folha', 'Adicional', 'Encargos', 'Total']} rows={funcsFiltrados.map((pf) => [pf.f.nome, fmtMoney(pf.folha), fmtMoney(pf.adicional), fmtMoney(pf.encargos), fmtMoney(pf.total)])} total={fmtMoney(funcsFiltrados.reduce((s, pf) => s + pf.total, 0))} />}
    </section>
  );
}