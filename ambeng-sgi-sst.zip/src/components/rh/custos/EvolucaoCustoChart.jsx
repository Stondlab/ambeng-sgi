import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { fmtMoney } from '@/lib/financeiro';
import { TrendingUp } from 'lucide-react';

const CORES = ['#0b2545', '#10b981', '#f59e0b', '#3b82f6', '#8b5cf6', '#ef4444', '#14b8a6', '#94a3b8'];

export default function EvolucaoCustoChart({ evo }) {
  const obrasSet = useMemo(() => { const s = new Set(); evo.forEach((e) => Object.keys(e.porObra).forEach((o) => s.add(o))); return [...s]; }, [evo]);
  const data = evo.map((e) => { const row = { mes: e.mes }; obrasSet.forEach((o) => { row[o] = e.porObra[o] || 0; }); return row; });
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><TrendingUp className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Evolução de Custo por Obra</h3></div>
      {data.length === 0 ? <p className="text-sm text-slate-400">Sem dados.</p> : (
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={data} margin={{ top: 8, right: 8, left: 8, bottom: 8 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eef2f7" />
            <XAxis dataKey="mes" tick={{ fontSize: 11, fill: '#64748b' }} />
            <YAxis tick={{ fontSize: 11, fill: '#64748b' }} tickFormatter={(v) => `R$ ${(v / 1000).toFixed(0)}k`} />
            <Tooltip formatter={(v) => fmtMoney(v)} contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 12 }} />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            {obrasSet.map((o, i) => <Bar key={o} dataKey={o} stackId="a" fill={CORES[i % CORES.length]} maxBarSize={36} />)}
          </BarChart>
        </ResponsiveContainer>
      )}
    </section>
  );
}