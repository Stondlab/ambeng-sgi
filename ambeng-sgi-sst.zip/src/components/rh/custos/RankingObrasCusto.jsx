import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { Trophy } from 'lucide-react';

export default function RankingObrasCusto({ porObra, onSelect }) {
  const arr = Object.entries(porObra).map(([obra, valor]) => ({ obra, valor })).sort((a, b) => b.valor - a.valor);
  const max = arr.length ? arr[0].valor : 1;
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><Trophy className="w-5 h-5 text-amber-500" /><h3 className="font-semibold text-[#0b2545]">Ranking de Obras por Custo de Mão de Obra</h3></div>
      {arr.length === 0 ? <p className="text-sm text-slate-400">Sem dados.</p> : (
        <div className="space-y-2.5">
          {arr.map((o, i) => (
            <div key={o.obra} className={`flex items-center gap-3 ${onSelect ? 'cursor-pointer hover:bg-slate-50 rounded-lg -mx-1 px-1 py-0.5' : ''}`} onClick={() => onSelect?.(o.obra)}>
              <span className={`w-6 text-center text-sm font-bold ${i === 0 ? 'text-amber-500' : i === 1 ? 'text-slate-400' : i === 2 ? 'text-amber-700' : 'text-slate-400'}`}>{i + 1}</span>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between text-sm mb-1"><span className="text-slate-600 truncate">{o.obra}</span><span className="font-semibold text-[#0b2545]">{fmtMoney(o.valor)}</span></div>
                <div className="h-2 rounded-full bg-slate-100 overflow-hidden"><div className="h-full bg-[#0b2545]" style={{ width: `${(o.valor / max * 100)}%` }} /></div>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}