import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { X } from 'lucide-react';
import { validarDataOpcional, validarNumeroOpcional } from '@/lib/validacao';

function Field({ label, className, children }) {
  return <div className={className}><Label>{label}</Label><div className="mt-1">{children}</div></div>;
}

const DEF = { nome: '', data_inicio: '', data_fim: '', inss_patronal: 23.3, fgts: 8, ferias_terco: 11.11, decimo_terceiro: 8.33, rat_sistema_s: 3, total: 53.74 };
const LABELS = { inss_patronal: 'INSS Patronal', fgts: 'FGTS', ferias_terco: 'Férias + 1/3', decimo_terceiro: '13º Salário', rat_sistema_s: 'RAT + Sistema S', total: 'Total' };
const NUMS = ['inss_patronal', 'fgts', 'ferias_terco', 'decimo_terceiro', 'rat_sistema_s', 'total'];

export default function VigenciaForm({ record, onClose, onSave }) {
  const isNew = !record.id;
  const [form, setForm] = useState(() => ({ ...DEF, ...record }));
  const [erro, setErro] = useState('');
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  const submit = () => {
    if (!form.data_inicio) return setErro('Informe a data de início.');
    if (!validarDataOpcional(form.data_inicio) || !validarDataOpcional(form.data_fim)) return setErro('Informe datas válidas.');
    if (form.data_fim && form.data_fim < form.data_inicio) return setErro('A data final não pode ser anterior à data inicial.');
    if (NUMS.some((k) => !validarNumeroOpcional(form[k]))) return setErro('Informe percentuais numéricos válidos e não negativos.');
    setErro(''); onSave(form, record.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">{isNew ? 'Nova Vigência' : 'Editar Vigência'}</h3><button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field className="sm:col-span-2" label="Nome (identificação)"><Input value={form.nome || ''} onChange={(e) => set('nome', e.target.value)} placeholder="Ex.: Vigência 2026" /></Field>
          <Field label="Início *"><Input type="date" value={form.data_inicio || ''} onChange={(e) => set('data_inicio', e.target.value)} /></Field>
          <Field label="Fim (vazio = vigente)"><Input type="date" value={form.data_fim || ''} onChange={(e) => set('data_fim', e.target.value)} /></Field>
          {NUMS.map((k) => <Field key={k} label={`${LABELS[k]} (%)`}><Input type="number" step="0.01" value={form[k] ?? ''} onChange={(e) => set(k, e.target.value)} /></Field>)}
        </div>
        <p className="text-xs text-slate-400">Todos os encargos são marcados como <span className="font-medium text-emerald-700">Provisionado</span>.</p>
        {erro && <p className="text-sm text-red-600">{erro}</p>}
        <div className="flex justify-end gap-2 pt-2"><Button variant="ghost" onClick={onClose}>Cancelar</Button><Button onClick={submit} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button></div>
      </div>
    </div>
  );
}