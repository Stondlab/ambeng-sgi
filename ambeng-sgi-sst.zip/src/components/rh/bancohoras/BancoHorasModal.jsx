import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { base44 } from '@/api/base44Client';
import { maskHHMM } from '@/lib/ponto';
import { calcularExpiracao, fmtMinutos, parseHorasMinutos } from '@/lib/bancoHoras';
import { mensagemAmigavelErro, validarDataOpcional } from '@/lib/validacao';

export default function BancoHorasModal({ func, onClose, onSaved }) {
  const [data, setData] = useState(new Date().toISOString().slice(0, 10));
  const [tipo, setTipo] = useState('Credito');
  const [horas, setHoras] = useState('');
  const [descricao, setDescricao] = useState('');
  const [salvando, setSalvando] = useState(false);
  const [erro, setErro] = useState('');

  const minutosAbs = parseHorasMinutos(horas);
  const minutos = tipo === 'Compensacao' ? -minutosAbs : minutosAbs;
  const valido = minutosAbs > 0 && !!data;
  const expiracao = calcularExpiracao(data);

  const submit = async () => {
    if (!validarDataOpcional(data)) return setErro('Informe uma data válida.');
    if (!/^\d{2}:\d{2}$/.test(horas) || !valido) return setErro('Informe as horas no formato HH:MM, com valor maior que zero.');
    setErro(''); setSalvando(true);
    try {
      await base44.entities.BancoHoras.create({
        funcionario_id: func.id, funcionario_nome: func.nome,
        data, minutos, tipo, descricao, data_expiracao: expiracao, status: 'Ativo', origem: 'Manual',
      });
      onSaved();
    } catch (error) { setErro(mensagemAmigavelErro(error)); }
    finally { setSalvando(false); }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>Novo lançamento — {func.nome}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Label>Data do lançamento</Label>
            <Input type="date" value={data} onChange={(e) => setData(e.target.value)} className="mt-1" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Tipo</Label>
              <Select value={tipo} onValueChange={setTipo}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>
                <SelectItem value="Credito">Crédito (acumular)</SelectItem>
                <SelectItem value="Compensacao">Compensação (usar saldo)</SelectItem>
              </SelectContent></Select>
            </div>
            <div>
              <Label>Horas (HH:MM)</Label>
              <Input value={horas} onChange={(e) => setHoras(maskHHMM(e.target.value))} placeholder="01:30" className="mt-1 font-mono" />
            </div>
          </div>
          <div>
            <Label>Descrição</Label>
            <Textarea value={descricao} onChange={(e) => setDescricao(e.target.value)} rows={2} className="mt-1" placeholder="Origem do lançamento..." />
          </div>
          {minutosAbs > 0 && (
            <p className="text-xs text-slate-500">
              Lançamento: <strong className={minutos < 0 ? 'text-rose-600' : 'text-emerald-600'}>{fmtMinutos(minutos)}</strong>
              {' · '}Expira em {expiracao ? new Date(expiracao + 'T00:00').toLocaleDateString('pt-BR') : '—'} (6 meses)
            </p>
          )}
        </div>
        {erro && <p className="text-sm text-red-600">{erro}</p>}
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button className="bg-[#0b2545] hover:bg-[#16365f]" disabled={!valido || salvando} onClick={submit}>{salvando ? 'Salvando...' : 'Salvar'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}