import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Plus, Trash2 } from 'lucide-react';
import { maskHHMM } from '@/lib/ponto';

// Entrada de batidas do dia (múltiplas, HH:MM). Alternância Entrada/Saída por índice.
// Usado no cadastro de Ponto e no modal de Apontamento (lançamento manual).
export default function BatidasInput({ value = [], onChange, readOnly }) {
  const arr = Array.isArray(value) ? value : [];
  const set = (i, v) => onChange(arr.map((x, idx) => idx === i ? v : x));
  const add = () => onChange([...arr, '']);
  const remove = (i) => onChange(arr.filter((_, idx) => idx !== i));

  return (
    <div className="space-y-2">
      {arr.map((b, i) => {
        const par = i % 2 === 0;
        const n = Math.floor(i / 2) + 1;
        return (
          <div key={i} className="flex items-center gap-2">
            <span className="text-xs text-slate-500 w-20 shrink-0">{par ? `Entrada ${n}` : `Saída ${n}`}</span>
            <Input
              value={b}
              onChange={(e) => set(i, maskHHMM(e.target.value))}
              placeholder="HH:MM"
              maxLength={5}
              disabled={readOnly}
              className="h-9 w-28 font-mono"
              inputMode="numeric"
            />
            {!readOnly && <button type="button" onClick={() => remove(i)} className="text-slate-300 hover:text-red-500 p-1"><Trash2 className="w-4 h-4" /></button>}
          </div>
        );
      })}
      {!readOnly && <Button type="button" variant="outline" size="sm" onClick={add}><Plus className="w-3.5 h-3.5 mr-1" />Adicionar batida</Button>}
    </div>
  );
}