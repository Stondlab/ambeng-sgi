import React, { useMemo, useState } from 'react';
import { AlertOctagon, AlertTriangle, CheckCircle2, Eye, EyeOff, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { resumoConformidadeRh, avaliarFgts, avaliarFerias, avaliarDocumentacao, avaliarAnotacaoCarteira } from '@/lib/conformidadeRh';

const CORES = { Crítica: 'bg-red-100 text-red-700 border-red-300', Alta: 'bg-orange-100 text-orange-700 border-orange-300', Média: 'bg-yellow-100 text-yellow-700 border-yellow-300' };
const ICON_SEV = { Crítica: AlertOctagon, Alta: AlertTriangle, Média: AlertTriangle };

export default function DashboardConformidadeRh({ data, apontamentos = [] }) {
  const [expandido, setExpandido] = useState(null);
  const conformidade = useMemo(() => resumoConformidadeRh(data, apontamentos), [data, apontamentos]);

  const itemsMap = useMemo(() => ({
    fgts: { nome: 'FGTS Regular', icon: '💰', desvios: avaliarFgts(data), norma: 'Lei 8.036/1990' },
    ferias: { nome: 'Férias em Dia', icon: '🏖️', desvios: avaliarFerias(data), norma: 'CLT Art. 130-132' },
    documentacao: { nome: 'Documentação Completa', icon: '📋', desvios: avaliarDocumentacao(data), norma: 'CLT Art. 36' },
    carteira: { nome: 'Anotação Carteira', icon: '📖', desvios: avaliarAnotacaoCarteira(data), norma: 'CLT Art. 29' },
  }), [data]);

  const exportarRelatorio = () => {
    const linhas = ['RELATÓRIO DE CONFORMIDADE RH — ' + new Date().toLocaleDateString('pt-BR')];
    linhas.push('');
    linhas.push(`RESUMO EXECUTIVO`);
    linhas.push(`Total de Desvios: ${conformidade.total}`);
    linhas.push(`Críticos: ${conformidade.criticas}`);
    linhas.push('');
    
    Object.entries(itemsMap).forEach(([key, item]) => {
      linhas.push(`${item.nome} (${item.norma}): ${item.desvios.length} desvios`);
      item.desvios.slice(0, 5).forEach((d) => {
        linhas.push(`  - ${d.nome || 'Colaborador'}: ${d.descricao || d.documento} [${d.severidade}]`);
      });
      if (item.desvios.length > 5) linhas.push(`  ... e mais ${item.desvios.length - 5}`);
      linhas.push('');
    });

    const csv = linhas.join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `conformidade-rh-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 mb-8">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <h2 className="text-lg font-semibold text-[#0b2545]">Conformidade RH — Legislação Trabalhista</h2>
          <span className={`text-sm font-bold px-2.5 py-1 rounded-full border ${conformidade.criticas > 0 ? 'bg-red-100 text-red-700 border-red-300' : 'bg-emerald-100 text-emerald-700 border-emerald-300'}`}>
            {conformidade.criticas > 0 ? `${conformidade.criticas} Crítico(s)` : 'Conforme'}
          </span>
        </div>
        <Button onClick={exportarRelatorio} size="sm" variant="outline"><Download className="w-4 h-4 mr-1" />Exportar</Button>
      </div>

      <p className="text-sm text-slate-500 mb-4">Auditoria de conformidade com CLT, NR-18, Lei FGTS e normativas do Ministério do Trabalho.</p>

      {/* Cards de resumo */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-xs text-slate-500 mb-1">Total de Desvios</div>
          <div className="text-2xl font-bold text-[#0b2545]">{conformidade.total}</div>
          <div className="text-xs text-slate-400 mt-1">{conformidade.criticas} críticos</div>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <div className="text-xs text-red-600 font-semibold mb-1">FGTS</div>
          <div className="text-2xl font-bold text-red-700">{conformidade.fgts}</div>
          <div className="text-xs text-red-500 mt-1">Lei 8.036/1990</div>
        </div>
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
          <div className="text-xs text-orange-600 font-semibold mb-1">Férias</div>
          <div className="text-2xl font-bold text-orange-700">{conformidade.ferias}</div>
          <div className="text-xs text-orange-500 mt-1">CLT Art. 130-132</div>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
          <div className="text-xs text-yellow-600 font-semibold mb-1">Documentação</div>
          <div className="text-2xl font-bold text-yellow-700">{conformidade.documentacao + conformidade.carteira}</div>
          <div className="text-xs text-yellow-500 mt-1">Carteira + Docs</div>
        </div>
      </div>

      {/* Detalhes por categoria */}
      <div className="space-y-3">
        {Object.entries(itemsMap).map(([key, item]) => (
          <div key={key} className="border border-slate-200 rounded-lg overflow-hidden">
            <button onClick={() => setExpandido(expandido === key ? null : key)} className="w-full flex items-center justify-between p-3 hover:bg-slate-50">
              <div className="flex items-center gap-3">
                <span className="text-xl">{item.icon}</span>
                <div className="text-left">
                  <p className="font-semibold text-[#0b2545]">{item.nome}</p>
                  <p className="text-xs text-slate-400">{item.norma}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className={`text-sm font-bold px-2.5 py-0.5 rounded-full border ${item.desvios.length === 0 ? 'bg-emerald-100 text-emerald-700 border-emerald-300' : 'bg-red-100 text-red-700 border-red-300'}`}>
                  {item.desvios.length === 0 ? '✓ Conforme' : `${item.desvios.length} desvios`}
                </span>
                {expandido === key ? <EyeOff className="w-4 h-4 text-slate-400" /> : <Eye className="w-4 h-4 text-slate-400" />}
              </div>
            </button>

            {expandido === key && (
              <div className="bg-slate-50 border-t border-slate-200 p-3 space-y-2 max-h-[300px] overflow-y-auto">
                {item.desvios.length === 0 ? (
                  <p className="text-sm text-emerald-700 flex items-center gap-2"><CheckCircle2 className="w-4 h-4" /> Todos os colaboradores estão conforme.</p>
                ) : (
                  item.desvios.map((d, i) => {
                    const Icon = ICON_SEV[d.severidade];
                    return (
                      <div key={i} className={`rounded-lg border p-2 text-sm ${CORES[d.severidade]}`}>
                        <div className="flex items-start gap-2">
                          <Icon className="w-4 h-4 shrink-0 mt-0.5" />
                          <div className="flex-1">
                            <p className="font-semibold">{d.nome || d.documento}</p>
                            <p className="text-xs opacity-90">{d.descricao}</p>
                          </div>
                          <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-white bg-opacity-40">{d.severidade}</span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-700">
        <strong>Foco em Conformidade:</strong> Este painel monitora legislação trabalhista brasileira: CLT (Consolidação das Leis do Trabalho), Lei FGTS, NR-18, e normativas do Ministério do Trabalho e Previdência Social.
      </div>
    </section>
  );
}