import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { format, subMonths, endOfMonth, differenceInCalendarDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';

// status de um item "as-of" a data de referência
function statusAsOf(data_validade, ref) {
  if (!data_validade) return 'em_dia';
  const d = differenceInCalendarDays(new Date(data_validade), ref);
  if (d < 0) return 'vencido';
  if (d <= 30) return 'a_vencer';
  return 'em_dia';
}

export default function StatusMesChart({ itens, meses = 6 }) {
  const data = useMemo(() => {
    const now = new Date();
    const points = [];
    for (let i = meses - 1; i >= 0; i--) {
      const ref = endOfMonth(subMonths(now, i));
      const acc = { vencido: 0, a_vencer: 0, em_dia: 0 };
      itens.forEach((it) => { acc[statusAsOf(it.data_validade, ref)]++; });
      points.push({ mes: format(ref, 'MMM', { locale: ptBR }), Vencido: acc.vencido, 'A vencer': acc.a_vencer, 'Em dia': acc.em_dia });
    }
    return points;
  }, [itens, meses]);

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-1">Status das certificações por mês</h3>
      <p className="text-xs text-slate-400 mb-4">ASOs + Treinamentos + EPIs</p>
      <ResponsiveContainer width="100%" height={240}>
        <AreaChart data={data} margin={{ top: 5, right: 10, left: -15, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis dataKey="mes" tick={{ fontSize: 12, fill: '#64748b' }} />
          <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: '#64748b' }} />
          <Tooltip />
          <Legend />
          <Area dataKey="Vencido" stackId="1" stroke="#dc2626" fill="#fecaca" />
          <Area dataKey="A vencer" stackId="1" stroke="#d97706" fill="#fde68a" />
          <Area dataKey="Em dia" stackId="1" stroke="#059669" fill="#a7f3d0" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}