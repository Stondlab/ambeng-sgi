import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { mensagemAmigavelErro, validarDataOpcional, validarNumeroOpcional } from '@/lib/validacao';

export default function ValidityForm({ fields, funcionarios, onSubmit, onCancel, fixedFuncionarioId }) {
  const [values, setValues] = useState(fixedFuncionarioId ? { funcionario_id: fixedFuncionarioId } : {});
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(null);
  const [erro, setErro] = useState('');
  const set = (k, v) => setValues((p) => ({ ...p, [k]: v }));

  const handleFile = async (k, file) => {
    if (!file) return;
    setUploading(k);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    set(k, file_url);
    setUploading(null);
  };

  const handle = async (e) => {
    e.preventDefault();
    if (!values.funcionario_id) return setErro('Selecione o funcionário.');
    const dataInvalida = fields.find((f) => f.type === 'date' && !validarDataOpcional(values[f.name]));
    if (dataInvalida) return setErro(`Informe uma data válida em ${dataInvalida.label}.`);
    const numeroInvalido = fields.find((f) => f.type === 'number' && !validarNumeroOpcional(values[f.name]));
    if (numeroInvalido) return setErro(`Informe um valor numérico válido em ${numeroInvalido.label}.`);
    setErro(''); setSaving(true);
    try {
      await onSubmit(values);
      setValues(fixedFuncionarioId ? { funcionario_id: fixedFuncionarioId } : {});
    } catch (e) { setErro(mensagemAmigavelErro(e)); }
    finally { setSaving(false); }
  };

  return (
    <form onSubmit={handle} className="bg-slate-50 border border-slate-200 rounded-lg p-4 mb-4 grid gap-4 md:grid-cols-2">
      {!fixedFuncionarioId && (
        <div className="md:col-span-2">
          <Label>Funcionário</Label>
          <Select value={values.funcionario_id || ''} onValueChange={(v) => set('funcionario_id', v)}>
            <SelectTrigger className="mt-1"><SelectValue placeholder="Selecione o funcionário" /></SelectTrigger>
            <SelectContent>
              {funcionarios.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      )}
      {fields.map((f) => (
        <div key={f.name} className={f.type === 'textarea' ? 'md:col-span-2' : ''}>
          <Label>{f.label}</Label>
          {f.options ? (
            <Select value={values[f.name] || ''} onValueChange={(v) => set(f.name, v)}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger>
              <SelectContent>
                {f.options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
              </SelectContent>
            </Select>
          ) : f.type === 'textarea' ? (
            <Textarea className="mt-1" rows={3} value={values[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
          ) : f.type === 'file' ? (
            <>
              <Input className="mt-1" type="file" accept={f.accept || '.pdf,image/*'} onChange={(e) => handleFile(f.name, e.target.files?.[0])} />
              {uploading === f.name && <p className="text-xs text-slate-400 mt-1">Enviando...</p>}
              {values[f.name] && uploading !== f.name && <p className="text-xs text-emerald-600 mt-1">Anexado.</p>}
            </>
          ) : f.type === 'readonly' ? (
            <Input className="mt-1 bg-slate-50 text-slate-400" disabled value={values[f.name] || ''} placeholder={f.placeholder || 'Será gerado automaticamente'} />
          ) : (
            <Input className="mt-1" type={f.type || 'text'} list={f.suggestions ? `sug-${f.name}` : undefined}
              value={values[f.name] ?? ''} onChange={(e) => set(f.name, f.type === 'number' ? Number(e.target.value) : e.target.value)} />
          )}
          {f.suggestions && (
            <datalist id={`sug-${f.name}`}>
              {f.suggestions.map((s) => <option key={s} value={s} />)}
            </datalist>
          )}
        </div>
      ))}
      {erro && <p className="md:col-span-2 text-sm text-red-600">{erro}</p>}
      <div className="md:col-span-2 flex gap-2 justify-end">
        {onCancel && <Button type="button" variant="ghost" onClick={onCancel}>Cancelar</Button>}
        <Button type="submit" disabled={saving || !values.funcionario_id} className="bg-[#0b2545] hover:bg-[#16365f]">
          {saving ? 'Salvando...' : 'Salvar'}
        </Button>
      </div>
    </form>
  );
}