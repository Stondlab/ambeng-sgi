import React from 'react';
import { Link } from 'react-router-dom';
import { Stethoscope, GraduationCap, Users, HardHat, CalendarCheck, AlertTriangle, ClipboardCheck, FileText, FileCheck, Printer, BarChart3 } from 'lucide-react';

const ACOES = [
  { key: 'saude', label: 'Novo ASO', icon: Stethoscope },
  { key: 'treinamentos', label: 'Novo Treinamento', icon: GraduationCap },
  { key: 'treinamentos', label: 'Nova Integração', icon: Users },
  { key: 'seguranca', label: 'Nova Entrega EPI', icon: HardHat },
  { key: 'seguranca', label: 'Registrar DDS', icon: CalendarCheck },
  { key: 'seguranca', label: 'Registrar Ocorrência', icon: AlertTriangle },
  { key: 'seguranca', label: 'Registrar Inspeção', icon: ClipboardCheck },
  { key: 'documentos', label: 'Enviar Documento', icon: FileText },
  { key: 'historico', label: 'Histórico', icon: FileCheck },
];

export default function AcoesRapidas({ onNav }) {
  return (
    <aside className="bg-white border border-slate-200 rounded-xl p-4">
      <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-3">Ações rápidas</h3>
      <div className="flex lg:flex-col gap-2 overflow-x-auto pb-1">
        {ACOES.map((a) => (
          <button key={a.label} onClick={() => onNav(a.key)} className="flex items-center gap-2 text-xs font-medium px-3 py-2 rounded-lg border border-slate-200 text-[#0b2545] hover:bg-slate-50 whitespace-nowrap shrink-0">
            <a.icon className="w-4 h-4" />{a.label}
          </button>
        ))}
        <button onClick={() => window.print()} className="flex items-center gap-2 text-xs font-medium px-3 py-2 rounded-lg border border-slate-200 text-[#0b2545] hover:bg-slate-50 whitespace-nowrap shrink-0">
          <Printer className="w-4 h-4" />Imprimir Ficha
        </button>
        <Link to="/relatorios" className="flex items-center gap-2 text-xs font-medium px-3 py-2 rounded-lg border border-slate-200 text-[#0b2545] hover:bg-slate-50 whitespace-nowrap shrink-0">
          <BarChart3 className="w-4 h-4" />Gerar Relatório
        </Link>
      </div>
    </aside>
  );
}