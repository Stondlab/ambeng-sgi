import React, { useEffect, useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Building2, ArrowRightCircle, CheckCircle2 } from 'lucide-react';
import { fmt } from '@/lib/sst';

export default function AlocacoesSection({ funcionario, funcionario_id, podeEditar, obras = [] }) {
  const [items, setItems] = useState([]);
  const [show, setShow] = useState(false);
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(false);

  const load = async () => {
    try {
      const all = await base44.entities.Alocacoes.list('-data_inicio', 200);
      setItems(all.filter((r) => r.funcionario_id === funcionario_id));
    } catch { setItems([]); }
  };
  useEffect(() => { load(); }, [funcionario_id]);

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const ativa = useMemo(() => items.find((a) => a.ativa && !a.data_fim), [items]);

  const save = async () => {
    if (!form.obra || !form.data_inicio) return;
    setLoading(true);
    try {
      const obraObj = obras.find((o) => o.nome === form.obra) || {};
      await base44.entities.Alocacoes.create({
        funcionario_id,
        funcionario_nome: funcionario?.nome,
        obra: form.obra,
        obra_id: obraObj.id || '',
        funcao: form.funcao || funcionario?.funcao || '',
        data_inicio: form.data_inicio,
        ativa: true,
        observacoes: form.observacoes || '',
      });
      setForm({}); setShow(false); load();
    } finally { setLoading(false); }
  };

  const desalocar = async (a) => {
    const motivo = window.prompt('Motivo do deslocamento:', 'Transferência');
    if (motivo === null) return;
    const hoje = new Date().toISOString().slice(0, 10);
    await base44.entities.Alocacoes.update(a.id, { data_fim: hoje, ativa: false, motivo_saida: motivo });
    load();
  };

  const del = async (id) => { await base44.entities.Alocacoes.delete(id); load(); };

  const ordenadas = [...items].sort((a, b) => (b.data_inicio || '').localeCompare(a.data_inicio || ''));

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Building2 className="w-4 h-4 text-[#0b2545]" />
          <h3 className="font-semibold text-[#0b2545]">Alocações por Obra</h3>
        </div>
        {podeEditar && <Button size="sm" variant="outline" onClick={() => setShow((s) => !s)}><Plus className="w-4 h-4 mr-1" />Nova alocação</Button>}
      </div>

      {ativa && (
        <div className="mb-4 flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span className="text-sm font-medium text-emerald-800">Alocação ativa: {ativa.obra}</span>
          <span className="text-xs text-emerald-600">desde {fmt(ativa.data_inicio)}</span>
          {podeEditar && (
            <button onClick={() => desalocar(ativa)} className="ml-auto inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-md bg-emerald-600 text-white hover:bg-emerald-700">
              <ArrowRightCircle className="w-3.5 h-3.5" />Desalocar
            </button>
          )}
        </div>
      )}

      {show && podeEditar && (
        <div className="grid gap-3 mb-4 md:grid-cols-2 bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div>
            <Label>Obra *</Label>
            <Select value={form.obra || ''} onValueChange={(v) => set('obra', v)}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Selecione a obra" /></SelectTrigger>
              <SelectContent>{obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label>Função na obra</Label>
            <Input className="mt-1" value={form.funcao || funcionario?.funcao || ''} onChange={(e) => set('funcao', e.target.value)} placeholder="Função exercida" />
          </div>
          <div>
            <Label>Início *</Label>
            <Input className="mt-1" type="date" value={form.data_inicio || ''} onChange={(e) => set('data_inicio', e.target.value)} />
          </div>
          <div className="md:col-span-2">
            <Label>Observações</Label>
            <Textarea className="mt-1" rows={2} value={form.observacoes || ''} onChange={(e) => set('observacoes', e.target.value)} />
          </div>
          <div className="md:col-span-2 flex justify-end gap-2">
            <Button size="sm" variant="ghost" onClick={() => setShow(false)}>Cancelar</Button>
            <Button size="sm" onClick={save} disabled={loading || !form.obra || !form.data_inicio} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar alocação</Button>
          </div>
        </div>
      )}

      {ordenadas.length === 0 ? <p className="text-sm text-slate-400 py-3">Nenhuma alocação registrada. A obra não é vínculo fixo — registre as passagens do colaborador pelas obras.</p> : (
        <div className="divide-y divide-slate-100">
          {ordenadas.map((a) => (
            <div key={a.id} className="py-2.5 flex items-start gap-3">
              <div className={`w-2.5 h-2.5 rounded-full mt-1.5 shrink-0 ${a.ativa && !a.data_fim ? 'bg-emerald-500' : 'bg-slate-300'}`} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-[#0b2545]">{a.obra}</p>
                <p className="text-xs text-slate-500">
                  {fmt(a.data_inicio)} {a.data_fim ? `→ ${fmt(a.data_fim)}` : '→ presente'}
                  {a.funcao ? ` · ${a.funcao}` : ''}
                  {a.motivo_saida ? ` · ${a.motivo_saida}` : ''}
                </p>
              </div>
              {podeEditar && (
                <div className="flex items-center gap-1">
                  {!a.data_fim && <button onClick={() => desalocar(a)} className="p-2 text-amber-600 hover:bg-amber-50 rounded" title="Desalocar"><ArrowRightCircle className="w-4 h-4" /></button>}
                  <button onClick={() => del(a.id)} className="p-2 text-red-500 hover:bg-red-50 rounded" title="Excluir"><Trash2 className="w-4 h-4" /></button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}