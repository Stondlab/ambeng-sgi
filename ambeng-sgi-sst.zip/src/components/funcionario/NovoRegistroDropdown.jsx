import React from 'react';
import { Link } from 'react-router-dom';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Plus, Stethoscope, GraduationCap, Users, HardHat, CalendarCheck, AlertTriangle, ShieldAlert, FileText, FileCheck, Printer, BarChart3 } from 'lucide-react';

export default function NovoRegistroDropdown({ onNav, podeCriar = true }) {
  if (!podeCriar) return null;
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button className="bg-amber-400 text-[#0b2545] hover:bg-amber-300 font-semibold">
          <Plus className="w-4 h-4 mr-1" /> Novo Registro
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-60">
        <DropdownMenuLabel>Adicionar registro</DropdownMenuLabel>
        <DropdownMenuItem onClick={() => onNav('saude')}><Stethoscope className="w-4 h-4 mr-2" />Novo ASO</DropdownMenuItem>
        <DropdownMenuItem onClick={() => onNav('treinamentos')}><GraduationCap className="w-4 h-4 mr-2" />Novo Treinamento</DropdownMenuItem>
        <DropdownMenuItem onClick={() => onNav('rh')}><Users className="w-4 h-4 mr-2" />Nova Integração</DropdownMenuItem>
        <DropdownMenuItem onClick={() => onNav('epis')}><HardHat className="w-4 h-4 mr-2" />Nova Entrega de EPI</DropdownMenuItem>
        <DropdownMenuItem onClick={() => onNav('ocorrencias')}><CalendarCheck className="w-4 h-4 mr-2" />Registrar DDS</DropdownMenuItem>
        <DropdownMenuItem onClick={() => onNav('ocorrencias')}><AlertTriangle className="w-4 h-4 mr-2" />Registrar Ocorrência</DropdownMenuItem>
        <DropdownMenuItem onClick={() => onNav('ocorrencias')}><ShieldAlert className="w-4 h-4 mr-2" />Registrar Não Conformidade</DropdownMenuItem>
        <DropdownMenuItem onClick={() => onNav('documentos')}><FileText className="w-4 h-4 mr-2" />Enviar Documento</DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => onNav('historico')}><FileCheck className="w-4 h-4 mr-2" />Histórico</DropdownMenuItem>
        <DropdownMenuItem onClick={() => window.print()}><Printer className="w-4 h-4 mr-2" />Imprimir Ficha</DropdownMenuItem>
        <DropdownMenuItem asChild><Link to="/relatorios"><BarChart3 className="w-4 h-4 mr-2" />Gerar PDF / Relatório</Link></DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}