import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Plus, Trash2, ExternalLink, Wrench, Car, Shirt, Cpu, AlertTriangle, Search, Package } from 'lucide-react';
import { fmt } from '@/lib/sst';
import { useAuth } from '@/lib/AuthContext';
import { perfilUsuario } from '@/lib/permissoes';

const CATS = ['Ferramentas', 'Equipamentos', 'Máquinas autorizadas', 'Veículos', 'Uniformes', 'Celular corporativo', 'Notebook', 'Tablet', 'Chaves', 'Crachá', 'Cartões de acesso', 'Outros'];
const COND = ['Novo', 'Bom', 'Regular', 'Necessita Manutenção'];
const STATUS = ['Em uso', 'Devolvido', 'Danificado', 'Extraviado'];
const CAT_ICON = { 'Máquinas autorizadas': Wrench, 'Veículos': Car, 'Uniformes': Shirt, 'Celular corporativo': Cpu, 'Notebook': Cpu, 'Tablet': Cpu, 'Ferramentas': Wrench, 'Equipamentos': Package };

const ADD_FIELDS = [
  { name: 'categoria', label: 'Categoria', type: 'select', options: CATS },
  { name: 'descricao', label: 'Descrição' },
  { name: 'marca', label: 'Marca' }, { name: 'modelo', label: 'Modelo' },
  { name: 'numero_serie', label: 'Nº de Série' }, { name: 'numero_patrimonial', label: 'Nº Patrimonial' },
  { name: 'quantidade', label: 'Quantidade', type: 'number' },
  { name: 'data_entrega', label: 'Data de Entrega', type: 'date' },
  { name: 'responsavel_entrega', label: 'Responsável pela Entrega' },
  { name: 'condicao', label: 'Condição de Entrega', type: 'select', options: COND },
  { name: 'data_prevista_devolucao', label: 'Data Prevista de Devolução', type: 'date' },
  { name: 'data_devolucao', label: 'Data de Devolução', type: 'date' },
  { name: 'status', label: 'Status', type: 'select', options: STATUS },
  { name: 'observacoes', label: 'Observações', type: 'textarea' },
];

export default function EquipamentosSection({ funcionario_id, func }) {
  const { user } = useAuth();
  const perfil = perfilUsuario(user);
  const readOnly = perfil === 'Encarregado';
  const [items, setItems] = useState([]);
  const [show, setShow] = useState(false);
  const [sel, setSel] = useState(null);
  const [form, setForm] = useState({});
  const [q, setQ] = useState('');
  const [uploading, setUploading] = useState(false);

  const load = async () => {
    try {
      const all = await base44.entities.Equipamentos.list('-created_date', 500);
      setItems(all.filter((e) => e.funcionario_id === funcionario_id));
    } catch { setItems([]); }
  };
  useEffect(() => { load(); }, [funcionario_id]);

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  const save = async () => {
    await base44.entities.Equipamentos.create({ ...form, funcionario_id, obra: func?.obra, empresa: func?.empresa });
    setForm({}); setShow(false); load();
  };
  const del = async (id) => { await base44.entities.Equipamentos.delete(id); setSel(null); load(); };
  const onFile = async (file, field) => {
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm((p) => ({ ...p, [field]: file_url }));
    setUploading(false);
  };

  const hoje = new Date().toISOString().slice(0, 10);
  const filtrados = useMemo(() => {
    const s = q.toLowerCase().trim();
    return items.filter((e) => !s || [e.categoria, e.numero_patrimonial, e.descricao, e.marca, e.modelo, e.status, e.obra, e.empresa].filter(Boolean).some((v) => v.toLowerCase().includes(s)));
  }, [items, q]);

  const counts = useMemo(() => {
    const by = (cat) => items.filter((e) => e.categoria === cat).length;
    const pendDev = items.filter((e) => e.status === 'Em uso' && e.data_prevista_devolucao && e.data_prevista_devolucao < hoje).length;
    const manut = items.filter((e) => e.condicao === 'Necessita Manutenção').length;
    return { ferr: by('Ferramentas'), maq: by('Máquinas autorizadas'), veic: by('Veículos'), unif: by('Uniformes'), equip: by('Equipamentos'), pendDev, manut };
  }, [items]);

  const alertas = useMemo(() => {
    const a = [];
    items.forEach((e) => {
      if (e.status === 'Em uso' && e.data_prevista_devolucao && e.data_prevista_devolucao < hoje) a.push({ t: 'Equipamento sem devolução', d: `${e.descricao || e.categoria} — previsto ${fmt(e.data_prevista_devolucao)}` });
      if (e.categoria === 'Máquinas autorizadas' && e.autorizacao_operacao !== 'Sim') a.push({ t: 'Máquina sem autorização', d: e.descricao || '—' });
      if (e.categoria === 'Veículos' && e.cnh_exigida && func?.cnh_categoria && !e.cnh_exigida.split('').every((c) => (func.cnh_categoria || '').includes(c))) a.push({ t: 'CNH incompatível', d: `Exige ${e.cnh_exigida}, colaborador tem ${func.cnh_categoria}` });
      if (e.condicao === 'Necessita Manutenção') a.push({ t: 'Equipamento em manutenção', d: e.descricao || '—' });
    });
    return a;
  }, [items, func, hoje]);

  const ind = [
    { l: 'Ferramentas', v: counts.ferr }, { l: 'Máquinas', v: counts.maq }, { l: 'Veículos', v: counts.veic },
    { l: 'Uniformes', v: counts.unif }, { l: 'Equipamentos', v: counts.equip }, { l: 'Pend. devolução', v: counts.pendDev, red: true },
    { l: 'Em manutenção', v: counts.manut, red: true }, { l: 'Total', v: items.length },
  ];

  const extraFields = useMemo(() => {
    const c = form.categoria;
    const base = [];
    if (c === 'Máquinas autorizadas') base.push(
      { name: 'treinamento_obrigatorio', label: 'Treinamento obrigatório' },
      { name: 'autorizacao_operacao', label: 'Autorização para operação', type: 'select', options: ['Sim', 'Não'] },
      { name: 'data_autorizacao', label: 'Data da autorização', type: 'date' },
      { name: 'validade_autorizacao', label: 'Validade da autorização', type: 'date' },
    );
    if (c === 'Veículos') base.push(
      { name: 'placa', label: 'Placa' }, { name: 'veiculo_modelo', label: 'Modelo' }, { name: 'ano', label: 'Ano' },
      { name: 'cnh_exigida', label: 'CNH exigida', type: 'select', options: ['A', 'B', 'C', 'D', 'E', 'AB'] },
      { name: 'validade_cnh', label: 'Validade da CNH', type: 'date' },
    );
    if (c === 'Uniformes') base.push(
      { name: 'tamanho', label: 'Tamanho' }, { name: 'data_substituicao', label: 'Data prevista de substituição', type: 'date' },
    );
    if (['Celular corporativo', 'Notebook', 'Tablet'].includes(c)) base.push(
      { name: 'termo_responsabilidade', label: 'Termo de responsabilidade (arquivo)', type: 'file' },
    );
    return base;
  }, [form.categoria]);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-[#0b2545]">Equipamentos</h3>
        {!readOnly && <Button size="sm" variant="outline" onClick={() => setShow((s) => !s)}><Plus className="w-4 h-4 mr-1" />Registrar</Button>}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
        {ind.map((x) => (
          <div key={x.l} className={`rounded-lg p-3 ${x.red && x.v > 0 ? 'bg-red-50 border border-red-200' : 'bg-slate-50 border border-slate-200'}`}>
            <p className={`text-2xl font-bold leading-none ${x.red && x.v > 0 ? 'text-red-600' : 'text-[#0b2545]'}`}>{x.v}</p>
            <p className="text-xs text-slate-500 mt-1">{x.l}</p>
          </div>
        ))}
      </div>

      {alertas.length > 0 && (
        <div className="mb-4 space-y-1.5">
          {alertas.map((al, i) => (
            <div key={i} className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-sm text-red-700"><AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" /><div><b>{al.t}.</b> {al.d}</div></div>
          ))}
        </div>
      )}

      <div className="relative mb-3">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <Input className="pl-9" placeholder="Pesquisar por categoria, patrimônio, descrição, marca, modelo, status, obra..." value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      {show && !readOnly && (
        <div className="grid gap-3 mb-4 md:grid-cols-2 bg-slate-50 border border-slate-200 rounded-lg p-3">
          {ADD_FIELDS.map((f) => (
            <div key={f.name} className={f.type === 'textarea' ? 'md:col-span-2' : ''}>
              <Label>{f.label}</Label>
              {f.type === 'select' ? (
                <Select value={form[f.name] || ''} onValueChange={(v) => set(f.name, v)}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{f.options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
              ) : f.type === 'textarea' ? (
                <Textarea className="mt-1" rows={2} value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
              ) : (
                <Input className="mt-1" type={f.type || 'text'} value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
              )}
            </div>
          ))}
          {extraFields.map((f) => (
            <div key={f.name} className={f.type === 'file' ? 'md:col-span-2' : ''}>
              <Label>{f.label}</Label>
              {f.type === 'select' ? (
                <Select value={form[f.name] || ''} onValueChange={(v) => set(f.name, v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{f.options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
              ) : f.type === 'file' ? (
                <Input className="mt-1" type="file" onChange={(e) => onFile(e.target.files?.[0], f.name)} />
              ) : (
                <Input className="mt-1" type={f.type || 'text'} value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
              )}
            </div>
          ))}
          <div><Label>Fotos</Label><Input className="mt-1" type="file" accept="image/*" onChange={(e) => onFile(e.target.files?.[0], 'fotos')} /></div>
          <div><Label>Documento de Entrega</Label><Input className="mt-1" type="file" onChange={(e) => onFile(e.target.files?.[0], 'documento_url')} /></div>
          {uploading && <p className="md:col-span-2 text-xs text-slate-400">Enviando arquivo...</p>}
          <div className="md:col-span-2 flex justify-end gap-2"><Button size="sm" variant="ghost" onClick={() => setShow(false)}>Cancelar</Button><Button size="sm" onClick={save} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button></div>
        </div>
      )}

      {filtrados.length === 0 ? <p className="text-sm text-slate-400 py-4">Nenhum equipamento registrado.</p> : (
        <div className="divide-y divide-slate-100">
          {filtrados.map((e) => {
            const Icon = CAT_ICON[e.categoria] || Package;
            return (
              <button key={e.id} onClick={() => setSel(e)} className="w-full text-left py-3 flex items-center gap-3 hover:bg-slate-50 rounded -mx-2 px-2">
                <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center shrink-0"><Icon className="w-4 h-4 text-[#0b2545]" /></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[#0b2545] truncate">{e.descricao || e.categoria}</p>
                  <p className="text-xs text-slate-400">{e.categoria}{e.numero_patrimonial ? ` · Pat ${e.numero_patrimonial}` : ''}{e.marca ? ` · ${e.marca}` : ''}</p>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${e.status === 'Em uso' ? 'bg-amber-100 text-amber-800' : e.status === 'Devolvido' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>{e.status}</span>
              </button>
            );
          })}
        </div>
      )}

      <Dialog open={!!sel} onOpenChange={(o) => !o && setSel(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{sel?.descricao || sel?.categoria}</DialogTitle><DialogDescription>{sel?.categoria}</DialogDescription></DialogHeader>
          {sel && (
            <dl className="grid gap-x-6 gap-y-2 sm:grid-cols-2 text-sm">
              <Row k="Marca" v={sel.marca} /><Row k="Modelo" v={sel.modelo} />
              <Row k="Nº de Série" v={sel.numero_serie} /><Row k="Nº Patrimonial" v={sel.numero_patrimonial} />
              <Row k="Quantidade" v={sel.quantidade} /><Row k="Condição" v={sel.condicao} />
              <Row k="Entrega" v={fmt(sel.data_entrega)} /><Row k="Resp. Entrega" v={sel.responsavel_entrega} />
              <Row k="Prev. Devolução" v={fmt(sel.data_prevista_devolucao)} /><Row k="Devolução" v={fmt(sel.data_devolucao)} />
              <Row k="Status" v={sel.status} /><Row k="Obra" v={sel.obra} />
              {sel.treinamento_obrigatorio && <Row k="Treinamento obrigatório" v={sel.treinamento_obrigatorio} />}
              {sel.autorizacao_operacao && <Row k="Autorização" v={sel.autorizacao_operacao} />}
              {sel.placa && <Row k="Placa" v={sel.placa} />}
              {sel.cnh_exigida && <Row k="CNH exigida" v={sel.cnh_exigida} />}
              {sel.tamanho && <Row k="Tamanho" v={sel.tamanho} />}
              {sel.observacoes && <div className="sm:col-span-2"><dt className="text-xs text-slate-400">Observações</dt><dd className="text-slate-700">{sel.observacoes}</dd></div>}
              {sel.fotos && <div className="sm:col-span-2"><dt className="text-xs text-slate-400">Fotos</dt><dd><a href={sel.fotos} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[#0b2545] hover:underline">Ver foto <ExternalLink className="w-3 h-3" /></a></dd></div>}
              {sel.documento_url && <div className="sm:col-span-2"><dt className="text-xs text-slate-400">Documento</dt><dd><a href={sel.documento_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[#0b2545] hover:underline">Abrir documento <ExternalLink className="w-3 h-3" /></a></dd></div>}
              {sel.categoria === 'Máquinas autorizadas' && sel.autorizacao_operacao !== 'Sim' && (
                <div className="sm:col-span-2 flex items-start gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg p-3"><AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />Colaborador não autorizado a operar este equipamento.</div>
              )}
            </dl>
          )}
          {sel && !readOnly && (
            <div className="flex justify-end mt-2"><Button size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50" onClick={() => del(sel.id)}><Trash2 className="w-4 h-4 mr-1" />Excluir</Button></div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}

function Row({ k, v }) {
  return <div><dt className="text-xs text-slate-400">{k}</dt><dd className="text-slate-700">{v ?? '—'}</dd></div>;
}