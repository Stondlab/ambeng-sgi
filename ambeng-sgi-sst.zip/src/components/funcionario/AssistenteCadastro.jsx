import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { UserPlus, FileSpreadsheet, RefreshCw, ArrowLeft } from 'lucide-react';
import CadastroManualForm from '@/components/funcionario/CadastroManualForm';
import ImportacaoColaboradores from '@/components/funcionario/ImportacaoColaboradores';

const OPCOES = [
  { key: 'manual', icon: UserPlus, titulo: 'Cadastro Manual', desc: 'Preencha a ficha completa do colaborador com checklist e progresso automático.', bg: 'bg-blue-50', ring: 'hover:border-blue-400', iconBg: 'bg-blue-100 text-blue-700' },
  { key: 'importar', icon: FileSpreadsheet, titulo: 'Importar Arquivo (.xlsx ou .csv)', desc: 'Assistente inteligente com mapeamento automático, validações e detecção de formato. Inclui template para download.', bg: 'bg-emerald-50', ring: 'hover:border-emerald-400', iconBg: 'bg-emerald-100 text-emerald-700' },
  { key: 'esocial', icon: RefreshCw, titulo: 'Importação via eSocial', desc: 'Estrutura preparada para importação futura via eSocial.', bg: 'bg-slate-50', ring: 'hover:border-slate-400', iconBg: 'bg-slate-200 text-slate-600' },
];

export default function AssistenteCadastro({ open, onClose, onConcluido }) {
  const [mode, setMode] = useState(null);
  const fechar = () => { setMode(null); onClose?.(); };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) fechar(); }}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[#0b2545]">
            {mode && <button onClick={() => setMode(null)} className="text-slate-400 hover:text-[#0b2545]"><ArrowLeft className="w-4 h-4" /></button>}
            {mode === 'manual' ? 'Cadastro Manual' : mode === 'importar' ? 'Importar Arquivo' : 'Novo Colaborador'}
          </DialogTitle>
        </DialogHeader>

        {!mode && (
          <div className="grid sm:grid-cols-2 gap-4 py-2">
            {OPCOES.map((o) => (
              <button
                key={o.key}
                disabled={o.key === 'esocial'}
                onClick={() => setMode(o.key)}
                className={`text-left ${o.bg} border border-transparent rounded-2xl p-6 transition-all duration-200 hover:-translate-y-1 hover:shadow-md ${o.ring} disabled:opacity-60 disabled:cursor-not-allowed disabled:hover:translate-y-0`}
              >
                <div className={`w-12 h-12 rounded-xl ${o.iconBg} flex items-center justify-center mb-4`}>
                  <o.icon className="w-6 h-6" />
                </div>
                <p className="font-semibold text-[#0b2545] text-lg mb-1">{o.titulo}</p>
                <p className="text-sm text-slate-500">{o.desc}</p>
                {o.key === 'esocial' && <span className="inline-block mt-3 text-xs text-amber-700 bg-amber-100 px-2.5 py-1 rounded-full font-medium">Em breve</span>}
              </button>
            ))}
          </div>
        )}

        {mode === 'manual' && <CadastroManualForm onClose={fechar} />}
        {mode === 'importar' && <ImportacaoColaboradores onClose={fechar} onConcluido={onConcluido} />}
        {mode === 'esocial' && <p className="text-slate-500">Importação via eSocial será disponibilizada em breve.</p>}
      </DialogContent>
    </Dialog>
  );
}