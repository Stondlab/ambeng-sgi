import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Lock, Plus, Trash2, Clock, CalendarClock, AlertTriangle, Flag, Ban, FileX, Wallet, Timer } from 'lucide-react';
import { fmt } from '@/lib/sst';

export const CONTROLES = [
  { key: 'ponto', label: 'Controle de Ponto', icon: Clock, entity: 'Ponto', fields: [
    { name: 'data', label: 'Data', type: 'date' }, { name: 'entrada', label: 'Entrada' }, { name: 'saida', label: 'Saída' },
    { name: 'intervalo', label: 'Intervalo' }, { name: 'total_horas', label: 'Horas Trabalhadas' },
    { name: 'status', label: 'Status', type: 'select', options: ['Presente', 'Falta', 'Atrasado', 'Atestado', 'Folga'] },
    { name: 'observacao', label: 'Observação', type: 'textarea' },
  ] },
  { key: 'banco', label: 'Banco de Horas', icon: Wallet, entity: 'HorasExtras', filter: { tipo: ['Saldo positivo', 'Saldo negativo', 'Hora compensada'] }, summary: (items) => {
    const sum = (t) => items.filter((i) => i.tipo === t).reduce((a, b) => a + (Number(b.quantidade) || 0), 0);
    const pos = sum('Saldo positivo'), neg = sum('Saldo negativo'), comp = sum('Hora compensada');
    const saldo = pos - neg + comp;
    return [
      { label: 'Saldo atual', value: `${saldo.toFixed(1)}h`, tone: saldo >= 0 ? 'success' : 'destructive' },
      { label: 'Horas positivas', value: `${pos.toFixed(1)}h`, tone: 'success' },
      { label: 'Horas negativas', value: `${neg.toFixed(1)}h`, tone: 'destructive' },
      { label: 'Compensações', value: `${comp.toFixed(1)}h`, tone: 'info' },
    ];
  }, fields: [
    { name: 'data', label: 'Data', type: 'date' }, { name: 'quantidade', label: 'Quantidade (h)', type: 'number' },
    { name: 'tipo', label: 'Tipo', type: 'select', options: ['Saldo positivo', 'Saldo negativo', 'Hora compensada'] },
    { name: 'motivo', label: 'Motivo' }, { name: 'observacoes', label: 'Observações', type: 'textarea' },
  ] },
  { key: 'extras', label: 'Horas Extras', icon: Timer, entity: 'HorasExtras', filter: { tipo: ['Hora extra', 'Pendente'] }, fields: [
    { name: 'data', label: 'Data', type: 'date' }, { name: 'quantidade', label: 'Quantidade (h)', type: 'number' },
    { name: 'tipo', label: 'Tipo', type: 'select', options: ['Hora extra', 'Pendente'] },
    { name: 'motivo', label: 'Motivo' }, { name: 'autorizado_por', label: 'Aprovador' }, { name: 'observacoes', label: 'Observações', type: 'textarea' },
  ] },
  { key: 'ferias', label: 'Férias', icon: CalendarClock, entity: 'Ferias', fields: [
    { name: 'periodo_aquisitivo_inicio', label: 'Per. aquisitivo (início)', type: 'date' },
    { name: 'periodo_aquisitivo_fim', label: 'Per. aquisitivo (fim)', type: 'date' },
    { name: 'periodo_concessivo_inicio', label: 'Per. concessivo (início)', type: 'date' },
    { name: 'periodo_concessivo_fim', label: 'Per. concessivo (fim)', type: 'date' },
    { name: 'inicio', label: 'Início', type: 'date' }, { name: 'fim', label: 'Fim', type: 'date' }, { name: 'dias', label: 'Dias', type: 'number' },
    { name: 'status', label: 'Status', type: 'select', options: ['Programada', 'Em andamento', 'Concluída'] },
  ] },
  { key: 'afast', label: 'Afastamentos', icon: AlertTriangle, entity: 'Afastamentos', fields: [
    { name: 'tipo', label: 'Tipo', type: 'select', options: ['INSS', 'Acidente', 'Licença Médica', 'Licença Maternidade', 'Licença Paternidade', 'Outros'] },
    { name: 'data_inicio', label: 'Início', type: 'date' }, { name: 'data_fim', label: 'Fim', type: 'date' }, { name: 'observacoes', label: 'Observações', type: 'textarea' },
  ] },
  { key: 'advert', label: 'Advertências', icon: Flag, entity: 'Advertencias', fields: [
    { name: 'data', label: 'Data', type: 'date' }, { name: 'tipo', label: 'Tipo' }, { name: 'motivo', label: 'Motivo' },
    { name: 'responsavel', label: 'Responsável' }, { name: 'status', label: 'Status', type: 'select', options: ['Ativa', 'Ciente', 'Cancelada'] },
    { name: 'documento_url', label: 'Documento', type: 'file' },
  ] },
  { key: 'susp', label: 'Suspensões', icon: Ban, entity: 'Suspensoes', fields: [
    { name: 'data', label: 'Data', type: 'date' }, { name: 'dias', label: 'Dias', type: 'number' }, { name: 'motivo', label: 'Motivo' }, { name: 'responsavel', label: 'Responsável' },
    { name: 'documento_url', label: 'Documento', type: 'file' },
  ] },
  { key: 'resc', label: 'Rescisão', icon: FileX, entity: 'Rescisao', fields: [
    { name: 'data', label: 'Data', type: 'date' },
    { name: 'tipo', label: 'Tipo', type: 'select', options: ['Sem justa causa', 'Com justa causa', 'Pedido de demissão', 'Término de contrato', 'Aposentadoria'] },
    { name: 'motivo', label: 'Motivo' }, { name: 'observacoes', label: 'Observações', type: 'textarea' },
  ] },
];

function matchFilter(record, filter) {
  if (!filter) return true;
  return Object.entries(filter).every(([field, vals]) => vals.includes(record[field]));
}

function RhCrud({ entity, fields, funcionario_id, filter, summary }) {
  const [items, setItems] = useState([]);
  const [show, setShow] = useState(false);
  const [form, setForm] = useState({});
  const [uploading, setUploading] = useState(false);

  const load = async () => {
    try {
      const all = await base44.entities[entity].list('-created_date', 200);
      setItems(all.filter((r) => r.funcionario_id === funcionario_id && matchFilter(r, filter)));
    } catch { setItems([]); }
  };
  useEffect(() => { load(); }, [entity, funcionario_id, filter]);

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  const onFile = async (file, field) => {
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setForm((p) => ({ ...p, [field]: file_url }));
    } finally { setUploading(false); }
  };
  const save = async () => {
    await base44.entities[entity].create({ ...form, funcionario_id });
    setForm({}); setShow(false); load();
  };
  const del = async (id) => { await base44.entities[entity].delete(id); load(); };

  return (
    <div>
      <div className="flex justify-end mb-2">
        <Button size="sm" variant="outline" onClick={() => setShow((s) => !s)}><Plus className="w-4 h-4 mr-1" />Adicionar</Button>
      </div>
      {show && (
        <div className="grid gap-3 mb-3 md:grid-cols-2 bg-slate-50 border border-slate-200 rounded-lg p-3">
          {fields.map((f) => (
            <div key={f.name} className={f.type === 'textarea' || f.type === 'file' ? 'md:col-span-2' : ''}>
              <Label>{f.label}</Label>
              {f.type === 'select' ? (
                <Select value={form[f.name] || ''} onValueChange={(v) => set(f.name, v)}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{f.options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
              ) : f.type === 'textarea' ? (
                <Textarea className="mt-1" rows={2} value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
              ) : f.type === 'file' ? (
                <Input className="mt-1" type="file" onChange={(e) => onFile(e.target.files?.[0], f.name)} />
              ) : (
                <Input className="mt-1" type={f.type || 'text'} value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
              )}
              {f.type === 'file' && form[f.name] && <p className="text-xs text-emerald-600 mt-1">Documento anexado.</p>}
            </div>
          ))}
          {uploading && <p className="md:col-span-2 text-xs text-slate-400">Enviando arquivo...</p>}
          <div className="md:col-span-2 flex justify-end gap-2">
            <Button size="sm" variant="ghost" onClick={() => setShow(false)}>Cancelar</Button>
            <Button size="sm" onClick={save} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button>
          </div>
        </div>
      )}
      {summary && items.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
          {summary(items).map((s) => (
            <div key={s.label} className="rounded-lg border border-slate-200 bg-slate-50/60 p-3">
              <p className={`text-lg font-heading font-bold ${s.tone === 'success' ? 'text-success' : s.tone === 'destructive' ? 'text-destructive' : 'text-info'}`}>{s.value}</p>
              <p className="text-xs text-slate-500 mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
      )}
      {items.length === 0 ? <p className="text-sm text-slate-400 py-3">Nenhum registro.</p> : (
        <div className="divide-y divide-slate-100">
          {items.map((it) => (
            <div key={it.id} className="py-2 flex items-start gap-2">
              <div className="flex-1 flex flex-wrap gap-x-4 gap-y-1 text-sm">
                {fields.slice(0, 4).map((f) => (
                  <span key={f.name} className="text-slate-600"><span className="text-slate-400 text-xs">{f.label}: </span>{f.type === 'date' ? fmt(it[f.name]) : (it[f.name] ?? '—')}</span>
                ))}
                {it.documento_url && <a href={it.documento_url} target="_blank" rel="noreferrer" className="text-[#0b2545] hover:underline text-xs">Ver documento</a>}
              </div>
              <button onClick={() => del(it.id)} className="p-2 text-red-500 hover:bg-red-50 rounded" title="Excluir"><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function RhSection({ funcionario_id }) {
  const [tab, setTab] = useState('ponto');
  const ativo = CONTROLES.find((c) => c.key === tab);
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><Lock className="w-4 h-4 text-amber-500" /><h3 className="font-semibold text-[#0b2545]">Módulo de RH</h3></div>
      <p className="text-sm text-slate-500 mb-4">Área restrita a RH e Administradores. Estrutura preparada para futura integração com sistema de RH.</p>
      <div className="flex flex-wrap gap-2 mb-4">
        {CONTROLES.map((c) => {
          const Icon = c.icon;
          const active = c.key === tab;
          return (
            <button key={c.key} onClick={() => setTab(c.key)} className={`inline-flex items-center gap-1.5 px-3 py-2 min-h-[40px] rounded-lg text-xs font-medium transition-colors ${active ? 'bg-[#0b2545] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
              <Icon className="w-4 h-4" />{c.label}
            </button>
          );
        })}
      </div>
      <RhCrud key={ativo.key} entity={ativo.entity} fields={ativo.fields} funcionario_id={funcionario_id} filter={ativo.filter} summary={ativo.summary} />
    </section>
  );
}