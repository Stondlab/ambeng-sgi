import React from 'react';
import { Image } from '@/components/ui/image';
import { Button } from '@/components/ui/button';
import { Pencil, Printer, History, Share2, User } from 'lucide-react';
import { fmt } from '@/lib/sst';

const STATUS = { 'Ativo': 'bg-emerald-100 text-emerald-700', 'Afastado': 'bg-amber-100 text-amber-800', 'Demitido': 'bg-slate-200 text-slate-600' };

function Linha({ label, value }) {
  return <div><dt className="text-xs text-slate-400">{label}</dt><dd className="text-sm text-slate-700">{value || '—'}</dd></div>;
}

export default function FichaIdentificacao({ func, onEditar, onHistorico, podeEditar = true }) {
  const compartilhar = async () => {
    const url = window.location.href;
    if (navigator.share) { try { await navigator.share({ title: func.nome, url }); } catch {} }
    else { try { await navigator.clipboard.writeText(url); } catch {} }
  };
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex flex-col sm:flex-row gap-5">
        <div className="w-24 h-24 rounded-xl bg-slate-100 overflow-hidden flex items-center justify-center shrink-0">
          {func.foto_url ? <Image src={func.foto_url} fittingType="fill" className="w-full h-full" /> : <User className="w-10 h-10 text-slate-400" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <h2 className="text-xl font-semibold text-[#0b2545]">{func.nome}</h2>
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS[func.status] || STATUS['Ativo']}`}>{func.status || 'Ativo'}</span>
          </div>
          <dl className="grid gap-x-6 gap-y-2 sm:grid-cols-2 lg:grid-cols-4 mt-3">
            <Linha label="Matrícula" value={func.matricula} />
            <Linha label="Empresa" value={func.empresa} />
            <Linha label="Obra" value={func.obra} />
            <Linha label="Cargo / Função" value={func.funcao} />
            <Linha label="CBO" value={func.cbo} />
            <Linha label="Admissão" value={fmt(func.data_admissao)} />
            <Linha label="CPF" value={func.cpf} />
            <Linha label="RG" value={func.rg} />
            <Linha label="CNH" value={func.cnh_numero ? `${func.cnh_categoria || ''} · val. ${fmt(func.cnh_validade)}` : null} />
            <Linha label="Telefone" value={func.telefone || func.whatsapp} />
            <Linha label="E-mail" value={func.email} />
            <Linha label="Contato emergência" value={func.contato_emergencia_telefone ? `${func.contato_emergencia_nome || ''} · ${func.contato_emergencia_telefone}` : null} />
          </dl>
        </div>
        <div className="flex sm:flex-col gap-2 sm:w-36 shrink-0">
          {podeEditar && <Button size="sm" variant="outline" onClick={onEditar}><Pencil className="w-4 h-4 mr-1" />Editar</Button>}
          <Button size="sm" variant="outline" onClick={() => window.print()}><Printer className="w-4 h-4 mr-1" />Imprimir</Button>
          <Button size="sm" variant="outline" onClick={onHistorico}><History className="w-4 h-4 mr-1" />Histórico</Button>
          <Button size="sm" variant="outline" onClick={compartilhar}><Share2 className="w-4 h-4 mr-1" />Compartilhar</Button>
        </div>
      </div>
    </section>
  );
}