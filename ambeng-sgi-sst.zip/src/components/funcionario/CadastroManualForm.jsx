import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Image } from '@/components/ui/image';
import { checklistLiberacao, statusLiberacao, STATUS_LIB } from '@/lib/liberacao';
import { validarCPF, validarEmail } from '@/lib/importacaoColaboradores';
import { applyTitleCaseAll } from '@/lib/titleCase';
import { Check, User, ChevronDown } from 'lucide-react';
import MoneyInput from '@/components/funcionario/MoneyInput';
import { obrasAtivasParaLancamento } from '@/lib/obraDisponibilidade';
import { mensagemAmigavelErro, validarDataOpcional, validarNumeroOpcional, validarTelefoneOpcional } from '@/lib/validacao';

const TURNO_JORNADA = {
  'Integral': '7 às 17',
  'Manhã': '7 às 12',
  'Tarde': '13 às 18',
  'Noite': '22 às 6',
  '12x36': '12x36 (7 às 19 / folga)',
};

const GRUPOS = [
  { title: 'Dados pessoais', fields: [
    { name: 'nome', label: 'Nome completo' },
    { name: 'cpf', label: 'CPF' },
    { name: 'rg', label: 'RG' },
    { name: 'pis', label: 'PIS' },
    { name: 'data_nascimento', label: 'Nascimento', type: 'date' },
    { name: 'sexo', label: 'Sexo', options: ['Masculino', 'Feminino', 'Outro'] },
    { name: 'estado_civil', label: 'Estado civil', options: ['Solteiro', 'Casado', 'Divorciado', 'Viúvo', 'União estável'] },
    { name: 'escolaridade', label: 'Escolaridade', options: ['Fundamental incompleto', 'Fundamental completo', 'Médio incompleto', 'Médio completo', 'Técnico', 'Superior incompleto', 'Superior completo'] },
  ]},
  { title: 'Contatos', fields: [
    { name: 'telefone', label: 'Telefone' },
    { name: 'whatsapp', label: 'WhatsApp' },
    { name: 'email', label: 'E-mail' },
    { name: 'endereco', label: 'Endereço' },
    { name: 'cep', label: 'CEP' },
    { name: 'cidade', label: 'Cidade' },
    { name: 'estado', label: 'Estado' },
  ]},
  { title: 'Emergência', fields: [
    { name: 'contato_emergencia_nome', label: 'Nome do contato' },
    { name: 'contato_emergencia_parentesco', label: 'Grau de parentesco' },
    { name: 'contato_emergencia_telefone', label: 'Telefone' },
  ]},
  { title: 'Profissionais', fields: [
    { name: 'empresa', label: 'Empresa', type: 'empresas' },
    { name: 'obra', label: 'Obra (opcional)', type: 'obras_lista' },
    { name: 'funcao', label: 'Cargo / Função', type: 'cargos' },
    { name: 'cbo', label: 'CBO' },
    { name: 'centro_custo', label: 'Centro de custo' },
    { name: 'data_admissao', label: 'Admissão', type: 'date' },
    { name: 'tipo_contratacao', label: 'Tipo de contratação', options: ['CLT', 'PJ', 'Terceirizado', 'Estágio', 'Aprendiz'] },
    { name: 'turno', label: 'Turno', options: ['Manhã', 'Tarde', 'Noite', 'Integral', '12x36'] },
    { name: 'jornada', label: 'Jornada' },
  ]},
  { title: 'CNH', fields: [
    { name: 'cnh_numero', label: 'Número da CNH' },
    { name: 'cnh_categoria', label: 'Categoria', options: ['A', 'B', 'C', 'D', 'E', 'AB'] },
    { name: 'cnh_validade', label: 'Validade', type: 'date' },
  ]},
  { title: 'Custos de Mão de Obra', fields: [
    { name: 'tipo_vinculo', label: 'Tipo de vínculo', options: ['Funcionário CLT com registro', 'Prestador'] },
    { name: 'custo_base', label: 'Salário base mensal (R$)', type: 'money' },
    { name: 'valor_hora', label: 'Valor/hora direto (R$) — opcional', type: 'money' },
    { name: 'vt_diario', label: 'VT diário (R$)', type: 'money' },
    { name: 'vr_diario', label: 'VR diário (R$)', type: 'money' },
    { name: 'premiacao_mensal', label: 'Premiação mensal (R$)', type: 'money' },
    { name: 'obra_padrao', label: 'Obra padrão', type: 'obras' },
  ]},
  { title: 'Uniforme', fields: [
    { name: 'tamanho_uniforme', label: 'Tamanho de uniforme' },
    { name: 'tamanho_calcado', label: 'Tamanho de calçado' },
  ]},
];

const REQUIRED = ['nome', 'cpf', 'tipo_vinculo', 'funcao', 'empresa', 'email', 'telefone', 'contato_emergencia_telefone', 'contato_emergencia_nome'];
const FIELD_LABELS = {
  nome: 'Nome completo', cpf: 'CPF', tipo_vinculo: 'Tipo de Vínculo', funcao: 'Cargo',
  empresa: 'Empresa', email: 'Email Profissional', telefone: 'Telefone Profissional',
  contato_emergencia_telefone: 'Telefone de Emergência', contato_emergencia_nome: 'Contato de Emergência',
};
const BADGE = {
  liberado: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  pendente: 'bg-amber-50 text-amber-700 border-amber-200',
  cadastro_incompleto: 'bg-slate-100 text-slate-700 border-slate-200',
  bloqueado: 'bg-red-50 text-red-700 border-red-200',
  desligado: 'bg-slate-200 text-slate-600 border-slate-300',
};
const ICONE = { cadastro: Check, foto: User, documentos: Check, aso: Check, integracao: Check, treinamentos: Check, epi: Check, cargo: Check, obra: Check, empresa: Check, contato: Check };

function GrupoRecolhivel({ titulo, children, defaultOpen = true }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <button onClick={() => setOpen((o) => !o)} className="w-full flex items-center justify-between px-4 py-3 hover:bg-slate-50 transition">
        <span className="font-medium text-[#0b2545]">{titulo}</span>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && <div className="px-4 pb-4">{children}</div>}
    </div>
  );
}

export default function CadastroManualForm({ onClose }) {
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  const [uploadingFoto, setUploadingFoto] = useState(false);
  const [erro, setErro] = useState('');
  const navigate = useNavigate();
  const [obras, setObras] = useState([]);
  const [cargos, setCargos] = useState([]);
  const [empresas, setEmpresas] = useState([]);
  const [matriculaPreview, setMatriculaPreview] = useState('');

  useEffect(() => { (async () => {
    try { setObras(obrasAtivasParaLancamento(await base44.entities.Obras.list('-created_date', 500))); } catch {}
    try { setCargos(await base44.entities.CargosFuncoes.list('nome', 500)); } catch {}
    try { setEmpresas(await base44.entities.Empresas.list('nome', 500)); } catch {}
    try {
      const res = await base44.functions.invoke('gerarMatricula', { preview: true });
      if (res.data?.matricula) setMatriculaPreview(res.data.matricula);
    } catch {}
  })(); }, []);

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const handleFieldChange = (name, value) => {
    setForm((p) => {
      const next = { ...p, [name]: value };
      if (name === 'funcao') {
        const cargo = cargos.find((c) => c.nome === value);
        if (cargo) {
          if (cargo.cbo) next.cbo = cargo.cbo;
          if (cargo.salario_base != null) next.custo_base = cargo.salario_base;
          if (cargo.vt_diario != null) next.vt_diario = cargo.vt_diario;
          if (cargo.vr_diario != null) next.vr_diario = cargo.vr_diario;
          if (cargo.empresa_id) {
            const emp = empresas.find((e) => e.id === cargo.empresa_id);
            if (emp) next.empresa = emp.nome_fantasia || emp.razao_social || emp.nome;
          }
        }
      }
      if (name === 'tipo_contratacao') {
        const VINCULO_MAP = {
          'CLT': 'Funcionário CLT com registro',
          'PJ': 'Prestador',
          'Terceirizado': 'Prestador',
          'Estágio': 'Funcionário CLT com registro',
          'Aprendiz': 'Funcionário CLT com registro',
        };
        if (VINCULO_MAP[value]) next.tipo_vinculo = VINCULO_MAP[value];
        if (value === 'CLT') {
          next.turno = 'Integral';
          next.jornada = TURNO_JORNADA['Integral'];
        }
      }
      if (name === 'turno' && TURNO_JORNADA[value]) {
        next.jornada = TURNO_JORNADA[value];
      }
      return next;
    });
  };
  const onFoto = async (file) => {
    if (!file) return;
    setUploadingFoto(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    set('foto_url', file_url);
    setUploadingFoto(false);
  };

  const progress = Math.round(REQUIRED.filter((k) => form[k]).length / REQUIRED.length * 100);
  const status = statusLiberacao(form, {});
  const checklist = checklistLiberacao(form, {});
  const okCount = checklist.filter((i) => i.ok).length;
  const statusTxt = progress === 100 ? 'Liberado para Trabalho' : 'Pendente de Liberação';

  const save = async () => {
    if (!form.nome || !form.nome.trim()) return setErro('Digite o nome completo.');
    if (form.cpf && !validarCPF(form.cpf)) return setErro('Informe um CPF válido.');
    if (form.email && !validarEmail(form.email)) return setErro('Informe um e-mail válido.');
    if ([form.telefone, form.whatsapp, form.contato_emergencia_telefone].some((v) => !validarTelefoneOpcional(v))) return setErro('Informe telefones com DDD e 10 ou 11 dígitos.');
    if ([form.data_nascimento, form.data_admissao, form.cnh_validade].some((v) => !validarDataOpcional(v))) return setErro('Informe datas válidas.');
    if ([form.custo_base, form.valor_hora, form.vt_diario, form.vr_diario, form.premiacao_mensal].some((v) => !validarNumeroOpcional(v))) return setErro('Informe valores numéricos válidos e não negativos.');
    setErro('');
    setSaving(true);
    try {
      // Matrícula automática (A0001...) — gerada pelo backend, sequencial e única.
      let matricula = '';
      try {
        const res = await base44.functions.invoke('gerarMatricula', { empresa: form.empresa || '' });
        matricula = res.data?.matricula || '';
      } catch {}
      if (!matricula) { setSaving(false); return setErro('Não foi possível gerar a matrícula automática. Tente novamente.'); }
      const payload = applyTitleCaseAll({ ...form, matricula, obra_padrao: form.obra_padrao === 'nenhum' ? '' : form.obra_padrao, cpf: String(form.cpf || '').replace(/\D/g, ''), status_liberacao: STATUS_LIB[status.status] });
      const criado = await base44.entities.Funcionarios.create(payload);
      try { const me = await base44.auth.me(); await base44.entities.Importacoes.create({ usuario: me.full_name || me.email || '—', data_hora: new Date().toISOString(), tipo: 'Manual', total_importados: 1 }); } catch {}
      onClose?.();
      navigate(`/funcionarios/${criado.id}`);
    } catch (e) { setErro(mensagemAmigavelErro(e, 'Não foi possível cadastrar. Verifique os dados informados.')); }
    setSaving(false);
  };

  return (
    <div className="space-y-4">
      {/* Matrícula automática */}
      {matriculaPreview && (
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-[#0b2545] text-white flex items-center justify-center font-bold text-sm shrink-0">
            {matriculaPreview.slice(0, 1)}
          </div>
          <div className="flex-1">
            <p className="text-xs text-slate-500">Matrícula gerada automaticamente</p>
            <p className="text-lg font-bold text-[#0b2545] tracking-wider">{matriculaPreview}</p>
          </div>
          <span className="text-[10px] text-slate-400 uppercase tracking-wide">Auto</span>
        </div>
      )}

      {/* Progresso */}
      <div className="bg-gradient-to-br from-[#0b2545] to-[#16365f] rounded-xl p-4 text-white">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Cadastro em elaboração</span>
          <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${progress === 100 ? 'bg-emerald-400 text-[#0b2545]' : 'bg-amber-400 text-[#0b2545]'}`}>{statusTxt}</span>
        </div>
        <div className="flex gap-1 mb-2">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className={`h-2.5 flex-1 rounded-full transition-colors ${i < Math.round(progress / 10) ? 'bg-amber-400' : 'bg-white/25'}`} />
          ))}
        </div>
        <div className="flex justify-between text-xs text-white/80">
          <span>{progress}% concluído</span>
          <span>{okCount}/{checklist.length} requisitos · Índice {Math.round((okCount / checklist.length) * 100)}%</span>
        </div>
      </div>

      {/* Checklist visual em cartões */}
      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">Checklist automático de liberação</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
          {checklist.map((i) => {
            const Icon = ICONE[i.key] || Check;
            return (
              <div key={i.key} className={`rounded-xl border p-3 flex items-center gap-2 transition ${i.ok ? 'bg-emerald-50 border-emerald-200' : 'bg-amber-50 border-amber-200'}`}>
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${i.ok ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                  {i.ok ? <Check className="w-4 h-4" /> : <Icon className="w-4 h-4" />}
                </div>
                <div className="min-w-0">
                  <p className={`text-xs font-medium truncate ${i.ok ? 'text-emerald-700' : 'text-amber-700'}`}>{i.label}</p>
                  <p className={`text-[10px] ${i.ok ? 'text-emerald-500' : 'text-amber-500'}`}>{i.ok ? 'Em dia' : 'Pendente'}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Foto */}
      <GrupoRecolhivel titulo="Foto do colaborador">
        <div className="flex items-center gap-4 pt-2">
          <div className="w-20 h-20 rounded-full bg-slate-100 overflow-hidden flex items-center justify-center shrink-0">
            {form.foto_url ? <Image src={form.foto_url} fittingType="fill" className="w-full h-full" /> : <User className="w-8 h-8 text-slate-400" />}
          </div>
          <div>
            <Label>Enviar foto</Label>
            <Input className="mt-1 max-w-xs" type="file" accept="image/*" onChange={(e) => onFoto(e.target.files?.[0])} />
            {uploadingFoto && <p className="text-xs text-slate-400 mt-1">Enviando...</p>}
          </div>
        </div>
      </GrupoRecolhivel>

      {/* Grupos recolhíveis */}
      {GRUPOS.map((g) => (
        <GrupoRecolhivel key={g.title} titulo={g.title} defaultOpen={g.title === 'Dados pessoais'}>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 pt-2">
            {g.fields.map((f) => (
              <div key={f.name}>
                <Label>{f.label}{REQUIRED.includes(f.name) ? ' *' : ''}</Label>
                {f.type === 'obras' ? (
                  <Select value={form[f.name] || ''} onValueChange={(v) => set(f.name, v === 'nenhum' ? '' : v)}>
                    <SelectTrigger className="mt-1"><SelectValue placeholder="Selecione (opcional)" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nenhum">— Nenhuma —</SelectItem>
                      {obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}
                    </SelectContent>
                  </Select>
                ) : f.type === 'obras_lista' ? (
                  <Select value={form[f.name] || 'nenhum'} onValueChange={(v) => set(f.name, v === 'nenhum' ? '' : v)}>
                    <SelectTrigger className="mt-1"><SelectValue placeholder="Selecione (opcional)" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nenhum">— Nenhuma —</SelectItem>
                      {obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>) }
                    </SelectContent>
                  </Select>
                ) : f.type === 'cargos' ? (
                  <div className="mt-1 space-y-1">
                    <Select value={form[f.name] || 'nenhum'} onValueChange={(v) => handleFieldChange(f.name, v === 'nenhum' ? '' : v)}>
                      <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="nenhum">— Nenhum —</SelectItem>
                        {cargos.map((c) => <SelectItem key={c.id} value={c.nome}>{c.nome}</SelectItem>)}
                        {form[f.name] && !cargos.find((c) => c.nome === form[f.name]) && <SelectItem value={form[f.name]}>{form[f.name]}</SelectItem>}
                      </SelectContent>
                    </Select>
                    <Input className="text-xs" placeholder="Ou digite um cargo personalizado" value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
                  </div>
                ) : f.type === 'empresas' ? (
                  <Select value={form[f.name] || 'nenhum'} onValueChange={(v) => set(f.name, v === 'nenhum' ? '' : v)}>
                    <SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nenhum">— Nenhuma —</SelectItem>
                      {empresas.map((e) => { const nome = e.nome_fantasia || e.razao_social || e.nome; return nome ? <SelectItem key={e.id} value={nome}>{nome}</SelectItem> : null; })}
                      {form[f.name] && !empresas.find((e) => (e.nome_fantasia || e.razao_social || e.nome) === form[f.name]) && <SelectItem value={form[f.name]}>{form[f.name]}</SelectItem>}
                    </SelectContent>
                  </Select>
                ) : f.options ? (
                 <Select value={form[f.name] || ''} onValueChange={(v) => handleFieldChange(f.name, v)}>
                   <SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger>
                   <SelectContent>{f.options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                 </Select>
                ) : f.type === 'money' ? (
                  <MoneyInput className="mt-1" value={form[f.name] ?? ''} onChange={(v) => set(f.name, v)} />
                ) : (
                  <Input className="mt-1" type={f.type || 'text'} value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
                )}
              </div>
            ))}
          </div>
        </GrupoRecolhivel>
      ))}

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-800">
        <strong>Premiação mensal:</strong> rateada entre as obras conforme os dias trabalhados (Apontamento Diário) e não tem incidência de encargos. O <strong>Custo base</strong> é o valor mensal (CLT) ou o valor da diária (Prestador).
      </div>

      {erro && <p className="text-sm text-red-600">{erro}</p>}

      <div className="flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose}>Cancelar</Button>
        <Button onClick={save} disabled={saving} className="bg-[#0b2545] hover:bg-[#16365f]">
          {saving ? 'Salvando...' : 'Cadastrar e abrir prontuário'}
        </Button>
      </div>
    </div>
  );
}