import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, FileText, ExternalLink } from 'lucide-react';
import { fmt, classificarDocumento, FAIXA_DOC } from '@/lib/sst';

const CATEGORIAS = ['Documentos pessoais', 'ASOs', 'Certificados', 'Fichas de EPI', 'Integrações', 'DDS', 'Inspeções', 'Ocorrências', 'Outros'];

export default function DocumentosSection({ funcionario_id, items, reload, categoriasPermitidas = CATEGORIAS, podeExcluir = true }) {
  const [show, setShow] = useState(false);
  const [form, setForm] = useState({ nome: '', tipo: categoriasPermitidas[0], file_url: '', data_validade: '' });
  const [uploading, setUploading] = useState(false);

  const sorted = [...items].filter((d) => categoriasPermitidas.includes(d.tipo || 'Outros')).sort((a, b) => new Date(b.data_upload || b.created_date) - new Date(a.data_upload || a.created_date));
  const byCat = categoriasPermitidas.map((c) => ({ cat: c, docs: sorted.filter((d) => (d.tipo || 'Outros') === c) }));

  const onFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm((prev) => ({ ...prev, file_url, nome: prev.nome || file.name }));
    setUploading(false);
  };
  const save = async (e) => {
    e.preventDefault();
    if (!form.file_url) return;
    await base44.entities.Documentos.create({ ...form, funcionario_id, data_upload: new Date().toISOString().slice(0, 10) });
    setForm({ nome: '', tipo: categoriasPermitidas[0], file_url: '', data_validade: '' }); setShow(false); reload();
  };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-[#0b2545]">Documentos</h3>
        <Button size="sm" variant="outline" onClick={() => setShow((s) => !s)}><Plus className="w-4 h-4 mr-1" />Enviar</Button>
      </div>
      {show && (
        <form onSubmit={save} className="grid gap-3 mb-4 md:grid-cols-2">
          <div><Label>Documento</Label><Input className="mt-1" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} placeholder="Ex.: RG / Certificado NR-35" required /></div>
          <div><Label>Categoria</Label>
            <Select value={form.tipo} onValueChange={(v) => setForm({ ...form, tipo: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{categoriasPermitidas.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select>
          </div>
          <div><Label>Validade (opcional)</Label><Input className="mt-1" type="date" value={form.data_validade} onChange={(e) => setForm({ ...form, data_validade: e.target.value })} /></div>
          <div className="md:col-span-2"><Label>Arquivo (PDF / JPG / PNG)</Label>
            <Input className="mt-1" type="file" accept=".pdf,image/jpeg,image/png" onChange={onFile} />
            {uploading && <p className="text-xs text-slate-400 mt-1">Enviando...</p>}
            {form.file_url && !uploading && <p className="text-xs text-emerald-600 mt-1">Arquivo anexado.</p>}
          </div>
          <div className="md:col-span-2 flex justify-end gap-2"><Button type="button" variant="ghost" onClick={() => setShow(false)}>Cancelar</Button><Button type="submit" disabled={!form.file_url || uploading} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button></div>
        </form>
      )}
      {sorted.length === 0 ? <p className="text-sm text-slate-400 py-4">Nenhum documento.</p> : (
        <div className="space-y-4">
          {byCat.filter((g) => g.docs.length).map((g) => (
            <div key={g.cat}>
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">{g.cat}</p>
              <div className="grid sm:grid-cols-2 gap-3">
                {g.docs.map((d) => (
                  <div key={d.id} className="border border-slate-100 rounded-lg p-3 flex items-center gap-3">
                    <FileText className="w-8 h-8 text-[#0b2545] shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-[#0b2545] truncate">{d.nome}</p>
                      <p className="text-xs text-slate-400">{fmt(d.data_upload)}{d.data_validade ? ` · válido até ${fmt(d.data_validade)}` : ''}</p>
                      {d.data_validade && (() => { const faixa = classificarDocumento(d.data_validade); const meta = FAIXA_DOC[faixa.faixa]; return <span className={`mt-1 inline-block text-[10px] font-medium px-1.5 py-0.5 rounded border ${meta.style}`}>{meta.label}</span>; })()}
                    </div>
                    <a href={d.file_url} target="_blank" rel="noreferrer" className="text-[#0b2545] hover:text-[#16365f]"><ExternalLink className="w-4 h-4" /></a>
                    {podeExcluir && <button onClick={async () => { await base44.entities.Documentos.delete(d.id); reload(); }} className="text-slate-300 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}