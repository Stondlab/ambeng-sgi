import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { formatarMoeda, parseMoeda } from '@/lib/moeda';

// Input monetário: exibe "R$ 3.017,81" fora do foco; ao focar mostra o número
// bruto com vírgula decimal para edição. Sempre devolve um number ao onChange.
export default function MoneyInput({ value, onChange, placeholder, className }) {
  const [foco, setFoco] = useState(false);
  const [texto, setTexto] = useState('');
  const vazio = value === '' || value == null || Number.isNaN(Number(value));

  useEffect(() => {
    if (foco) {
      setTexto(vazio ? '' : String(value).replace('.', ','));
    } else {
      setTexto(vazio ? '' : formatarMoeda(Number(value)));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, foco]);

  return (
    <Input
      className={className}
      inputMode="decimal"
      placeholder={placeholder || 'R$ 0,00'}
      value={texto}
      onFocus={() => setFoco(true)}
      onBlur={() => { setFoco(false); onChange?.(parseMoeda(texto)); }}
      onChange={(e) => setTexto(e.target.value)}
    />
  );
}