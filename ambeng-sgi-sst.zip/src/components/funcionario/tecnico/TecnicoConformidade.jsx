import React from 'react';
import RelatedSection from '@/components/funcionario/RelatedSection';
import { ASO_FIELDS, TREIN_FIELDS, EPI_FIELDS, INSP_FIELDS } from '@/lib/funcionarioSafetyFields';

export default function TecnicoConformidade({ funcionarioId, dados, reload, permissoes, beforeSaveEpi }) {
  const secoes = [
    { title: 'Saúde Ocupacional — ASOs', entityName: 'ASOs', fields: ASO_FIELDS, items: dados.asos, addLabel: 'Adicionar ASO', perm: permissoes.asos },
    { title: 'Treinamentos', entityName: 'Treinamentos', fields: TREIN_FIELDS, items: dados.treinamentos, addLabel: 'Adicionar treinamento', perm: permissoes.treinamentos },
    { title: 'EPIs', entityName: 'EPIs', fields: EPI_FIELDS, items: dados.epis, addLabel: 'Nova entrega de EPI', perm: permissoes.epis, beforeSave: beforeSaveEpi },
    { title: 'Avaliações / Inspeções', entityName: 'Inspecoes', fields: INSP_FIELDS, items: dados.inspecoes, addLabel: 'Nova avaliação', perm: permissoes.sst },
  ];
  return <section><h2 className="mb-3 text-lg font-semibold text-foreground">Conformidade e Saúde</h2><div className="space-y-4">{secoes.map((secao) => <RelatedSection key={secao.entityName} {...secao} funcionario_id={funcionarioId} reload={reload} podeCriar={secao.perm.podeCriar} podeExcluir={secao.perm.podeExcluir} />)}</div></section>;
}