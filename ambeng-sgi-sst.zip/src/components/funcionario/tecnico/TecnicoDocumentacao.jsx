import React from 'react';
import DdsSection from '@/components/funcionario/DdsSection';
import DocumentosSection from '@/components/funcionario/DocumentosSection';
import RelatedSection from '@/components/funcionario/RelatedSection';
import { INTEGRACAO_FIELDS, INSP_FIELDS } from '@/lib/funcionarioSafetyFields';

const CATEGORIAS_SEGURANCA = ['Integrações', 'DDS', 'Inspeções'];
export default function TecnicoDocumentacao({ funcionarioId, dados, reload, permissao }) {
  return <section><h2 className="mb-3 text-lg font-semibold text-foreground">Documentação de Segurança</h2><div className="space-y-4"><DdsSection funcionario_id={funcionarioId} items={dados.dds} reload={reload} /><RelatedSection title="Integrações de Segurança" entityName="Integracoes" fields={INTEGRACAO_FIELDS} funcionario_id={funcionarioId} items={dados.integracoes} reload={reload} addLabel="Nova integração" podeCriar={permissao.podeCriar} podeExcluir={permissao.podeExcluir} /><RelatedSection title="Inspeções" entityName="Inspecoes" fields={INSP_FIELDS} funcionario_id={funcionarioId} items={dados.inspecoes} reload={reload} addLabel="Nova inspeção" podeCriar={permissao.podeCriar} podeExcluir={permissao.podeExcluir} /><DocumentosSection funcionario_id={funcionarioId} items={dados.documentos} reload={reload} categoriasPermitidas={CATEGORIAS_SEGURANCA} podeExcluir={permissao.podeExcluir} /></div></section>;
}