import React from 'react';
import { Building2, BriefcaseBusiness, Hash } from 'lucide-react';

export default function TecnicoIdentificacao({ funcionario }) {
  const itens = [{ Icon: Hash, label: 'Matrícula', valor: funcionario.matricula }, { Icon: Building2, label: 'Empresa', valor: funcionario.empresa }, { Icon: Building2, label: 'Obra', valor: funcionario.obra }, { Icon: BriefcaseBusiness, label: 'Cargo / Função', valor: funcionario.funcao }];
  return <section className="rounded-lg border border-border bg-card p-5"><h1 className="text-xl font-semibold text-foreground">{funcionario.nome}</h1><p className="mt-1 text-sm text-muted-foreground">Visão simplificada de Segurança do Trabalho</p><div className="mt-5 grid gap-3 sm:grid-cols-2">{itens.map(({ Icon, label, valor }) => <div key={label} className="flex items-center gap-3 rounded-md bg-muted p-3"><Icon className="h-5 w-5 text-primary" /><div><p className="text-xs text-muted-foreground">{label}</p><p className="font-medium text-foreground">{valor || '—'}</p></div></div>)}</div></section>;
}