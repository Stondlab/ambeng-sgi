import React, { useMemo } from 'react';
import { UserCheck, Stethoscope, GraduationCap, HardHat, ShieldAlert, Ban, CalendarOff, Moon } from 'lucide-react';
import { fmt } from '@/lib/sst';

const TONES = {
  admissao: { icon: UserCheck, cls: 'bg-primary text-primary-foreground' },
  aso: { icon: Stethoscope, cls: 'bg-info text-white' },
  treinamento: { icon: GraduationCap, cls: 'bg-info text-white' },
  epi: { icon: HardHat, cls: 'bg-success text-white' },
  advertencia: { icon: ShieldAlert, cls: 'bg-warning text-white' },
  suspenso: { icon: Ban, cls: 'bg-destructive text-white' },
  afastamento: { icon: CalendarOff, cls: 'bg-amber-400 text-amber-950' },
  ferias: { icon: Moon, cls: 'bg-success text-white' },
};

export default function Timeline360({ events }) {
  const sorted = useMemo(
    () => [...events].filter((e) => e.date).sort((a, b) => new Date(b.date) - new Date(a.date)),
    [events]
  );
  if (!sorted.length) return <p className="text-sm text-slate-400">Sem eventos registrados.</p>;
  return (
    <ol className="relative border-l-2 border-slate-100 ml-2 space-y-3">
      {sorted.map((e, i) => {
        const T = TONES[e.tipo] || TONES.admissao;
        const Icon = T.icon;
        return (
          <li key={i} className="ml-5 relative animate-fade-in">
            <span className={`absolute -left-[30px] top-0.5 w-7 h-7 rounded-full flex items-center justify-center ring-4 ring-white ${T.cls}`}>
              <Icon className="w-3.5 h-3.5" />
            </span>
            <p className="text-sm text-foreground font-medium pt-0.5">{e.label}</p>
            <p className="text-xs text-slate-400">{fmt(e.date)}</p>
          </li>
        );
      })}
    </ol>
  );
}