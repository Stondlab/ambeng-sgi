import React, { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Car, User, Briefcase, MapPin, Shirt, Loader2, AlertTriangle, Check } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getStatus, diasRestantes, fmt } from '@/lib/sst';
import { formatarMoeda } from '@/lib/moeda';
import MoneyInput from '@/components/funcionario/MoneyInput';
import CustoHoraResumo from '@/components/funcionario/CustoHoraResumo';
import { useToast } from '@/components/ui/use-toast';
import { mensagemAmigavelErro, validarCPF, validarDataOpcional, validarEmailOpcional, validarNumeroOpcional, validarTelefoneOpcional } from '@/lib/validacao';

const PESSOAIS = [
  { name: 'nome', label: 'Nome completo' },
  { name: 'cpf', label: 'CPF' },
  { name: 'rg', label: 'RG' },
  { name: 'orgao_emissor', label: 'Órgão emissor' },
  { name: 'data_nascimento', label: 'Nascimento', type: 'date' },
  { name: 'sexo', label: 'Sexo', options: ['Masculino', 'Feminino', 'Outro'] },
  { name: 'estado_civil', label: 'Estado civil', options: ['Solteiro', 'Casado', 'Divorciado', 'Viúvo', 'União estável'] },
  { name: 'tipo_sanguineo', label: 'Tipo sanguíneo', options: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] },
  { name: 'nacionalidade', label: 'Nacionalidade' },
  { name: 'naturalidade', label: 'Naturalidade' },
];
const CONTRATO = [
  { name: 'data_admissao', label: 'Admissão', type: 'date' },
  { name: 'funcao', label: 'Função' },
  { name: 'cbo', label: 'CBO' },
  { name: 'tipo_contratacao', label: 'Tipo de contratação', options: ['CLT', 'PJ', 'Terceirizado', 'Estágio', 'Aprendiz'] },
  { name: 'jornada', label: 'Jornada' },
  { name: 'turno', label: 'Turno', options: ['Manhã', 'Tarde', 'Noite', 'Integral', '12x36'] },
  { name: 'custo_base', label: 'Salário / custo base mensal (R$)', type: 'money' },
  { name: 'valor_hora', label: 'Valor/hora direto (R$) — opcional', type: 'money' },
  { name: 'vt_diario', label: 'VT diário (R$)', type: 'money' },
  { name: 'vr_diario', label: 'VR diário (R$)', type: 'money' },
  { name: 'premiacao_mensal', label: 'Premiação mensal (R$)', type: 'money' },
  { name: 'obra_padrao', label: 'Obra padrão' },
  { name: 'empresa', label: 'Empresa' },
  { name: 'obra', label: 'Obra' },
];
const ENDERECO = [
  { name: 'endereco', label: 'Endereço' },
  { name: 'numero', label: 'Número' },
  { name: 'complemento', label: 'Complemento' },
  { name: 'bairro', label: 'Bairro' },
  { name: 'cep', label: 'CEP' },
  { name: 'cidade', label: 'Cidade' },
  { name: 'estado', label: 'Estado' },
  { name: 'telefone', label: 'Telefone' },
  { name: 'whatsapp', label: 'WhatsApp' },
  { name: 'email', label: 'E-mail' },
  { name: 'email_corporativo', label: 'E-mail corporativo' },
  { name: 'contato_emergencia_nome', label: 'Contato de emergência' },
  { name: 'contato_emergencia_parentesco', label: 'Parentesco' },
  { name: 'contato_emergencia_telefone', label: 'Telefone do contato' },
];
const CNH = [
  { name: 'cnh_numero', label: 'Número da CNH' },
  { name: 'cnh_categoria', label: 'Categoria', options: ['A', 'B', 'C', 'D', 'E', 'AB'] },
  { name: 'cnh_validade', label: 'Validade', type: 'date' },
];
const UNIFORME = [
  { name: 'tamanho_uniforme', label: 'Camisa / uniforme' },
  { name: 'tamanho_calca', label: 'Calça' },
  { name: 'tamanho_jaqueta', label: 'Jaqueta' },
  { name: 'tamanho_calcado', label: 'Calçado (número)' },
  { name: 'tamanho_capacete', label: 'Capacete' },
  { name: 'tamanho_luva', label: 'Luva' },
  { name: 'tamanho_cinto', label: 'Cinto' },
  { name: 'uniforme_observacoes', label: 'Observações', type: 'textarea' },
];

function Field({ f, form, set, readOnly }) {
  const val = form[f.name] ?? '';
  if (f.options) return (
    <div>
      <Label>{f.label}</Label>
      <Select value={val || ''} onValueChange={(v) => set(f.name, v)} disabled={readOnly}>
        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
        <SelectContent>{f.options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
      </Select>
    </div>
  );
  if (f.type === 'textarea') return (
    <div className="sm:col-span-2 lg:col-span-3">
      <Label>{f.label}</Label>
      <Textarea className="mt-1" rows={2} value={val} onChange={(e) => set(f.name, e.target.value)} disabled={readOnly} />
    </div>
  );
  if (f.type === 'money') return (
    <div>
      <Label>{f.label}</Label>
      {readOnly
        ? <Input className="mt-1" disabled value={val !== '' && val != null ? formatarMoeda(Number(val)) : ''} />
        : <MoneyInput className="mt-1" value={val} onChange={(v) => set(f.name, v)} />}
    </div>
  );
  return (
    <div>
      <Label>{f.label}</Label>
      <Input className="mt-1" type={f.type || 'text'} value={f.type === 'date' ? String(val).slice(0, 10) : val} onChange={(e) => set(f.name, e.target.value)} disabled={readOnly} />
    </div>
  );
}

function Grid({ fields, form, set, readOnly }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {fields.map((f) => <Field key={f.name} f={f} form={form} set={set} readOnly={readOnly} />)}
    </div>
  );
}

export default function EditarCadastroModal({ funcionario, podeEditar, onClose, onSaved }) {
  const [form, setForm] = useState({ ...funcionario });
  const [salvando, setSalvando] = useState(false);
  const readOnly = !podeEditar;
  const { toast } = useToast();
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const dirty = useMemo(() => JSON.stringify(form) !== JSON.stringify(funcionario), [form, funcionario]);

  const cnhStatus = useMemo(() => (form.cnh_validade ? getStatus(form.cnh_validade) : null), [form.cnh_validade]);
  const cnhTone = cnhStatus === 'Vencido'
    ? { ring: 'border-rose-200', chip: 'bg-rose-100 text-rose-700', dot: 'bg-rose-500', text: 'text-rose-700' }
    : cnhStatus === 'A vencer'
    ? { ring: 'border-amber-200', chip: 'bg-amber-100 text-amber-700', dot: 'bg-amber-500', text: 'text-amber-700' }
    : cnhStatus === 'Em dia'
    ? { ring: 'border-emerald-200', chip: 'bg-emerald-100 text-emerald-700', dot: 'bg-emerald-500', text: 'text-emerald-700' }
    : null;

  const salvar = async () => {
    if (!validarCPF(form.cpf)) return toast({ title: 'CPF inválido', description: 'Informe um CPF válido.', variant: 'destructive' });
    if (![form.email, form.email_corporativo].every(validarEmailOpcional)) return toast({ title: 'E-mail inválido', description: 'Revise os e-mails informados.', variant: 'destructive' });
    if (![form.telefone, form.whatsapp, form.contato_emergencia_telefone].every(validarTelefoneOpcional)) return toast({ title: 'Telefone inválido', description: 'Use DDD e 10 ou 11 dígitos.', variant: 'destructive' });
    if (![form.data_nascimento, form.data_admissao, form.cnh_validade].every(validarDataOpcional)) return toast({ title: 'Data inválida', description: 'Revise as datas informadas.', variant: 'destructive' });
    if (![form.custo_base, form.valor_hora, form.vt_diario, form.vr_diario, form.premiacao_mensal].every((v) => validarNumeroOpcional(v))) return toast({ title: 'Valor inválido', description: 'Use valores numéricos não negativos.', variant: 'destructive' });
    setSalvando(true);
    try {
      await base44.entities.Funcionarios.update(funcionario.id, form);
      toast({ title: 'Alterações salvas com sucesso!', description: 'O cadastro foi atualizado.', className: 'bg-emerald-50 border-emerald-200 text-emerald-800' });
      onSaved();
    } catch (e) {
      toast({ title: 'Erro ao salvar', description: mensagemAmigavelErro(e), variant: 'destructive' });
    } finally { setSalvando(false); }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editar cadastro — {funcionario.nome}</DialogTitle>
        </DialogHeader>

        {readOnly && (
          <div className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
            Seu perfil permite apenas visualização do cadastro.
          </div>
        )}

        {dirty && !readOnly && (
          <div className="sticky top-0 z-20 -mx-6 -mt-2 mb-2 bg-amber-100 border-b border-amber-300 px-6 py-2.5 flex items-center gap-2 shadow-sm">
            <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
            <span className="text-sm font-medium text-amber-900">Você tem alterações não salvas</span>
          </div>
        )}

        <Tabs defaultValue="pessoais" className="w-full">
          <TabsList className="grid w-full grid-cols-5 h-auto">
            <TabsTrigger value="pessoais" className="text-xs"><User className="w-3.5 h-3.5 mr-1" />Pessoais</TabsTrigger>
            <TabsTrigger value="contrato" className="text-xs"><Briefcase className="w-3.5 h-3.5 mr-1" />Contrato</TabsTrigger>
            <TabsTrigger value="endereco" className="text-xs"><MapPin className="w-3.5 h-3.5 mr-1" />Contato</TabsTrigger>
            <TabsTrigger value="cnh" className="text-xs"><Car className="w-3.5 h-3.5 mr-1" />CNH</TabsTrigger>
            <TabsTrigger value="uniforme" className="text-xs"><Shirt className="w-3.5 h-3.5 mr-1" />Uniforme</TabsTrigger>
          </TabsList>

          <TabsContent value="pessoais" className="mt-4"><Grid fields={PESSOAIS} form={form} set={set} readOnly={readOnly} /></TabsContent>
          <TabsContent value="contrato" className="mt-4"><Grid fields={CONTRATO} form={form} set={set} readOnly={readOnly} /><CustoHoraResumo funcionario={form} /></TabsContent>
          <TabsContent value="endereco" className="mt-4"><Grid fields={ENDERECO} form={form} set={set} readOnly={readOnly} /></TabsContent>

          <TabsContent value="cnh" className="mt-4">
            {cnhTone && (
              <div className={`flex items-center gap-3 p-3 rounded-xl border ${cnhTone.ring} mb-4`}>
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${cnhTone.chip} shrink-0`}><Car className="w-5 h-5" /></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">CNH {cnhStatus}</p>
                  <p className={`text-xs ${cnhTone.text}`}>
                    {cnhStatus === 'Vencido' ? 'Vencida — renovação urgente necessária'
                      : cnhStatus === 'A vencer' ? `Vence em ${diasRestantes(form.cnh_validade)} dias`
                      : `Em dia — valida até ${fmt(form.cnh_validade)}`}
                  </p>
                </div>
                <span className={`w-3 h-3 rounded-full ${cnhTone.dot} shrink-0`} />
              </div>
            )}
            <Grid fields={CNH} form={form} set={set} readOnly={readOnly} />
          </TabsContent>

          <TabsContent value="uniforme" className="mt-4"><Grid fields={UNIFORME} form={form} set={set} readOnly={readOnly} /></TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="secondary" onClick={onClose} className="text-slate-600">Cancelar</Button>
          <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" disabled={readOnly || salvando || !dirty} onClick={salvar}>
            {salvando ? (<><Loader2 className="w-4 h-4 mr-1.5 animate-spin" />Salvando...</>) : (<><Check className="w-4 h-4 mr-1.5" />Salvar Alterações</>)}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}