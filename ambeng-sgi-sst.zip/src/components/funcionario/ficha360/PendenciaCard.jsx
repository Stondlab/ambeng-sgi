import React from 'react';
import { Stethoscope, GraduationCap, HardHat, FileCheck2 } from 'lucide-react';

const ICONS = { aso: Stethoscope, treinamento: GraduationCap, epi: HardHat, documento: FileCheck2 };
const TONE = {
  verde: { ring: 'border-emerald-200', chip: 'bg-emerald-100 text-emerald-700', dot: 'bg-emerald-500', text: 'text-emerald-700' },
  amarelo: { ring: 'border-amber-200', chip: 'bg-amber-100 text-amber-700', dot: 'bg-amber-500', text: 'text-amber-700' },
  vermelho: { ring: 'border-rose-200', chip: 'bg-rose-100 text-rose-700', dot: 'bg-rose-500', text: 'text-rose-700' },
};

export default function PendenciaCard({ tipo, titulo, status }) {
  const Icon = ICONS[tipo];
  const t = TONE[status.nivel];
  const c = status.counts;
  return (
    <div className={`bg-white border rounded-xl p-4 ${t.ring}`}>
      <div className="flex items-center gap-3 mb-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${t.chip}`}><Icon className="w-5 h-5" /></div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-sm text-foreground truncate">{titulo}</h3>
          <p className={`text-xs font-medium ${t.text}`}>{status.motivo}</p>
        </div>
        <span className={`w-3 h-3 rounded-full ${t.dot} shrink-0`} />
      </div>
      <div className="flex flex-wrap gap-1.5 text-[11px]">
        {c.emdia > 0 && <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">{c.emdia} em dia</span>}
        {c.vencendo > 0 && <span className="px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200">{c.vencendo} vencendo</span>}
        {c.vencidos > 0 && <span className="px-2 py-0.5 rounded-full bg-rose-50 text-rose-700 border border-rose-200">{c.vencidos} vencido(s)</span>}
        {c.faltantes > 0 && <span className="px-2 py-0.5 rounded-full bg-rose-50 text-rose-700 border border-rose-200">{c.faltantes} faltante(s)</span>}
      </div>
      {status.criticos.length > 0 && (
        <ul className="mt-3 space-y-1">
          {status.criticos.slice(0, 5).map((it, i) => (
            <li key={i} className="text-xs text-slate-500 flex items-center gap-1.5">
              <span className={`w-1.5 h-1.5 rounded-full ${TONE[it.tone].dot} shrink-0`} />
              <span className="truncate">{it.label}</span>
              <span className="text-slate-400 ml-auto whitespace-nowrap">{it.detail}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}