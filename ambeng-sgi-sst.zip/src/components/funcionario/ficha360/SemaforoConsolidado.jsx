import React from 'react';
import { ShieldCheck, AlertTriangle, ShieldAlert } from 'lucide-react';

const CONF = {
  verde: { bg: 'bg-emerald-50', border: 'border-emerald-200', icon: ShieldCheck, iconCls: 'text-emerald-600', title: 'Tudo em dia', desc: 'Nenhuma pendência. Colaborador regular para trabalho.', badge: 'bg-emerald-500' },
  amarelo: { bg: 'bg-amber-50', border: 'border-amber-200', icon: AlertTriangle, iconCls: 'text-amber-600', title: 'Atenção — pendências próximas', desc: 'Há itens vencendo em até 30 dias. Regularize antes do vencimento.', badge: 'bg-amber-500' },
  vermelho: { bg: 'bg-rose-50', border: 'border-rose-200', icon: ShieldAlert, iconCls: 'text-rose-600', title: 'Crítico — pendências vencidas ou faltantes', desc: 'Existem itens vencidos ou faltantes. Avaliar bloqueio até regularização.', badge: 'bg-rose-500' },
};

export default function SemaforoConsolidado({ nivel }) {
  const c = CONF[nivel] || CONF.verde;
  const Icon = c.icon;
  return (
    <div className={`rounded-2xl border-2 p-5 flex items-center gap-4 ${c.bg} ${c.border}`}>
      <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 bg-white border ${c.border}`}>
        <Icon className={`w-8 h-8 ${c.iconCls}`} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className={`w-3 h-3 rounded-full ${c.badge}`} />
          <h2 className="font-heading font-bold text-lg text-foreground">{c.title}</h2>
        </div>
        <p className="text-sm text-slate-600">{c.desc}</p>
      </div>
    </div>
  );
}