import React from 'react';
import { getStatus, fmt } from '@/lib/sst';
import { CheckCircle2 } from 'lucide-react';

const DOT = { red: 'bg-red-500', amber: 'bg-amber-500', green: 'bg-emerald-500' };
const TXT = { red: 'text-red-700', amber: 'text-amber-700', green: 'text-emerald-700' };

export default function AlertasPanel({ funcionario, asos, treinamentos, epis, integracoes, documentos }) {
  const alerts = [];
  const push = (label, tone, detail) => alerts.push({ label, tone, detail });

  asos.forEach((a) => {
    const s = getStatus(a.data_validade);
    if (s !== 'Em dia') push(`ASO ${a.tipo || ''}`, s === 'Vencido' ? 'red' : 'amber', `validade ${fmt(a.data_validade)}`);
  });
  treinamentos.forEach((t) => {
    const s = getStatus(t.data_validade);
    if (s !== 'Em dia') push(`Treinamento ${t.norma_curso || ''}`, s === 'Vencido' ? 'red' : 'amber', `validade ${fmt(t.data_validade)}`);
  });
  epis.forEach((e) => {
    const s = getStatus(e.data_validade);
    if (s !== 'Em dia') push(`EPI ${e.item || ''} (CA ${e.certificado_aprovacao || '—'})`, s === 'Vencido' ? 'red' : 'amber', `validade ${fmt(e.data_validade)}`);
  });
  if (funcionario.cnh_validade) {
    const s = getStatus(funcionario.cnh_validade);
    if (s !== 'Em dia') push('CNH', s === 'Vencido' ? 'red' : 'amber', `validade ${fmt(funcionario.cnh_validade)}`);
  }
  if (integracoes.length === 0) push('Integração não realizada', 'amber', 'Sem registro de integração');
  if (documentos.length === 0) push('Documento pendente', 'amber', 'Nenhum documento enviado');

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-3">Pendências e alertas</h3>
      {alerts.length === 0 ? (
        <div className="flex items-center gap-2 text-emerald-700"><CheckCircle2 className="w-5 h-5" /><span className="text-sm">Tudo em dia — nenhuma pendência.</span></div>
      ) : (
        <ul className="space-y-2">
          {alerts.map((a, i) => (
            <li key={i} className="flex items-center gap-3 text-sm">
              <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${DOT[a.tone]}`} />
              <span className={`font-medium ${TXT[a.tone]}`}>{a.label}</span>
              <span className="text-slate-400 ml-auto text-xs">{a.detail}</span>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}