import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Image } from '@/components/ui/image';
import { Pencil, User, Check, Loader2, ChevronDown, Trash2, AlertTriangle } from 'lucide-react';
import { differenceInYears, parseISO } from 'date-fns';
import { fmt } from '@/lib/sst';
import MoneyInput from '@/components/funcionario/MoneyInput';
import { formatarMoeda } from '@/lib/moeda';

const GROUPS = [
  { title: 'Dados pessoais', fields: [
    { name: 'nome', label: 'Nome completo' },
    { name: 'cpf', label: 'CPF' },
    { name: 'rg', label: 'RG' },
    { name: 'orgao_emissor', label: 'Órgão emissor' },
    { name: 'pis', label: 'PIS' },
    { name: 'ctps', label: 'CTPS' },
    { name: 'data_nascimento', label: 'Nascimento', type: 'date' },
    { name: 'sexo', label: 'Sexo', options: ['Masculino', 'Feminino', 'Outro'] },
    { name: 'estado_civil', label: 'Estado civil', options: ['Solteiro', 'Casado', 'Divorciado', 'Viúvo', 'União estável'] },
    { name: 'escolaridade', label: 'Escolaridade', options: ['Fundamental incompleto', 'Fundamental completo', 'Médio incompleto', 'Médio completo', 'Técnico', 'Superior incompleto', 'Superior completo'] },
    { name: 'tipo_sanguineo', label: 'Tipo sanguíneo', options: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] },
    { name: 'nacionalidade', label: 'Nacionalidade' },
    { name: 'naturalidade', label: 'Naturalidade' },
  ]},
  { title: 'Contatos', fields: [
    { name: 'telefone', label: 'Telefone principal' },
    { name: 'whatsapp', label: 'WhatsApp' },
    { name: 'email', label: 'E-mail' },
    { name: 'email_corporativo', label: 'E-mail corporativo' },
    { name: 'endereco', label: 'Endereço' },
    { name: 'numero', label: 'Número' },
    { name: 'complemento', label: 'Complemento' },
    { name: 'bairro', label: 'Bairro' },
    { name: 'cep', label: 'CEP' },
    { name: 'cidade', label: 'Cidade' },
    { name: 'estado', label: 'Estado' },
  ]},
  { title: 'Emergência', fields: [
    { name: 'contato_emergencia_nome', label: 'Nome do contato' },
    { name: 'contato_emergencia_parentesco', label: 'Grau de parentesco' },
    { name: 'contato_emergencia_telefone', label: 'Telefone' },
    { name: 'contato_emergencia_telefone_alt', label: 'Telefone alternativo' },
    { name: 'contato_emergencia_observacoes', label: 'Observações', type: 'textarea' },
  ]},
  { title: 'Dados profissionais', fields: [
    { name: 'empresa', label: 'Empresa' },
    { name: 'obra', label: 'Obra' },
    { name: 'matricula', label: 'Matrícula' },
    { name: 'funcao', label: 'Cargo / Função' },
    { name: 'cbo', label: 'CBO' },
    { name: 'tipo_contratacao', label: 'Tipo de contratação', options: ['CLT', 'PJ', 'Terceirizado', 'Estágio', 'Aprendiz'] },
    { name: 'jornada', label: 'Jornada' },
    { name: 'turno', label: 'Turno', options: ['Manhã', 'Tarde', 'Noite', 'Integral', '12x36'] },
    { name: 'data_admissao', label: 'Admissão', type: 'date' },
    { name: 'data_desligamento', label: 'Desligamento', type: 'date' },
    { name: 'motivo_desligamento', label: 'Motivo do desligamento' },
    { name: 'status', label: 'Status', options: ['Ativo', 'Afastado', 'Demitido'] },
  ]},
  { title: 'Uniforme e Medidas', fields: [
    { name: 'tamanho_uniforme', label: 'Camisa / uniforme' },
    { name: 'tamanho_calca', label: 'Calça' },
    { name: 'tamanho_jaqueta', label: 'Jaqueta' },
    { name: 'tamanho_calcado', label: 'Calçado (número)' },
    { name: 'tamanho_capacete', label: 'Capacete' },
    { name: 'tamanho_luva', label: 'Luva' },
    { name: 'tamanho_cinto', label: 'Cinto' },
    { name: 'uniforme_observacoes', label: 'Observações', type: 'textarea' },
  ]},
  { title: 'Custos de mão de obra', fields: [
    { name: 'custo_base', label: 'Salário base mensal (R$)', type: 'money' },
    { name: 'vt_diario', label: 'VT diário (R$)', type: 'money' },
    { name: 'vr_diario', label: 'VR diário (R$)', type: 'money' },
    { name: 'premiacao_mensal', label: 'Premiação mensal (R$)', type: 'money' },
    { name: 'obra_padrao', label: 'Obra padrão (opcional)' },
  ]},
  { title: 'CNH', fields: [
    { name: 'cnh_numero', label: 'Número da CNH' },
    { name: 'cnh_categoria', label: 'Categoria', options: ['A', 'B', 'C', 'D', 'E', 'AB'] },
    { name: 'cnh_validade', label: 'Validade', type: 'date' },
  ]},
];

const STATUS = { 'Ativo': 'bg-emerald-100 text-emerald-700', 'Afastado': 'bg-amber-100 text-amber-800', 'Demitido': 'bg-slate-200 text-slate-600' };

function idade(n) { try { return n ? `${differenceInYears(new Date(), parseISO(n))} anos` : '—'; } catch { return '—'; } }

function GrupoRecolhivel({ titulo, children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border border-slate-100 rounded-lg overflow-hidden">
      <button type="button" onClick={() => setOpen((o) => !o)} className="w-full flex items-center justify-between px-3 py-2 hover:bg-slate-50 transition">
        <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">{titulo}</span>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && <div className="px-3 pb-3">{children}</div>}
    </div>
  );
}

export default function DadosPessoais({ funcionario, onSaved, startEditing, podeEditar = true }) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({});
  const [uploadingFoto, setUploadingFoto] = useState(false);
  const [saveState, setSaveState] = useState('idle'); // idle | saving | saved
  const lastSavedRef = useRef(funcionario);

  const start = () => { setForm(funcionario); lastSavedRef.current = funcionario; setEditing(true); };

  // Permite que o botão EDITAR do cabeçalho abra o formulário.
  useEffect(() => { if (startEditing && podeEditar) start(); /* eslint-disable-next-line */ }, [startEditing, podeEditar]);

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  const onFoto = async (file) => {
    if (!file) return;
    setUploadingFoto(true);
    try { const { file_url } = await base44.integrations.Core.UploadFile({ file }); set('foto_url', file_url); }
    catch {}
    setUploadingFoto(false);
  };
  const removeFoto = () => set('foto_url', '');

  const dirty = editing && Object.keys(form).some((k) => form[k] !== (lastSavedRef.current[k] ?? ''));

  // Auto-save debounced
  useEffect(() => {
    if (!editing) return;
    const changed = Object.keys(form).some((k) => form[k] !== lastSavedRef.current[k]);
    if (!changed) return;
    setSaveState('saving');
    const t = setTimeout(async () => {
      try { await base44.entities.Funcionarios.update(funcionario.id, form); lastSavedRef.current = form; setSaveState('saved'); setTimeout(() => setSaveState('idle'), 2000); }
      catch { setSaveState('idle'); }
    }, 800);
    return () => clearTimeout(t);
  }, [form, editing]);

  // Aviso antes de sair com alterações não salvas
  useEffect(() => {
    if (!editing) return;
    const handler = (e) => { if (saveState === 'saving') { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [editing, saveState]);

  // Função (não componente) para evitar remontagem dos inputs a cada digitação,
  // que era a causa do campo "Admissão" não aceitar preenchimento corretamente.
  const renderField = (f) => {
    if (f.options) return (
      <Select value={form[f.name] || ''} onValueChange={(v) => set(f.name, v)}>
        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
        <SelectContent>{f.options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
      </Select>
    );
    if (f.type === 'textarea') return <Textarea className="mt-1" rows={2} value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />;
    if (f.type === 'money') return <MoneyInput className="mt-1" value={form[f.name] ?? ''} onChange={(v) => set(f.name, v)} />;
    if (f.type === 'date') return <Input className="mt-1" type="date" value={(form[f.name] || '').slice(0, 10)} onChange={(e) => set(f.name, e.target.value)} />;
    return <Input className="mt-1" type={f.type || 'text'} value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />;
  };

  if (editing) {
    return (
      <section className="bg-white border border-slate-200 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <h3 className="font-semibold text-[#0b2545]">Editar dados do funcionário</h3>
          <div className="flex items-center gap-3">
            {saveState === 'saving' && <span className="inline-flex items-center gap-1 text-xs text-amber-600"><Loader2 className="w-3.5 h-3.5 animate-spin" />Salvando...</span>}
            {saveState === 'saved' && <span className="inline-flex items-center gap-1 text-xs text-emerald-600"><Check className="w-3.5 h-3.5" />Alterações salvas</span>}
            {dirty && saveState !== 'saving' && <span className="inline-flex items-center gap-1 text-xs text-amber-600"><AlertTriangle className="w-3.5 h-3.5" />Existem alterações não salvas</span>}
            <Button size="sm" variant="ghost" onClick={() => { setEditing(false); onSaved?.(); }}><Check className="w-4 h-4 mr-1" />Concluir edição</Button>
          </div>
        </div>
        <div className="mb-5 flex items-center gap-4">
          <div className="w-20 h-20 rounded-full bg-slate-100 overflow-hidden flex items-center justify-center shrink-0">
            {form.foto_url ? <Image src={form.foto_url} fittingType="fill" className="w-full h-full" /> : <User className="w-8 h-8 text-slate-400" />}
          </div>
          <div>
            <Label>Foto</Label>
            <div className="flex items-center gap-2 mt-1">
              <Input className="max-w-xs" type="file" accept="image/*" onChange={(e) => onFoto(e.target.files?.[0])} />
              {form.foto_url && <Button size="sm" variant="outline" onClick={removeFoto}><Trash2 className="w-3.5 h-3.5 mr-1" />Remover</Button>}
            </div>
            {uploadingFoto && <p className="text-xs text-slate-400 mt-1">Enviando...</p>}
          </div>
        </div>
        <div className="space-y-2">
          {GROUPS.map((g) => (
            <GrupoRecolhivel key={g.title} titulo={g.title} defaultOpen={g.title === 'Dados pessoais'}>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 pt-2">
                {g.fields.map((f) => (
                  <div key={f.name}>
                    <Label>{f.label}</Label>
                    {renderField(f)}
                  </div>
                ))}
              </div>
            </GrupoRecolhivel>
          ))}
        </div>
      </section>
    );
  }

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-slate-100 overflow-hidden flex items-center justify-center shrink-0">
            {funcionario.foto_url ? <Image src={funcionario.foto_url} fittingType="fill" className="w-full h-full" /> : <User className="w-7 h-7 text-slate-400" />}
          </div>
          <div>
            <h3 className="font-semibold text-[#0b2545]">{funcionario.nome}</h3>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-sm text-slate-500">{funcionario.funcao || '—'}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS[funcionario.status] || STATUS['Ativo']}`}>{funcionario.status || 'Ativo'}</span>
            </div>
          </div>
        </div>
        {podeEditar && <Button size="sm" variant="outline" onClick={start}><Pencil className="w-4 h-4 mr-1" />Editar</Button>}
      </div>
      <div className="space-y-2">
        {GROUPS.map((g) => (
          <GrupoRecolhivel key={g.title} titulo={g.title} defaultOpen={g.title === 'Dados pessoais'}>
            <dl className="grid gap-x-6 gap-y-3 sm:grid-cols-2 lg:grid-cols-3 text-sm pt-2">
              {g.fields.map((f) => (
                <div key={f.name}>
                  <dt className="text-xs text-slate-400">{f.label}{f.name === 'data_nascimento' ? ` · ${idade(funcionario.data_nascimento)}` : ''}</dt>
                  <dd className="text-slate-700">{f.type === 'date' ? fmt(funcionario[f.name]) : f.type === 'money' ? (funcionario[f.name] != null && funcionario[f.name] !== '' ? formatarMoeda(funcionario[f.name]) : '—') : (funcionario[f.name] || '—')}</dd>
                </div>
              ))}
            </dl>
          </GrupoRecolhivel>
        ))}
      </div>
    </section>
  );
}