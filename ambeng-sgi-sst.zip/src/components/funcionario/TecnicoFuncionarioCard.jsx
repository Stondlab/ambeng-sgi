import React from 'react';
import { Link } from 'react-router-dom';
import { Building2, GraduationCap, HardHat, HeartPulse, User } from 'lucide-react';
import { Image } from '@/components/ui/image';

export default function TecnicoFuncionarioCard({ funcionario, dados }) {
  const indicadores = [{ Icon: HeartPulse, valor: dados.asos.length, label: 'ASOs' }, { Icon: GraduationCap, valor: dados.treinamentos.length, label: 'Treinamentos' }, { Icon: HardHat, valor: dados.epis.length, label: 'EPIs' }];
  return <Link to={`/prontuario/${funcionario.id}`} className="block rounded-lg border border-border bg-card p-4 transition hover:border-primary/30 hover:shadow-card-hover">
    <div className="flex items-start gap-3"><div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full bg-primary text-primary-foreground">{funcionario.foto_url ? <Image src={funcionario.foto_url} fittingType="fill" className="h-full w-full" /> : <User className="h-6 w-6" />}</div><div className="min-w-0"><p className="truncate font-semibold text-foreground">{funcionario.nome}</p><p className="text-sm text-muted-foreground">{funcionario.funcao || 'Função não informada'}</p><p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground"><Building2 className="h-3.5 w-3.5" />{funcionario.obra || 'Sem obra'} · {funcionario.empresa || 'Sem empresa'}</p><p className="mt-1 text-xs text-muted-foreground">Matrícula: {funcionario.matricula || '—'}</p></div></div>
    <div className="mt-3 grid grid-cols-3 gap-2 border-t border-border pt-3">{indicadores.map(({ Icon, valor, label }) => <div key={label} className="text-center"><Icon className="mx-auto h-4 w-4 text-primary" /><p className="mt-1 text-sm font-semibold text-foreground">{valor}</p><p className="text-[10px] text-muted-foreground">{label}</p></div>)}</div>
  </Link>;
}