import React from 'react';
import { Plus, UserRound } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PessoasEmptyState({ canCreate, onCreate }) {
  return <section className="flex flex-col items-center justify-center rounded-lg border border-border bg-card px-6 py-12 text-center shadow-card"><span className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary"><UserRound className="h-8 w-8" /></span><h3 className="text-xl font-semibold text-foreground">Nenhum colaborador ainda</h3><p className="mt-2 text-sm text-muted-foreground">Crie o primeiro colaborador para começar.</p>{canCreate && <Button onClick={onCreate} className="mt-6"><Plus className="h-4 w-4" />Novo Colaborador</Button>}</section>;
}