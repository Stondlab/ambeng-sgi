import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Trash2 } from 'lucide-react';
import { fmt } from '@/lib/sst';

export default function DdsSection({ funcionario_id, items, reload }) {
  const [show, setShow] = useState(false);
  const [form, setForm] = useState({ data: '', tema: '', responsavel: '' });

  const sorted = [...items].sort((a, b) => new Date(b.data) - new Date(a.data));

  const save = async (e) => {
    e.preventDefault();
    await base44.entities.DDS.create({ ...form, funcionario_id });
    setForm({ data: '', tema: '', responsavel: '' }); setShow(false); reload();
  };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-[#0b2545]">DDS</h3>
        <Button size="sm" variant="outline" onClick={() => setShow((s) => !s)}><Plus className="w-4 h-4 mr-1" />Registrar DDS</Button>
      </div>
      <div className="flex gap-8 mb-4 text-sm">
        <div><span className="text-xs text-slate-400 block">Quantidade realizada</span><span className="text-[#0b2545] font-semibold text-lg">{sorted.length}</span></div>
        <div><span className="text-xs text-slate-400 block">Última participação</span><span className="text-[#0b2545] font-semibold text-lg">{fmt(sorted[0]?.data)}</span></div>
      </div>
      {show && (
        <form onSubmit={save} className="grid gap-3 mb-4 sm:grid-cols-3">
          <div><Label>Data</Label><Input className="mt-1" type="date" value={form.data} onChange={(e) => setForm({ ...form, data: e.target.value })} required /></div>
          <div><Label>Tema</Label><Input className="mt-1" value={form.tema} onChange={(e) => setForm({ ...form, tema: e.target.value })} /></div>
          <div><Label>Responsável</Label><Input className="mt-1" value={form.responsavel} onChange={(e) => setForm({ ...form, responsavel: e.target.value })} /></div>
          <div className="sm:col-span-3 flex justify-end gap-2"><Button type="button" variant="ghost" onClick={() => setShow(false)}>Cancelar</Button><Button type="submit" className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button></div>
        </form>
      )}
      {sorted.length === 0 ? <p className="text-sm text-slate-400 py-2">Nenhum DDS registrado.</p> : (
        <div className="divide-y divide-slate-100">
          {sorted.map((d) => (
            <div key={d.id} className="py-2 flex items-center gap-3 text-sm">
              <span className="text-slate-700 font-medium w-24">{fmt(d.data)}</span>
              <span className="text-slate-500">{d.tema}</span>
              <span className="text-slate-400 ml-auto">{d.responsavel}</span>
              <button onClick={async () => { await base44.entities.DDS.delete(d.id); reload(); }} className="text-slate-300 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}