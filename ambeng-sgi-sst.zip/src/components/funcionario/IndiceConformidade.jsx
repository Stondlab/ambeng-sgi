import React, { useMemo } from 'react';
import { conformidade } from '@/lib/relatorios';

const tone = (p) => (p == null
  ? { bar: 'bg-slate-300', text: 'text-slate-500' }
  : p >= 90 ? { bar: 'bg-emerald-500', text: 'text-emerald-700' }
  : p >= 70 ? { bar: 'bg-amber-500', text: 'text-amber-700' }
  : { bar: 'bg-red-500', text: 'text-red-700' });

export default function IndiceConformidade({ data }) {
  const { areas, indice, totConf, totPend, totVenc, semRegistro } = useMemo(() => conformidade(data), [data]);
  const gt = tone(indice);
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <h3 className="font-semibold text-[#0b2545]">Índice de Conformidade</h3>
        <div className="ml-auto flex items-center gap-4">
          <div className="flex gap-2 text-[11px] text-slate-500">
            <span className="text-emerald-600">{totConf} conf.</span>
            <span className="text-amber-600">{totPend} pend.</span>
            <span className="text-red-600">{totVenc} venc.</span>
            <span className="text-slate-400">{semRegistro} s/reg.</span>
          </div>
          <span className={`text-2xl font-bold ${gt.text}`}>{indice == null ? '—' : `${indice}%`}</span>
        </div>
      </div>
      <div className="space-y-2.5">
        {areas.map((a) => {
          const t = tone(a.analisavel ? a.pct : null);
          return (
            <div key={a.area} className="flex items-center gap-3">
              <span className="text-xs text-slate-500 w-36 shrink-0">{a.area}</span>
              <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                <div className={`h-full rounded-full ${t.bar}`} style={{ width: `${a.pct}%` }} />
              </div>
              <span className={`text-xs font-medium w-16 text-right ${t.text}`}>{a.analisavel ? `${a.pct}%` : 'S/ reg.'}</span>
              <span className="text-[10px] text-slate-400 w-20 text-right">{a.conforme}/{a.total || 0}</span>
            </div>
          );
        })}
      </div>
      <p className="text-[11px] text-slate-400 mt-3">Itens sem registro não são contados como não conformes. Índice = conformes ÷ (conformes + pendentes + vencidos).</p>
    </section>
  );
}