import React from 'react';
import { statusASO, statusTreinamento, statusEPI, statusDocumentos, semaforoConsolidado } from '@/lib/ficha360';
import SemaforoConsolidado from '@/components/funcionario/ficha360/SemaforoConsolidado';
import PendenciaCard from '@/components/funcionario/ficha360/PendenciaCard';
import Timeline360 from '@/components/funcionario/ficha360/Timeline360';
import LiberacaoPanel from '@/components/liberacao/LiberacaoPanel';
import useResumo360Data from '@/hooks/useResumo360Data';

export default function Resumo360Section({ func, fd, demandas, podeVerRH, onUpdated }) {
  const { documentos, events } = useResumo360Data(func, fd, podeVerRH);
  const aso = statusASO(fd.asos || []);
  const treinamento = statusTreinamento(fd.treinamentos || []);
  const epi = statusEPI(fd.epis || []);
  const documento = statusDocumentos(documentos);
  const nivel = semaforoConsolidado([aso, treinamento, epi, documento]);

  return (
    <div className="space-y-4">
      <SemaforoConsolidado nivel={nivel} />
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
        <PendenciaCard tipo="aso" titulo="ASOs" status={aso} />
        <PendenciaCard tipo="treinamento" titulo="Treinamentos" status={treinamento} />
        <PendenciaCard tipo="epi" titulo="EPIs" status={epi} />
        <PendenciaCard tipo="documento" titulo="Documentação" status={documento} />
      </div>
      <LiberacaoPanel func={func} ctx={{ asos: fd.asos, treinamentos: fd.treinamentos, epis: fd.epis, integracoes: fd.integracoes, documentos: fd.documentos }} demandas={demandas} onUpdated={onUpdated} />
      <section className="rounded-xl border border-slate-200 bg-white p-4">
        <h3 className="font-semibold text-primary">Timeline resumida</h3>
        <p className="mb-3 text-xs text-slate-400">Principais eventos do colaborador em ordem cronológica.</p>
        <Timeline360 events={events} />
      </section>
    </div>
  );
}