import React, { useMemo } from 'react';
import { indiceColaborador } from '@/lib/relatorios';
import { FileText, Heart, GraduationCap, HardHat, Megaphone, UserCheck, AlertTriangle } from 'lucide-react';

const ICON = { 'ASOs': Heart, 'Treinamentos': GraduationCap, 'EPIs': HardHat, 'Integração': UserCheck, 'DDS': Megaphone, 'Documentação': FileText, 'Ocorrências': AlertTriangle };
const color = (p) => (p == null ? '#94a3b8' : p >= 90 ? '#059669' : p >= 70 ? '#d97706' : '#dc2626');

export default function IndiceConformidadeDonut({ data }) {
  const { cats, indice, totConf, totPend, totVenc, semRegistro } = useMemo(() => indiceColaborador(data), [data]);
  const geralColor = color(indice);
  const R = 54, sw = 12, C = 2 * Math.PI * R, dash = ((indice ?? 0) / 100) * C;

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-4">Índice de Conformidade</h3>
      <div className="flex flex-col sm:flex-row items-center gap-6">
        <div className="relative shrink-0">
          <svg width="140" height="140" viewBox="0 0 140 140">
            <circle cx="70" cy="70" r={R} fill="none" stroke="#e2e8f0" strokeWidth={sw} />
            <circle cx="70" cy="70" r={R} fill="none" stroke={geralColor} strokeWidth={sw} strokeDasharray={`${dash} ${C}`} strokeLinecap="round" transform="rotate(-90 70 70)" />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-2xl font-bold" style={{ color: geralColor }}>{indice == null ? '—' : `${indice}%`}</span>
            <span className="text-[10px] text-slate-400">{indice == null ? 'Sem registro' : 'Geral'}</span>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-x-4 gap-y-2 flex-1">
          {cats.map((c) => {
            const Icon = ICON[c.label] || FileText;
            const col = color(c.analisavel ? c.p : null);
            return (
              <div key={c.label} className="flex items-center gap-2">
                <span className="w-7 h-7 rounded-full flex items-center justify-center shrink-0" style={{ background: col + '22' }}><Icon className="w-4 h-4" style={{ color: col }} /></span>
                <div className="min-w-0">
                  <p className="text-[11px] text-slate-500 leading-none truncate">{c.label}</p>
                  <p className="text-xs font-semibold leading-none mt-0.5" style={{ color: col }}>{c.analisavel ? `${c.p}%` : 'Sem registro'}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
        <div className="rounded-lg bg-emerald-50 p-2"><p className="text-lg font-bold text-emerald-700">{totConf}</p><p className="text-[10px] text-slate-500">Conformes</p></div>
        <div className="rounded-lg bg-amber-50 p-2"><p className="text-lg font-bold text-amber-700">{totPend}</p><p className="text-[10px] text-slate-500">Pendentes</p></div>
        <div className="rounded-lg bg-red-50 p-2"><p className="text-lg font-bold text-red-700">{totVenc}</p><p className="text-[10px] text-slate-500">Vencidos</p></div>
        <div className="rounded-lg bg-slate-100 p-2"><p className="text-lg font-bold text-slate-500">{semRegistro}</p><p className="text-[10px] text-slate-500">Sem registro</p></div>
      </div>
    </section>
  );
}