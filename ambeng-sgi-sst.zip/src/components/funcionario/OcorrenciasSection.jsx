import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, ExternalLink, Pencil } from 'lucide-react';
import { fmt } from '@/lib/sst';
import { registrarAcao } from '@/lib/historico';

const TIPOS = ['Quase Acidente', 'Acidente', 'Não Conformidade', 'Observação de Segurança'];
const GRAV = { 'Baixa': 'bg-emerald-100 text-emerald-700', 'Média': 'bg-amber-100 text-amber-800', 'Alta': 'bg-red-100 text-red-700' };
const SIT = { 'Aberta': 'bg-slate-100 text-slate-600', 'Em investigação': 'bg-amber-100 text-amber-800', 'Ação corretiva': 'bg-blue-100 text-blue-700', 'Encerrada': 'bg-emerald-100 text-emerald-700' };

export default function OcorrenciasSection({ funcionario_id, items, reload }) {
  const [show, setShow] = useState(false);
  const [selected, setSelected] = useState(null);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ data: '', tipo: '', gravidade: '', descricao: '' });
  const [editForm, setEditForm] = useState({});
  const [uploading, setUploading] = useState(false);
  const [eventos, setEventos] = useState([]);

  useEffect(() => {
    if (!selected) return;
    base44.entities.HistoricoAcoes.list('-data_hora', 100).then((all) => setEventos(all.filter((h) => h.modulo === 'Ocorrência' && h.registro === selected.id))).catch(() => setEventos([]));
  }, [selected]);

  const sorted = [...items].sort((a, b) => new Date(b.data) - new Date(a.data));

  const save = async (e) => {
    e.preventDefault();
    const created = await base44.entities.Ocorrencias.create({ ...form, funcionario_id, situacao: 'Aberta' });
    registrarAcao('Ocorrência registrada', form.tipo || '', null, 'Ocorrência', created?.id || '');
    setForm({ data: '', tipo: '', gravidade: '', descricao: '' }); setShow(false); reload();
  };

  const openEdit = () => { setEditForm(selected); setEditing(true); };
  const saveEdit = async () => {
    await base44.entities.Ocorrencias.update(selected.id, editForm);
    registrarAcao('Editou ocorrência', selected.tipo || '', null, 'Ocorrência', selected.id);
    setEditing(false); setSelected(null); reload();
  };
  const onFoto = async (file) => {
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setEditForm((p) => ({ ...p, fotos: file_url }));
    setUploading(false);
  };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-[#0b2545]">Ocorrências</h3>
        <Button size="sm" variant="outline" onClick={() => setShow((s) => !s)}><Plus className="w-4 h-4 mr-1" />Registrar</Button>
      </div>
      {show && (
        <form onSubmit={save} className="grid gap-3 mb-4 md:grid-cols-2">
          <div><Label>Data</Label><Input className="mt-1" type="date" value={form.data} onChange={(e) => setForm({ ...form, data: e.target.value })} required /></div>
          <div><Label>Tipo</Label>
            <Select value={form.tipo} onValueChange={(v) => setForm({ ...form, tipo: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{TIPOS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select>
          </div>
          <div><Label>Gravidade</Label>
            <Select value={form.gravidade} onValueChange={(v) => setForm({ ...form, gravidade: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{['Baixa', 'Média', 'Alta'].map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent></Select>
          </div>
          <div className="md:col-span-2"><Label>Descrição</Label><Textarea className="mt-1" rows={3} value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} /></div>
          <div className="md:col-span-2 flex justify-end gap-2"><Button type="button" variant="ghost" onClick={() => setShow(false)}>Cancelar</Button><Button type="submit" disabled={!form.tipo || !form.gravidade} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button></div>
        </form>
      )}
      {sorted.length === 0 ? <p className="text-sm text-slate-400 py-4">Nenhuma ocorrência registrada.</p> : (
        <div className="space-y-2">
          {sorted.map((o) => (
            <button key={o.id} onClick={() => { setSelected(o); setEditing(false); }} className="w-full text-left border border-slate-100 rounded-lg p-3 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-semibold text-[#0b2545]">{fmt(o.data)}</span>
                <span className="text-sm text-slate-600">{o.tipo}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${GRAV[o.gravidade]}`}>{o.gravidade}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${SIT[o.situacao] || SIT['Aberta']}`}>{o.situacao || 'Aberta'}</span>
              </div>
            </button>
          ))}
        </div>
      )}

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Ocorrência</DialogTitle>
            <DialogDescription>{selected && fmt(selected.data)}</DialogDescription>
          </DialogHeader>
          {selected && !editing && (
            <>
            <dl className="space-y-3 text-sm">
              <div className="flex gap-2"><span className={`text-xs px-2 py-0.5 rounded-full font-medium ${GRAV[selected.gravidade]}`}>{selected.gravidade}</span><span className={`text-xs px-2 py-0.5 rounded-full font-medium ${SIT[selected.situacao] || SIT['Aberta']}`}>{selected.situacao || 'Aberta'}</span></div>
              <div><dt className="text-xs text-slate-400">Descrição</dt><dd className="text-slate-700">{selected.descricao || '—'}</dd></div>
              <div><dt className="text-xs text-slate-400">Investigação</dt><dd className="text-slate-700">{selected.investigacao || '—'}</dd></div>
              <div><dt className="text-xs text-slate-400">Ações corretivas</dt><dd className="text-slate-700">{selected.acoes_corretivas || '—'}</dd></div>
              <div><dt className="text-xs text-slate-400">Encerramento</dt><dd className="text-slate-700">{selected.encerramento || '—'}</dd></div>
              <div><dt className="text-xs text-slate-400">Fotos</dt><dd>{selected.fotos ? <a href={selected.fotos} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[#0b2545] hover:underline">Ver foto <ExternalLink className="w-3 h-3" /></a> : '—'}</dd></div>
            </dl>
            <div className="mt-3 border-t border-slate-100 pt-3">
              <p className="text-xs font-semibold text-[#0b2545] mb-2">Histórico da Ocorrência</p>
              {eventos.length === 0 ? <p className="text-xs text-slate-400">Sem eventos registrados.</p> : (
                <div className="space-y-2">
                  {eventos.map((e) => (
                    <div key={e.id} className="flex gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#0b2545] mt-1.5 shrink-0" />
                      <div><p className="text-xs text-slate-700">{e.acao}</p><p className="text-[10px] text-slate-400">{new Date(e.data_hora).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })} · {e.usuario_nome || '—'}</p></div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            </>
          )}
          {selected && editing && (
            <div className="grid gap-3 text-sm">
              <div><Label>Situação</Label>
                <Select value={editForm.situacao || 'Aberta'} onValueChange={(v) => setEditForm({ ...editForm, situacao: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{['Aberta', 'Em investigação', 'Ação corretiva', 'Encerrada'].map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select>
              </div>
              <div><Label>Investigação</Label><Textarea className="mt-1" rows={2} value={editForm.investigacao || ''} onChange={(e) => setEditForm({ ...editForm, investigacao: e.target.value })} /></div>
              <div><Label>Ações corretivas</Label><Textarea className="mt-1" rows={2} value={editForm.acoes_corretivas || ''} onChange={(e) => setEditForm({ ...editForm, acoes_corretivas: e.target.value })} /></div>
              <div><Label>Encerramento</Label><Textarea className="mt-1" rows={2} value={editForm.encerramento || ''} onChange={(e) => setEditForm({ ...editForm, encerramento: e.target.value })} /></div>
              <div><Label>Foto</Label><Input className="mt-1" type="file" accept="image/*" onChange={(e) => onFoto(e.target.files?.[0])} />{uploading && <p className="text-xs text-slate-400 mt-1">Enviando...</p>}</div>
            </div>
          )}
          {selected && (
            <div className="flex justify-between mt-2">
              <Button size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50" onClick={async () => { await base44.entities.Ocorrencias.delete(selected.id); setSelected(null); reload(); }}><Trash2 className="w-4 h-4 mr-1" />Excluir</Button>
              {editing ? (
                <Button size="sm" onClick={saveEdit} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button>
              ) : (
                <Button size="sm" variant="outline" onClick={openEdit}><Pencil className="w-4 h-4 mr-1" />Investigar/encerrar</Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}