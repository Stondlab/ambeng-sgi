import React from 'react';

const STATUS = [{ key: 'regular', label: 'Regulares', tone: 'border-success bg-success/10 text-success' }, { key: 'atencao', label: 'Atenção', tone: 'border-warning bg-warning/10 text-warning' }, { key: 'critico', label: 'Críticos', tone: 'border-destructive bg-destructive/10 text-destructive' }];
export default function PessoasResumo({ counts, alertas, filtro, onFiltro }) {
  return <div className="space-y-6">
    <section className="rounded-lg border border-border bg-card p-4 shadow-card">
      <h2 className="mb-4 text-lg font-semibold text-foreground">Status geral</h2>
      <div className="grid grid-cols-3 gap-3">{STATUS.map((item) => <button key={item.key} onClick={() => onFiltro(item.key)} className={`flex min-h-24 flex-col items-center justify-center rounded-md border-2 p-4 transition-colors ${item.tone} ${filtro === item.key ? 'ring-2 ring-primary/30' : ''}`}><span className="text-3xl font-bold">{counts[item.key]}</span><span className="text-xs font-medium">{item.label}</span></button>)}</div>
    </section>
    <section className="rounded-lg border border-border bg-card p-4 shadow-card">
      <h2 className="mb-4 text-lg font-semibold text-foreground">Alertas</h2>
      {alertas.length ? <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{alertas.map((item, index) => <div key={`${item.text}-${index}`} className={`flex items-center gap-3 rounded-md p-3 ${item.tone === 'red' ? 'bg-destructive/10 text-destructive' : 'bg-warning/10 text-warning'}`}><span className="text-xl font-bold">{item.text.match(/^\d+/)?.[0] || '!'}</span><span className="text-sm font-medium">{item.text.replace(/^\d+\s*/, '')}</span></div>)}</div> : <p className="text-sm text-success">Nenhum alerta ativo.</p>}
    </section>
  </div>;
}