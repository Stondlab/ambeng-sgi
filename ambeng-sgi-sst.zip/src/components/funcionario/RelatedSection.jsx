import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Plus, Trash2, ExternalLink } from 'lucide-react';
import ValidityForm from '@/components/ValidityForm';
import StatusBadge from '@/components/StatusBadge';
import { fmt } from '@/lib/sst';
import { titleCase } from '@/lib/titleCase';

export default function RelatedSection({ title, entityName, fields, funcionario_id, items, reload, addLabel = 'Adicionar', podeCriar = true, podeExcluir = true, beforeSave }) {
  const [show, setShow] = useState(false);
  const [selected, setSelected] = useState(null);
  const hasStatus = fields.some((f) => f.name === 'data_validade');

  const sorted = [...items].sort((a, b) =>
    new Date(b.data_validade || b.data || b.created_date) - new Date(a.data_validade || a.data || a.created_date)
  );

  const save = async (values) => {
    let processed = { ...values };
    if (beforeSave) processed = await beforeSave(processed);
    fields.forEach((f) => {
      if (processed[f.name] && typeof processed[f.name] === 'string' && f.type !== 'date' && f.type !== 'number' && f.type !== 'file' && f.type !== 'boolean' && !f.options) {
        processed[f.name] = titleCase(processed[f.name]);
      }
    });
    await base44.entities[entityName].create({ ...processed, funcionario_id });
    setShow(false);
    reload();
  };
  const remove = async (id) => {
    await base44.entities[entityName].delete(id);
    setSelected(null);
    reload();
  };

  const valueOf = (it, f) => {
    if (f.type === 'date') return fmt(it[f.name]) || '—';
    if (f.type === 'file') return it[f.name] ? (
      <a href={it[f.name]} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[#0b2545] hover:underline">Abrir arquivo <ExternalLink className="w-3 h-3" /></a>
    ) : '—';
    return it[f.name] ?? '—';
  };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-[#0b2545]">{title}</h3>
        {podeCriar && <Button size="sm" variant="outline" onClick={() => setShow((s) => !s)}><Plus className="w-4 h-4 mr-1" />{addLabel}</Button>}
      </div>
      {show && <ValidityForm fields={fields} fixedFuncionarioId={funcionario_id} onSubmit={save} onCancel={() => setShow(false)} />}
      {sorted.length === 0 ? (
        <p className="text-sm text-slate-400 py-4">Nenhum registro.</p>
      ) : (
        <div className="divide-y divide-slate-100">
          {sorted.map((it) => (
            <button key={it.id} onClick={() => setSelected(it)} className="w-full text-left py-3 flex items-center gap-3 hover:bg-slate-50 rounded -mx-2 px-2 transition-colors">
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm">
                  {fields.slice(0, 3).map((f) => (
                    <span key={f.name} className="text-slate-600">
                      <span className="text-slate-400 text-xs">{f.label}: </span>
                      {f.type === 'date' ? fmt(it[f.name]) : (it[f.name] || '—')}
                    </span>
                  ))}
                </div>
              </div>
              {hasStatus && <StatusBadge data_validade={it.data_validade} />}
            </button>
          ))}
        </div>
      )}

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{title}</DialogTitle>
            <DialogDescription>Detalhes do registro</DialogDescription>
          </DialogHeader>
          {selected && (
            <dl className="grid gap-x-6 gap-y-3 sm:grid-cols-2 text-sm">
              {fields.map((f) => (
                <div key={f.name} className={f.type === 'textarea' || f.type === 'file' ? 'sm:col-span-2' : ''}>
                  <dt className="text-xs text-slate-400">{f.label}</dt>
                  <dd className="text-slate-700 break-words">{valueOf(selected, f)}</dd>
                </div>
              ))}
              {hasStatus && (
                <div className="sm:col-span-2">
                  <dt className="text-xs text-slate-400 mb-1">Situação</dt>
                  <StatusBadge data_validade={selected.data_validade} />
                </div>
              )}
            </dl>
          )}
          {selected && podeExcluir && (
            <div className="flex justify-end mt-2">
              <Button size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50" onClick={() => remove(selected.id)}>
                <Trash2 className="w-4 h-4 mr-1" />Excluir
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}