import React from 'react';
import { Link } from 'react-router-dom';
import TecnicoIdentificacao from '@/components/funcionario/tecnico/TecnicoIdentificacao';
import TecnicoConformidade from '@/components/funcionario/tecnico/TecnicoConformidade';
import TecnicoDocumentacao from '@/components/funcionario/tecnico/TecnicoDocumentacao';

export default function TecnicoFuncionarioDetail({ funcionario, dados, reload, permissoes, beforeSaveEpi }) {
  return <div className="mx-auto max-w-6xl space-y-6"><Link to="/funcionarios" className="inline-flex min-h-11 items-center text-sm text-muted-foreground hover:text-primary">← Voltar aos funcionários</Link><TecnicoIdentificacao funcionario={funcionario} /><TecnicoConformidade funcionarioId={funcionario.id} dados={dados} reload={reload} permissoes={permissoes} beforeSaveEpi={beforeSaveEpi} /><TecnicoDocumentacao funcionarioId={funcionario.id} dados={dados} reload={reload} permissao={permissoes.sst} /></div>;
}