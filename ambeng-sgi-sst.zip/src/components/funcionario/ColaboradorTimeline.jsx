import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { fmt } from '@/lib/sst';

const DOT = { navy: 'bg-primary', blue: 'bg-info', amber: 'bg-warning', green: 'bg-success', red: 'bg-destructive', slate: 'bg-slate-400' };

export default function ColaboradorTimeline({ funcionario, funcionario_id, asos, treinamentos, epis, dds, integracoes, ocorrencias, alocacoes = [], podeVerRH, podeVerEquip }) {
  const [rh, setRh] = useState({ equipamentos: [], advertencias: [], suspensoes: [], ferias: [], afastamentos: [], rescisao: [] });

  useEffect(() => {
    let cancelled = false;
    const fetchOne = async (entity) => {
      try { const all = await base44.entities[entity].list('-created_date', 200); return all.filter((r) => r.funcionario_id === funcionario_id); } catch { return []; }
    };
    (async () => {
      const next = {};
      if (podeVerRH) {
        const [advertencias, suspensoes, ferias, afastamentos, rescisao] = await Promise.all(['Advertencias', 'Suspensoes', 'Ferias', 'Afastamentos', 'Rescisao'].map(fetchOne));
        Object.assign(next, { advertencias, suspensoes, ferias, afastamentos, rescisao });
      }
      if (podeVerEquip) next.equipamentos = await fetchOne('Equipamentos');
      if (!cancelled) setRh((p) => ({ ...p, ...next }));
    })();
    return () => { cancelled = true; };
  }, [funcionario_id, podeVerRH, podeVerEquip]);

  const events = [];
  if (funcionario.data_admissao) events.push({ date: funcionario.data_admissao, label: 'Admissão', tone: 'navy' });
  integracoes.forEach((i) => events.push({ date: i.data, label: `Integração${i.responsavel ? ` — ${i.responsavel}` : ''}`, tone: 'blue' }));
  dds.forEach((d) => events.push({ date: d.data, label: `DDS${d.tema ? `: ${d.tema}` : ''}`, tone: 'amber' }));
  epis.forEach((e) => events.push({ date: e.data_entrega, label: `Entrega de EPI${e.item ? `: ${e.item}` : ''}`, tone: 'green' }));
  if (podeVerEquip) rh.equipamentos.forEach((eq) => events.push({ date: eq.data_entrega, label: `Entrega de equipamento${eq.descricao || eq.categoria ? `: ${eq.descricao || eq.categoria}` : ''}`, tone: 'green' }));
  treinamentos.forEach((t) => events.push({ date: t.data_realizacao, label: `Treinamento${t.norma_curso ? `: ${t.norma_curso}` : ''}`, tone: 'blue' }));
  asos.forEach((a) => events.push({ date: a.data_exame, label: `ASO${a.tipo ? `: ${a.tipo}` : ''}`, tone: 'navy' }));
  ocorrencias.forEach((o) => events.push({ date: o.data, label: `Ocorrência${o.tipo ? `: ${o.tipo}` : ''}`, tone: 'red' }));
  alocacoes.forEach((a) => {
    events.push({ date: a.data_inicio, label: `Alocado em ${a.obra || 'obra'}${a.funcao ? ` — ${a.funcao}` : ''}`, tone: 'navy' });
    if (a.data_fim) events.push({ date: a.data_fim, label: `Desalocado de ${a.obra || 'obra'}${a.motivo_saida ? ` — ${a.motivo_saida}` : ''}`, tone: 'slate' });
  });
  if (podeVerRH) {
    rh.advertencias.forEach((a) => events.push({ date: a.data, label: `Advertência${a.tipo ? ` (${a.tipo})` : ''}${a.motivo ? `: ${a.motivo}` : ''}`, tone: 'amber' }));
    rh.suspensoes.forEach((s) => events.push({ date: s.data, label: `Suspensão${s.dias ? ` (${s.dias} dias)` : ''}${s.motivo ? `: ${s.motivo}` : ''}`, tone: 'red' }));
    rh.ferias.forEach((f) => events.push({ date: f.inicio, label: `Férias${f.dias ? ` (${f.dias} dias)` : ''}`, tone: 'green' }));
    rh.afastamentos.forEach((af) => {
      events.push({ date: af.data_inicio, label: `Afastamento${af.tipo ? `: ${af.tipo}` : ''}`, tone: 'amber' });
      if (af.data_fim) events.push({ date: af.data_fim, label: 'Retorno de afastamento', tone: 'green' });
    });
    rh.rescisao.forEach((r) => events.push({ date: r.data, label: `Rescisão${r.tipo ? `: ${r.tipo}` : ''}`, tone: 'red' }));
  }
  if (funcionario.updated_date) events.push({ date: funcionario.updated_date.slice(0, 10), label: 'Atualização cadastral', tone: 'slate' });

  events.sort((a, b) => new Date(b.date || '') - new Date(a.date || ''));

  return (
    <section className="bg-white border border-slate-200/70 rounded-2xl p-6 shadow-card">
      <h3 className="font-heading font-semibold text-primary mb-4">Histórico do colaborador</h3>
      {events.length === 0 ? <p className="text-sm text-slate-400">Sem eventos registrados.</p> : (
        <ol className="relative border-l-2 border-slate-100 ml-2 space-y-4">
          {events.map((e, i) => (
            <li key={i} className="ml-4 relative animate-fade-in">
              <span className={`absolute -left-[26px] top-1.5 w-3 h-3 rounded-full ${DOT[e.tone]} ring-4 ring-white`} />
              <p className="text-sm text-foreground">{e.label}</p>
              <p className="text-xs text-slate-400">{fmt(e.date)}</p>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}