import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { UploadCloud, FileSpreadsheet, Check, AlertTriangle, Download, ArrowRight, ArrowLeft, RefreshCw } from 'lucide-react';
import { TEMPLATE_COLUNAS, CAMPOS_SISTEMA, autoMapear, classificar, gerarModelo, gerarRelatorioImportacao, normalizarData, normalizarTipoVinculo } from '@/lib/importacaoColaboradores';

const ST = { valido: 'bg-emerald-100 text-emerald-700', duplicado: 'bg-amber-100 text-amber-700', erro: 'bg-red-100 text-red-700' };
const STLBL = { valido: 'Válido', duplicado: 'Duplicado', erro: 'Com erro' };
const PASSOS = ['Selecionar', 'Mapear', 'Validar', 'Importar', 'Conclusão'];

export default function ImportacaoColaboradores({ onClose, onConcluido }) {
  const [step, setStep] = useState(1);
  const [file, setFile] = useState(null);
  const [fileUrl, setFileUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [lendo, setLendo] = useState(false);
  const [linhas, setLinhas] = useState([]);
  const [colunas, setColunas] = useState([]);
  const [mapeamento, setMapeamento] = useState({});
  const [classificacao, setClassificacao] = useState([]);
  const [acaoDup, setAcaoDup] = useState('ignorar');
  const [progresso, setProgresso] = useState(0);
  const [fase, setFase] = useState('');
  const [resultado, setResultado] = useState(null);
  const [erro, setErro] = useState('');
  const [drag, setDrag] = useState(false);

  const onFile = async (f) => {
    if (!f) return;
    setFile(f); setUploading(true); setErro('');
    try { const { file_url } = await base44.integrations.Core.UploadFile({ file: f }); setFileUrl(file_url); }
    catch { setErro('Falha ao enviar arquivo.'); }
    setUploading(false);
  };

  const ler = async () => {
    setLendo(true); setErro(''); setFase('Lendo arquivo...'); setProgresso(15);
    try {
      const schema = { type: 'object', properties: Object.fromEntries(TEMPLATE_COLUNAS.map((c) => [c, { type: 'string' }])) };
      const res = await base44.integrations.Core.ExtractDataFromUploadedFile({ file_url: fileUrl, json_schema: schema });
      const rows = Array.isArray(res.output) ? res.output : (res.output && res.output.rows) || [];
      if (!rows.length) { setErro('Nenhuma linha encontrada.'); setLendo(false); return; }
      const cols = Object.keys(rows[0]);
      setLinhas(rows); setColunas(cols); setMapeamento(autoMapear(cols));
      setProgresso(40); setStep(2);
    } catch (e) { setErro('Não foi possível ler o arquivo.'); }
    setLendo(false);
  };

  const validar = async () => {
    setFase('Validando dados...'); setProgresso(55); setErro('');
    const mapped = linhas.map((l) => {
      const o = {};
      CAMPOS_SISTEMA.forEach((c) => {
        const src = mapeamento[c.key];
        let v = src ? (l[src] ?? '') : '';
        if (c.type === 'date') v = normalizarData(v);
        if (c.key === 'tipo_vinculo') v = normalizarTipoVinculo(v);
        o[c.key] = v;
      });
      return o;
    });
    let existentes = [];
    try { existentes = await base44.entities.Funcionarios.list('nome', 500); } catch {}
    const cpfs = existentes.map((f) => f.cpf).filter(Boolean);
    const clas = classificar(mapped, cpfs);
    setClassificacao(clas);
    setProgresso(70); setStep(3);
  };

  const limpar = (r) => {
    const o = {};
    CAMPOS_SISTEMA.forEach((c) => { o[c.key] = r[c.key] || ''; });
    if (o.tipo_vinculo) o.tipo_vinculo = normalizarTipoVinculo(o.tipo_vinculo);
    return o;
  };

  const importar = async () => {
    setStep(4); setErro('');
    const t0 = Date.now();
    const validos = classificacao.filter((r) => r._tipo === 'valido');
    const duplicados = classificacao.filter((r) => r._tipo === 'duplicado');
    const comErro = classificacao.filter((r) => r._tipo === 'erro');
    let importados = 0, rejeitados = comErro.length, duplicCont = duplicados.length;
    let existentes = [];
    try { existentes = await base44.entities.Funcionarios.list('nome', 500); } catch {}
    const byCpf = {}; existentes.forEach((f) => { if (f.cpf) byCpf[String(f.cpf).replace(/\D/g, '')] = f; });

    setFase('Criando colaboradores...'); setProgresso(75);
    const criar = validos.map(limpar);
    if (criar.length) { try { await base44.entities.Funcionarios.bulkCreate(criar); importados += criar.length; } catch {} }
    setFase('Processando duplicados...'); setProgresso(88);
    if (acaoDup === 'atualizar') {
      for (const d of duplicados) {
        const ex = byCpf[d._cpf];
        if (ex) { try { await base44.entities.Funcionarios.update(ex.id, limpar(d)); importados++; } catch {} }
      }
    }
    setFase('Finalizando...'); setProgresso(100);
    const tempo = Date.now() - t0;
    const resumo = classificacao.map((r) => ({
      nome: r.nome, cpf: r.cpf,
      status: r._tipo === 'valido' ? 'Importado' : (r._tipo === 'duplicado' ? (acaoDup === 'atualizar' ? 'Atualizado' : 'Ignorado') : 'Rejeitado'),
      observacoes: r._erros,
    }));
    setResultado({ importados, rejeitados, duplicados: duplicCont, ignorados: acaoDup === 'ignorar' ? duplicCont : 0, tempo, resumo });
    try {
      const me = await base44.auth.me();
      await base44.entities.Importacoes.create({
        usuario: me.full_name || me.email || '—', data_hora: new Date().toISOString(),
        arquivo: file?.name || '', tipo: 'Arquivo', total_importados: importados, total_rejeitados: rejeitados,
        total_duplicados: duplicCont, tempo_ms: tempo, detalhes: `${resumo.length} linhas processadas`,
      });
    } catch {}
    onConcluido?.();
    setStep(5);
  };

  const validCount = classificacao.filter((r) => r._tipo === 'valido').length;
  const dupCount = classificacao.filter((r) => r._tipo === 'duplicado').length;
  const errCount = classificacao.filter((r) => r._tipo === 'erro').length;

  return (
    <div className="space-y-4">
      {/* Stepper */}
      <div className="flex items-center gap-2 mb-2">
        {PASSOS.map((p, i) => (
          <div key={p} className="flex items-center gap-2">
            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold ${i + 1 === step ? 'bg-[#0b2545] text-white' : i + 1 < step ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-500'}`}>{i + 1 < step ? <Check className="w-3.5 h-3.5" /> : i + 1}</span>
            <span className={`text-xs hidden sm:inline ${i + 1 === step ? 'text-[#0b2545] font-medium' : 'text-slate-400'}`}>{p}</span>
            {i < PASSOS.length - 1 && <div className="w-4 h-px bg-slate-200" />}
          </div>
        ))}
      </div>

      {erro && <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2"><AlertTriangle className="w-4 h-4" />{erro}</div>}

      {/* Etapa 1 — Arquivo */}
      {step === 1 && (
        <div className="space-y-4">
          <div
            onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => { e.preventDefault(); setDrag(false); onFile(e.dataTransfer.files?.[0]); }}
            className={`border-2 border-dashed rounded-xl p-8 text-center transition ${drag ? 'border-amber-400 bg-amber-50' : 'border-slate-300 bg-slate-50'}`}
          >
            <UploadCloud className="w-10 h-10 text-slate-400 mx-auto mb-2" />
            <p className="text-sm text-slate-600 mb-2">Arraste o arquivo aqui ou selecione</p>
            <p className="text-xs text-slate-400 mb-3">Formatos aceitos: .xlsx, .xls, .csv — detecção automática</p>
            <Label className="inline-block">
              <span className="inline-flex items-center gap-1 text-sm font-medium px-4 py-2 rounded-lg bg-[#0b2545] text-white cursor-pointer hover:bg-[#16365f]">
                <FileSpreadsheet className="w-4 h-4" /> Selecionar arquivo
              </span>
              <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
            </Label>
            {uploading && <p className="text-xs text-slate-400 mt-2">Enviando...</p>}
            {file && !uploading && (
              <p className="text-xs text-emerald-600 mt-2 flex items-center justify-center gap-1">
                <Check className="w-3 h-3" /> {file.name}
                <span className="text-slate-400 ml-1">({(file.size / 1024).toFixed(1)} KB)</span>
              </p>
            )}
          </div>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-700">
            <p className="font-medium mb-1">📋 Instruções para preenchimento:</p>
            <ul className="list-disc list-inside space-y-0.5 text-blue-600">
              <li>Campos com * são obrigatórios</li>
              <li>Formato de data: DD/MM/AAAA</li>
              <li>Tipo Vínculo: escreva <strong>CLT</strong> ou <strong>Prestador</strong></li>
              <li>Valores monetários: use apenas números (ex: 2500 ou 2500.00)</li>
            </ul>
          </div>
          <div className="flex justify-between items-center">
            <Button variant="outline" onClick={gerarModelo}><Download className="w-4 h-4 mr-1" />📥 Baixar Template</Button>
            <Button onClick={ler} disabled={!fileUrl || lendo} className="bg-[#0b2545] hover:bg-[#16365f]">
              {lendo ? 'Lendo...' : 'Ler planilha'} <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </div>
      )}

      {/* Etapa 2 — Mapeamento */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
            <p className="text-sm text-slate-600 mb-3">Mapeamento inteligente — relate as colunas da planilha aos campos do sistema.</p>
            <div className="grid gap-2.5">
              {CAMPOS_SISTEMA.map((c) => (
                <div key={c.key} className="flex items-center gap-3">
                  <span className="text-sm text-slate-600 w-44 shrink-0">{c.label}{c.required ? ' *' : ''}</span>
                  <Select value={mapeamento[c.key] || ''} onValueChange={(v) => setMapeamento((p) => ({ ...p, [c.key]: v || undefined }))}>
                    <SelectTrigger><SelectValue placeholder="— não mapeado —" /></SelectTrigger>
                    <SelectContent>
                      {colunas.map((col) => <SelectItem key={col} value={col}>{col}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>
          </div>
          <div className="flex justify-between">
            <Button variant="ghost" onClick={() => setStep(1)}><ArrowLeft className="w-4 h-4 mr-1" />Voltar</Button>
            <Button onClick={validar} disabled={!mapeamento.nome} className="bg-[#0b2545] hover:bg-[#16365f]">Validar <ArrowRight className="w-4 h-4 ml-1" /></Button>
          </div>
        </div>
      )}

      {/* Etapa 3 — Validação */}
      {step === 3 && (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-center"><p className="text-2xl font-bold text-emerald-700">{validCount}</p><p className="text-xs text-emerald-700">Válidos</p></div>
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-center"><p className="text-2xl font-bold text-amber-700">{dupCount}</p><p className="text-xs text-amber-700">Duplicados</p></div>
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-center"><p className="text-2xl font-bold text-red-700">{errCount}</p><p className="text-xs text-red-700">Com erro</p></div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="overflow-x-auto max-h-72">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 text-slate-500 text-xs uppercase sticky top-0">
                  <tr><th className="text-left px-3 py-2">Nome</th><th className="text-left px-3 py-2">CPF</th><th className="text-left px-3 py-2">Cargo</th><th className="text-left px-3 py-2">Empresa</th><th className="text-left px-3 py-2">Status</th></tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {classificacao.map((r, i) => (
                    <tr key={i} className="hover:bg-slate-50">
                      <td className="px-3 py-2 text-slate-700">{r.nome || '—'}</td>
                      <td className="px-3 py-2 text-slate-500">{r.cpf || '—'}</td>
                      <td className="px-3 py-2 text-slate-500">{r.funcao || '—'}</td>
                      <td className="px-3 py-2 text-slate-500">{r.empresa || '—'}</td>
                      <td className="px-3 py-2"><span className={`text-xs px-2 py-0.5 rounded-full ${ST[r._tipo]}`}>{STLBL[r._tipo]}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {dupCount > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
              <p className="text-sm font-medium text-amber-800 mb-2">Foram encontrados {dupCount} CPF(s) já cadastrado(s). O que deseja fazer?</p>
              <div className="flex gap-2">
                <Button size="sm" variant={acaoDup === 'atualizar' ? 'default' : 'outline'} className={acaoDup === 'atualizar' ? 'bg-[#0b2545]' : ''} onClick={() => setAcaoDup('atualizar')}>Atualizar cadastro existente</Button>
                <Button size="sm" variant={acaoDup === 'ignorar' ? 'default' : 'outline'} className={acaoDup === 'ignorar' ? 'bg-[#0b2545]' : ''} onClick={() => setAcaoDup('ignorar')}>Ignorar duplicados</Button>
              </div>
            </div>
          )}

          <div className="flex justify-between">
            <Button variant="ghost" onClick={() => setStep(2)}><ArrowLeft className="w-4 h-4 mr-1" />Voltar</Button>
            <Button onClick={importar} disabled={validCount === 0 && (dupCount === 0 || acaoDup === 'ignorar')} className="bg-[#0b2545] hover:bg-[#16365f]">Importar {acaoDup === 'atualizar' && dupCount ? `${validCount + dupCount}` : validCount} registro(s) <ArrowRight className="w-4 h-4 ml-1" /></Button>
          </div>
        </div>
      )}

      {/* Etapa 4 — Importando */}
      {step === 4 && (
        <div className="bg-white border border-slate-200 rounded-xl p-8 text-center">
          <RefreshCw className="w-8 h-8 text-[#0b2545] mx-auto mb-3 animate-spin" />
          <p className="text-sm text-slate-600 mb-3">{fase}</p>
          <div className="max-w-md mx-auto h-2 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-amber-400 transition-all" style={{ width: `${progresso}%` }} />
          </div>
          <p className="text-xs text-slate-400 mt-2">{progresso}% · Tempo estimado: ~{Math.max(2, Math.round((classificacao.length) * 0.05))}s</p>
        </div>
      )}

      {/* Etapa 5 — Conclusão */}
      {step === 5 && resultado && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-4"><Check className="w-5 h-5 text-emerald-600" /><h3 className="font-semibold text-[#0b2545]">Importação concluída</h3></div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-emerald-50 rounded-lg p-3 text-center"><p className="text-xl font-bold text-emerald-700">{resultado.importados}</p><p className="text-xs text-emerald-700">Importados</p></div>
              <div className="bg-amber-50 rounded-lg p-3 text-center"><p className="text-xl font-bold text-amber-700">{resultado.duplicados}</p><p className="text-xs text-amber-700">Duplicados</p></div>
              <div className="bg-red-50 rounded-lg p-3 text-center"><p className="text-xl font-bold text-red-700">{resultado.rejeitados}</p><p className="text-xs text-red-700">Rejeitados</p></div>
              <div className="bg-slate-50 rounded-lg p-3 text-center"><p className="text-xl font-bold text-slate-600">{(resultado.tempo / 1000).toFixed(1)}s</p><p className="text-xs text-slate-500">Tempo</p></div>
            </div>
          </div>
          <div className="flex flex-wrap justify-between gap-2">
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => gerarRelatorioImportacao(resultado.resumo)}><Download className="w-4 h-4 mr-1" />Baixar relatório</Button>
              <Button variant="outline" onClick={() => gerarRelatorioImportacao(resultado.resumo.filter((r) => r.status === 'Rejeitado'))}><AlertTriangle className="w-4 h-4 mr-1" />Ver erros</Button>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => { setStep(1); setFile(null); setFileUrl(''); setLinhas([]); setColunas([]); setMapeamento({}); setClassificacao([]); setResultado(null); setProgresso(0); }}><RefreshCw className="w-4 h-4 mr-1" />Importar novamente</Button>
              <Button onClick={onClose} className="bg-[#0b2545] hover:bg-[#16365f]">Concluir</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}