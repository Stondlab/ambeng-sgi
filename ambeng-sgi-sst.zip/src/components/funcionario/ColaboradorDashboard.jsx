import React, { useState } from 'react';
import { getStatus, fmt, classificarColaborador, CLASSE_COLAB } from '@/lib/sst';
import DrillDownDialog from '@/components/dashboard/DrillDownDialog';
import { Stethoscope, GraduationCap, HardHat, CalendarCheck, Users, AlertTriangle, FileText, ShieldAlert, ClipboardCheck, FileWarning, ArrowRight } from 'lucide-react';

const TONE = {
  green: { text: 'text-emerald-700', border: 'border-l-emerald-500' },
  amber: { text: 'text-amber-700', border: 'border-l-amber-500' },
  red: { text: 'text-red-700', border: 'border-l-red-500' },
  slate: { text: 'text-slate-500', border: 'border-l-slate-300' },
};

function Pill({ status }) {
  const map = {
    'Em dia': 'bg-emerald-100 text-emerald-700', 'A vencer': 'bg-amber-100 text-amber-700', 'Vencido': 'bg-red-100 text-red-700',
    'Conforme': 'bg-emerald-100 text-emerald-700', 'Pendente': 'bg-amber-100 text-amber-700', 'Não Conforme': 'bg-red-100 text-red-700',
    'Aberta': 'bg-amber-100 text-amber-700', 'Em Andamento': 'bg-blue-100 text-blue-700', 'Resolvida': 'bg-emerald-100 text-emerald-700',
    'Nenhuma': 'bg-emerald-100 text-emerald-700',
  };
  return <span className={`text-[11px] font-medium px-2 py-0.5 rounded ${map[status] || 'bg-slate-100 text-slate-600'}`}>{status || '—'}</span>;
}

// Itens baseados em validade (ASO/Treinamento/EPI): ausência = PENDENTE (não conforme).
function valSt(items) {
  if (!items || items.length === 0) return { label: 'Pendente', tone: 'red', pending: 0 };
  let tone = 'green', label = 'Em dia';
  let pend = 0;
  items.forEach((i) => {
    const s = getStatus(i.data_validade);
    if (s !== 'Em dia') pend++;
    if (s === 'Vencido') { tone = 'red'; label = 'Vencido'; }
    else if (s === 'A vencer' && tone !== 'red') { tone = 'amber'; label = 'A vencer'; }
  });
  return { label, tone, pending: pend };
}

function Card({ icon: Icon, label, status, onClick }) {
  const t = TONE[status.tone] || TONE.slate;
  return (
    <button onClick={onClick} className={`text-left bg-white border border-slate-200 border-l-4 ${t.border} rounded-lg p-3 hover:shadow-sm transition w-full`}>
      <div className="flex items-center gap-2 mb-1">
        <Icon className="w-5 h-5 text-slate-400 shrink-0" />
        <span className={`text-xs font-semibold ${t.text}`}>{status.label}</span>
        <span className="ml-auto text-lg font-bold text-[#0b2545]">{status.count}</span>
      </div>
      <p className="text-xs text-slate-400 truncate">{label}</p>
    </button>
  );
}

export default function ColaboradorDashboard({ funcionario, asos = [], treinamentos = [], epis = [], dds = [], integracoes = [], ocorrencias = [], documentos = [], inspecoes = [], demandas = [], onCardClick }) {
  const [active, setActive] = useState(null);

  const asoSt = { ...valSt(asos), count: asos.length };
  const treSt = { ...valSt(treinamentos), count: treinamentos.length };
  const epiSt = { ...valSt(epis), count: epis.length };

  const intSt = integracoes.length ? { label: 'Em dia', tone: 'green', count: integracoes.length } : { label: 'Pendente', tone: 'red', count: 0 };
  const ddsSt = dds.length ? { label: 'Em dia', tone: 'green', count: dds.length } : { label: 'Pendente', tone: 'red', count: 0 };
  const docSt = documentos.length ? { label: 'Em dia', tone: 'green', count: documentos.length } : { label: 'Pendente', tone: 'red', count: 0 };

  const nc = ocorrencias.filter((o) => o.tipo === 'Não Conformidade');
  const ncAbertas = nc.filter((o) => o.situacao !== 'Encerrada' && o.situacao !== 'Resolvida' && o.situacao !== 'Cancelada').length;
  const ncSt = nc.length ? (ncAbertas === 0 ? { label: 'Em dia', tone: 'green', count: nc.length } : { label: 'Aberta', tone: 'red', count: ncAbertas }) : { label: 'Nenhuma', tone: 'green', count: 0 };
  const ocoAbertas = ocorrencias.filter((o) => o.situacao !== 'Encerrada' && o.situacao !== 'Resolvida' && o.situacao !== 'Cancelada').length;
  const ocoSt = ocorrencias.length ? (ocoAbertas === 0 ? { label: 'Em dia', tone: 'green', count: ocorrencias.length } : { label: 'Aberta', tone: 'amber', count: ocoAbertas }) : { label: 'Nenhuma', tone: 'green', count: 0 };

  const insp = inspecoes || [];
  const inspPend = insp.filter((i) => i.status !== 'Conforme').length;
  const inspSt = insp.length ? (inspPend === 0 ? { label: 'Em dia', tone: 'green', count: insp.length } : { label: 'Pendente', tone: 'amber', count: inspPend }) : { label: 'Pendente', tone: 'red', count: 0 };

  const apr = demandas || [];
  const aprPend = apr.filter((d) => d.status !== 'Concluído' && d.status !== 'Cancelado').length;
  const aprSt = apr.length ? (aprPend === 0 ? { label: 'Em dia', tone: 'green', count: apr.length } : { label: 'Pendente', tone: 'amber', count: aprPend }) : { label: 'Pendente', tone: 'red', count: 0 };

  const CARDS = [
    { id: 'saude', icon: Stethoscope, label: 'ASO', status: asoSt, rows: asos, title: 'ASOs do colaborador', columns: [
      { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' },
      { key: 'venc', label: 'Validade', value: (r) => fmt(r.data_validade) },
      { key: 'med', label: 'Médico', value: (r) => r.medico || '—' },
      { key: 'st', label: 'Status', render: (r) => <Pill status={getStatus(r.data_validade)} /> },
    ] },
    { id: 'treinamentos', icon: GraduationCap, label: 'Treinamentos', status: treSt, rows: treinamentos, title: 'Treinamentos do colaborador', columns: [
      { key: 'curso', label: 'Curso', value: (r) => r.norma_curso || r.nome_curso || '—' },
      { key: 'venc', label: 'Validade', value: (r) => fmt(r.data_validade) },
      { key: 'carga', label: 'Carga (h)', value: (r) => r.carga_horaria || '—' },
      { key: 'st', label: 'Status', render: (r) => <Pill status={getStatus(r.data_validade)} /> },
    ] },
    { id: 'integracoes', icon: Users, label: 'Integração', status: intSt, rows: integracoes, title: 'Integrações do colaborador', columns: [
      { key: 'data', label: 'Data', value: (r) => fmt(r.data) },
      { key: 'resp', label: 'Responsável', value: (r) => r.responsavel || '—' },
      { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' },
    ] },
    { id: 'epis', icon: HardHat, label: 'EPIs', status: epiSt, rows: epis, title: 'EPIs do colaborador', columns: [
      { key: 'item', label: 'EPI', value: (r) => r.item || '—' },
      { key: 'ca', label: 'CA', value: (r) => r.certificado_aprovacao || '—' },
      { key: 'ent', label: 'Entrega', value: (r) => fmt(r.data_entrega) },
      { key: 'st', label: 'Status', render: (r) => <Pill status={getStatus(r.data_validade)} /> },
    ] },
    { id: 'dds', icon: CalendarCheck, label: 'DDS', status: ddsSt, rows: dds, title: 'DDS do colaborador', columns: [
      { key: 'data', label: 'Data', value: (r) => fmt(r.data) },
      { key: 'tema', label: 'Tema', value: (r) => r.tema || '—' },
      { key: 'resp', label: 'Responsável', value: (r) => r.responsavel || '—' },
    ] },
    { id: 'documentos', icon: FileText, label: 'Documentação', status: docSt, rows: documentos, title: 'Documentos do colaborador', columns: [
      { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' },
      { key: 'venc', label: 'Validade', value: (r) => fmt(r.data_validade) },
      { key: 'st', label: 'Status', render: (r) => <Pill status={getStatus(r.data_validade)} /> },
    ] },
    { id: 'ocorrencias', icon: AlertTriangle, label: 'Ocorrências', status: ocoSt, rows: ocorrencias, title: 'Ocorrências do colaborador', columns: [
      { key: 'data', label: 'Data', value: (r) => fmt(r.data) },
      { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' },
      { key: 'grav', label: 'Gravidade', value: (r) => r.gravidade || '—' },
      { key: 'sit', label: 'Situação', render: (r) => <Pill status={r.situacao} /> },
    ] },
    { id: 'nc', icon: ShieldAlert, label: 'Não Conformidades', status: ncSt, rows: nc, title: 'Não conformidades do colaborador', columns: [
      { key: 'data', label: 'Data', value: (r) => fmt(r.data) },
      { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' },
      { key: 'grav', label: 'Gravidade', value: (r) => r.gravidade || '—' },
      { key: 'sit', label: 'Situação', render: (r) => <Pill status={r.situacao} /> },
    ] },
    { id: 'inspecoes', icon: ClipboardCheck, label: 'Inspeções', status: inspSt, rows: insp, title: 'Inspeções do colaborador', columns: [
      { key: 'tipo', label: 'Tipo', value: (r) => r.tipo || '—' },
      { key: 'data', label: 'Data', value: (r) => fmt(r.data) },
      { key: 'prox', label: 'Próxima', value: (r) => fmt(r.data_proxima) },
      { key: 'st', label: 'Status', render: (r) => <Pill status={r.status} /> },
    ] },
    { id: 'apr', icon: FileWarning, label: 'APR', status: aprSt, rows: apr, title: 'APRs do colaborador', columns: [
      { key: 'tit', label: 'Título', value: (r) => r.titulo || '—' },
      { key: 'prazo', label: 'Prazo', value: (r) => fmt(r.prazo) },
      { key: 'prio', label: 'Prioridade', value: (r) => r.prioridade || '—' },
      { key: 'st', label: 'Status', render: (r) => <Pill status={r.status} /> },
    ] },
  ];

  const drill = CARDS.find((c) => c.id === active);
  const open = (id) => setActive(id);
  const go = (id) => () => { setActive(null); onCardClick?.(id); };

  const { classe, motivos } = classificarColaborador(funcionario, { asos, treinamentos, epis, integracoes, dds, ocorrencias, documentos });

  return (
    <>
      <div className={`mb-4 rounded-xl border p-4 flex items-center gap-3 ${CLASSE_COLAB[classe].style}`}>
        <span className="text-sm font-bold uppercase tracking-wide">{classe}</span>
        <span className="text-xs opacity-80">· {motivos.join(' · ')}</span>
        <span className="ml-auto text-[11px] opacity-70">Classificação automática do colaborador</span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {CARDS.map((c) => { const Icon = c.icon; return (
          <Card key={c.id} icon={Icon} label={c.label} status={c.status} onClick={() => open(c.id)} />
        );})}
      </div>

      {drill && (
        <DrillDownDialog
          open
          onOpenChange={(o) => !o && setActive(null)}
          title={drill.title}
          subtitle="Registros que compõem este indicador"
          icon={drill.icon}
          columns={drill.columns}
          rows={drill.rows}
          renderAction={() => (
            <button onClick={go(drill.id)} className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-md bg-[#0b2545] text-white hover:bg-[#0b2545]/90">
              Abrir seção <ArrowRight className="w-3 h-3" />
            </button>
          )}
        />
      )}
    </>
  );
}