import React, { useMemo, useState } from 'react';
import { getStatus, fmt } from '@/lib/sst';
import { CheckCircle2, Clock, XCircle, Minus } from 'lucide-react';

const NRS = ['NR-35 Trabalho em Altura', 'NR-18 Construção Civil', 'NR-10 Eletricidade', 'NR-11 Operação de Equipamentos', 'NR-06 EPI', 'NR-12 Segurança no Trabalho', 'NR-33 Espaços Confinados', 'NR-20 Combustíveis'];

function statusInfo(t) {
  const s = getStatus(t?.data_validade);
  if (!t) return { icon: Minus, color: 'text-slate-300', bg: '', label: 'Não se aplica' };
  if (s === 'Em dia') return { icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50', label: 'Em dia' };
  if (s === 'A vencer') return { icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50', label: 'A vencer' };
  return { icon: XCircle, color: 'text-red-600', bg: 'bg-red-50', label: 'Vencido' };
}

export default function MatrizTreinamentos({ funcionarios, treinamentos, onSelect }) {
  const [nrCols] = useState(NRS);
  const matrix = useMemo(() => {
    return funcionarios.map((f) => {
      const row = { func: f, cells: {} };
      nrCols.forEach((nr) => {
        const rec = treinamentos.find((t) => t.funcionario_id === f.id && t.norma_curso === nr);
        row.cells[nr] = rec || null;
      });
      return row;
    });
  }, [funcionarios, treinamentos, nrCols]);

  const summary = useMemo(() => nrCols.map((nr) => {
    const recs = treinamentos.filter((t) => t.norma_curso === nr);
    const emDia = recs.filter((t) => getStatus(t.data_validade) === 'Em dia').length;
    const aVencer = recs.filter((t) => getStatus(t.data_validade) === 'A vencer').length;
    const vencido = recs.filter((t) => getStatus(t.data_validade) === 'Vencido').length;
    return { nr, emDia, aVencer, vencido };
  }), [treinamentos, nrCols]);

  return (
    <div className="space-y-4">
      {/* Summary cards per NR */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {summary.map((s) => (
          <div key={s.nr} className="bg-white border border-slate-200 rounded-xl p-3">
            <p className="text-xs font-semibold text-[#0b2545] truncate">{s.nr}</p>
            <div className="flex items-center gap-3 mt-2 text-xs">
              <span className="flex items-center gap-1 text-emerald-600"><CheckCircle2 className="w-3.5 h-3.5" />{s.emDia}</span>
              <span className="flex items-center gap-1 text-amber-600"><Clock className="w-3.5 h-3.5" />{s.aVencer}</span>
              <span className="flex items-center gap-1 text-red-600"><XCircle className="w-3.5 h-3.5" />{s.vencido}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Matrix */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-500 text-xs">
            <tr>
              <th className="text-left px-3 py-3 sticky left-0 bg-slate-50 min-w-[160px]">Funcionário</th>
              {nrCols.map((nr) => <th key={nr} className="px-2 py-3 text-center min-w-[70px]">{nr.replace(' Trabalho em Altura', '').replace(' Construção Civil', '').replace(' Operação de Equipamentos', '').replace(' Segurança no Trabalho', '').replace(' Espaços Confinados', '').replace(' Combustíveis', '').replace(' Eletricidade', '').replace(' EPI', '')}</th>)}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {matrix.map(({ func, cells }) => (
              <tr key={func.id} className="hover:bg-slate-50">
                <td className="px-3 py-2.5 font-medium text-[#0b2545] sticky left-0 bg-white">{func.nome}</td>
                {nrCols.map((nr) => {
                  const info = statusInfo(cells[nr]);
                  const Icon = info.icon;
                  return (
                    <td key={nr} className="px-2 py-2.5 text-center">
                      <button
                        onClick={() => onSelect && onSelect({ func, treinamento: cells[nr], nr })}
                        className={`w-9 h-9 rounded-lg flex items-center justify-center ${info.bg} hover:ring-2 hover:ring-[#0b2545]/30`}
                        title={cells[nr] ? `${info.label} · vence ${fmt(cells[nr].data_validade)}` : 'Não se aplica'}
                      >
                        <Icon className={`w-5 h-5 ${info.color}`} />
                      </button>
                    </td>
                  );
                })}
              </tr>
            ))}
            {matrix.length === 0 && <tr><td colSpan={nrCols.length + 1} className="px-4 py-10 text-center text-slate-400">Nenhum funcionário.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}