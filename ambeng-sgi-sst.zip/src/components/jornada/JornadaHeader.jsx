import React from 'react';
import { Download, FileText, Plus, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function JornadaHeader({ ultimaImportacao, onImportar, onManual, onExportar, onRelatorio, canManage }) {
  const data = ultimaImportacao?.data_hora ? `${new Date(ultimaImportacao.data_hora).toLocaleDateString('pt-BR')} às ${new Date(ultimaImportacao.data_hora).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}` : 'Nenhuma importação registrada';
  return <header className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
    <div><h1 className="text-2xl font-semibold tracking-tight text-foreground">JORNADA E PONTO</h1><p className="mt-1 text-sm text-muted-foreground">Controle gerencial de jornada, horas e alocação por obra.</p></div>
    <div className="flex flex-col items-start gap-2 sm:items-end"><div className="flex flex-wrap gap-2">{canManage && <Button onClick={onManual}><Plus />Lançar jornada</Button>}{canManage && <Button variant="outline" onClick={onImportar}><Upload />Importar ponto</Button>}<Button variant="outline" onClick={onExportar}><Download />Exportar</Button><Button variant="outline" onClick={onRelatorio}><FileText />Relatório</Button></div><div className="text-left text-xs text-muted-foreground sm:text-right"><p><b className="text-foreground">Última importação:</b> {data}</p><p><b className="text-foreground">Fonte:</b> Sistema de Ponto Externo</p></div></div>
  </header>;
}