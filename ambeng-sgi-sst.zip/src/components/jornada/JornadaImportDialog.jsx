import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import ImportacaoPonto from '@/pages/ImportacaoPonto';

export default function JornadaImportDialog({ open, onClose, onImported }) {
  return <Dialog open={open} onOpenChange={(value) => !value && onClose()}><DialogContent className="h-[92vh] max-w-6xl overflow-y-auto"><DialogHeader><DialogTitle>IMPORTAR REGISTROS</DialogTitle><p className="text-sm text-muted-foreground">Fonte: Sistema externo · os registros originais serão preservados.</p></DialogHeader><ImportacaoPonto embedded onImported={onImported} /></DialogContent></Dialog>;
}