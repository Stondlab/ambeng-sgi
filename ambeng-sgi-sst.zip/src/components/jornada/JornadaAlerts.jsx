import React from 'react';
import { AlertTriangle, CircleAlert } from 'lucide-react';

export default function JornadaAlerts({ rows, onFilter }) {
  const alerts = [
    { label: 'jornadas sem obra vinculada', count: rows.filter((r) => !r.obra).length, tone: 'text-amber-700 bg-amber-50', action: () => onFilter('obra', 'sem') },
    { label: 'jornadas com horário inconsistente', count: rows.filter((r) => r.status === 'INCONSISTÊNCIA').length, tone: 'text-destructive bg-destructive/5', action: () => onFilter('status', 'INCONSISTÊNCIA') },
    { label: 'jornadas com horas extras acima de 2h', count: rows.filter((r) => r.extrasMin > 120).length, tone: 'text-amber-700 bg-amber-50', action: () => onFilter('modo', 'extras') },
  ].filter((item) => item.count);
  return <section className="rounded-xl border border-border bg-card p-4"><h2 className="flex items-center gap-2 text-sm font-semibold"><AlertTriangle className="h-4 w-4 text-amber-600" />ALERTAS E INCONSISTÊNCIAS</h2><div className="mt-3 grid gap-2 lg:grid-cols-3">{alerts.map((item) => <button key={item.label} onClick={item.action} className={`flex min-h-11 items-center gap-2 rounded-lg px-3 text-left text-sm ${item.tone}`}><CircleAlert className="h-4 w-4 shrink-0" /><b>{item.count}</b> {item.label}</button>)}{!alerts.length && <p className="text-sm text-success">Nenhuma inconsistência para os filtros selecionados.</p>}</div></section>;
}