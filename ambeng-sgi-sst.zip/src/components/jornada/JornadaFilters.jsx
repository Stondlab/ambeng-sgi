import React from 'react';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { mesLabel, corDaObra } from '@/lib/centralJornada';

const Field = ({ label, value, onChange, children }) => <label className="min-w-0"><span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</span><Select value={value} onValueChange={onChange}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{children}</SelectContent></Select></label>;
export default function JornadaFilters({ filters, setFilter, periods, empresas, funcionarios, obras }) {
  return <section className="grid gap-3 rounded-xl border border-border bg-card p-3 sm:grid-cols-2 lg:grid-cols-7">
    <Field label="Período" value={filters.periodo} onChange={(v) => setFilter('periodo', v)}>{periods.map((v) => <SelectItem key={v} value={v}>{mesLabel(v)}</SelectItem>)}</Field>
    <Field label="Empresa" value={filters.empresa} onChange={(v) => setFilter('empresa', v)}><SelectItem value="todas">Todas</SelectItem>{empresas.map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}</Field>
    <Field label="Funcionário" value={filters.funcionario} onChange={(v) => setFilter('funcionario', v)}><SelectItem value="todos">Todos</SelectItem>{funcionarios.map((v) => <SelectItem key={v.id} value={v.id}>{v.nome}</SelectItem>)}</Field>
    <Field label="Obra" value={filters.obra} onChange={(v) => setFilter('obra', v)}><SelectItem value="todas">Todas</SelectItem><SelectItem value="sem">Sem obra</SelectItem>{obras.map((v) => <SelectItem key={v.id} value={v.nome}><span className="inline-flex items-center gap-2"><i className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: corDaObra(v, obras) }} />{v.nome}</span></SelectItem>)}</Field>
    <Field label="Status" value={filters.status} onChange={(v) => setFilter('status', v)}>{['TODOS', 'IMPORTADO', 'CONFERIDO', 'PENDENTE', 'INCONSISTÊNCIA', 'FALTA', 'ATRASADO', 'ATESTADO', 'FOLGA', 'CANCELADO'].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}</Field>
    <Field label="Origem" value={filters.origem} onChange={(v) => setFilter('origem', v)}>{['TODAS', 'IMPORTADO', 'MANUAL'].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}</Field>
    <label><span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Buscar</span><div className="relative mt-1"><Search className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground" /><Input className="pl-9" value={filters.busca} onChange={(e) => setFilter('busca', e.target.value)} placeholder="Buscar funcionário..." /></div></label>
  </section>;
}