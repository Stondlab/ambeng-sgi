import React from 'react';
import { corDaObra } from '@/lib/centralJornada';

export default function ObrasLegend({ obras }) {
  if (!obras.length) return null;
  return <div className="flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-border px-4 py-3">
    <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Legenda de obras</span>
    {obras.map((obra, index) => <span key={obra.id || obra.nome} className="inline-flex items-center gap-1.5 text-xs text-foreground"><i className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: corDaObra(obra, obras) }} />{obra.nome}</span>)}
    <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground"><i className="h-2.5 w-2.5 rounded-full border border-border bg-card" />Sem obra</span>
    <span className="ml-auto inline-flex flex-wrap gap-3 text-xs text-muted-foreground"><b className="text-success">✓ Conferido</b><b className="text-amber-700">◷ Pendente/importado</b><b className="text-destructive">⚠ Divergência</b><b>— Sem ponto</b></span>
  </div>;
}