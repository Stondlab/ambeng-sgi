import React from 'react';
import { fmtDuracao, fmtHoras } from '@/lib/centralJornada';

export default function JornadaKpis({ resumo }) {
  const items = [
    ['Funcionários', resumo.funcionarios], ['Jornadas importadas', resumo.jornadas],
    ['Horas trabalhadas', fmtHoras(resumo.minutos)], ['Horas extras', fmtHoras(resumo.extras)],
    ['Inconsistências', resumo.inconsistencias], ['Banco de horas', fmtDuracao(resumo.banco, true)],
  ];
  return <section className="grid grid-cols-2 divide-x divide-y divide-border overflow-hidden rounded-xl border border-border bg-card sm:grid-cols-3 lg:grid-cols-6 lg:divide-y-0">
    {items.map(([label, value]) => <div key={label} className="min-w-0 px-3 py-3"><p className="truncate text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</p><p className={`mt-1 truncate text-lg font-semibold ${label === 'Inconsistências' && value ? 'text-destructive' : label === 'Banco de horas' && resumo.banco >= 0 ? 'text-success' : 'text-foreground'}`}>{value}</p></div>)}
  </section>;
}