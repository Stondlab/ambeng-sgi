import React, { useEffect, useMemo, useState } from 'react';
import { BadgeCheck, Clock3, ExternalLink } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { fmtDuracao, corDaObra } from '@/lib/centralJornada';
import { nomeUsuario } from '@/lib/usuarioNome';
import { useToast } from '@/components/ui/use-toast';

export default function JornadaCellDialog({ cell, obras, user, canManage, onClose, onSaved, onDetails, onEditManual }) {
  const { toast } = useToast();
  const primary = useMemo(() => (cell?.apontamentos || []).find((item) => item.ponto_id === cell?.row?.id) || (cell?.apontamentos || []).find((item) => !item.ponto_id), [cell]);
  const current = obras.find((obra) => obra.nome === (primary?.obra || cell?.row?.obra));
  const [obraId, setObraId] = useState(current?.id || 'sem'); const [saving, setSaving] = useState(false);
  useEffect(() => setObraId(current?.id || 'sem'), [cell, current?.id]);
  if (!cell) return null;
  const row = cell.row; const obra = obras.find((item) => item.id === obraId);
  const save = async () => {
    if (!obra) return toast({ title: 'Selecione uma obra.', variant: 'destructive' });
    setSaving(true); const agora = new Date().toISOString(); const usuario = nomeUsuario(user);
    const evento = { usuario, data_hora: agora, acao: 'Associação gerencial de obra alterada', obra_anterior: primary?.obra || row?.obra || '', obra_nova: obra.nome };
    try {
      if (primary) { let hist = []; try { hist = JSON.parse(primary.historico || '[]'); } catch {} await base44.entities.Apontamentos.update(primary.id, { obra: obra.nome, obra_id: obra.id, ponto_id: row?.id || '', historico: JSON.stringify([...hist, evento]), usuario_lancamento: usuario, data_hora_lancamento: agora }); }
      else await base44.entities.Apontamentos.create({ funcionario_id: cell.func.id, ponto_id: row?.id || '', matricula: cell.func.matricula || '', data: cell.date, obra: obra.nome, obra_id: obra.id, horas: row ? row.minutos / 60 : 0, tipo: 'Trabalhado', observacao: row?.observacao || '', status: row ? 'Conferido' : 'Pendente', origem: 'Manual', usuario_lancamento: usuario, data_hora_lancamento: agora, historico: JSON.stringify([evento]) });
      toast({ title: 'Obra associada à jornada.' }); await onSaved(); onClose();
    } catch { toast({ title: 'Não foi possível salvar a associação.', variant: 'destructive' }); }
    finally { setSaving(false); }
  };
  return <Dialog open onOpenChange={(open) => !open && onClose()}><DialogContent className="max-w-md"><DialogHeader><div className="flex items-center gap-2"><span className="rounded-full bg-primary/10 px-2 py-1 text-[10px] font-semibold text-primary">IMPORTADO</span><span className="text-xs text-muted-foreground">Origem: sistema externo</span></div><DialogTitle className="pt-2">{cell.func.nome}</DialogTitle><p className="text-sm text-muted-foreground">{cell.func.funcao || 'Cargo não informado'} · {cell.date.split('-').reverse().join('/')}</p></DialogHeader><div className="grid grid-cols-2 gap-3 rounded-xl bg-muted/50 p-4 text-sm"><div><p className="text-xs text-muted-foreground">Jornada importada</p><b>{row ? `${row.entrada} — ${row.saida}` : 'Sem ponto'}</b></div><div><p className="text-xs text-muted-foreground">Horas</p><b>{row ? fmtDuracao(row.minutos) : '00:00'}</b></div><div><p className="text-xs text-muted-foreground">Horas extras</p><b>{row ? fmtDuracao(row.extrasMin) : '00:00'}</b></div><div><p className="text-xs text-muted-foreground">Status</p><b className="inline-flex items-center gap-1"><BadgeCheck className="h-4 w-4 text-success" />{row?.status || 'SEM PONTO'}</b></div></div>{cell.records?.filter((item) => item.origem === 'MANUAL').map((item) => <button key={item.id} onClick={() => onEditManual(item)} className="flex w-full items-center justify-between rounded-lg border border-border bg-card p-3 text-left text-sm"><span><b>Registro manual</b><small className="block text-muted-foreground">{item.entrada} — {item.saida} · {item.obra || 'Sem obra'}</small></span><span className="text-xs font-semibold text-primary">Editar</span></button>)}<div><label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Selecionar obra</label><Select value={obraId} onValueChange={setObraId} disabled={!canManage}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione a obra" /></SelectTrigger><SelectContent><SelectItem value="sem" disabled>Sem obra vinculada</SelectItem>{obras.map((item, index) => <SelectItem key={item.id} value={item.id}><span className="inline-flex items-center gap-2"><i className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: corDaObra(item, obras) }} />{item.nome}</span></SelectItem>)}</SelectContent></Select></div><div className="rounded-lg border border-primary/20 bg-primary/5 p-3 text-xs text-muted-foreground"><Clock3 className="mr-1 inline h-3.5 w-3.5 text-primary" />Registro importado do sistema oficial de ponto. Somente a associação gerencial da obra será alterada.</div><DialogFooter className="gap-2 sm:justify-between"><Button variant="ghost" onClick={() => onDetails(cell.func)}><ExternalLink />Ver detalhes</Button><Button onClick={save} disabled={!canManage || !obra || saving}>{saving ? 'Salvando...' : 'Salvar associação'}</Button></DialogFooter></DialogContent></Dialog>;
}