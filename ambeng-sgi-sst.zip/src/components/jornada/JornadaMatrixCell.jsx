import React from 'react';
import { AlertTriangle, Check, Clock3, Minus } from 'lucide-react';
import { corTexto, siglaObra } from '@/lib/centralJornada';

const statusIcon = {
  CONFERIDO: Check,
  IMPORTADO: Clock3,
  PENDENTE: Clock3,
  'INCONSISTÊNCIA': AlertTriangle,
};

export default function JornadaMatrixCell({ row, records = [], obra, color, onClick, label }) {
  const Icon = row ? statusIcon[row.status] || Clock3 : Minus;
  const title = row ? `${row.func.nome} · ${row.data.split('-').reverse().join('/')} · ${obra || 'Sem obra'} · ${row.status}` : label;
  return <td className="border-b border-r border-border p-1 align-middle">
    <button onClick={onClick} title={title} className="relative flex h-11 w-full min-w-12 items-center justify-center rounded-md border border-border/70 px-1 text-[10px] font-bold shadow-sm transition-opacity hover:opacity-80" style={obra ? { backgroundColor: color, color: corTexto(color) } : undefined}>
      {obra ? siglaObra(obra) : row ? 'S/O' : '—'}
      {records.length > 0 && <span className="absolute bottom-0.5 left-0.5 flex gap-0.5">{records.some((item) => item.origem === 'IMPORTADO') && <i className="rounded bg-card/80 px-0.5 text-[7px] not-italic text-foreground">I</i>}{records.some((item) => item.origem === 'MANUAL') && <i className="rounded bg-card/80 px-0.5 text-[7px] not-italic text-foreground">M</i>}</span>}
      <Icon className={`absolute right-0.5 top-0.5 h-3 w-3 ${obra ? '' : row?.status === 'INCONSISTÊNCIA' ? 'text-destructive' : 'text-muted-foreground'}`} />
    </button>
  </td>;
}