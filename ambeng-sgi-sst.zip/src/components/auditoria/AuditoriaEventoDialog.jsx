import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

export default function AuditoriaEventoDialog({ evento, onClose }) {
  return (
    <Dialog open={Boolean(evento)} onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Detalhe do evento</DialogTitle></DialogHeader>
        {evento && <dl className="grid gap-3 text-sm">
          {[['Data', `${evento.data || '—'} ${evento.hora || ''}`], ['Tipo', evento.tipo], ['Ação', evento.acao], ['Usuário', evento.usuario], ['Entidade/Alvo', evento.alvo]].map(([label, value]) => (
            <div key={label} className="grid grid-cols-[120px_1fr] gap-3 border-b border-border pb-2">
              <dt className="text-muted-foreground">{label}</dt><dd className="font-medium text-foreground">{value || '—'}</dd>
            </div>
          ))}
        </dl>}
      </DialogContent>
    </Dialog>
  );
}