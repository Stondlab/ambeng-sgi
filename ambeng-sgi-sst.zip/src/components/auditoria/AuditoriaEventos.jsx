import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Download, History } from 'lucide-react';
import AuditoriaEventoDialog from '@/components/auditoria/AuditoriaEventoDialog';

export default function AuditoriaEventos() {
  const [eventos, setEventos] = useState([]);
  const [filtros, setFiltros] = useState({ tipo: 'todos', de: '', ate: '', usuario: '', entidade: '' });
  const [selecionado, setSelecionado] = useState(null);
  useEffect(() => { base44.entities.Auditoria.list('-data', 500).then(setEventos).catch(() => setEventos([])); }, []);
  const tipos = useMemo(() => [...new Set(eventos.map((e) => e.tipo).filter(Boolean))], [eventos]);
  const lista = useMemo(() => eventos.filter((e) => {
    if (filtros.tipo !== 'todos' && e.tipo !== filtros.tipo) return false;
    if (filtros.de && e.data < filtros.de) return false;
    if (filtros.ate && e.data > filtros.ate) return false;
    if (filtros.usuario && !(e.usuario || '').toLowerCase().includes(filtros.usuario.toLowerCase())) return false;
    return !filtros.entidade || `${e.tipo || ''} ${e.alvo || ''}`.toLowerCase().includes(filtros.entidade.toLowerCase());
  }), [eventos, filtros]);
  const exportar = () => {
    const rows = [['Data', 'Hora', 'Tipo', 'Ação', 'Usuário', 'Entidade/Alvo'], ...lista.map((e) => [e.data, e.hora, e.tipo, e.acao, e.usuario, e.alvo])];
    const csv = rows.map((r) => r.map((v) => `"${String(v || '').replace(/"/g, '""')}"`).join(';')).join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = 'eventos-auditoria.csv'; link.click(); URL.revokeObjectURL(url);
  };
  return <div className="space-y-4">
    <div className="grid gap-3 rounded-xl border border-border bg-card p-4 sm:grid-cols-2 lg:grid-cols-5">
      <Select value={filtros.tipo} onValueChange={(tipo) => setFiltros({ ...filtros, tipo })}><SelectTrigger><SelectValue placeholder="Tipo" /></SelectTrigger><SelectContent><SelectItem value="todos">Todos os tipos</SelectItem>{tipos.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select>
      <Input type="date" value={filtros.de} onChange={(e) => setFiltros({ ...filtros, de: e.target.value })} aria-label="Data inicial" />
      <Input type="date" value={filtros.ate} onChange={(e) => setFiltros({ ...filtros, ate: e.target.value })} aria-label="Data final" />
      <Input value={filtros.usuario} onChange={(e) => setFiltros({ ...filtros, usuario: e.target.value })} placeholder="Usuário" />
      <Input value={filtros.entidade} onChange={(e) => setFiltros({ ...filtros, entidade: e.target.value })} placeholder="Entidade ou alvo" />
    </div>
    <div className="flex items-center justify-between"><p className="text-sm text-muted-foreground">{lista.length} evento(s)</p><Button variant="outline" onClick={exportar}><Download className="h-4 w-4" />Exportar</Button></div>
    <div className="rounded-xl border border-border bg-card p-4">{lista.length ? <div className="space-y-2">{lista.map((e) => <button key={e.id} onClick={() => setSelecionado(e)} className="flex min-h-[52px] w-full items-center gap-3 rounded-lg border border-border px-3 text-left hover:bg-muted"><History className="h-4 w-4 text-primary" /><span className="flex-1"><strong className="block text-sm">{e.acao || e.tipo}</strong><span className="text-xs text-muted-foreground">{e.usuario || '—'} · {e.alvo || '—'}</span></span><time className="text-xs text-muted-foreground">{e.data || '—'} {e.hora || ''}</time></button>)}</div> : <p className="py-8 text-center text-sm text-muted-foreground">Nenhum evento encontrado.</p>}</div>
    <AuditoriaEventoDialog evento={selecionado} onClose={() => setSelecionado(null)} />
  </div>;
}