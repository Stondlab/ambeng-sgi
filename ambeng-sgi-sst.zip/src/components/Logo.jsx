import React from 'react';
import { Link } from 'react-router-dom';

export default function Logo({ size = 36, variant = 'full', tone = 'light', collapsed = false, onClick }) {
  const wordmark = tone === 'light' ? 'text-white' : 'text-primary';
  const sub = tone === 'light' ? 'text-white/50' : 'text-slate-400';
  return (
    <Link to="/" onClick={onClick} className="flex items-center gap-2.5 overflow-hidden">
      <span className="shrink-0" style={{ width: size, height: size }}>
        <img
          src="https://media.base44.com/images/public/6a760a7aa90c4cdeb50d7009/5e755b9ff_ambeng.png"
          alt="AMBENG"
          width={size}
          height={size}
          style={{ width: size, height: size, objectFit: 'contain' }}
          draggable={false}
        />
      </span>
      {variant === 'full' && !collapsed && (
        <span className="flex flex-col leading-none">
          <span className={`font-heading font-bold text-base tracking-wide ${wordmark}`}>AMBENG</span>
          <span className={`text-[10px] font-medium tracking-[0.18em] ${sub}`}>SGI · SST</span>
        </span>
      )}
    </Link>
  );
}