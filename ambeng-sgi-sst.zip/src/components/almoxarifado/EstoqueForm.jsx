import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { base44 } from '@/api/base44Client';

export default function EstoqueForm({ tipo, obras, open, onClose, onSaved }) {
  const [form, setForm] = useState({ nome: '', obra: '', quantidade: 0, minimo: 0, detalhe: '', ca: '' });
  const save = async (event) => { event.preventDefault(); const obra = obras.find((o) => o.id === form.obra); if (tipo === 'EPI') await base44.entities.EstoqueEPI.create({ nome: form.nome, obra: obra?.nome || '', ca: form.ca, estoque_atual: Number(form.quantidade), estoque_minimo: Number(form.minimo) }); else await base44.entities.EstoqueAlmoxarifado.create({ nome: form.nome, tipo, obra_id: obra?.id || '', obra: obra?.nome || '', quantidade_atual: Number(form.quantidade), quantidade_minima: Number(form.minimo), unidade: form.detalhe || 'un' }); onSaved(); };
  return <Dialog open={open} onOpenChange={(value) => !value && onClose()}><DialogContent><DialogHeader><DialogTitle>Novo item · {tipo}</DialogTitle></DialogHeader><form onSubmit={save} className="space-y-4">
    <div><Label>Nome</Label><Input className="mt-1" required value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} /></div>
    <div><Label>Obra</Label><Select value={form.obra} onValueChange={(obra) => setForm({ ...form, obra })}><SelectTrigger className="mt-1"><SelectValue placeholder="Estoque geral" /></SelectTrigger><SelectContent>{obras.map((obra) => <SelectItem key={obra.id} value={obra.id}>{obra.nome}</SelectItem>)}</SelectContent></Select></div>
    <div className="grid grid-cols-2 gap-3"><div><Label>Quantidade</Label><Input className="mt-1" type="number" min="0" value={form.quantidade} onChange={(e) => setForm({ ...form, quantidade: e.target.value })} /></div><div><Label>Estoque mínimo</Label><Input className="mt-1" type="number" min="0" value={form.minimo} onChange={(e) => setForm({ ...form, minimo: e.target.value })} /></div></div>
    {tipo === 'EPI' ? <div><Label>CA</Label><Input className="mt-1" value={form.ca} onChange={(e) => setForm({ ...form, ca: e.target.value })} /></div> : <div><Label>Unidade</Label><Input className="mt-1" placeholder="un, kg, m..." value={form.detalhe} onChange={(e) => setForm({ ...form, detalhe: e.target.value })} /></div>}
    <div className="flex justify-end gap-2"><Button type="button" variant="outline" onClick={onClose}>Cancelar</Button><Button type="submit">Salvar</Button></div>
  </form></DialogContent></Dialog>;
}