import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function RequisicaoForm({ obras, open, onClose, onSaved }) {
  const [form, setForm] = useState({ tipo_item: 'EPI', item_nome: '', obra: '', quantidade: 1, solicitante: '', observacoes: '' });
  const save = async (event) => { event.preventDefault(); const obra = obras.find((o) => o.id === form.obra); await base44.entities.RequisicoesAlmoxarifado.create({ ...form, obra_id: obra?.id || '', obra: obra?.nome || '', quantidade: Number(form.quantidade), data_solicitacao: new Date().toISOString().slice(0, 10), status: 'Pendente' }); onSaved(); };
  return <Dialog open={open} onOpenChange={(value) => !value && onClose()}><DialogContent><DialogHeader><DialogTitle>Nova requisição</DialogTitle></DialogHeader><form onSubmit={save} className="space-y-4">
    <div><Label>Tipo</Label><Select value={form.tipo_item} onValueChange={(tipo_item) => setForm({ ...form, tipo_item })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{['EPI', 'Ferramenta', 'Material'].map((tipo) => <SelectItem key={tipo} value={tipo}>{tipo}</SelectItem>)}</SelectContent></Select></div>
    <div><Label>Item</Label><Input className="mt-1" required value={form.item_nome} onChange={(e) => setForm({ ...form, item_nome: e.target.value })} /></div>
    <div className="grid grid-cols-2 gap-3"><div><Label>Obra</Label><Select value={form.obra} onValueChange={(obra) => setForm({ ...form, obra })}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{obras.map((obra) => <SelectItem key={obra.id} value={obra.id}>{obra.nome}</SelectItem>)}</SelectContent></Select></div><div><Label>Quantidade</Label><Input className="mt-1" type="number" min="1" value={form.quantidade} onChange={(e) => setForm({ ...form, quantidade: e.target.value })} /></div></div>
    <div><Label>Solicitante</Label><Input className="mt-1" value={form.solicitante} onChange={(e) => setForm({ ...form, solicitante: e.target.value })} /></div>
    <div className="flex justify-end gap-2"><Button type="button" variant="outline" onClick={onClose}>Cancelar</Button><Button type="submit">Criar requisição</Button></div>
  </form></DialogContent></Dialog>;
}