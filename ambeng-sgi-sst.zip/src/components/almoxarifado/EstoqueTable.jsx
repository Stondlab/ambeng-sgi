import React from 'react';
import { Minus, Plus, Trash2 } from 'lucide-react';

export default function EstoqueTable({ itens, tipo, podeEditar, podeExcluir, onQuantidade, onExcluir }) {
  const atual = (item) => tipo === 'EPI' ? item.estoque_atual : item.quantidade_atual;
  const minimo = (item) => tipo === 'EPI' ? item.estoque_minimo : item.quantidade_minima;
  return <div className="overflow-x-auto rounded-lg border border-border bg-card"><table className="w-full text-sm">
    <thead className="bg-muted text-xs uppercase text-muted-foreground"><tr><th className="px-4 py-3 text-left">Item</th><th className="px-4 py-3 text-left">Obra</th><th className="px-4 py-3 text-left">Detalhe</th><th className="px-4 py-3 text-center">Estoque</th><th className="px-4 py-3 text-center">Mínimo</th><th className="px-4 py-3" /></tr></thead>
    <tbody className="divide-y divide-border">{!itens.length && <tr><td colSpan={6} className="px-4 py-10 text-center text-muted-foreground">Nenhum item cadastrado.</td></tr>}{itens.map((item) => <tr key={item.id}>
      <td className="px-4 py-3 font-medium text-foreground">{item.nome}</td><td className="px-4 py-3 text-muted-foreground">{item.obra || 'Geral'}</td><td className="px-4 py-3 text-muted-foreground">{tipo === 'EPI' ? `CA ${item.ca || '—'}` : item.localizacao || item.unidade || '—'}</td>
      <td className={`px-4 py-3 text-center font-semibold ${atual(item) <= minimo(item) ? 'text-destructive' : 'text-foreground'}`}>{atual(item) || 0}</td><td className="px-4 py-3 text-center text-muted-foreground">{minimo(item) || 0}</td>
      <td className="px-4 py-3"><div className="flex justify-end gap-1">{podeEditar && <><button className="min-h-10 min-w-10 rounded-md text-success hover:bg-muted" onClick={() => onQuantidade(item, 1)}><Plus className="mx-auto h-4 w-4" /></button><button className="min-h-10 min-w-10 rounded-md text-warning hover:bg-muted" onClick={() => onQuantidade(item, -1)}><Minus className="mx-auto h-4 w-4" /></button></>}{podeExcluir && <button className="min-h-10 min-w-10 rounded-md text-destructive hover:bg-muted" onClick={() => onExcluir(item)}><Trash2 className="mx-auto h-4 w-4" /></button>}</div></td>
    </tr>)}</tbody>
  </table></div>;
}