import React from 'react';
import { getStatus, statusStyles, diasRestantes } from '@/lib/sst';

export default function StatusBadge({ data_validade }) {
  const status = getStatus(data_validade);
  const d = diasRestantes(data_validade);
  const label = status === 'Vencido' ? `Vencido (${Math.abs(d)}d)`
    : status === 'A vencer' ? `A vencer (${d}d)` : 'Em dia';
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium whitespace-nowrap ${statusStyles[status]}`}>
      {label}
    </span>
  );
}