import React from 'react';
import { ChevronDown } from 'lucide-react';

export function Badge({ status = 'info', children }) {
  const tones = { success: 'border-success/30 bg-success/10 text-success', warning: 'border-warning/30 bg-warning/10 text-warning', error: 'border-destructive/30 bg-destructive/10 text-destructive', info: 'border-primary/30 bg-primary/10 text-primary' };
  return <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold ${tones[status]}`}>{children}</span>;
}

export function Card({ label, value, status, actions }) {
  return <div className="rounded-md border border-border bg-muted/40 p-4"><div className="mb-2 flex items-center justify-between gap-2"><span className="text-xs font-medium text-muted-foreground">{label}</span>{status && <Badge status={status}>{status}</Badge>}</div><p className="font-semibold text-foreground">{value || '—'}</p>{actions && <div className="mt-4 flex flex-wrap gap-2">{actions}</div>}</div>;
}

export function Section({ id, title, icon: Icon, open, onToggle, children, badge, fixed = false }) {
  return <section className="overflow-hidden rounded-lg border border-border bg-card shadow-card"><button type="button" onClick={() => !fixed && onToggle?.(id)} className={`flex min-h-14 w-full items-center justify-between gap-3 px-4 py-3 text-left ${fixed ? 'cursor-default' : 'hover:bg-muted/60'}`}><span className="flex min-w-0 items-center gap-3">{Icon && <Icon className="h-5 w-5 shrink-0 text-primary" />}<span className="font-semibold text-foreground">{title}</span>{badge && <Badge>{badge}</Badge>}</span>{!fixed && <ChevronDown className={`h-5 w-5 shrink-0 text-muted-foreground transition-transform ${open ? 'rotate-180' : ''}`} />}</button>{open && <div className="border-t border-border p-4">{children}</div>}</section>;
}

export function Resumo360({ children }) {
  return <section className="rounded-lg border border-primary/20 bg-primary/5 p-4"><h2 className="mb-4 text-lg font-semibold text-foreground">Resumo 360°</h2>{children}</section>;
}

export default Section;