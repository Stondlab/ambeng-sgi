import React from 'react';
import { AlertTriangle, GraduationCap, HardHat, Stethoscope } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ACTIONS = [{ label: 'Agendar ASO', icon: Stethoscope, target: ['conformidade', 'saude'], primary: true }, { label: 'Registrar Treino', icon: GraduationCap, target: ['conformidade', 'treinamentos'] }, { label: 'Entregar EPI', icon: HardHat, target: ['conformidade', 'epis'] }, { label: 'Ocorrência', icon: AlertTriangle, target: ['conformidade', 'ocorrencias'] }];
export default function QuickActions({ onAction }) {
  return <div className="sticky bottom-3 z-20 grid grid-cols-2 gap-2 rounded-lg border border-border bg-card/95 p-3 shadow-lg backdrop-blur md:grid-cols-4">{ACTIONS.map(({ label, icon: Icon, target, primary }) => <Button key={label} variant={primary ? 'default' : 'outline'} onClick={() => onAction(...target)} className="min-w-0"><Icon className="h-4 w-4" /><span className="truncate">{label}</span></Button>)}</div>;
}