import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/Prontuario/SectionComponent';

export default function PontoResumoFuncionario({ funcionarioId }) {
  const [registros, setRegistros] = useState(null);
  useEffect(() => { base44.entities.Ponto.filter({ funcionario_id: funcionarioId }, '-data', 100).then(setRegistros); }, [funcionarioId]);
  const resumo = useMemo(() => { const hoje = new Date().toISOString().slice(0, 10); const mes = hoje.slice(0, 7); const atuais = (registros || []).filter((r) => r.data?.startsWith(mes)); return { hoje: (registros || []).find((r) => r.data === hoje), dias: atuais.length, atrasos: atuais.filter((r) => r.status === 'Atrasado').length, faltas: atuais.filter((r) => r.status === 'Falta').length }; }, [registros]);
  if (!registros) return <p className="text-sm text-muted-foreground">Carregando jornada...</p>;
  return <div className="space-y-4"><div className="grid gap-3 sm:grid-cols-3"><Card label="Hoje" value={resumo.hoje ? `${resumo.hoje.status || 'Presente'} · ${resumo.hoje.total_horas || 'horas pendentes'}` : 'Sem marcação'} status={resumo.hoje?.status === 'Atrasado' ? 'warning' : undefined} /><Card label="Este mês" value={`${resumo.dias} dia(s) registrado(s)`} /><Card label="Ocorrências no mês" value={`${resumo.atrasos} atraso(s) · ${resumo.faltas} falta(s)`} /></div><Button asChild variant="outline"><Link to="/colaboradores/ponto">Ver detalhes do ponto</Link></Button></div>;
}