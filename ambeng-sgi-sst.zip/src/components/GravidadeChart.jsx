import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

const COLORS = { 'Alta': '#dc2626', 'Média': '#d97706', 'Baixa': '#059669' };

export default function GravidadeChart({ ocorrencias }) {
  const data = useMemo(() => {
    const counts = { 'Alta': 0, 'Média': 0, 'Baixa': 0 };
    ocorrencias.forEach((o) => { if (o.gravidade in counts) counts[o.gravidade]++; });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [ocorrencias]);

  const total = data.reduce((s, d) => s + d.value, 0);

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-1">Ocorrências por gravidade</h3>
      <p className="text-xs text-slate-400 mb-4">{total} registro(s) no total</p>
      {total === 0 ? (
        <p className="text-sm text-slate-400 py-10 text-center">Sem ocorrências registradas.</p>
      ) : (
        <ResponsiveContainer width="100%" height={240}>
          <PieChart>
            <Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={85} paddingAngle={2}>
              {data.map((d) => <Cell key={d.name} fill={COLORS[d.name]} />)}
            </Pie>
            <Tooltip formatter={(v) => [`${v} ocorrência(s)`, '']} />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}