import React, { useMemo, useState } from 'react';
import { getStatus, fmt } from '@/lib/sst';
import { CheckCircle2, Clock, XCircle, Minus, Plus } from 'lucide-react';

const TIPOS = ['Capacete', 'Cinto de Segurança', 'Luva Isolante', 'Botina de Segurança', 'Óculos de Proteção', 'Protetor Auricular'];

function statusInfo(e) {
  const s = getStatus(e?.data_validade);
  if (!e) return { icon: Minus, color: 'text-slate-300', bg: '', label: 'Não entregue' };
  if (s === 'Em dia') return { icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50', label: 'Em dia' };
  if (s === 'A vencer') return { icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50', label: 'A vencer' };
  return { icon: XCircle, color: 'text-red-600', bg: 'bg-red-50', label: 'Vencido' };
}

export default function MatrizEPIs({ funcionarios, epis, onSelect, onEntrega, podeEntregar = true }) {
  const [tipos] = useState(TIPOS);
  const matrix = useMemo(() => funcionarios.map((f) => {
    const cells = {};
    tipos.forEach((t) => { cells[t] = epis.filter((e) => e.funcionario_id === f.id && e.item === t).sort((a, b) => (b.data_entrega || '').localeCompare(a.data_entrega || ''))[0] || null; });
    return { func: f, cells };
  }), [funcionarios, epis, tipos]);

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-500 text-xs">
            <tr>
              <th className="text-left px-3 py-3 sticky left-0 bg-slate-50 min-w-[160px]">Funcionário</th>
              {tipos.map((t) => <th key={t} className="px-2 py-3 text-center min-w-[80px]">{t.split(' ')[0]}</th>)}
              <th className="px-3 py-3 text-center min-w-[80px]">Ação</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {matrix.map(({ func, cells }) => (
              <tr key={func.id} className="hover:bg-slate-50">
                <td className="px-3 py-2.5 font-medium text-[#0b2545] sticky left-0 bg-white">{func.nome}</td>
                {tipos.map((t) => {
                  const info = statusInfo(cells[t]);
                  const Icon = info.icon;
                  return (
                    <td key={t} className="px-2 py-2.5 text-center">
                      <button onClick={() => onSelect && onSelect({ func, epi: cells[t], tipo: t })} className={`w-9 h-9 rounded-lg flex items-center justify-center ${info.bg} hover:ring-2 hover:ring-[#0b2545]/30`} title={cells[t] ? `${info.label} · vence ${fmt(cells[t].data_validade)}` : 'Não entregue'}>
                        <Icon className={`w-5 h-5 ${info.color}`} />
                      </button>
                    </td>
                  );
                })}
                <td className="px-2 py-2.5 text-center">
                  {podeEntregar ? (
                    <button onClick={() => onEntrega && onEntrega(func)} className="min-h-[44px] px-2 inline-flex items-center gap-1 text-xs text-amber-600 font-medium hover:underline"><Plus className="w-4 h-4" />Entregar</button>
                  ) : <span className="text-xs text-slate-300">—</span>}
                </td>
              </tr>
            ))}
            {matrix.length === 0 && <tr><td colSpan={tipos.length + 2} className="px-4 py-10 text-center text-slate-400">Nenhum funcionário.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export { TIPOS };