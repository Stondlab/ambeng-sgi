import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Check, Download, AlertTriangle, RefreshCw, ChevronDown, ChevronRight } from 'lucide-react';

export default function ImportResultPanel({ resultado, onAgain, onDownload, onDownloadErrors }) {
  const [showErrors, setShowErrors] = useState(false);
  const erros = resultado.detalhes.filter((d) => d.errors.length > 0);

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Check className="w-5 h-5 text-emerald-600" />
          <h3 className="font-semibold text-[#0b2545]">Importação concluída</h3>
        </div>
        <p className="text-sm text-slate-500 mb-4">{resultado.analisados} registros analisados</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-emerald-50 rounded-lg p-3 text-center"><p className="text-xl font-bold text-emerald-700">{resultado.importados}</p><p className="text-xs text-emerald-700">Importados</p></div>
          <div className="bg-blue-50 rounded-lg p-3 text-center"><p className="text-xl font-bold text-blue-700">{resultado.atualizados}</p><p className="text-xs text-blue-700">Atualizados</p></div>
          <div className="bg-slate-100 rounded-lg p-3 text-center"><p className="text-xl font-bold text-slate-600">{resultado.ignorados}</p><p className="text-xs text-slate-500">Ignorados</p></div>
          <div className="bg-red-50 rounded-lg p-3 text-center"><p className="text-xl font-bold text-red-700">{resultado.comErro}</p><p className="text-xs text-red-700">Com erro</p></div>
        </div>
      </div>

      {erros.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-xl">
          <button onClick={() => setShowErrors((s) => !s)} className="w-full flex items-center gap-2 px-4 py-3 text-sm font-medium text-red-700">
            {showErrors ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            <AlertTriangle className="w-4 h-4" />{erros.length} registro(s) com erro — clique para {showErrors ? 'ocultar' : 'ver'}
          </button>
          {showErrors && (
            <div className="border-t border-slate-100 max-h-64 overflow-y-auto">
              <table className="w-full text-sm">
                <tbody className="divide-y divide-slate-100">
                  {erros.map((d) => (
                    <tr key={d.idx}><td className="px-3 py-2 text-slate-400 w-10">{d.idx}</td><td className="px-3 py-2 text-red-600">{d.errors.join(' | ')}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      <div className="flex flex-wrap justify-between gap-2">
        <div className="flex gap-2">
          <Button variant="outline" onClick={onDownload}><Download className="w-4 h-4 mr-1" />Relatório completo</Button>
          {erros.length > 0 && <Button variant="outline" onClick={onDownloadErrors}><AlertTriangle className="w-4 h-4 mr-1" />Baixar erros</Button>}
        </div>
        <Button onClick={onAgain} className="bg-[#0b2545] hover:bg-[#16365f]"><RefreshCw className="w-4 h-4 mr-1" />Nova importação</Button>
      </div>
    </div>
  );
}