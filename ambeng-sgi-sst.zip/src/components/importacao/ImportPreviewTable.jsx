import React, { useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { fmtMoney } from '@/lib/importacaoDados';

const ST = { novo: 'bg-emerald-100 text-emerald-700', existente: 'bg-amber-100 text-amber-700', erro: 'bg-red-100 text-red-700' };
const STLBL = { novo: 'Novo', existente: 'Existente', erro: 'Com erro' };
const FILTROS = [
  { id: 'todos', label: 'Todos' },
  { id: 'novo', label: 'Novos' },
  { id: 'aviso', label: 'Não vinculado' },
  { id: 'erro', label: 'Com erro' },
];

export default function ImportPreviewTable({ cfg, rows }) {
  const [filtro, setFiltro] = useState('todos');
  const count = (f) =>
    f === 'todos' ? rows.length
      : f === 'aviso' ? rows.filter((r) => r.tipo !== 'erro' && r.warnings?.length).length
        : rows.filter((r) => r.tipo === f).length;
  const filtrados = filtro === 'todos' ? rows
    : filtro === 'aviso' ? rows.filter((r) => r.tipo !== 'erro' && r.warnings?.length)
      : rows.filter((r) => r.tipo === filtro);

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div className="flex items-center gap-2 px-3 py-2 border-b border-slate-100 overflow-x-auto">
        {FILTROS.map((f) => (
          <button
            key={f.id}
            onClick={() => setFiltro(f.id)}
            className={`text-xs px-3 py-1.5 rounded-full whitespace-nowrap transition ${filtro === f.id ? 'bg-[#0b2545] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
          >
            {f.label} ({count(f.id)})
          </button>
        ))}
      </div>
      <div className="overflow-x-auto max-h-80">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-500 text-xs uppercase sticky top-0">
            <tr>
              <th className="text-left px-3 py-2">#</th>
              {cfg.preview.map((p) => <th key={p.field} className="text-left px-3 py-2">{p.label}</th>)}
              <th className="text-left px-3 py-2">Status</th>
              <th className="text-left px-3 py-2">Observações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtrados.map((r) => (
              <tr key={r.idx} className={r.tipo === 'erro' ? 'bg-red-50/40' : 'hover:bg-slate-50'}>
                <td className="px-3 py-2 text-slate-400">{r.idx}</td>
                {cfg.preview.map((p) => (
                  <td key={p.field} className="px-3 py-2 text-slate-700">
                    {p.money ? fmtMoney(r.record[p.field]) : (r.record[p.field] || '—')}
                  </td>
                ))}
                <td className="px-3 py-2">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${ST[r.tipo]}`}>{STLBL[r.tipo]}</span>
                  {r.errors.length === 0 && r.warnings?.length > 0 && <span className="block text-[10px] text-amber-600 mt-0.5">não vinculado</span>}
                </td>
                <td className="px-3 py-2 text-xs max-w-xs">
                  {r.errors.length > 0 && <span className="inline-flex items-start gap-1 text-red-600"><AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />{r.errors.join(' | ')}</span>}
                  {r.errors.length === 0 && r.warnings?.length > 0 && <span className="inline-flex items-start gap-1 text-amber-600"><AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />{r.warnings.join(' | ')}</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}