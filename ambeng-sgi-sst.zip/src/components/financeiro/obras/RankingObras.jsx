import React, { useMemo, useState } from 'react';
import { fmtMoney } from '@/lib/financeiro';

const COLS = [
  { key: 'receita', label: 'Receita', get: (o) => o.fin.receitaPrevista, fmt: fmtMoney, estrategico: true },
  { key: 'lucro', label: 'Lucro previsto', get: (o) => o.fin.lucroPrevisto, fmt: fmtMoney, estrategico: true },
  { key: 'margem', label: 'Margem', get: (o) => o.fin.margemPrevista, fmt: (v) => (v == null ? '—' : `${v.toFixed(1)}%`), estrategico: true },
  { key: 'custo', label: 'Custo', get: (o) => o.fin.custoRealizado, fmt: fmtMoney, estrategico: false },
  { key: 'orc', label: 'Orç. utilizado', get: (o) => o.fin.pctOrc, fmt: (v) => (v == null ? '—' : `${v.toFixed(0)}%`), estrategico: false },
  { key: 'aReceber', label: 'A receber', get: (o) => o.fin.receitaPrevista - o.fin.receitaRecebida, fmt: fmtMoney, estrategico: true },
  { key: 'aPagar', label: 'A pagar', get: (o) => o.fin.aPagar, fmt: fmtMoney, estrategico: false },
  { key: 'risco', label: 'Risco', get: (o) => (o.fin.situacao === 'risco' ? 1 : 0), fmt: (v) => (v ? '🔴' : '—'), estrategico: false },
];

export default function RankingObras({ obras, podeVerEstrategico }) {
  const [sortKey, setSortKey] = useState('lucro');
  const [dir, setDir] = useState('desc');

  const cols = COLS.filter((c) => c.estrategico || true).filter((c) => podeVerEstrategico || !c.estrategico);
  const sorted = useMemo(() => {
    const col = COLS.find((c) => c.key === sortKey) || COLS[0];
    return [...obras].sort((a, b) => {
      const av = col.get(a) ?? -Infinity; const bv = col.get(b) ?? -Infinity;
      return dir === 'desc' ? bv - av : av - bv;
    });
  }, [obras, sortKey, dir]);

  const toggle = (k) => { if (k === sortKey) setDir(dir === 'desc' ? 'asc' : 'desc'); else { setSortKey(k); setDir('desc'); } };

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <h3 className="font-semibold text-[#0b2545] mb-3">Ranking Financeiro</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-xs uppercase text-slate-500 bg-slate-50">
            <tr>
              <th className="text-left px-3 py-2">Obra</th>
              {cols.map((c) => (
                <th key={c.key} className="text-right px-3 py-2 cursor-pointer select-none hover:text-[#0b2545]" onClick={() => toggle(c.key)}>
                  {c.label}{sortKey === c.key ? (dir === 'desc' ? ' ↓' : ' ↑') : ''}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sorted.map((o) => (
              <tr key={o.id} className="hover:bg-slate-50">
                <td className="px-3 py-2.5 font-medium text-[#0b2545] truncate max-w-[200px]">{o.nome}</td>
                {cols.map((c) => {
                  const v = c.get(o);
                  let cls = 'text-slate-700';
                  if (c.key === 'lucro' || c.key === 'margem') cls = v >= 0 ? 'text-emerald-700' : 'text-red-600';
                  if (c.key === 'orc' && v != null && v > 100) cls = 'text-red-600';
                  return <td key={c.key} className={`px-3 py-2.5 text-right ${cls}`}>{c.fmt(v)}</td>;
                })}
              </tr>
            ))}
            {!sorted.length && <tr><td colSpan={cols.length + 1} className="px-3 py-8 text-center text-slate-400">Sem obras.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}