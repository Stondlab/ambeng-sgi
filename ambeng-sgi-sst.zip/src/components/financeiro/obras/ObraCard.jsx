import React from 'react';
import { fmtMoney, shortDate } from '@/lib/financeiro';
import { Pencil, Trash2 } from 'lucide-react';

const ST = {
  'Planejamento': 'bg-slate-100 text-slate-600',
  'Em andamento': 'bg-blue-100 text-blue-700',
  'Pausada': 'bg-amber-100 text-amber-700',
  'Concluída': 'bg-emerald-100 text-emerald-700',
};

function Bloco({ titulo, linhas, pos }) {
  return (
    <div className="rounded-lg bg-slate-50 p-3">
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-2">{titulo}</p>
      <div className="space-y-1">
        {linhas.map(([l, v]) => (
          <div key={l} className="flex justify-between text-sm">
            <span className="text-slate-500">{l}</span>
            <span className={`font-medium ${pos ? 'text-emerald-700' : 'text-red-600'}`}>{fmtMoney(v)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function ObraCard({ obra, receitas, despesas, onEdit, onDelete, podeEditar = true, podeExcluir = true }) {
  const recPrev = receitas.filter((r) => r.status === 'Prevista').reduce((s, r) => s + (Number(r.valor) || 0), 0);
  const recReceb = receitas.filter((r) => r.status === 'Recebida').reduce((s, r) => s + (Number(r.valor) || 0), 0);
  const despTotal = despesas.reduce((s, d) => s + (Number(d.valor) || 0), 0);
  const despPago = despesas.filter((d) => d.status === 'Pago').reduce((s, d) => s + (Number(d.valor) || 0), 0);
  const totalPrev = recPrev + recReceb;
  const lucroPrev = totalPrev - despTotal;
  const lucroEfet = recReceb - despPago;
  const pctOrc = obra.orcamento > 0 ? Math.min(100, (despTotal / obra.orcamento) * 100) : null;

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-semibold text-[#0b2545] truncate">{obra.nome}</h3>
            <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${ST[obra.status] || ST['Planejamento']}`}>{obra.status}</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {obra.cliente ? `Cliente: ${obra.cliente}` : ''}
            {obra.responsavel ? `${obra.cliente ? ' · ' : ''}Resp.: ${obra.responsavel}` : ''}
            {obra.data_inicio ? `${obra.cliente || obra.responsavel ? ' · ' : ''}Início: ${shortDate(obra.data_inicio)}` : ''}
          </p>
        </div>
        <div className="flex gap-1 shrink-0">
          {podeEditar && <button onClick={onEdit} className="p-1.5 text-slate-400 hover:text-[#0b2545]" title="Editar"><Pencil className="w-4 h-4" /></button>}
          {podeExcluir && <button onClick={onDelete} className="p-1.5 text-slate-400 hover:text-red-500" title="Excluir"><Trash2 className="w-4 h-4" /></button>}
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-3">
        <Bloco titulo="Receitas" linhas={[['Previsto', recPrev], ['Recebido', recReceb]]} pos />
        <Bloco titulo="Despesas" linhas={[['Total', despTotal], ['Pago', despPago]]} />
      </div>

      <div className="grid sm:grid-cols-2 gap-3 mt-3 pt-3 border-t border-slate-100">
        <div className="flex justify-between text-sm"><span className="text-slate-500">Lucro previsto</span><span className={`font-semibold ${lucroPrev >= 0 ? 'text-emerald-700' : 'text-red-600'}`}>{fmtMoney(lucroPrev)}</span></div>
        <div className="flex justify-between text-sm"><span className="text-slate-500">Lucro efetivado</span><span className={`font-semibold ${lucroEfet >= 0 ? 'text-emerald-700' : 'text-red-600'}`}>{fmtMoney(lucroEfet)}</span></div>
      </div>

      {pctOrc != null && (
        <div className="mt-3 pt-3 border-t border-slate-100">
          <div className="flex justify-between text-xs mb-1"><span className="text-slate-500">Orçamento utilizado</span><span className="font-medium text-[#0b2545]">{pctOrc.toFixed(0)}% · {fmtMoney(despTotal)} / {fmtMoney(obra.orcamento)}</span></div>
          <div className="h-2 rounded-full bg-slate-100 overflow-hidden"><div className={`h-full ${pctOrc >= 100 ? 'bg-red-500' : pctOrc >= 80 ? 'bg-amber-500' : 'bg-emerald-500'}`} style={{ width: `${pctOrc}%` }} /></div>
        </div>
      )}
    </div>
  );
}