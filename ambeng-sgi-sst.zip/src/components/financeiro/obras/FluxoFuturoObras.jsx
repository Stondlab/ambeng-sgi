import React, { useMemo, useState } from 'react';
import { fluxoFuturo } from '@/lib/obrasFinanceiro';
import { fmtMoney } from '@/lib/financeiro';

const PERIODOS = [7, 30, 60, 90];

export default function FluxoFuturoObras({ receitas, despesas, podeVerEstrategico }) {
  const [dias, setDias] = useState(30);
  const f = useMemo(() => fluxoFuturo(receitas, despesas, dias), [receitas, despesas, dias]);

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
        <h3 className="font-semibold text-[#0b2545]">Fluxo Futuro</h3>
        <div className="flex gap-1">
          {PERIODOS.map((p) => (
            <button key={p} onClick={() => setDias(p)} className={`text-xs px-3 py-1.5 rounded-lg ${dias === p ? 'bg-[#0b2545] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>{p} dias</button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-blue-50 rounded-lg p-3 text-center"><p className="text-xs text-blue-700">Receitas previstas</p><p className="text-lg font-bold text-blue-700">{fmtMoney(f.entradas)}</p></div>
        <div className="bg-slate-50 rounded-lg p-3 text-center"><p className="text-xs text-slate-600">Despesas previstas</p><p className="text-lg font-bold text-slate-700">{fmtMoney(f.saidas)}</p></div>
        <div className={`rounded-lg p-3 text-center ${f.saldo >= 0 ? 'bg-emerald-50' : 'bg-red-50'}`}><p className={`text-xs ${f.saldo >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>Saldo projetado</p><p className={`text-lg font-bold ${f.saldo >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>{fmtMoney(f.saldo)}</p></div>
      </div>
      {!podeVerEstrategico && <p className="text-xs text-slate-400 mt-2">Visão de receitas restrita ao perfil estratégico.</p>}
    </div>
  );
}