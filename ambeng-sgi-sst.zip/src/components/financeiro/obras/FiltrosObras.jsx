import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { SlidersHorizontal, X } from 'lucide-react';

const STATUS = ['Planejamento', 'Em andamento', 'Pausada', 'Concluída'];
const SITUACAO = [
  { id: 'saudavel', label: 'Saudável' },
  { id: 'atencao', label: 'Atenção' },
  { id: 'risco', label: 'Prejuízo / Orçamento estourado' },
];

export default function FiltrosObras({ filtros, setFiltros, responsaveis, clientes, mais, setMais, onClear }) {
  const set = (k, v) => setFiltros((p) => ({ ...p, [k]: v }));
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-3">
      <div className="flex flex-wrap items-center gap-2">
        <Select value={filtros.status} onValueChange={(v) => set('status', v)}>
          <SelectTrigger className="w-44 h-9"><SelectValue placeholder="Status da obra" /></SelectTrigger>
          <SelectContent><SelectItem value="all">Todos os status</SelectItem>{STATUS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={filtros.situacao} onValueChange={(v) => set('situacao', v)}>
          <SelectTrigger className="w-56 h-9"><SelectValue placeholder="Situação financeira" /></SelectTrigger>
          <SelectContent><SelectItem value="all">Todas as situações</SelectItem>{SITUACAO.map((s) => <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>)}</SelectContent>
        </Select>
        <Button variant="ghost" size="sm" onClick={() => setMais(!mais)}><SlidersHorizontal className="w-4 h-4 mr-1" />{mais ? 'Menos filtros' : 'Mais filtros'}</Button>
        <Button variant="ghost" size="sm" onClick={onClear}><X className="w-4 h-4 mr-1" />Limpar</Button>
      </div>
      {mais && (
        <div className="flex flex-wrap items-center gap-2 mt-3 pt-3 border-t border-slate-100">
          <Select value={filtros.responsavel} onValueChange={(v) => set('responsavel', v)}>
            <SelectTrigger className="w-48 h-9"><SelectValue placeholder="Responsável" /></SelectTrigger>
            <SelectContent><SelectItem value="all">Todos os responsáveis</SelectItem>{responsaveis.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={filtros.cliente} onValueChange={(v) => set('cliente', v)}>
            <SelectTrigger className="w-48 h-9"><SelectValue placeholder="Cliente" /></SelectTrigger>
            <SelectContent><SelectItem value="all">Todos os clientes</SelectItem>{clientes.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
}