import React from 'react';
import { fmtMoney } from '@/lib/financeiro';

const tone = (label, val, estrategico) => {
  if (!estrategico && ['Receita Prevista', 'Receita Recebida', 'Lucro Previsto', 'Lucro Realizado', 'Margem Média'].includes(label)) return null;
  const base = 'rounded-xl border p-4 transition hover:shadow-card-hover cursor-pointer text-left';
  switch (label) {
    case 'Receita Prevista': return `${base} bg-blue-50 border-blue-200 text-blue-700`;
    case 'Receita Recebida': return `${base} bg-emerald-50 border-emerald-200 text-emerald-700`;
    case 'Custo Total': return `${base} bg-slate-50 border-slate-200 text-slate-700`;
    case 'Custo Pago': return `${base} bg-slate-50 border-slate-200 text-slate-700`;
    case 'A Pagar': return `${base} bg-amber-50 border-amber-200 text-amber-700`;
    case 'Lucro Previsto': return `${base} ${val >= 0 ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-red-50 border-red-200 text-red-700'}`;
    case 'Lucro Realizado': return `${base} ${val >= 0 ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-red-50 border-red-200 text-red-700'}`;
    case 'Margem Média': return `${base} ${val >= 15 ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : val >= 0 ? 'bg-amber-50 border-amber-200 text-amber-700' : 'bg-red-50 border-red-200 text-red-700'}`;
    default: return base;
  }
};

export default function ResumoExecutivoObras({ resumo, podeVerEstrategico, onClick }) {
  const items = [
    { label: 'Receita Prevista', valor: resumo.receitaPrevista, fmt: fmtMoney, to: 'receitas' },
    { label: 'Receita Recebida', valor: resumo.receitaRecebida, fmt: fmtMoney, to: 'receitas' },
    { label: 'Custo Total', valor: resumo.custoTotal, fmt: fmtMoney, to: 'lista' },
    { label: 'Custo Pago', valor: resumo.custoPago, fmt: fmtMoney, to: 'lista' },
    { label: 'A Pagar', valor: resumo.aPagar, fmt: fmtMoney, to: 'despesas' },
    podeVerEstrategico && { label: 'Lucro Previsto', valor: resumo.lucroPrevisto, fmt: fmtMoney, to: 'lista' },
    podeVerEstrategico && { label: 'Lucro Realizado', valor: resumo.lucroRealizado, fmt: fmtMoney, to: 'lista' },
    podeVerEstrategico && { label: 'Margem Média', valor: resumo.margemMedia, fmt: (v) => (v == null ? '—' : `${v.toFixed(1)}%`), to: 'analise' },
  ].filter(Boolean);

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {items.map((it) => (
        <button key={it.label} onClick={() => onClick(it.to)} className={tone(it.label, it.valor, podeVerEstrategico)}>
          <p className="text-xs opacity-80">{it.label}</p>
          <p className="text-lg sm:text-xl font-bold leading-none mt-1">{it.fmt(it.valor)}</p>
        </button>
      ))}
    </div>
  );
}