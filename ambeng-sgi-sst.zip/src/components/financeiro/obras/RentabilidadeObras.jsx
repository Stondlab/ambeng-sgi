import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { rentabilidadeObras } from '@/lib/obrasFinanceiro';

const SIT_COLOR = { saudavel: 'bg-emerald-500', atencao: 'bg-amber-500', risco: 'bg-red-500' };
const LUCRO_COLOR = (v) => (v >= 0 ? 'text-emerald-700' : 'text-red-600');

export default function RentabilidadeObras({ obras, podeVerEstrategico }) {
  if (!podeVerEstrategico) return null;
  const rows = rentabilidadeObras(obras);
  const maxRec = Math.max(...rows.map((r) => r.receita), 1);

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <h3 className="font-semibold text-[#0b2545] mb-3">Rentabilidade por Obra</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-xs uppercase text-slate-500 bg-slate-50"><tr><th className="text-left px-3 py-2">Obra</th><th className="text-right px-3 py-2">Receita</th><th className="text-right px-3 py-2">Custo</th><th className="text-right px-3 py-2">Lucro</th><th className="text-left px-3 py-2 w-40">Margem</th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((r) => (
              <tr key={r.nome} className="hover:bg-slate-50">
                <td className="px-3 py-2.5 font-medium text-[#0b2545] truncate max-w-[180px]"><span className={`inline-block w-2 h-2 rounded-full mr-1.5 ${SIT_COLOR[r.situacao]}`} />{r.nome}</td>
                <td className="px-3 py-2.5 text-right text-blue-700">{fmtMoney(r.receita)}</td>
                <td className="px-3 py-2.5 text-right text-slate-600">{fmtMoney(r.custo)}</td>
                <td className={`px-3 py-2.5 text-right font-semibold ${LUCRO_COLOR(r.lucro)}`}>{fmtMoney(r.lucro)}</td>
                <td className="px-3 py-2.5">
                  <div className="flex items-center gap-2">
                    <div className="h-1.5 rounded-full bg-slate-100 flex-1 overflow-hidden"><div className={`h-full ${SIT_COLOR[r.situacao]}`} style={{ width: `${Math.max(2, Math.min(100, r.margem ?? 0))}%` }} /></div>
                    <span className="text-xs text-slate-500 w-12 text-right">{r.margem == null ? '—' : `${r.margem.toFixed(1)}%`}</span>
                  </div>
                </td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan={5} className="px-3 py-8 text-center text-slate-400">Sem obras.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}