import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { STATUS_OBRA } from '@/lib/financeiro';
import { X } from 'lucide-react';
import { applyTitleCaseAll } from '@/lib/titleCase';
import { validarDataOpcional, validarNumeroOpcional } from '@/lib/validacao';

function Field({ label, className, children }) {
  return <div className={className}><Label>{label}</Label><div className="mt-1">{children}</div></div>;
}

export default function ObraForm({ record, onClose, onSave }) {
  const isNew = !record.id;
  const [erro, setErro] = useState('');
  const [form, setForm] = useState(() => {
    const init = {};
    ['nome', 'cliente', 'status', 'responsavel', 'observacoes'].forEach((k) => { init[k] = record[k] ?? ''; });
    ['orcamento'].forEach((k) => { init[k] = record[k] ?? ''; });
    ['data_inicio', 'data_fim'].forEach((k) => { init[k] = record[k] ?? ''; });
    return init;
  });
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const submit = () => {
    if (!form.nome?.trim()) return setErro('Informe o nome da obra.');
    if (!validarNumeroOpcional(form.orcamento)) return setErro('Informe um orçamento numérico válido e não negativo.');
    if (!validarDataOpcional(form.data_inicio) || !validarDataOpcional(form.data_fim)) return setErro('Informe datas válidas.');
    if (form.data_inicio && form.data_fim && form.data_fim < form.data_inicio) return setErro('A data final não pode ser anterior à data inicial.');
    setErro(''); onSave(applyTitleCaseAll(form), record.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-xl bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">{isNew ? 'Nova Obra' : 'Editar Obra'}</h3><button type="button" onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field className="sm:col-span-2" label="Nome da obra *"><Input value={form.nome} onChange={(e) => set('nome', e.target.value)} /></Field>
          <Field label="Cliente"><Input value={form.cliente} onChange={(e) => set('cliente', e.target.value)} /></Field>
          <Field label="Responsável"><Input value={form.responsavel} onChange={(e) => set('responsavel', e.target.value)} /></Field>
          <Field label="Orçamento (R$)"><Input type="number" step="0.01" value={form.orcamento} onChange={(e) => set('orcamento', e.target.value)} /></Field>
          <Field label="Status"><Select value={form.status} onValueChange={(v) => set('status', v)}><SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{STATUS_OBRA.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></Field>
          <Field label="Data de início"><Input type="date" value={form.data_inicio} onChange={(e) => set('data_inicio', e.target.value)} /></Field>
          <Field label="Data de fim"><Input type="date" value={form.data_fim} onChange={(e) => set('data_fim', e.target.value)} /></Field>
          <Field className="sm:col-span-2" label="Observações"><Textarea rows={2} value={form.observacoes} onChange={(e) => set('observacoes', e.target.value)} /></Field>
        </div>
        {erro && <p className="text-sm text-red-600">{erro}</p>}
        <div className="flex justify-end gap-2 pt-2"><Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button><Button type="button" onClick={submit} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button></div>
      </div>
    </div>
  );
}