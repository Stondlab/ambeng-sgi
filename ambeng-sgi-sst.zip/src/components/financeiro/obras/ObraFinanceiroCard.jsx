import React from 'react';
import { useNavigate } from 'react-router-dom';
import { fmtMoney, shortDate } from '@/lib/financeiro';
import { Pencil, Trash2, ChevronRight } from 'lucide-react';

const ST = {
  'Planejamento': 'bg-slate-100 text-slate-600',
  'Em andamento': 'bg-blue-100 text-blue-700',
  'Pausada': 'bg-amber-100 text-amber-700',
  'Concluída': 'bg-emerald-100 text-emerald-700',
  'Cancelada': 'bg-slate-100 text-slate-500',
};
const SIT = { saudavel: 'bg-emerald-500', atencao: 'bg-amber-500', risco: 'bg-red-500' };
const SIT_LABEL = { saudavel: 'Saudável', atencao: 'Atenção', risco: 'Risco' };

function orcBarColor(pct) {
  if (pct == null) return 'bg-slate-300';
  if (pct > 100) return 'bg-red-500';
  if (pct >= 90) return 'bg-amber-500';
  if (pct >= 70) return 'bg-amber-400';
  return 'bg-emerald-500';
}

export default function ObraFinanceiroCard({ obra, podeEditar, podeExcluir, podeVerEstrategico, onEdit, onDelete }) {
  const navigate = useNavigate();
  const f = obra.fin;
  const meta = [obra.cliente && `Cliente: ${obra.cliente}`, obra.responsavel && `Resp.: ${obra.responsavel}`, obra.data_inicio && `Início: ${shortDate(obra.data_inicio)}`, obra.data_fim && `Término: ${shortDate(obra.data_fim)}`].filter(Boolean).join(' · ');
  const lucroColor = f.lucroPrevisto >= 0 ? 'text-emerald-700' : 'text-red-600';
  const margemStr = f.margemPrevista == null ? '—' : `${f.margemPrevista.toFixed(1)}%`;
  const pctOrcStr = f.pctOrc == null ? 'Orçamento não informado' : `${f.pctOrc.toFixed(0)}% utilizado`;

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 hover:shadow-card-hover transition cursor-pointer" onClick={() => navigate(`/obras/${obra.id}`)}>
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${SIT[f.situacao]}`} title={SIT_LABEL[f.situacao]} />
            <h3 className="font-semibold text-[#0b2545] truncate">{obra.nome}</h3>
            <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${ST[obra.status] || ST['Planejamento']}`}>{obra.status}</span>
          </div>
          {meta && <p className="text-xs text-slate-500 mt-1 truncate">{meta}</p>}
        </div>
        <div className="flex gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
          {podeEditar && <button onClick={onEdit} className="p-1.5 text-slate-400 hover:text-[#0b2545]" title="Editar"><Pencil className="w-4 h-4" /></button>}
          {podeExcluir && <button onClick={onDelete} className="p-1.5 text-slate-400 hover:text-red-500" title="Excluir"><Trash2 className="w-4 h-4" /></button>}
        </div>
      </div>

      {/* Resultado em destaque */}
      {podeVerEstrategico && (
        <div className="flex items-end justify-between bg-slate-50 rounded-lg px-3 py-2.5 mb-3">
          <div>
            <p className="text-[11px] uppercase tracking-wide text-slate-500">Resultado previsto</p>
            <p className={`text-2xl font-bold leading-none ${lucroColor}`}>{f.lucroPrevisto >= 0 ? '+' : ''}{fmtMoney(f.lucroPrevisto)}</p>
          </div>
          <div className="text-right">
            <p className="text-[11px] uppercase tracking-wide text-slate-500">Margem</p>
            <p className={`text-lg font-bold leading-none ${f.margemPrevista != null && f.margemPrevista < 0 ? 'text-red-600' : 'text-[#0b2545]'}`}>{margemStr}</p>
          </div>
        </div>
      )}

      {/* Comparativo previsto x realizado */}
      <div className="space-y-2 text-sm">
        {podeVerEstrategico && (
          <div>
            <div className="flex justify-between"><span className="text-slate-500">Receita prevista</span><span className="font-medium text-blue-700">{fmtMoney(f.receitaPrevista)}</span></div>
            <div className="flex justify-between"><span className="text-slate-400 text-xs pl-2">Recebido</span><span className="text-emerald-700 text-xs">{fmtMoney(f.receitaRecebida)}</span></div>
          </div>
        )}
        <div>
          <div className="flex justify-between"><span className="text-slate-500">Custo realizado</span><span className="font-medium text-slate-700">{fmtMoney(f.custoRealizado)}</span></div>
          <div className="flex justify-between"><span className="text-slate-400 text-xs pl-2">Pago</span><span className="text-slate-600 text-xs">{fmtMoney(f.custoPago)}</span></div>
          <div className="flex justify-between"><span className="text-slate-400 text-xs pl-2">A pagar</span><span className="text-amber-700 text-xs">{fmtMoney(f.aPagar)}</span></div>
        </div>
      </div>

      {/* Orçamento (sem cap em 100%) */}
      <div className="mt-3 pt-3 border-t border-slate-100">
        <div className="flex justify-between text-xs mb-1"><span className="text-slate-500">{pctOrcStr}</span>{f.pctOrc != null && <span className="text-slate-500">{fmtMoney(f.custoRealizado)} / {fmtMoney(f.custoPrevisto)}</span>}</div>
        <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
          <div className={`h-full ${orcBarColor(f.pctOrc)}`} style={{ width: `${Math.min(100, f.pctOrc ?? 0)}%` }} />
        </div>
      </div>

      <div className="flex justify-end mt-2">
        <span className="text-xs text-slate-400 inline-flex items-center">Ver detalhes <ChevronRight className="w-3.5 h-3.5" /></span>
      </div>
    </div>
  );
}