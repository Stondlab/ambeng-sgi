import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Plus, LayoutGrid, List, BarChart3 } from 'lucide-react';
import { useFiltrosFinanceiro } from '@/lib/FiltrosFinanceiroContext';
import { usePermissoes } from '@/lib/PermissoesContext';
import { pode } from '@/lib/permissoes';
import { statsObras, resumoExecutivo, saudeObras, alertasObras } from '@/lib/obrasFinanceiro';
import { obrasDisponiveisNoPeriodo } from '@/lib/obraDisponibilidade';
import FiltrosObras from './FiltrosObras';
import ResumoExecutivoObras from './ResumoExecutivoObras';
import SaudeObrasResumo from './SaudeObrasResumo';
import AlertasObras from './AlertasObras';
import ObraFinanceiroCard from './ObraFinanceiroCard';
import RankingObras from './RankingObras';
import AnaliseCustosObras from './AnaliseCustosObras';
import RentabilidadeObras from './RentabilidadeObras';
import FluxoFuturoObras from './FluxoFuturoObras';
import ObraForm from './ObraForm';

const VIEWS = [
  { id: 'visao', label: 'Visão Geral', Icon: LayoutGrid },
  { id: 'lista', label: 'Lista', Icon: List },
  { id: 'analise', label: 'Análise', Icon: BarChart3 },
];
const EMPTY = { status: 'all', responsavel: 'all', cliente: 'all', situacao: 'all' };

export default function ObrasFinanceiro({ obras, receitas, despesas, podeCriar, podeEditar, podeExcluir, onSave, onDelete }) {
  const navigate = useNavigate();
  const { perfilEfetivo } = usePermissoes();
  const podeVerEstrategico = pode(perfilEfetivo, 'fin_receitas', 'visualizar');
  const { obra: obraGlobal, dataInicio, dataFim } = useFiltrosFinanceiro();
  const [view, setView] = useState('visao');
  const [filtros, setFiltros] = useState(EMPTY);
  const [mais, setMais] = useState(false);
  const [edit, setEdit] = useState(null);

  const obrasPeriodo = useMemo(() => obrasDisponiveisNoPeriodo(obras, dataInicio, dataFim), [obras, dataInicio, dataFim]);
  const receitasPeriodo = useMemo(() => receitas.filter((r) => { const dt = r.data_prevista || r.data_emissao; return dt && dt >= dataInicio && dt <= dataFim; }), [receitas, dataInicio, dataFim]);
  const despesasPeriodo = useMemo(() => despesas.filter((d) => { const dt = d.data_vencimento || d.data_compra; return dt && dt >= dataInicio && dt <= dataFim; }), [despesas, dataInicio, dataFim]);
  const stats = useMemo(() => statsObras(obrasPeriodo, receitasPeriodo, despesasPeriodo), [obrasPeriodo, receitasPeriodo, despesasPeriodo]);
  const receitasF = useMemo(() => (obraGlobal === 'geral' ? receitasPeriodo : receitasPeriodo.filter((r) => r.obra === obraGlobal)), [receitasPeriodo, obraGlobal]);
  const despesasF = useMemo(() => (obraGlobal === 'geral' ? despesasPeriodo : despesasPeriodo.filter((d) => d.obra === obraGlobal)), [despesasPeriodo, obraGlobal]);

  const filtrados = useMemo(() => stats.filter((o) => {
    if (obraGlobal !== 'geral' && o.nome !== obraGlobal) return false;
    if (filtros.status !== 'all' && o.status !== filtros.status) return false;
    if (filtros.responsavel !== 'all' && (o.responsavel || '') !== filtros.responsavel) return false;
    if (filtros.cliente !== 'all' && (o.cliente || '') !== filtros.cliente) return false;
    if (filtros.situacao !== 'all' && o.fin.situacao !== filtros.situacao) return false;
    return true;
  }), [stats, filtros, obraGlobal]);

  const resumo = useMemo(() => resumoExecutivo(filtrados), [filtrados]);
  const saude = useMemo(() => saudeObras(filtrados), [filtrados]);
  const alertas = useMemo(() => alertasObras(filtrados, receitasF, despesasF), [filtrados, receitasF, despesasF]);
  const responsaveis = useMemo(() => [...new Set(obrasPeriodo.map((o) => o.responsavel).filter(Boolean))], [obrasPeriodo]);
  const clientes = useMemo(() => [...new Set(obrasPeriodo.map((o) => o.cliente).filter(Boolean))], [obrasPeriodo]);

  const onResumoClick = (to) => {
    if (to === 'despesas') navigate('/financeiro/despesas');
    else if (to === 'receitas') navigate('/financeiro/receitas');
    else if (to === 'analise') setView('analise');
    else setView('lista');
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex bg-slate-100 rounded-lg p-1">
          {VIEWS.map((v) => (
            <button key={v.id} onClick={() => setView(v.id)} className={`inline-flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md transition ${view === v.id ? 'bg-white text-[#0b2545] shadow-sm font-medium' : 'text-slate-500 hover:text-slate-700'}`}>
              <v.Icon className="w-4 h-4" />{v.label}
            </button>
          ))}
        </div>
        {podeCriar && <Button onClick={() => setEdit({})} className="bg-[#0b2545] hover:bg-[#16365f] min-h-[44px]"><Plus className="w-4 h-4 mr-1" />Nova Obra</Button>}
      </div>

      <FiltrosObras filtros={filtros} setFiltros={setFiltros} responsaveis={responsaveis} clientes={clientes} mais={mais} setMais={setMais} onClear={() => setFiltros(EMPTY)} />

      {view === 'visao' && (
        <div className="space-y-4">
          <ResumoExecutivoObras resumo={resumo} podeVerEstrategico={podeVerEstrategico} onClick={onResumoClick} />
          <div className="grid lg:grid-cols-2 gap-4">
            <SaudeObrasResumo saude={saude} />
            <AlertasObras alertas={alertas} />
          </div>
          <FluxoFuturoObras receitas={receitasF} despesas={despesasF} podeVerEstrategico={podeVerEstrategico} />
          <div className="grid lg:grid-cols-2 gap-3">
            {filtrados.map((o) => <ObraFinanceiroCard key={o.id} obra={o} podeEditar={podeEditar} podeExcluir={podeExcluir} podeVerEstrategico={podeVerEstrategico} onEdit={() => setEdit(o)} onDelete={() => onDelete(o.id)} />)}
            {!filtrados.length && <p className="text-sm text-slate-400 text-center py-10 lg:col-span-2">Nenhuma obra encontrada com os filtros atuais.</p>}
          </div>
        </div>
      )}

      {view === 'lista' && (
        <div className="space-y-4">
          <ResumoExecutivoObras resumo={resumo} podeVerEstrategico={podeVerEstrategico} onClick={onResumoClick} />
          <div className="grid lg:grid-cols-2 gap-3">
            {filtrados.map((o) => <ObraFinanceiroCard key={o.id} obra={o} podeEditar={podeEditar} podeExcluir={podeExcluir} podeVerEstrategico={podeVerEstrategico} onEdit={() => setEdit(o)} onDelete={() => onDelete(o.id)} />)}
            {!filtrados.length && <p className="text-sm text-slate-400 text-center py-10 lg:col-span-2">Nenhuma obra encontrada com os filtros atuais.</p>}
          </div>
        </div>
      )}

      {view === 'analise' && (
        <div className="space-y-4">
          <ResumoExecutivoObras resumo={resumo} podeVerEstrategico={podeVerEstrategico} onClick={onResumoClick} />
          <div className="grid lg:grid-cols-2 gap-4">
            <SaudeObrasResumo saude={saude} />
            <AlertasObras alertas={alertas} />
          </div>
          <RankingObras obras={filtrados} podeVerEstrategico={podeVerEstrategico} />
          <AnaliseCustosObras obras={filtrados} despesas={despesasF} podeVerEstrategico={podeVerEstrategico} />
          <RentabilidadeObras obras={filtrados} podeVerEstrategico={podeVerEstrategico} />
          <FluxoFuturoObras receitas={receitasF} despesas={despesasF} podeVerEstrategico={podeVerEstrategico} />
        </div>
      )}

      {edit && <ObraForm record={edit} onClose={() => setEdit(null)} onSave={onSave} />}
    </div>
  );
}