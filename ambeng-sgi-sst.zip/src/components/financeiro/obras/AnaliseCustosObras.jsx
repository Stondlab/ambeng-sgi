import React, { useMemo, useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { fmtMoney, bucketCat, shortDate } from '@/lib/financeiro';
import { custosPorCategoria } from '@/lib/obrasFinanceiro';

const HEX = { 'Material': '#3b82f6', 'Mão de Obra': '#10b981', 'Serviço': '#f59e0b', 'ADM': '#8b5cf6', 'Outros': '#94a3b8' };

export default function AnaliseCustosObras({ obras, despesas, podeVerEstrategico }) {
  const [sel, setSel] = useState(null);
  const data = useMemo(() => custosPorCategoria(despesas), [despesas]);
  const total = data.reduce((s, d) => s + d.value, 0);
  const despesasCat = useMemo(() => (sel ? despesas.filter((d) => bucketCat(d.categoria) === sel) : []), [sel, despesas]);

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <h3 className="font-semibold text-[#0b2545] mb-3">Análise de Custos por Categoria</h3>
      {data.length === 0 ? <p className="text-sm text-slate-400 py-8 text-center">Sem despesas lançadas.</p> : (
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="flex items-center gap-4">
            <ResponsiveContainer width={180} height={180}>
              <PieChart>
                <Pie data={data} dataKey="value" nameKey="name" innerRadius={48} outerRadius={80} paddingAngle={2} onClick={(e) => setSel(e.name)}>
                  {data.map((e, i) => <Cell key={i} fill={HEX[e.name]} className="cursor-pointer" />)}
                </Pie>
                <Tooltip formatter={(v) => fmtMoney(v)} contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-2 flex-1">
              {data.map((c) => (
                <button key={c.name} onClick={() => setSel(sel === c.name ? null : c.name)} className={`flex items-center gap-2 text-sm w-full text-left rounded-md px-2 py-1 ${sel === c.name ? 'bg-slate-100' : ''}`}>
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: HEX[c.name] }} />
                  <span className="flex-1 text-slate-600">{c.name}</span>
                  <span className="font-medium text-[#0b2545]">{fmtMoney(c.value)}</span>
                  <span className="text-xs text-slate-400">{total > 0 ? `${(c.value / total * 100).toFixed(0)}%` : ''}</span>
                </button>
              ))}
              <p className="text-xs text-slate-400 pt-1">Clique numa categoria para ver as despesas.</p>
            </div>
          </div>
          <div>
            {sel ? (
              <div className="max-h-72 overflow-y-auto">
                <p className="text-xs font-semibold uppercase text-slate-500 mb-2">{sel} — {despesasCat.length} despesa(s)</p>
                <table className="w-full text-sm">
                  <tbody className="divide-y divide-slate-100">
                    {despesasCat.map((d) => (
                      <tr key={d.id}><td className="py-2 pr-2 truncate max-w-[180px] text-slate-700">{d.descricao || d.fornecedor || '—'}</td><td className="py-2 text-slate-500 text-xs whitespace-nowrap">{shortDate(d.data_vencimento)}</td><td className="py-2 text-right font-medium text-[#0b2545]">{fmtMoney(d.valor)}</td></tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : <p className="text-sm text-slate-400 self-center">Selecione uma categoria para detalhar.</p>}
          </div>
        </div>
      )}
    </div>
  );
}