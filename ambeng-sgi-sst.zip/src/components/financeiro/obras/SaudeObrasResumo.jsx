import React from 'react';

export default function SaudeObrasResumo({ saude }) {
  const items = [
    { cor: 'bg-emerald-500', label: 'Saudáveis', n: saude.saudavel },
    { cor: 'bg-amber-500', label: 'Em atenção', n: saude.atencao },
    { cor: 'bg-red-500', label: 'Em risco', n: saude.risco },
  ];
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-3">Saúde Financeira das Obras</p>
      <div className="flex flex-wrap gap-5">
        {items.map((it) => (
          <div key={it.label} className="flex items-center gap-2">
            <span className={`w-3 h-3 rounded-full ${it.cor}`} />
            <span className="text-sm text-slate-600">{it.label}</span>
            <span className="text-sm font-bold text-[#0b2545]">{it.n}</span>
          </div>
        ))}
        <span className="text-xs text-slate-400 ml-auto self-center">{saude.total} obra(s)</span>
      </div>
    </div>
  );
}