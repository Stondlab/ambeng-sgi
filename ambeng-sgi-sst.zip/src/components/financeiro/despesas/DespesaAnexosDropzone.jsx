import React, { useRef, useState } from 'react';
import { FileText, Trash2, Upload } from 'lucide-react';

export default function DespesaAnexosDropzone({ anexos, uploading, onAdd, onRemove }) {
  const inputRef = useRef(null);
  const [dragging, setDragging] = useState(false);
  const receber = (files) => { if (files?.[0]) onAdd(files[0]); };
  return <div className="space-y-2">
    <button type="button" onClick={() => inputRef.current?.click()} onDragOver={(e) => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={(e) => { e.preventDefault(); setDragging(false); receber(e.dataTransfer.files); }} className={`flex min-h-[92px] w-full flex-col items-center justify-center rounded-xl border-2 border-dashed text-sm transition ${dragging ? 'border-primary bg-primary/5 text-primary' : 'border-border bg-muted/30 text-muted-foreground'}`}>
      <Upload className="mb-1 h-5 w-5" />{uploading ? 'Enviando arquivo…' : 'Clique ou arraste um arquivo'}
    </button>
    <input ref={inputRef} type="file" className="hidden" onChange={(e) => receber(e.target.files)} disabled={uploading} />
    {anexos.map((a, i) => <div key={`${a.url}-${i}`} className="flex items-center gap-2 rounded-lg border bg-card p-2">
      <FileText className="h-4 w-4 text-muted-foreground" /><a href={a.url} target="_blank" rel="noreferrer" className="min-w-0 flex-1 truncate text-sm font-medium text-primary">{a.nome}</a>
      <button type="button" onClick={() => onRemove(i)} className="min-h-[36px] min-w-[36px] text-destructive"><Trash2 className="mx-auto h-4 w-4" /></button>
    </div>)}
  </div>;
}