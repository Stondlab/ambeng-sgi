import { Package, HardHat, Wrench, Briefcase, Tag, Receipt, Zap, CreditCard, Banknote, Wallet, ArrowLeftRight } from 'lucide-react';

export const CAT_META = {
  'Material': { Icon: Package, color: 'text-blue-600', bg: 'bg-blue-50' },
  'Mão de Obra': { Icon: HardHat, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  'Serviço': { Icon: Wrench, color: 'text-amber-600', bg: 'bg-amber-50' },
  'ADM': { Icon: Briefcase, color: 'text-violet-600', bg: 'bg-violet-50' },
  'Outros': { Icon: Tag, color: 'text-slate-500', bg: 'bg-slate-100' },
};

export const PAG_META = {
  'Boleto': { Icon: Receipt, label: 'Boleto' },
  'Pix': { Icon: Zap, label: 'PIX' },
  'Cartão Crédito': { Icon: CreditCard, label: 'Crédito' },
  'Cartão Débito': { Icon: Banknote, label: 'Débito' },
  'Dinheiro': { Icon: Wallet, label: 'Dinheiro' },
  'Transferência': { Icon: ArrowLeftRight, label: 'Transferência' },
};

export const catMeta = (c) => CAT_META[c] || CAT_META['Outros'];
export const pagMeta = (p) => PAG_META[p] || { Icon: Wallet, label: p || '—' };