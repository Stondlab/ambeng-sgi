import React, { useEffect, useMemo, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Plus, Search } from 'lucide-react';

export default function FornecedorPicker({ value, fornecedores, onSelect, onCreate }) {
  const [busca, setBusca] = useState(value || '');
  const [novo, setNovo] = useState(false);
  useEffect(() => setBusca(value || ''), [value]);
  const opcoes = useMemo(() => fornecedores.filter((f) => f.ativa !== false && (f.nome || '').toLowerCase().includes(busca.toLowerCase())).slice(0, 6), [fornecedores, busca]);
  const escolher = (f) => { setBusca(f.nome); onSelect(f); };
  const criar = async () => {
    const nome = busca.trim();
    if (!nome) return;
    const criado = await onCreate(nome);
    if (criado) { escolher(criado); setNovo(false); }
  };
  return <div className="relative">
    <Search className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground" />
    <Input className="pl-9" value={busca} onChange={(e) => { setBusca(e.target.value); onSelect({ nome: e.target.value }); }} onFocus={() => setNovo(true)} placeholder="Pesquisar fornecedor" />
    {novo && busca && <div className="absolute z-50 mt-1 w-full rounded-lg border bg-card p-1 shadow-card-hover">
      {opcoes.map((f) => <button type="button" key={f.id} onMouseDown={(e) => { e.preventDefault(); escolher(f); setNovo(false); }} className="w-full rounded-md px-3 py-2 text-left text-sm hover:bg-muted">{f.nome}</button>)}
      {!opcoes.some((f) => f.nome.toLowerCase() === busca.trim().toLowerCase()) && <Button type="button" variant="ghost" className="w-full justify-start" onMouseDown={(e) => e.preventDefault()} onClick={criar}><Plus />Novo fornecedor “{busca.trim()}”</Button>}
    </div>}
  </div>;
}