import React from 'react';
import { fmtMoney } from '@/lib/financeiro';

export default function ParcelasPreview({ valores, datas }) {
  if (valores.length <= 1) return null;
  return <div className="rounded-xl border bg-muted/30 p-3">
    <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Parcelas calculadas</p>
    <div className="grid gap-1 sm:grid-cols-2">
      {valores.map((valor, i) => <div key={i} className="flex justify-between rounded-md bg-card px-2.5 py-1.5 text-xs"><span>{i + 1}/{valores.length} · {datas[i]?.split('-').reverse().join('/') || '—'}</span><strong>{fmtMoney(valor)}</strong></div>)}
    </div>
  </div>;
}