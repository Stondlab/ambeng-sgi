import React from 'react';
import { fmtMoney, shortDate, valorMes, descricaoParcela } from '@/lib/financeiro';
import { aguardandoAprovacao } from '@/lib/despesasCentral';
import { Button } from '@/components/ui/button';
import { Check, X } from 'lucide-react';

export default function AguardandoAprovacao({ items, podeAprovar, onAprovar, onReprovar, onOpen }) {
  const rows = aguardandoAprovacao(items);
  const total = rows.reduce((s, d) => s + valorMes(d), 0);
  return (
    <div className="bg-white border border-amber-200 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-amber-700">Aguardando Aprovação</h3>
        <div className="text-right"><p className="text-xs text-slate-500">{rows.length} despesa(s)</p><p className="text-lg font-bold text-amber-700">{fmtMoney(total)}</p></div>
      </div>
      <div className="space-y-2 max-h-80 overflow-y-auto">
        {rows.map((d) => (
          <div key={d.id} className="flex items-center gap-2 rounded-lg border border-slate-100 px-3 py-2 hover:bg-amber-50/40">
            <div className="flex-1 min-w-0 cursor-pointer" onClick={() => onOpen(d)}>
              <p className="font-medium text-[#0b2545] truncate">{descricaoParcela(d)}</p>
              <p className="text-xs text-slate-500 truncate">{d.fornecedor || '—'}{d.obra ? ` · ${d.obra}` : ''} · Venc. {shortDate(d.data_vencimento)}{d.responsavel ? ` · Resp.: ${d.responsavel}` : ''}</p>
            </div>
            <span className="text-sm font-semibold text-[#0b2545] whitespace-nowrap">{fmtMoney(valorMes(d))}</span>
            {podeAprovar && (
              <div className="flex gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                <Button size="icon" className="h-8 w-8 bg-emerald-600 hover:bg-emerald-700" onClick={() => onAprovar(d)} title="Aprovar"><Check className="w-4 h-4" /></Button>
                <Button size="icon" variant="outline" className="h-8 w-8 border-red-200 text-red-600 hover:bg-red-50" onClick={() => onReprovar(d)} title="Reprovar"><X className="w-4 h-4" /></Button>
              </div>
            )}
          </div>
        ))}
        {!rows.length && <p className="text-sm text-slate-400 text-center py-6">Nenhuma despesa aguardando aprovação.</p>}
      </div>
    </div>
  );
}