import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { TrendingUp, TrendingDown } from 'lucide-react';

export default function ComparativoMensal({ comp }) {
  const variacao = comp.variacao;
  const subiu = variacao != null && variacao > 0;
  const caiu = variacao != null && variacao < 0;
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-3">Comparativo Mensal</p>
      <div className="grid grid-cols-3 gap-3">
        <div className="text-center"><p className="text-xs text-slate-500">Mês anterior</p><p className="text-lg font-bold text-slate-700 mt-1">{fmtMoney(comp.anterior)}</p></div>
        <div className="text-center bg-slate-50 rounded-lg py-2"><p className="text-xs text-slate-500">Este mês</p><p className="text-xl font-bold text-[#0b2545] mt-1">{fmtMoney(comp.este)}</p></div>
        <div className="text-center">
          <p className="text-xs text-slate-500">Variação</p>
          <p className={`text-lg font-bold mt-1 inline-flex items-center gap-1 ${subiu ? 'text-red-600' : caiu ? 'text-emerald-700' : 'text-slate-500'}`}>
            {subiu ? <TrendingUp className="w-4 h-4" /> : caiu ? <TrendingDown className="w-4 h-4" /> : null}
            {variacao == null ? '—' : `${variacao > 0 ? '+' : ''}${variacao.toFixed(1)}%`}
          </p>
          {variacao != null && <p className="text-[10px] text-slate-400 mt-0.5">{subiu ? 'aumento' : caiu ? 'redução' : 'estável'}</p>}
        </div>
      </div>
    </div>
  );
}