import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { gastosPorCategoria } from '@/lib/despesasCentral';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const HEX = { 'Material': '#3b82f6', 'Mão de Obra': '#10b981', 'Serviço': '#f59e0b', 'ADM': '#8b5cf6', 'Outros': '#94a3b8' };

export default function GastosPorCategoria({ items, onFilter }) {
  const data = gastosPorCategoria(items);
  const total = data.reduce((s, d) => s + d.value, 0);
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <h3 className="font-semibold text-[#0b2545] mb-3">Gastos por Categoria</h3>
      {data.length === 0 ? <p className="text-sm text-slate-400 py-8 text-center">Sem despesas no período.</p> : (
        <div className="grid lg:grid-cols-2 gap-4 items-center">
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={data} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={2} onClick={(e) => onFilter({ categoria: e.name })}>
                {data.map((e, i) => <Cell key={i} fill={HEX[e.name]} className="cursor-pointer" />)}
              </Pie>
              <Tooltip formatter={(v) => fmtMoney(v)} contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5">
            {data.map((c) => (
              <button key={c.name} onClick={() => onFilter({ categoria: c.name })} className="flex items-center gap-2 text-sm w-full text-left rounded-md px-2 py-1.5 hover:bg-slate-100">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: HEX[c.name] }} />
                <span className="flex-1 text-slate-600">{c.name}</span>
                <span className="font-medium text-[#0b2545]">{fmtMoney(c.value)}</span>
                <span className="text-xs text-slate-400 w-10 text-right">{c.pct.toFixed(0)}%</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}