import React from 'react';
import { fmtMoney } from '@/lib/financeiro';

const tone = (label, val) => {
  const base = 'min-w-0 rounded-xl border p-3 transition hover:shadow-card-hover text-left cursor-pointer min-h-[84px] overflow-hidden';
  switch (label) {
    case 'Gasto do Período': return `${base} bg-slate-50 border-slate-200 text-slate-700`;
    case 'Pago': return `${base} bg-emerald-50 border-emerald-200 text-emerald-700`;
    case 'A Pagar': return `${base} bg-blue-50 border-blue-200 text-blue-700`;
    case 'Atrasado': return `${base} bg-red-50 border-red-200 text-red-700`;
    case 'Aguardando Aprovação': return `${base} bg-amber-50 border-amber-200 text-amber-700`;
    case 'Comprometido': return `${base} bg-purple-50 border-purple-200 text-purple-700`;
    default: return base;
  }
};

const CARDS = [
  { key: 'gastoPeriodo', label: 'Gasto do Período', fmt: fmtMoney, filter: null },
  { key: 'pago', label: 'Pago', fmt: fmtMoney, filter: { statusPagamento: 'Pago' } },
  { key: 'aPagar', label: 'A Pagar', fmt: fmtMoney, filter: { statusPagamento: 'Pendente' } },
  { key: 'atrasado', label: 'Atrasado', fmt: fmtMoney, filter: { statusPagamento: 'Atrasado' } },
  { key: 'aguardando', label: 'Aguardando Aprovação', fmt: fmtMoney, filter: { statusAprovacao: 'Aguardando aprovação' } },
  { key: 'comprometido', label: 'Comprometido', fmt: fmtMoney, filter: { futuro: true } },
];

export default function ResumoDespesas({ resumo, onFilter }) {
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
      {CARDS.map((c) => (
        <button key={c.key} onClick={() => c.filter && onFilter(c.filter)} className={tone(c.label, resumo[c.key])}>
          <p className="text-[11px] opacity-80 leading-tight">{c.label}</p>
          <p className={`${c.fmt(resumo[c.key]).length > 15 ? 'text-sm' : c.fmt(resumo[c.key]).length > 12 ? 'text-base' : 'text-lg'} mt-2 break-words font-bold leading-tight`}>{c.fmt(resumo[c.key])}</p>
        </button>
      ))}
    </div>
  );
}