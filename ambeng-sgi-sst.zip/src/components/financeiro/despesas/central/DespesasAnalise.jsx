import React, { useMemo } from 'react';
import { comparativoMensal, pressaoCaixa, gastosPorCategoria, gastosPorObra, insightsDespesas, aguardandoAprovacao, despesasAtrasadas } from '@/lib/despesasCentral';
import ComparativoMensal from './ComparativoMensal';
import PressaoCaixa from './PressaoCaixa';
import GastosPorCategoria from './GastosPorCategoria';
import GastosPorObra from './GastosPorObra';
import ComposicaoDespesas from './ComposicaoDespesas';
import EvolucaoDespesas from './EvolucaoDespesas';
import AnaliseFinanceiraDespesas from './AnaliseFinanceiraDespesas';

export default function DespesasAnalise({ items, futureItems, range, setObra, applyFilter, onPeriod, podeVerEstrategico }) {
  const comparativo = useMemo(() => comparativoMensal(items), [items]);
  const pressao = useMemo(() => pressaoCaixa(futureItems), [futureItems]);
  const categorias = useMemo(() => gastosPorCategoria(items), [items]);
  const obras = useMemo(() => gastosPorObra(items), [items]);
  const aguardando = useMemo(() => aguardandoAprovacao(items), [items]);
  const atrasadas = useMemo(() => despesasAtrasadas(items), [items]);
  const insights = useMemo(() => insightsDespesas(items, comparativo, pressao, categorias, obras, aguardando, atrasadas), [items, comparativo, pressao, categorias, obras, aguardando, atrasadas]);
  return <div className="space-y-4">
    <ComparativoMensal comp={comparativo} />
    <PressaoCaixa pressao={pressao} onPeriod={onPeriod} />
    <div className="grid gap-4 lg:grid-cols-2"><GastosPorCategoria items={items} onFilter={applyFilter} /><GastosPorObra items={items} onFilter={(patch) => patch.obra ? setObra(patch.obra) : applyFilter(patch)} /></div>
    <div className="grid gap-4 lg:grid-cols-2"><ComposicaoDespesas items={items} onFilter={applyFilter} /><EvolucaoDespesas items={items} range={range} /></div>
    {podeVerEstrategico && <AnaliseFinanceiraDespesas insights={insights} />}
  </div>;
}