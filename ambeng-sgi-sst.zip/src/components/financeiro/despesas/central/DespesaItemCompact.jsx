import React from 'react';
import { fmtMoney, shortDate, despesaStatus, valorMes } from '@/lib/financeiro';
import { catMeta } from '../icons';
import { CheckCircle2, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ST_PAG = { Pago: 'bg-emerald-100 text-emerald-700', Pendente: 'bg-amber-100 text-amber-700', Atrasado: 'bg-red-100 text-red-700' };
const ST_APROV = {
  'Aprovada': 'bg-emerald-100 text-emerald-700',
  'Aguardando aprovação': 'bg-amber-100 text-amber-700',
  'Reprovada': 'bg-red-100 text-red-700',
  'Rascunho': 'bg-slate-100 text-slate-600',
  'Cancelada': 'bg-slate-100 text-slate-500',
};

export default function DespesaItemCompact({ d, onOpen, podeEditar, onMarkPaid }) {
  const stPag = despesaStatus(d);
  const stAprov = d.status_aprovacao || 'Não informado';
  const cat = catMeta(d.categoria);
  const parcelado = Number(d.total_parcelas) > 1;
  const isCredito = d.forma_pagamento === 'Cartão Crédito';
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-3.5 hover:shadow-card-hover transition cursor-pointer" onClick={() => onOpen(d)}>
      <div className="flex items-start gap-3">
        <span className={`shrink-0 w-9 h-9 rounded-lg flex items-center justify-center ${cat.bg}`}><cat.Icon className={`w-4 h-4 ${cat.color}`} /></span>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="font-semibold text-[#0b2545] truncate">{d.descricao || 'Não informado'}</p>
              <p className="text-xs text-slate-500 truncate">{d.fornecedor || '—'}{(d.funcionario || d.beneficiario) ? ` · ${d.funcionario || d.beneficiario}` : ''}{d.obra ? ` · ${d.obra}` : ''}{d.categoria ? ` · ${d.categoria}` : ''}</p>
            </div>
            <div className="text-right shrink-0">
              <p className="text-lg font-bold text-[#0b2545] whitespace-nowrap leading-none">{fmtMoney(valorMes(d))}</p>
              {parcelado && <p className="text-[11px] text-slate-400 whitespace-nowrap mt-0.5">Total {fmtMoney(d.valor)}</p>}
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs mt-2">
            <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${ST_PAG[stPag]}`}>Pag.: {stPag}</span>
            <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${ST_APROV[stAprov] || 'bg-slate-100 text-slate-500'}`}>Aprov.: {stAprov}</span>
            {parcelado && <span className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-600">Parcela {d.parcela_atual || 0}/{d.total_parcelas}</span>}
            {d.data_vencimento && <span className="text-slate-400">Venc.: {shortDate(d.data_vencimento)}</span>}
            {isCredito && d.cartao && <span className="text-slate-400">Cartão: {d.cartao}</span>}
            {podeEditar && stPag !== 'Pago' && <Button type="button" size="sm" variant="outline" className="ml-auto min-h-9 text-emerald-700" onClick={(event) => { event.stopPropagation(); onMarkPaid(d); }}><CheckCircle2 className="h-4 w-4" />Marcar como paga</Button>}
          </div>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-300 shrink-0 mt-1" />
      </div>
    </div>
  );
}