import React, { useState } from 'react';
import { fmtMoney, shortDate, despesaStatus, valorMes, descricaoParcela } from '@/lib/financeiro';
import { proximosVencimentos } from '@/lib/despesasCentral';
import { ArrowUp, ArrowDown, ArrowUpDown } from 'lucide-react';

const TABS = [7, 15, 30, 60, 90];
const ST_BADGE = { Pago: 'bg-emerald-100 text-emerald-700', Pendente: 'bg-amber-100 text-amber-700', Atrasado: 'bg-red-100 text-red-700' };

export default function ProximosVencimentos({ items, onOpen }) {
  const [tab, setTab] = useState(7);
  const [sortField, setSortField] = useState(null);
  const [sortDir, setSortDir] = useState('asc');

  const rowsRaw = proximosVencimentos(items, tab);
  const rows = sortField ? [...rowsRaw].sort((a, b) => {
    let cmp = 0;
    if (sortField === 'valor') cmp = valorMes(a) - valorMes(b);
    else if (sortField === 'vencimento') cmp = (a.data_vencimento || '').localeCompare(b.data_vencimento || '');
    else if (sortField === 'descricao') cmp = (a.descricao || '').localeCompare(b.descricao || '');
    else if (sortField === 'fornecedor') cmp = (a.fornecedor || '').localeCompare(b.fornecedor || '');
    else if (sortField === 'obra') cmp = (a.obra || '').localeCompare(b.obra || '');
    else if (sortField === 'status') cmp = (despesaStatus(a)).localeCompare(despesaStatus(b));
    return sortDir === 'asc' ? cmp : -cmp;
  }) : rowsRaw;

  const toggleSort = (field) => {
    if (sortField === field) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else { setSortField(field); setSortDir('asc'); }
  };
  const SortIcon = ({ field }) => {
    if (sortField !== field) return <ArrowUpDown className="w-3 h-3 text-slate-300 inline ml-0.5" />;
    return sortDir === 'asc' ? <ArrowUp className="w-3 h-3 text-[#0b2545] inline ml-0.5" /> : <ArrowDown className="w-3 h-3 text-[#0b2545] inline ml-0.5" />;
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <h3 className="font-semibold text-[#0b2545]">Próximos Vencimentos</h3>
        <div className="flex gap-1">
          {TABS.map((d) => <button key={d} onClick={() => setTab(d)} className={`text-xs px-3 py-1.5 rounded-lg ${tab === d ? 'bg-[#0b2545] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>{d} dias</button>)}
        </div>
      </div>
      <div className="min-w-0">
        <div className="divide-y divide-border md:hidden">{rows.map((d) => { const st = despesaStatus(d); return <button key={d.id} className="block w-full py-3 text-left" onClick={() => onOpen(d)}><div className="flex items-start justify-between gap-3"><p className="min-w-0 font-medium text-foreground">{descricaoParcela(d)}</p><p className="shrink-0 font-semibold">{fmtMoney(valorMes(d))}</p></div><p className="mt-1 text-xs text-muted-foreground">{d.obra || 'Sem obra'} · {d.fornecedor || 'Sem fornecedor'}</p><div className="mt-2 flex items-center justify-between text-xs"><span>{shortDate(d.data_vencimento)}</span><span className={`rounded-full px-2 py-0.5 font-medium ${ST_BADGE[st]}`}>{st}</span></div></button>; })}{!rows.length && <p className="py-8 text-center text-sm text-muted-foreground">Sem vencimentos no período.</p>}</div>
        <table className="hidden w-full table-fixed text-sm md:table">
          <thead className="text-xs uppercase text-slate-500 bg-slate-50">
            <tr>
              <th className="w-1/4 text-left px-3 py-2 cursor-pointer hover:text-[#0b2545]" onClick={() => toggleSort('descricao')}>Descrição <SortIcon field="descricao" /></th>
              <th className="text-left px-3 py-2 cursor-pointer hover:text-[#0b2545]" onClick={() => toggleSort('obra')}>Obra <SortIcon field="obra" /></th>
              <th className="text-left px-3 py-2 cursor-pointer hover:text-[#0b2545]" onClick={() => toggleSort('fornecedor')}>Fornecedor <SortIcon field="fornecedor" /></th>
              <th className="text-right px-3 py-2 cursor-pointer hover:text-[#0b2545]" onClick={() => toggleSort('valor')}>Valor <SortIcon field="valor" /></th>
              <th className="text-left px-3 py-2 cursor-pointer hover:text-[#0b2545]" onClick={() => toggleSort('vencimento')}>Vencimento <SortIcon field="vencimento" /></th>
              <th className="text-left px-3 py-2 cursor-pointer hover:text-[#0b2545]" onClick={() => toggleSort('status')}>Status <SortIcon field="status" /></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((d) => {
              const st = despesaStatus(d);
              const critico = valorMes(d) > 5000;
              return (
                <tr key={d.id} className="hover:bg-slate-50 cursor-pointer" onClick={() => onOpen(d)}>
                  <td className="px-3 py-2.5 text-[#0b2545] font-medium truncate">{descricaoParcela(d)}</td>
                  <td className="px-3 py-2.5 text-slate-500 truncate">{d.obra || '—'}</td>
                  <td className="px-3 py-2.5 text-slate-500 truncate">{d.fornecedor || '—'}</td>
                  <td className={`px-3 py-2.5 text-right font-semibold whitespace-nowrap ${critico ? 'text-[#0b2545]' : 'text-slate-700'}`}>{fmtMoney(valorMes(d))}</td>
                  <td className="px-3 py-2.5 whitespace-nowrap text-slate-600">{shortDate(d.data_vencimento)}</td>
                  <td className="px-3 py-2.5"><span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${ST_BADGE[st]}`}>{st}</span></td>
                </tr>
              );
            })}
            {!rows.length && <tr><td colSpan={6} className="px-3 py-8 text-center text-slate-400">Sem vencimentos no período.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}