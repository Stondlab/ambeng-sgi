import React from 'react';
import { fmtMoney, shortDate, valorMes, descricaoParcela } from '@/lib/financeiro';
import { despesasAtrasadas } from '@/lib/despesasCentral';
import { useColumnSort } from '@/lib/useColumnSort';
import SortableTh from '@/components/financeiro/SortableTh';

export default function DespesasAtrasadas({ items, onOpen }) {
  const { sortField, sortDir, toggleSort, sortRows } = useColumnSort();

  const rowsRaw = despesasAtrasadas(items);
  const rows = sortRows(rowsRaw, {
    fornecedor: (a, b) => (a.fornecedor || '').localeCompare(b.fornecedor || ''),
    descricao: (a, b) => (descricaoParcela(a) || '').localeCompare(descricaoParcela(b) || ''),
    valor: (a, b) => valorMes(a) - valorMes(b),
    vencimento: (a, b) => (a.data_vencimento || '').localeCompare(b.data_vencimento || ''),
    diasAtraso: (a, b) => (a.diasAtraso || 0) - (b.diasAtraso || 0),
  });
  const total = rows.reduce((s, d) => s + valorMes(d), 0);

  return (
    <div className="bg-white border border-red-200 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-red-700">Despesas Atrasadas</h3>
        <div className="text-right"><p className="text-xs text-slate-500">{rows.length} despesa(s)</p><p className="text-lg font-bold text-red-700">{fmtMoney(total)}</p></div>
      </div>
      <div className="min-w-0 max-h-80 overflow-y-auto">
        <div className="divide-y divide-border md:hidden">{rows.map((d) => <button key={d.id} className="block w-full py-3 text-left" onClick={() => onOpen(d)}><div className="flex items-start justify-between gap-3"><p className="min-w-0 font-medium text-foreground">{descricaoParcela(d)}</p><p className="shrink-0 font-semibold text-red-700">{fmtMoney(valorMes(d))}</p></div><p className="mt-1 text-xs text-muted-foreground">{d.obra || 'Sem obra'} · {d.fornecedor || 'Sem fornecedor'}</p><div className="mt-2 flex justify-between text-xs"><span>{shortDate(d.data_vencimento)}</span><span className="font-medium text-red-600">{d.diasAtraso}d em atraso</span></div></button>)}{!rows.length && <p className="py-8 text-center text-sm text-muted-foreground">Nenhuma despesa atrasada.</p>}</div>
        <table className="hidden w-full table-fixed text-sm md:table">
          <thead className="text-xs uppercase text-slate-500 bg-slate-50 sticky top-0">
            <tr>
              <SortableTh field="descricao" label="Descrição" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="w-1/4 px-3 py-2" />
              <th className="text-left px-3 py-2">Obra</th>
              <SortableTh field="fornecedor" label="Fornecedor" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
              <SortableTh field="valor" label="Valor" align="right" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
              <SortableTh field="vencimento" label="Vencimento" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
              <SortableTh field="diasAtraso" label="Dias atraso" align="right" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((d) => (
              <tr key={d.id} className="hover:bg-red-50/40 cursor-pointer" onClick={() => onOpen(d)}>
                <td className="px-3 py-2.5 text-[#0b2545] font-medium truncate">{descricaoParcela(d)}</td>
                <td className="px-3 py-2.5 text-slate-500 truncate">{d.obra || '—'}</td>
                <td className="px-3 py-2.5 text-slate-600 truncate">{d.fornecedor || '—'}</td>
                <td className="px-3 py-2.5 text-right font-semibold text-red-700">{fmtMoney(valorMes(d))}</td>
                <td className="px-3 py-2.5 text-slate-600 whitespace-nowrap">{shortDate(d.data_vencimento)}</td>
                <td className="px-3 py-2.5 text-right text-red-600 font-medium">{d.diasAtraso}d</td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan={6} className="px-3 py-8 text-center text-slate-400">Nenhuma despesa atrasada. 🟢</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}