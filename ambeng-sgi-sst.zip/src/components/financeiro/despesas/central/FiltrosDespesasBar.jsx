import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import FinanceiroFilterShell from '@/components/financeiro/FinanceiroFilterShell';
import { Search } from 'lucide-react';
import { CATEGORIAS } from '@/lib/financeiro';

const FORMAS = ['Dinheiro', 'Pix', 'Cartão Crédito', 'Cartão Débito', 'Boleto', 'Transferência'];
const APROVACOES = ['Rascunho', 'Aguardando aprovação', 'Aprovada', 'Reprovada', 'Cancelada', { value: 'nao', label: 'Não informado' }];
const STATUS = [{ value: 'Pago', label: 'Pago' }, { value: 'Parcial', label: 'Parcial' }, { value: 'Pendente', label: 'Pendente' }, { value: 'A pagar', label: 'A pagar' }, { value: 'Atrasado', label: 'Atrasado' }];
const FilterSelect = ({ value, onChange, placeholder, all, options }) => <Select value={value} onValueChange={onChange}><SelectTrigger className="h-10 w-full"><SelectValue placeholder={placeholder} /></SelectTrigger><SelectContent><SelectItem value="all">{all}</SelectItem>{options.map((item) => { const option = typeof item === 'string' ? { value: item, label: item } : item; return <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>; })}</SelectContent></Select>;

export default function FiltrosDespesasBar({ filtros, setFiltros, cartoes, fornecedores, responsaveis, beneficiarios, onClear }) {
  const set = (key, value) => setFiltros((current) => ({ ...current, [key]: value }));
  return <FinanceiroFilterShell partyLabel="Fornecedor" partyValue={filtros.fornecedor} partyOptions={fornecedores} onPartyChange={(value) => set('fornecedor', value)} statusValue={filtros.statusPagamento} statusOptions={STATUS} onStatusChange={(value) => set('statusPagamento', value)} onClear={onClear}>
    <div className="grid min-w-0 grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
      <div className="relative sm:col-span-2"><Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><Input className="pl-9" value={filtros.busca} onChange={(e) => set('busca', e.target.value)} placeholder="Buscar descrição, fornecedor ou beneficiário" /></div>
      <FilterSelect value={filtros.statusAprovacao} onChange={(v) => set('statusAprovacao', v)} placeholder="Aprovação" all="Toda aprovação" options={APROVACOES} />
      <FilterSelect value={filtros.categoria} onChange={(v) => set('categoria', v)} placeholder="Categoria" all="Todas as categorias" options={[...CATEGORIAS, { value: 'nao', label: 'Não classificada' }]} />
      <FilterSelect value={filtros.cartao} onChange={(v) => set('cartao', v)} placeholder="Cartão" all="Todos os cartões" options={cartoes.map((c) => c.nome)} />
      <FilterSelect value={filtros.forma} onChange={(v) => set('forma', v)} placeholder="Forma de pagamento" all="Todas as formas" options={FORMAS} />
      <FilterSelect value={filtros.tipo} onChange={(v) => set('tipo', v)} placeholder="Tipo de despesa" all="Todos os tipos" options={['Fixa', 'Variável', 'Eventual']} />
      <FilterSelect value={filtros.funcionario} onChange={(v) => set('funcionario', v)} placeholder="Funcionário" all="Todos os funcionários" options={beneficiarios} />
      <FilterSelect value={filtros.responsavel} onChange={(v) => set('responsavel', v)} placeholder="Responsável" all="Todos os responsáveis" options={responsaveis} />
      <div className="sm:col-span-2"><Label className="mb-1.5 block text-xs text-muted-foreground">Data da compra</Label><div className="grid grid-cols-2 gap-2"><Input type="date" value={filtros.compraInicio} onChange={(e) => set('compraInicio', e.target.value)} /><Input type="date" value={filtros.compraFim} onChange={(e) => set('compraFim', e.target.value)} /></div></div>
    </div>
  </FinanceiroFilterShell>;
}