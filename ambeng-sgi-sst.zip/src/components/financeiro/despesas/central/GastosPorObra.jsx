import React, { useState } from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { gastosPorObra } from '@/lib/despesasCentral';
import { ChevronUp, ChevronDown } from 'lucide-react';

export default function GastosPorObra({ items, onFilter }) {
  const [asc, setAsc] = useState(false);
  const data = gastosPorObra(items);
  const rows = asc ? [...data].reverse() : data;
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-[#0b2545]">Gastos por Obra</h3>
        <button onClick={() => setAsc(!asc)} className="text-xs text-slate-500 inline-flex items-center gap-1 hover:text-[#0b2545]">{asc ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}{asc ? 'Menor gasto' : 'Maior gasto'}</button>
      </div>
      <div className="overflow-x-auto max-h-72 overflow-y-auto">
        <table className="w-full text-sm">
          <thead className="text-xs uppercase text-slate-500 bg-slate-50 sticky top-0"><tr><th className="text-left px-3 py-2">Obra</th><th className="text-right px-3 py-2">Total</th><th className="text-right px-3 py-2">Pago</th><th className="text-right px-3 py-2">A pagar</th><th className="text-right px-3 py-2 w-16">% total</th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((o) => (
              <tr key={o.nome} className="hover:bg-slate-50 cursor-pointer" onClick={() => onFilter({ obra: o.nome })}>
                <td className="px-3 py-2.5 text-[#0b2545] font-medium truncate max-w-[160px]">{o.nome}</td>
                <td className="px-3 py-2.5 text-right font-semibold text-slate-700">{fmtMoney(o.total)}</td>
                <td className="px-3 py-2.5 text-right text-emerald-700">{fmtMoney(o.pago)}</td>
                <td className="px-3 py-2.5 text-right text-blue-700">{fmtMoney(o.aPagar)}</td>
                <td className="px-3 py-2.5 text-right text-slate-400">{o.pct.toFixed(0)}%</td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan={5} className="px-3 py-8 text-center text-slate-400">Sem despesas.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}