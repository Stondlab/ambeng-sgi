import React, { lazy, Suspense, useEffect, useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus, Printer } from 'lucide-react';
import { fmtMoney, valorMes } from '@/lib/financeiro';
import { useColumnSort } from '@/lib/useColumnSort';
import SortBar from '@/components/financeiro/SortBar';
import { useFiltrosFinanceiro } from '@/lib/FiltrosFinanceiroContext';
import { usePermissoes } from '@/lib/PermissoesContext';
import { pode } from '@/lib/permissoes';
import { filterDespesas, resumoDespesas } from '@/lib/despesasCentral';
import FiltrosDespesasBar from './FiltrosDespesasBar';
import ResumoDespesas from './ResumoDespesas';
import ProximosVencimentos from './ProximosVencimentos';
import DespesasAtrasadas from './DespesasAtrasadas';
import AguardandoAprovacao from './AguardandoAprovacao';
import DespesaItemCompact from './DespesaItemCompact';
import DespesaModal from './DespesaModal';
import DespesaForm from '../DespesaForm';
import QuickSettlementDialog from '@/components/financeiro/QuickSettlementDialog';

const DespesasAnalise = lazy(() => import('./DespesasAnalise'));

const EMPTY = {
  busca: '', fornecedor: 'all', categoria: 'all', statusAprovacao: 'all', statusPagamento: 'all',
  cartao: 'all', forma: 'all', tipo: 'all', responsavel: 'all', futuro: false,
  compraInicio: '', compraFim: '', vencInicio: '', vencFim: '', funcionario: 'all',
};

export default function DespesasCentral({ items, obras, obrasAtivas, cartoes, fornecedores, onCriarFornecedor, podeCriar, podeEditar, podeExcluir, onSave, onDelete, onAprovar, onReprovar, onPrepareForm }) {
  const { perfilEfetivo } = usePermissoes();
  const podeVerEstrategico = pode(perfilEfetivo, 'fin_receitas', 'visualizar');
  const podeAprovar = pode(perfilEfetivo, 'fin_despesas', 'editar') && ['Administrador', 'CEO', 'CFO'].includes(perfilEfetivo);
  const { obra: obraGlobal, setObra, dataInicio, dataFim, range } = useFiltrosFinanceiro();

  const [filtros, setFiltros] = useState(EMPTY);
  const [detail, setDetail] = useState(null);
  const [edit, setEdit] = useState(null);
  const [view, setView] = useState('operacional');
  const [settlement, setSettlement] = useState(null);
  const [settling, setSettling] = useState(false);
  const { sortField, sortDir, toggleSort, sortRows } = useColumnSort();
  useEffect(() => { const id = new URLSearchParams(window.location.search).get('id'); if (id) setDetail(items.find((row) => row.id === id) || null); }, [items]);

  // Conjunto do período (resumo/comparativos usam o range global; os lançamentos listados usam filtros locais + range).
  const itemsObra = useMemo(() => items.filter((d) => obraGlobal === 'geral' || d.obra === obraGlobal), [items, obraGlobal]);
  const itemsPeriodo = useMemo(() => itemsObra.filter((d) => {
    if (range && range.start) { const dt = d.data_vencimento || d.data_compra; if (!dt || dt < range.start || dt > range.end) return false; }
    return true;
  }), [itemsObra, range]);

  const filteredRaw = useMemo(() => filterDespesas(itemsPeriodo, filtros, 'geral', null), [itemsPeriodo, filtros]);
  const filtered = useMemo(() => sortRows(filteredRaw, {
    fornecedor: (a, b) => (a.fornecedor || '').localeCompare(b.fornecedor || ''),
    descricao: (a, b) => (a.descricao || '').localeCompare(b.descricao || ''),
    valor: (a, b) => valorMes(a) - valorMes(b),
    vencimento: (a, b) => (a.data_vencimento || '').localeCompare(b.data_vencimento || ''),
  }), [filteredRaw, sortField, sortDir]);
  const totalValor = filtered.reduce((s, d) => s + valorMes(d), 0);

  const resumo = useMemo(() => resumoDespesas(itemsPeriodo), [itemsPeriodo]);

  const nomesFornecedoresHistorico = useMemo(() => [...new Set(items.map((d) => d.fornecedor).filter(Boolean))], [items]);
  const responsaveis = useMemo(() => [...new Set(items.map((d) => d.responsavel).filter(Boolean))], [items]);
  const beneficiarios = useMemo(() => [...new Set(items.map((d) => d.funcionario || d.beneficiario).filter(Boolean))], [items]);

  const applyFilter = (patch) => setFiltros((p) => ({ ...p, ...patch, futuro: patch.futuro ?? false }));
  const onPeriod = (key) => {
    const dias = { d7: 7, d15: 15, d30: 30, d60: 60, d90: 90 }[key];
    const e = new Date(); e.setDate(e.getDate() + dias); const eIso = e.toISOString().slice(0, 10); const tIso = new Date().toISOString().slice(0, 10);
    setFiltros((p) => ({ ...p, vencInicio: tIso, vencFim: eIso, statusPagamento: 'all', futuro: false }));
  };
  const openDetail = (d) => setDetail(d);
  const onEdit = async (d) => { setDetail(null); await onPrepareForm?.(); setEdit(d); };
  const markPaid = async (date) => { setSettling(true); const ok = await onSave({ ...settlement, status: 'Pago', data_pagamento: date, valor_pago: valorMes(settlement) }, settlement.id); setSettling(false); if (ok) setSettlement(null); };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-end gap-2">
        <div className="flex gap-2">
          {podeCriar && <Button onClick={async () => { await onPrepareForm?.(); setEdit({}); }} className="bg-[#0b2545] hover:bg-[#16365f] min-h-[44px]"><Plus className="w-4 h-4 mr-1" />Nova Despesa</Button>}
          <Button variant="outline" onClick={() => window.print()} className="min-h-[44px]"><Printer className="w-4 h-4 mr-1" />Imprimir</Button>
        </div>
      </div>

      <div className="grid grid-cols-2 rounded-xl border border-border bg-muted p-1"><button onClick={() => setView('operacional')} className={`min-h-11 rounded-lg text-sm font-medium ${view === 'operacional' ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground'}`}>Operacional</button><button onClick={() => setView('analisar')} className={`min-h-11 rounded-lg text-sm font-medium ${view === 'analisar' ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground'}`}>Analisar</button></div>

      {view === 'operacional' ? <>
        <FiltrosDespesasBar filtros={filtros} setFiltros={setFiltros} obras={obras} cartoes={cartoes} fornecedores={nomesFornecedoresHistorico} responsaveis={responsaveis} beneficiarios={beneficiarios} onClear={() => setFiltros(EMPTY)} />
        <ResumoDespesas resumo={resumo} onFilter={applyFilter} />
        <div className="space-y-4"><ProximosVencimentos items={itemsObra} onOpen={openDetail} /><DespesasAtrasadas items={itemsPeriodo} onOpen={openDetail} /></div>
        <AguardandoAprovacao items={items} podeAprovar={podeAprovar} onAprovar={onAprovar} onReprovar={onReprovar} onOpen={openDetail} />
        <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white px-4 py-3"><p className="text-sm text-slate-500">{filtered.length} despesa(s)</p><p className="text-sm font-semibold text-[#0b2545]">Total: {fmtMoney(totalValor)}</p></div>
        <SortBar columns={[{ key: 'fornecedor', label: 'Fornecedor', flex: true }, { key: 'descricao', label: 'Descrição' }, { key: 'valor', label: 'Valor' }, { key: 'vencimento', label: 'Vencimento' }]} sortField={sortField} sortDir={sortDir} onSort={toggleSort} />
        <div className="space-y-2.5">{filtered.length === 0 ? <p className="py-10 text-center text-sm text-slate-400">Nenhuma despesa encontrada com os filtros atuais.</p> : filtered.map((d) => <DespesaItemCompact key={d.id} d={d} podeEditar={podeEditar} onOpen={openDetail} onMarkPaid={setSettlement} />)}</div>
      </> : <Suspense fallback={<p className="py-10 text-center text-sm text-muted-foreground">Carregando análises…</p>}><DespesasAnalise items={itemsPeriodo} futureItems={itemsObra} range={range} setObra={setObra} applyFilter={applyFilter} onPeriod={onPeriod} podeVerEstrategico={podeVerEstrategico} /></Suspense>}

      <QuickSettlementDialog record={settlement} type="despesa" open={!!settlement} onClose={() => setSettlement(null)} onConfirm={markPaid} pending={settling} />
      <DespesaModal d={detail} open={!!detail} onClose={() => setDetail(null)} onSave={onSave} onDelete={onDelete} obras={obras} cartoes={cartoes} podeEditar={podeEditar} podeExcluir={podeExcluir} fornecedoresHistorico={nomesFornecedoresHistorico} />

      {edit && <DespesaForm record={edit} obras={obrasAtivas} cartoes={cartoes} fornecedores={fornecedores} despesasHistorico={items} onCriarFornecedor={onCriarFornecedor} onClose={() => setEdit(null)} onSave={async (f, id) => { const ok = await onSave(f, id); if (ok) setEdit(null); }} />}
    </div>
  );
}