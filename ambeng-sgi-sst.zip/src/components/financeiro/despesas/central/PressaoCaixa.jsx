import React from 'react';
import { fmtMoney } from '@/lib/financeiro';

export default function PressaoCaixa({ pressao, onPeriod }) {
  const items = [
    { key: 'd7', label: 'Próximos 7 dias', val: pressao.d7 },
    { key: 'd15', label: 'Próximos 15 dias', val: pressao.d15 },
    { key: 'd30', label: 'Próximos 30 dias', val: pressao.d30 },
    { key: 'd60', label: 'Próximos 60 dias', val: pressao.d60 },
    { key: 'd90', label: 'Próximos 90 dias', val: pressao.d90 },
  ];
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-3">Comprometimento Futuro</p>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {items.map((it) => (
          <button key={it.key} onClick={() => onPeriod(it.key)} className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-left hover:shadow-card-hover transition">
            <p className="text-xs text-blue-700">{it.label}</p>
            <p className="text-base font-bold text-blue-700 mt-1">{fmtMoney(it.val)}</p>
          </button>
        ))}
      </div>
    </div>
  );
}