import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { Receipt, Plus, Trash2, FileText, FileCheck2, Paperclip, Upload, Save, ChevronDown, ChevronUp } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { fmtMoney, despesaStatus, valorMes, CATEGORIAS, today, calcParcelas } from '@/lib/financeiro';
import { nomeUsuario } from '@/lib/usuarioNome';
import { calcProximoCicloCartao } from '@/lib/cicloCartao';
import { applyTitleCaseAll } from '@/lib/titleCase';
import { mensagemAmigavelErro, validarDataOpcional, validarNumeroOpcional } from '@/lib/validacao';

const FORMAS = ['PIX', 'Boleto', 'Cartão Crédito'];
const STATUS_PAG = ['Pendente', 'Pago', 'Parcial', 'Atrasado'];
const STATUS_APROV = [
  { v: '', l: 'Não informado' },
  { v: 'Rascunho', l: 'Rascunho' },
  { v: 'Aguardando aprovação', l: 'Aguardando aprovação' },
  { v: 'Aprovada', l: 'Aprovada' },
  { v: 'Reprovada', l: 'Reprovada' },
  { v: 'Cancelada', l: 'Cancelada' },
];
const TIPOS_ANEXO = ['Nota fiscal', 'Boleto', 'Comprovante', 'Outros'];
const CAMPOS_HIST = {
  descricao: 'Descrição', fornecedor: 'Fornecedor', obra: 'Obra',
  categoria: 'Categoria', forma_pagamento: 'Forma de pagamento',
  cartao: 'Cartão', data_vencimento: 'Vencimento', data_pagamento: 'Data do pagamento',
  data_compra: 'Data da compra', status: 'Status do pagamento', responsavel: 'Responsável',
  status_aprovacao: 'Status da aprovação', data_aprovacao: 'Data da aprovação',
  observacoes: 'Observação', valor: 'Valor total', parcela_atual: 'Parcela atual', total_parcelas: 'Total de parcelas',
};

const fmtDate = (iso) => iso ? new Date(iso + 'T00:00').toLocaleDateString('pt-BR') : '—';

function initForm(d) {
  if (!d) d = {};
  const f = {};
  ['descricao', 'fornecedor', 'obra', 'categoria', 'forma_pagamento', 'cartao',
    'status', 'status_aprovacao', 'responsavel', 'observacoes', 'data_vencimento', 'data_pagamento', 'data_compra', 'data_aprovacao', 'anexos', 'historico']
    .forEach((k) => { f[k] = d[k] ?? ''; });
  ['valor', 'valor_parcela', 'parcela_atual', 'total_parcelas'].forEach((k) => { f[k] = d[k] ?? ''; });
  return f;
}

function parseJSON(v, fb) { try { return v ? JSON.parse(v) : fb; } catch { return fb; } }
function appendHist(histStr, entries) {
  const arr = parseJSON(histStr, []);
  entries.forEach((e) => arr.push({ ...e, data_hora: new Date().toISOString() }));
  return JSON.stringify(arr);
}

function Card({ title, action, children, className }) {
  return (
    <div className={`bg-white border border-slate-200 rounded-xl shadow-card ${className || ''}`}>
      <div className="px-4 py-2.5 border-b border-slate-100 flex items-center justify-between">
        <h4 className="text-xs font-bold uppercase tracking-wider text-[#0b2545]">{title}</h4>
        {action}
      </div>
      <div className="p-4">{children}</div>
    </div>
  );
}

function ResumoCard({ label, value, sub, accent }) {
  return (
    <div className={`rounded-xl border p-3 ${accent || 'border-slate-200 bg-white'}`}>
      <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">{label}</div>
      <div className="text-lg font-bold text-[#0b2545] mt-0.5 leading-tight">{value}</div>
      {sub && <div className="text-[11px] text-slate-500 mt-0.5">{sub}</div>}
    </div>
  );
}

// Campo de formulário: label + input, com cálculo automático
function FormField({ label, children, hint }) {
  return (
    <div>
      <Label className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">{label}</Label>
      <div className="mt-1">{children}</div>
      {hint && <p className="text-[11px] text-slate-400 mt-0.5">{hint}</p>}
    </div>
  );
}

// Fornecedor com auto-complete a partir do histórico
function FornecedorAutocomplete({ value, onCommit, suggestions, readOnly }) {
  const [draft, setDraft] = useState(value);
  const [focused, setFocused] = useState(false);
  const inputRef = useRef(null);
  useEffect(() => { setDraft(value); }, [value]);

  const filtered = useMemo(() => {
    if (!draft || draft.length < 1) return [];
    return suggestions.filter((s) => s.toLowerCase().includes(draft.toLowerCase())).slice(0, 8);
  }, [draft, suggestions]);

  if (readOnly) {
    return <div className="h-11 flex items-center px-3 text-sm text-slate-700 rounded-lg border border-slate-200 bg-slate-50">{value || '—'}</div>;
  }

  return (
    <div className="relative">
      <Input
        ref={inputRef}
        value={draft || ''}
        onChange={(e) => setDraft(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => { setTimeout(() => setFocused(false), 150); onCommit(applyTitleCaseAll(draft)); }}
        placeholder="Digite o fornecedor"
      />
      {focused && filtered.length > 0 && (
        <div className="absolute z-50 mt-1 w-full bg-white border border-slate-200 rounded-lg shadow-card-hover max-h-48 overflow-y-auto">
          {filtered.map((s) => (
            <button
              key={s}
              type="button"
              className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 border-b border-slate-50 last:border-0"
              onMouseDown={(e) => { e.preventDefault(); setDraft(s); onCommit(s); setFocused(false); }}
            >
              {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function DespesaModal({ d, open, onClose, onSave, onDelete, obras, cartoes, podeEditar, podeExcluir, fornecedoresHistorico }) {
  const { toast } = useToast();
  const [form, setForm] = useState(() => initForm(d));
  const [base, setBase] = useState(() => initForm(d));
  const [user, setUser] = useState(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [novoTipo, setNovoTipo] = useState('Nota fiscal');
  const [showComplete, setShowComplete] = useState(false);
  const fileRef = useRef(null);

  useEffect(() => { if (open) { setUser(null); (async () => { try { setUser(await base44.auth.me()); } catch {} })(); } }, [open]);
  useEffect(() => {
    if (d) {
      const f = initForm(d);
      setForm(f); setBase(f);
    }
  }, [d]);

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  const readOnly = !podeEditar;

  const stPag = despesaStatus(form);
  const stAprov = form.status_aprovacao || 'Não informado';
  const parcelado = Number(form.total_parcelas) > 1;
  const valorCompetencia = valorMes(form);
  const tituloCurto = (form.descricao || 'Despesa').replace(/\s*\(\d+\/\d+\)\s*$/, '');

  // Cálculo automático de valor_parcela
  const valorTotalNum = Number(form.valor) || 0;
  const totalParcNum = Math.max(1, parseInt(form.total_parcelas) || 1);
  const valorParcelaCalc = (calcParcelas(valorTotalNum, totalParcNum)[0]) || 0;

  const dirty = useMemo(() => Object.keys(CAMPOS_HIST).some((k) => String(form[k] ?? '') !== String(base[k] ?? '')), [form, base]);

  const ST_PAG = { Pago: 'bg-emerald-100 text-emerald-700', Parcial: 'bg-sky-100 text-sky-700', Pendente: 'bg-amber-100 text-amber-700', Atrasado: 'bg-red-100 text-red-700' };
  const ST_APROV = {
    'Aprovada': 'bg-emerald-100 text-emerald-700', 'Aguardando aprovação': 'bg-amber-100 text-amber-700',
    'Reprovada': 'bg-red-100 text-red-700', 'Rascunho': 'bg-slate-100 text-slate-600',
    'Cancelada': 'bg-slate-100 text-slate-500', 'Não informado': 'bg-slate-100 text-slate-500',
  };

  // ANEXOS
  const anexos = parseJSON(form.anexos, []);
  const addAnexo = async (file) => {
    if (!file || !d?.id) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const arr = [...anexos, { url: file_url, nome: file.name, tipo: novoTipo, data: new Date().toISOString() }];
      const str = JSON.stringify(arr);
      set('anexos', str);
      const hist = appendHist(form.historico, [{ usuario: nomeUsuario(user), campo: 'Anexo', anterior: '—', novo: file.name }]);
      set('historico', hist);
      await base44.entities.Despesas.update(d.id, { anexos: str, historico: hist });
      toast({ title: 'Anexo adicionado.' });
    } catch (e) { toast({ title: 'Falha ao enviar anexo.', description: e?.message, variant: 'destructive' }); }
    setUploading(false);
    if (fileRef.current) fileRef.current.value = '';
  };
  const removeAnexo = async (idx) => {
    if (!confirm('Remover este anexo?')) return;
    const arr = anexos.filter((_, i) => i !== idx);
    const str = JSON.stringify(arr);
    set('anexos', str);
    const hist = appendHist(form.historico, [{ usuario: nomeUsuario(user), campo: 'Anexo', anterior: anexos[idx]?.nome || '—', novo: '—' }]);
    set('historico', hist);
    if (d?.id) await base44.entities.Despesas.update(d.id, { anexos: str, historico: hist });
    toast({ title: 'Anexo removido.' });
  };

  // SALVAR
  const salvar = async () => {
    if (!d?.id) return;
    if (!validarNumeroOpcional(form.valor) || !validarNumeroOpcional(form.valor_pago)) return toast({ title: 'Informe valores numéricos válidos e não negativos.', variant: 'destructive' });
    if ([form.data_compra, form.data_vencimento, form.data_pagamento, form.data_aprovacao].some((data) => !validarDataOpcional(data))) return toast({ title: 'Informe datas válidas.', variant: 'destructive' });

    setSaving(true);
    try {
      const diff = [];
      Object.keys(CAMPOS_HIST).forEach((k) => {
        const ant = base[k] ?? '';
        const nv = form[k] ?? '';
        if (String(ant) !== String(nv)) diff.push({ usuario: nomeUsuario(user), campo: CAMPOS_HIST[k], campoKey: k, anterior: ant || '—', novo: nv || '—' });
      });
      const payload = { ...form };
      Object.keys(payload).forEach((k) => {
        if (payload[k] === '' || (typeof payload[k] === 'object' && payload[k] !== null)) payload[k] = null;
      });
      ['valor', 'valor_parcela', 'valor_pago', 'parcela_atual', 'total_parcelas'].forEach((k) => { payload[k] = payload[k] == null ? null : Number(payload[k]); });
      if (payload.forma_pagamento !== 'Cartão Crédito') payload.cartao = null;
      if (diff.length) payload.historico = appendHist(form.historico, diff.map(({ campo, ...r }) => ({ ...r, campo })));
      const ok = await onSave(payload, d.id);
      if (ok) { setBase({ ...form }); toast({ title: 'Alterações salvas.' }); }
    } catch (e) { toast({ title: 'Erro ao salvar.', description: mensagemAmigavelErro(e), variant: 'destructive' }); }
    setSaving(false);
  };

  const excluir = async () => {
    if (!confirm('Excluir esta despesa?')) return;
    await onDelete(d.id); onClose();
  };

  // HISTÓRICO
  const hist = parseJSON(form.historico, []);
  const iconAnexo = (tipo) => /nota/i.test(tipo) ? FileText : /boleto/i.test(tipo) ? FileCheck2 : Paperclip;
  const AnexoIcon = (t) => { const Ic = iconAnexo(t); return <Ic className="w-4 h-4 text-slate-500" />; };

  // Handlers com automação
  const handleFormaPagamento = (v) => {
    set('forma_pagamento', v);
    if (v !== 'Cartão Crédito') {
      set('cartao', '');
    }
  };

  const handleCartao = (v) => {
    set('cartao', v);
    if (v && cartoes) {
      const cartaoSelecionado = cartoes.find((c) => c.nome === v);
      if (cartaoSelecionado) {
        const { data_pagamento, data_vencimento } = calcProximoCicloCartao(cartaoSelecionado);
        set('data_pagamento', data_pagamento);
        set('data_vencimento', data_vencimento);
      }
    }
  };

  const handleParcelas = (v) => {
    const n = Math.max(1, parseInt(v) || 1);
    setForm((p) => ({
      ...p,
      total_parcelas: n,
      parcela_atual: Math.min(Number(p.parcela_atual) || 1, n) || 1,
      valor_parcela: calcParcelas(Number(p.valor) || 0, n)[0] || 0,
      tipo_pagamento: n > 1 ? 'Parcelado' : 'À vista',
    }));
  };

  const handleValor = (v) => {
    const n = Number(v) || 0;
    setForm((p) => {
      const parc = Math.max(1, parseInt(p.total_parcelas) || 1);
      return { ...p, valor: v, valor_parcela: calcParcelas(n, parc)[0] || 0 };
    });
  };

  const handleVencimento = (v) => {
    set('data_vencimento', v);
    if (form.status !== 'Pago') {
      const hoje = today();
      set('status', v && v < hoje ? 'Atrasado' : 'Pendente');
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl w-[92vw] max-h-[92vh] p-0 gap-0 overflow-hidden flex flex-col">
        {/* Cabeçalho */}
        <div className="px-6 py-4 border-b border-slate-200 bg-gradient-to-r from-[#0b2545] to-[#16365f] text-white shrink-0">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0"><Receipt className="w-5 h-5" /></div>
              <div className="min-w-0">
                <h2 className="text-lg font-bold leading-tight truncate">DESPESA — {tituloCurto}{parcelado ? ` (${form.parcela_atual || 0}/${form.total_parcelas})` : ''}</h2>
                <p className="text-sm text-white/70 mt-0.5 truncate">{[form.fornecedor, form.obra, form.categoria].filter(Boolean).join(' · ') || 'Sem dados cadastrais'}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className={`px-2.5 py-1 rounded-full text-[11px] font-semibold ${ST_PAG[stPag]}`}>Pag.: {stPag}</span>
              <span className={`px-2.5 py-1 rounded-full text-[11px] font-semibold ${ST_APROV[stAprov] || 'bg-slate-100 text-slate-500'}`}>Aprov.: {stAprov}</span>
            </div>
          </div>
        </div>

        {/* Corpo */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50/60">

          {/* Resumo financeiro */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <ResumoCard label="Valor total" value={fmtMoney(form.valor)} />
            <ResumoCard label="Parcela" value={parcelado ? `${form.parcela_atual || 0}/${form.total_parcelas}` : 'À vista'} />
            <ResumoCard label="Vencimento" value={fmtDate(form.data_vencimento)} />
            <ResumoCard label="Status" value={stPag} />
          </div>

          {/* SEÇÃO RÁPIDA */}
          <Card title="Dados principais">
            <div className="grid sm:grid-cols-2 gap-4">
              <FormField label="Descrição" required>
                <Input value={form.descricao} onChange={(e) => set('descricao', applyTitleCaseAll(e.target.value))} readOnly={readOnly} placeholder="Descrição da despesa" />
              </FormField>
              <FormField label="Fornecedor">
                <FornecedorAutocomplete value={form.fornecedor} onCommit={(v) => set('fornecedor', v)} suggestions={fornecedoresHistorico || []} readOnly={readOnly} />
              </FormField>
              <FormField label="Categoria" required>
                <Select value={form.categoria} onValueChange={(v) => set('categoria', v)} disabled={readOnly}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>{CATEGORIAS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </FormField>
              <FormField label="Forma de Pagamento" required>
                <Select value={form.forma_pagamento} onValueChange={handleFormaPagamento} disabled={readOnly}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>{FORMAS.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent>
                </Select>
              </FormField>
              {form.forma_pagamento === 'Cartão Crédito' && (
                <FormField label="Cartão" required>
                  <Select value={form.cartao} onValueChange={handleCartao} disabled={readOnly}>
                    <SelectTrigger><SelectValue placeholder="Selecione o cartão" /></SelectTrigger>
                    <SelectContent>{cartoes.map((c) => <SelectItem key={c.id} value={c.nome}>{c.nome}</SelectItem>)}</SelectContent>
                  </Select>
                </FormField>
              )}
              <FormField label="Data de Vencimento" required>
                <Input type="date" value={form.data_vencimento} onChange={(e) => handleVencimento(e.target.value)} disabled={readOnly} />
              </FormField>
              <FormField label="Data do Pagamento">
                <Input type="date" value={form.data_pagamento} onChange={(e) => set('data_pagamento', e.target.value)} disabled={readOnly} />
              </FormField>
              <FormField label="Valor Total (R$)" required>
                <Input type="number" step="0.01" value={form.valor} onChange={(e) => handleValor(e.target.value)} disabled={readOnly} />
              </FormField>
              <FormField label="Quantidade de Parcelas" hint={parcelado ? `Valor da parcela: ${fmtMoney(valorParcelaCalc)}` : '1 = à vista'}>
                <Input type="number" min="1" value={form.total_parcelas} onChange={(e) => handleParcelas(e.target.value)} disabled={readOnly} />
              </FormField>
              <FormField label="Status do Pagamento">
                <Select value={form.status} onValueChange={(v) => set('status', v)} disabled={readOnly}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{STATUS_PAG.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </FormField>
            </div>
          </Card>

          {/* SEÇÃO COMPLETA (expandível) */}
          <button
            type="button"
            onClick={() => setShowComplete((s) => !s)}
            className="w-full flex items-center justify-between px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-xs font-bold uppercase tracking-wider text-[#0b2545] hover:bg-slate-50"
          >
            <span>Mais opções</span>
            {showComplete ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {showComplete && (
            <div className="space-y-4">
              <Card title="Dados complementares">
                <div className="grid sm:grid-cols-2 gap-4">
                  <FormField label="Obra">
                    <Select value={form.obra} onValueChange={(v) => set('obra', v)} disabled={readOnly}>
                      <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                      <SelectContent>{obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}</SelectContent>
                    </Select>
                  </FormField>
                  <FormField label="Responsável">
                    <Input value={form.responsavel} onChange={(e) => set('responsavel', applyTitleCaseAll(e.target.value))} readOnly={readOnly} />
                  </FormField>
                  <FormField label="Status da Aprovação">
                    <Select value={form.status_aprovacao || '_none'} onValueChange={(v) => set('status_aprovacao', v === '_none' ? '' : v)} disabled={readOnly}>
                      <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                      <SelectContent>{STATUS_APROV.map((s) => <SelectItem key={s.v || 'none'} value={s.v || '_none'}>{s.l}</SelectItem>)}</SelectContent>
                    </Select>
                  </FormField>
                  <FormField label="Data da Aprovação">
                    <Input type="date" value={form.data_aprovacao} onChange={(e) => set('data_aprovacao', e.target.value)} disabled={readOnly} />
                  </FormField>
                  <FormField label="Observação" className="sm:col-span-2">
                    <Textarea rows={2} value={form.observacoes} onChange={(e) => set('observacoes', e.target.value)} readOnly={readOnly} />
                  </FormField>
                </div>
              </Card>
            </div>
          )}

          {/* Anexos */}
          <Card title="Anexos" action={!readOnly && (
            <div className="flex items-center gap-2">
              <Select value={novoTipo} onValueChange={setNovoTipo}>
                <SelectTrigger className="h-8 w-[140px] text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>{TIPOS_ANEXO.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
              <Button size="sm" variant="outline" onClick={() => fileRef.current?.click()} disabled={uploading} className="h-8">
                {uploading ? <><Upload className="w-3.5 h-3.5" />Enviando…</> : <><Plus className="w-3.5 h-3.5" />Adicionar arquivo</>}
              </Button>
              <input ref={fileRef} type="file" className="hidden" onChange={(e) => e.target.files?.[0] && addAnexo(e.target.files[0])} />
            </div>
          )}>
            {anexos.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-4">Nenhum anexo. {podeEditar && 'Toque em "Adicionar arquivo".'}</p>
            ) : (
              <div className="space-y-2">
                {anexos.map((a, i) => (
                  <div key={i} className="flex items-center gap-3 p-2 rounded-lg border border-slate-200 bg-slate-50/60">
                    {AnexoIcon(a.tipo)}
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium text-slate-700 truncate">{a.nome}</div>
                      <div className="text-[11px] text-slate-500">{a.tipo} · {new Date(a.data).toLocaleDateString('pt-BR')}</div>
                    </div>
                    <a href={a.url} target="_blank" rel="noreferrer" className="text-xs text-[#0b2545] font-medium hover:underline">Abrir</a>
                    {!readOnly && <button onClick={() => removeAnexo(i)} className="p-1 text-slate-400 hover:text-rose-500"><Trash2 className="w-4 h-4" /></button>}
                  </div>
                ))}
              </div>
            )}
          </Card>

          {/* Histórico */}
          <Card title="Histórico">
            {hist.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-4">Sem alterações registradas.</p>
            ) : (
              <div className="space-y-1.5">
                {hist.slice().reverse().map((h, i) => {
                  const dt = new Date(h.data_hora);
                  return (
                    <div key={i} className="flex items-start gap-3 text-sm py-1 border-b border-slate-50 last:border-0">
                      <div className="w-20 shrink-0 text-xs font-bold text-[#0b2545] uppercase truncate">{h.usuario || '—'}</div>
                      <div className="text-xs text-slate-400 w-36 shrink-0">{dt.toLocaleDateString('pt-BR')} {dt.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                      <div className="min-w-0 flex-1">
                        <span className="text-slate-500">{h.campo}: </span>
                        <span className="text-slate-400 line-through">{h.anterior}</span> <span className="text-slate-400">→</span> <span className="text-slate-700 font-medium">{h.novo}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>

        {/* Rodapé */}
        <div className="px-6 py-3 border-t border-slate-200 bg-white flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-500">{dirty ? 'Você tem alterações não salvas.' : 'Alterações salvas.'}</div>
          <div className="flex items-center gap-2">
            {podeExcluir && <Button variant="destructive" onClick={excluir} className="min-h-[44px]"><Trash2 className="w-4 h-4 mr-1" />Excluir</Button>}
            {!readOnly && <Button onClick={salvar} disabled={saving || !dirty} className="bg-[#0b2545] hover:bg-[#16365f] min-h-[44px]"><Save className="w-4 h-4 mr-1" />{saving ? 'Salvando…' : 'Salvar alterações'}</Button>}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}