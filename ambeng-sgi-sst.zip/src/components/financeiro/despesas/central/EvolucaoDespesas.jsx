import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { fmtMoney, shortDate } from '@/lib/financeiro';
import { evolucaoDespesas } from '@/lib/despesasCentral';

const GRAN = [{ id: 'dia', label: 'Diário' }, { id: 'semana', label: 'Semanal' }, { id: 'mes', label: 'Mensal' }];

export default function EvolucaoDespesas({ items, range }) {
  const [g, setG] = useState('mes');
  const data = evolucaoDespesas(items, g, range);
  const fmtLabel = (l) => (g === 'dia' ? shortDate(l) : g === 'mes' ? `${l.slice(5, 7)}/${l.slice(2, 4)}` : shortDate(l));
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-[#0b2545]">Evolução das Despesas</h3>
        <div className="flex gap-1">
          {GRAN.map((x) => <button key={x.id} onClick={() => setG(x.id)} className={`text-xs px-3 py-1.5 rounded-lg ${g === x.id ? 'bg-[#0b2545] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>{x.label}</button>)}
        </div>
      </div>
      <ResponsiveContainer width="100%" height={240}>
        <BarChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
          <XAxis dataKey="label" tickFormatter={fmtLabel} tick={{ fontSize: 11, fill: '#94a3b8' }} />
          <YAxis tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} tick={{ fontSize: 11, fill: '#94a3b8' }} />
          <Tooltip formatter={(v) => fmtMoney(v)} labelFormatter={(l) => fmtLabel(l)} contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 12 }} />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Bar dataKey="Pago" stackId="a" fill="#10b981" name="Pago" />
          <Bar dataKey="Pendente" stackId="a" fill="#f59e0b" name="Pendente" />
          <Bar dataKey="Atrasado" stackId="a" fill="#ef4444" name="Atrasado" />
        </BarChart>
      </ResponsiveContainer>
      {!data.length && <p className="text-sm text-slate-400 text-center -mt-20">Sem dados no período.</p>}
    </div>
  );
}