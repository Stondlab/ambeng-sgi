import React, { useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { CalendarDays, CreditCard, Sparkles, X } from 'lucide-react';
import { CATEGORIAS, addMeses, calcParcelas, fmtMoney, today } from '@/lib/financeiro';
import { calcVencimentoCartao, vencimentoParcela } from '@/lib/cicloCartao';
import { applyTitleCaseAll } from '@/lib/titleCase';
import { validarDataOpcional, validarNumeroOpcional } from '@/lib/validacao';
import FornecedorPicker from './FornecedorPicker';
import DespesaAnexosDropzone from './DespesaAnexosDropzone';
import ParcelasPreview from './ParcelasPreview';

const FORMAS = [{ value: 'Pix', label: 'PIX' }, { value: 'Boleto', label: 'Boleto' }, { value: 'Cartão Crédito', label: 'Cartão de Crédito' }];
const TIPOS = ['À vista', 'Parcelado'];
const STATUS = ['Pendente', 'Pago', 'Parcial'];
const CATEGORIAS_DIRETAS = ['Mão de Obra', 'Material', 'Equipamento', 'Serviço', 'Serviço Terceirizado'];
const Field = ({ label, className = '', hint, children }) => <div className={className}><Label>{label}</Label><div className="mt-1">{children}</div>{hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}</div>;

export default function DespesaForm({ record, obras, cartoes, fornecedores = [], despesasHistorico = [], onCriarFornecedor, onClose, onSave }) {
  const { toast } = useToast();
  const [uploading, setUploading] = useState(false);
  const [sugestaoCategoria, setSugestaoCategoria] = useState('');
  const [form, setForm] = useState(() => ({
    descricao: typeof record.descricao === 'string' ? record.descricao : '', fornecedor: typeof record.fornecedor === 'string' ? record.fornecedor : '', fornecedor_id: record.fornecedor_id || '', obra: typeof record.obra === 'string' ? record.obra : '', obra_id: record.obra_id || '',
    data_compra: record.data_compra || '', valor: record.valor ?? '', forma_pagamento: record.forma_pagamento || '', cartao: record.cartao || '', cartao_id: record.cartao_id || '',
    tipo_pagamento: record.tipo_pagamento || '', total_parcelas: record.total_parcelas ?? '', categoria: record.categoria || '', status: record.status || '',
    data_vencimento: record.data_vencimento || '', data_pagamento: record.data_pagamento || '', valor_pago: record.valor_pago || '', funcionario: record.funcionario || record.beneficiario || '', funcionario_id: record.funcionario_id || '', observacoes: record.observacoes || '', anexos: record.anexos || '',
  }));
  const set = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));
  const cartoesCredito = useMemo(() => cartoes.filter((c) => c.ativa !== false && c.tipo !== 'Débito'), [cartoes]);
  const cartaoSelecionado = cartoesCredito.find((c) => c.id === form.cartao_id || c.nome === form.cartao);
  const parcelado = form.tipo_pagamento === 'Parcelado';
  const totalParcelas = parcelado ? Math.max(2, Number(form.total_parcelas) || 2) : 1;
  const valoresParcelas = useMemo(() => calcParcelas(form.valor, totalParcelas), [form.valor, totalParcelas]);
  const datasParcelas = useMemo(() => Array.from({ length: totalParcelas }, (_, i) => form.forma_pagamento === 'Cartão Crédito' ? vencimentoParcela(form.data_vencimento, i) : addMeses(form.data_vencimento, i)), [form.forma_pagamento, form.data_vencimento, totalParcelas]);
  const anexos = useMemo(() => { try { return form.anexos ? JSON.parse(form.anexos) : []; } catch { return []; } }, [form.anexos]);

  const recalcularVencimento = (dataCompra, cartao = cartaoSelecionado) => {
    if (form.forma_pagamento === 'Pix') set('data_vencimento', dataCompra);
    if (form.forma_pagamento === 'Cartão Crédito' && cartao) set('data_vencimento', calcVencimentoCartao(cartao, dataCompra));
  };
  const selecionarFornecedor = (fornecedor) => {
    setForm((prev) => ({ ...prev, fornecedor: fornecedor.nome || '', fornecedor_id: fornecedor.id || '' }));
    const historico = despesasHistorico.filter((d) => (fornecedor.id && d.fornecedor_id === fornecedor.id) || (d.fornecedor || '').toLowerCase() === (fornecedor.nome || '').toLowerCase());
    const contagem = historico.reduce((map, d) => ({ ...map, [d.categoria]: (map[d.categoria] || 0) + 1 }), {});
    const frequente = Object.entries(contagem).sort((a, b) => b[1] - a[1])[0]?.[0];
    setSugestaoCategoria(CATEGORIAS.includes(fornecedor.categoria) ? fornecedor.categoria : (CATEGORIAS.includes(frequente) ? frequente : ''));
  };
  const escolherForma = (value) => {
    setForm((prev) => ({ ...prev, forma_pagamento: value, cartao: value === 'Cartão Crédito' ? prev.cartao : '', cartao_id: value === 'Cartão Crédito' ? prev.cartao_id : '', data_vencimento: value === 'Pix' ? prev.data_compra : value === 'Boleto' ? '' : prev.data_vencimento }));
  };
  const escolherCartao = (id) => {
    const cartao = cartoesCredito.find((c) => c.id === id);
    setForm((prev) => ({ ...prev, cartao_id: id, cartao: cartao?.nome || '', data_vencimento: calcVencimentoCartao(cartao, prev.data_compra) }));
  };
  const escolherStatus = (value) => setForm((prev) => ({ ...prev, status: value, data_pagamento: value === 'Pendente' ? '' : (prev.data_pagamento || today()), valor_pago: value === 'Parcial' ? prev.valor_pago : '' }));
  const adicionarAnexo = async (file) => {
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      set('anexos', JSON.stringify([...anexos, { url: file_url, nome: file.name, tipo: 'Anexo', data: new Date().toISOString() }]));
    } catch (e) {
      toast({ title: 'Não foi possível anexar o arquivo', description: e?.message, variant: 'destructive' });
    } finally {
      setUploading(false);
    }
  };
  const removerAnexo = (index) => set('anexos', JSON.stringify(anexos.filter((_, i) => i !== index)));

  const submit = () => {
    if (CATEGORIAS_DIRETAS.includes(form.categoria) && !form.obra_id) return toast({ title: 'Selecione a obra para esta despesa direta.', variant: 'destructive' });
    if (!validarNumeroOpcional(form.valor) || !validarNumeroOpcional(form.valor_pago)) return toast({ title: 'Informe valores numéricos válidos e não negativos.', variant: 'destructive' });
    const datas = [form.data_compra, form.data_vencimento, form.data_pagamento];
    if (datas.some((data) => !validarDataOpcional(data))) return toast({ title: 'Informe datas válidas.', variant: 'destructive' });
    const optionalText = (value) => typeof value === 'string' && value.trim() ? applyTitleCaseAll(value.trim()) : null;
    onSave({
      ...form,
      descricao: optionalText(form.descricao),
      fornecedor: optionalText(form.fornecedor),
      observacoes: optionalText(form.observacoes),
      total_parcelas: form.total_parcelas === '' ? null : totalParcelas,
      valor_parcela: form.valor === '' ? null : valoresParcelas[0],
      datas_parcelas: form.data_vencimento ? datasParcelas : [],
    }, record.id);
  };

  return <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-4">
    <div className="absolute inset-0 bg-black/40" onClick={onClose} />
    <div className="relative max-h-[94vh] w-full overflow-y-auto rounded-t-2xl bg-background p-5 shadow-card-hover sm:max-w-2xl sm:rounded-2xl">
      <div className="mb-5 flex items-start justify-between"><div><h3 className="text-lg font-semibold text-primary">Nova Despesa</h3><p className="text-sm text-muted-foreground">Preencha o essencial; o restante é calculado automaticamente.</p></div><button onClick={onClose} className="min-h-[44px] min-w-[44px]"><X className="mx-auto h-5 w-5" /></button></div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Obra"><Select value={form.obra} onValueChange={(nome) => { const obra = obras.find((o) => o.nome === nome); setForm((p) => ({ ...p, obra: nome, obra_id: obra?.id || '' })); }}><SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}</SelectContent></Select></Field>
        <Field label="Descrição" required className="sm:col-span-2"><Input value={form.descricao} onChange={(e) => set('descricao', e.target.value)} autoFocus placeholder="Ex.: Compra de materiais elétricos" /></Field>
        <Field label="Fornecedor"><FornecedorPicker value={form.fornecedor} fornecedores={fornecedores} onSelect={selecionarFornecedor} onCreate={onCriarFornecedor} /></Field>
        <Field label="Funcionário / beneficiário"><Input value={form.funcionario} onChange={(e) => set('funcionario', e.target.value)} placeholder="Opcional" /></Field>
        <Field label="Data da compra" required><Input type="date" value={form.data_compra} onChange={(e) => { set('data_compra', e.target.value); recalcularVencimento(e.target.value); }} /></Field>
        <Field label="Valor total (R$)" required><Input type="number" min="0.01" step="0.01" value={form.valor} onChange={(e) => set('valor', e.target.value)} placeholder="0,00" /></Field>
        <Field label="Forma de pagamento" required><Select value={form.forma_pagamento} onValueChange={escolherForma}><SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{FORMAS.map((f) => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}</SelectContent></Select></Field>

        {form.forma_pagamento && <Field label="Tipo de pagamento"><Select value={form.tipo_pagamento} onValueChange={(value) => setForm((p) => ({ ...p, tipo_pagamento: value, total_parcelas: value === 'À vista' ? 1 : Math.max(2, Number(p.total_parcelas) || 2) }))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{TIPOS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select></Field>}
        {form.forma_pagamento === 'Cartão Crédito' && <Field label="Cartão" required><Select value={form.cartao_id} onValueChange={escolherCartao}><SelectTrigger><SelectValue placeholder="Selecione o cartão" /></SelectTrigger><SelectContent>{cartoesCredito.map((c) => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent></Select></Field>}
        {parcelado && <Field label="Quantidade de parcelas" required><Input type="number" min="2" value={form.total_parcelas} onChange={(e) => set('total_parcelas', Math.max(2, Number(e.target.value) || 2))} /></Field>}
        {parcelado && <Field label="Valor da parcela" hint="A última parcela absorve eventuais centavos."><Input readOnly value={fmtMoney(valoresParcelas[0])} /></Field>}
        {form.forma_pagamento === 'Boleto' && <Field label="Primeiro vencimento" required><Input type="date" value={form.data_vencimento} onChange={(e) => set('data_vencimento', e.target.value)} /></Field>}
        {form.forma_pagamento === 'Pix' && <div className="flex items-center gap-2 rounded-xl border bg-muted/30 p-3 text-sm text-muted-foreground"><CalendarDays className="h-4 w-4" />Vencimento igual à data da compra.</div>}
        {form.forma_pagamento === 'Cartão Crédito' && form.data_vencimento && <div className="flex items-center gap-2 rounded-xl border border-primary/20 bg-primary/5 p-3 text-sm text-primary"><CreditCard className="h-4 w-4" />Fatura com vencimento em <strong>{form.data_vencimento.split('-').reverse().join('/')}</strong></div>}

        <Field label="Categoria" required><Select value={form.categoria} onValueChange={(v) => { set('categoria', v); setSugestaoCategoria(''); }}><SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{CATEGORIAS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select>{sugestaoCategoria && sugestaoCategoria !== form.categoria && <button type="button" onClick={() => { set('categoria', sugestaoCategoria); setSugestaoCategoria(''); }} className="mt-2 flex items-center gap-1 text-xs font-medium text-primary"><Sparkles className="h-3.5 w-3.5" />Usar sugestão: {sugestaoCategoria}</button>}</Field>
        <Field label="Status do pagamento"><Select value={form.status} onValueChange={escolherStatus}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{STATUS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></Field>
        {(form.status === 'Pago' || form.status === 'Parcial') && <Field label="Data de pagamento"><Input type="date" value={form.data_pagamento} onChange={(e) => set('data_pagamento', e.target.value)} /></Field>}
        {form.status === 'Parcial' && <Field label="Valor pago (R$)" required><Input type="number" min="0.01" step="0.01" value={form.valor_pago} onChange={(e) => set('valor_pago', e.target.value)} /></Field>}
        <Field label="Observação" className="sm:col-span-2"><Textarea rows={2} value={form.observacoes} onChange={(e) => set('observacoes', e.target.value)} placeholder="Opcional" /></Field>
        <Field label="Anexo" className="sm:col-span-2"><DespesaAnexosDropzone anexos={anexos} uploading={uploading} onAdd={adicionarAnexo} onRemove={removerAnexo} /></Field>
      </div>
      <div className="mt-4"><ParcelasPreview valores={valoresParcelas} datas={datasParcelas} /></div>
      <div className="mt-5 flex justify-end gap-2"><Button variant="ghost" onClick={onClose}>Cancelar</Button><Button onClick={submit}>Salvar despesa</Button></div>
    </div>
  </div>;
}