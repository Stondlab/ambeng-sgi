import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CATEGORIAS } from '@/lib/financeiro';
import { Search, X } from 'lucide-react';

const FORMAS = ['Dinheiro', 'Pix', 'Cartão Crédito', 'Cartão Débito', 'Boleto', 'Transferência'];
const MESES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

export default function FiltrosDespesas({ filtros, setFiltros, obras, cartoes, onClear, obraGlobal, setObraGlobal }) {
  const set = (k, v) => setFiltros((p) => ({ ...p, [k]: v }));
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Filtros</p>
        <button onClick={onClear} className="text-xs text-slate-400 hover:text-red-500 inline-flex items-center gap-1"><X className="w-3.5 h-3.5" />Limpar</button>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="col-span-2 md:col-span-4">
          <Label>Beneficiário ou fornecedor</Label>
          <div className="relative mt-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <Input className="pl-9" value={filtros.busca} onChange={(e) => set('busca', e.target.value)} placeholder="Buscar fornecedor, beneficiário ou descrição..." />
          </div>
        </div>
        <div><Label>Compra de</Label><Input type="date" className="mt-1" value={filtros.compraInicio} onChange={(e) => set('compraInicio', e.target.value)} /></div>
        <div><Label>Compra até</Label><Input type="date" className="mt-1" value={filtros.compraFim} onChange={(e) => set('compraFim', e.target.value)} /></div>
        <div>
          <Label>Vencimento (mês)</Label>
          <Select value={filtros.mesVenc} onValueChange={(v) => set('mesVenc', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todos</SelectItem>{MESES.map((m, i) => <SelectItem key={i + 1} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent></Select>
        </div>
        <div>
          <Label>Obra</Label>
          <Select value={obraGlobal} onValueChange={setObraGlobal}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="geral">Todas</SelectItem>{obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}</SelectContent></Select>
        </div>
        <div>
          <Label>Cartão</Label>
          <Select value={filtros.cartao} onValueChange={(v) => set('cartao', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todos</SelectItem>{cartoes.map((c) => <SelectItem key={c.id} value={c.nome}>{c.nome}</SelectItem>)}</SelectContent></Select>
        </div>
        <div>
          <Label>Categoria</Label>
          <Select value={filtros.categoria} onValueChange={(v) => set('categoria', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todas</SelectItem>{CATEGORIAS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select>
        </div>
        <div>
          <Label>Tipo de pagamento</Label>
          <Select value={filtros.pagamento} onValueChange={(v) => set('pagamento', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todos</SelectItem>{FORMAS.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent></Select>
        </div>
      </div>
    </div>
  );
}