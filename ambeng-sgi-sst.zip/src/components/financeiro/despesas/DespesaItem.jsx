import React from 'react';
import { fmtMoney, shortDate, despesaStatus, valorMes } from '@/lib/financeiro';
import { catMeta, pagMeta } from './icons';
import { Pencil, Trash2 } from 'lucide-react';

const ST_BADGE = {
  'Pago': 'bg-emerald-100 text-emerald-700',
  'Pendente': 'bg-amber-100 text-amber-700',
  'Atrasado': 'bg-red-100 text-red-700',
};

export default function DespesaItem({ d, onEdit, onDelete, podeEditar = true, podeExcluir = true }) {
  const status = despesaStatus(d);
  const cat = catMeta(d.categoria);
  const pag = pagMeta(d.forma_pagamento);
  const CatIcon = cat.Icon;
  const PagIcon = pag.Icon;
  const parcelado = Number(d.total_parcelas) > 1;
  const serieTotal = parcelado ? (Number(d.valor) || 0) : 0;
  const isCredito = d.forma_pagamento === 'Cartão Crédito';

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex items-start gap-3">
        <span className={`shrink-0 w-10 h-10 rounded-lg flex items-center justify-center ${cat.bg}`}><CatIcon className={`w-5 h-5 ${cat.color}`} /></span>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="font-semibold text-[#0b2545] truncate">{d.descricao}</p>
              <p className="text-xs text-slate-500 truncate">{d.fornecedor ? `Forn.: ${d.fornecedor}` : ''}{d.beneficiario ? `${d.fornecedor ? ' · ' : ''}Benef.: ${d.beneficiario}` : ''}</p>
            </div>
            <div className="text-right shrink-0">
              <p className="text-lg font-bold text-[#0b2545] whitespace-nowrap leading-none">{fmtMoney(valorMes(d))}</p>
              {parcelado && <p className="text-[11px] text-slate-400 whitespace-nowrap mt-0.5">Total {fmtMoney(d.valor)}</p>}
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 mt-2">
            <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${ST_BADGE[status]}`}>{status}</span>
            {d.obra && <span>Obra: {d.obra}</span>}
            {d.data_compra && <span>Compra: {shortDate(d.data_compra)}</span>}
            <span>Venc.: {shortDate(d.data_vencimento)}</span>
          </div>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400 mt-1">
            <span className="inline-flex items-center gap-1"><PagIcon className="w-3.5 h-3.5" />{pag.label}</span>
            {isCredito && d.cartao && <span>Cartão: {d.cartao}</span>}
            {parcelado && <span>Parcela {d.parcela_atual || 0}/{d.total_parcelas} · série: {fmtMoney(serieTotal)}</span>}
          </div>
        </div>
        <div className="flex flex-col gap-1 shrink-0">
          {podeEditar && <button onClick={onEdit} className="p-1.5 text-slate-400 hover:text-[#0b2545]" title="Editar"><Pencil className="w-4 h-4" /></button>}
          {podeExcluir && <button onClick={onDelete} className="p-1.5 text-slate-400 hover:text-red-500" title="Excluir"><Trash2 className="w-4 h-4" /></button>}
        </div>
      </div>
    </div>
  );
}