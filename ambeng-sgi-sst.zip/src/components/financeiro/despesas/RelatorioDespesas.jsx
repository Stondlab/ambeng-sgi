import React from 'react';
import { Button } from '@/components/ui/button';
import { fmtMoney, bucketCat, CATEGORIAS, despesaStatus, valorMes } from '@/lib/financeiro';
import { Printer, X } from 'lucide-react';

const FORMAS = ['Dinheiro', 'Pix', 'Cartão Crédito', 'Cartão Débito', 'Boleto', 'Transferência'];

function group(items, keyFn) {
  const map = {};
  items.forEach((it) => { const k = keyFn(it) || '—'; if (!map[k]) map[k] = { count: 0, valor: 0 }; map[k].count++; map[k].valor += valorMes(it); });
  return map;
}

function Tabela({ titulo, map, ordem }) {
  const keys = [...ordem.filter((k) => map[k]), ...Object.keys(map).filter((k) => !ordem.includes(k))];
  return (
    <div>
      <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-2">{titulo}</h4>
      <table className="w-full text-sm">
        <tbody className="divide-y divide-slate-100">
          {keys.map((k) => (
            <tr key={k}><td className="py-1.5 text-slate-600">{k}</td><td className="py-1.5 text-right text-slate-400 w-16">{map[k].count}</td><td className="py-1.5 text-right font-medium text-[#0b2545] w-32">{fmtMoney(map[k].valor)}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function RelatorioDespesas({ items, onClose }) {
  const total = items.reduce((s, d) => s + valorMes(d), 0);
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-2xl bg-white rounded-t-2xl sm:rounded-2xl p-5 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4"><h3 className="font-semibold text-[#0b2545]">Relatório de Despesas</h3><button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div className="rounded-lg bg-[#0b2545] text-white p-4 mb-5"><p className="text-xs opacity-70">Total · {items.length} despesa(s)</p><p className="text-2xl font-bold">{fmtMoney(total)}</p></div>
        <div className="grid sm:grid-cols-2 gap-6">
          <Tabela titulo="Por Categoria" map={group(items, (d) => bucketCat(d.categoria))} ordem={CATEGORIAS} />
          <Tabela titulo="Por Status" map={group(items, (d) => despesaStatus(d))} ordem={['Pago', 'Pendente', 'Atrasado']} />
          <Tabela titulo="Por Forma de Pagamento" map={group(items, (d) => d.forma_pagamento)} ordem={FORMAS} />
          <Tabela titulo="Por Obra" map={group(items, (d) => d.obra)} ordem={[]} />
        </div>
        <div className="flex justify-end pt-5"><Button variant="outline" onClick={() => window.print()}><Printer className="w-4 h-4 mr-1" />Imprimir</Button></div>
      </div>
    </div>
  );
}