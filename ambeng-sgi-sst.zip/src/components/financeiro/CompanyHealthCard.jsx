import React from 'react';
import { CheckCircle2, CircleAlert } from 'lucide-react';

export default function CompanyHealthCard({ resumo }) {
  const operational = resumo.obras.filter((o) => o.statusObra !== 'Concluída');
  const losses = operational.filter((o) => o.receita > 0 && o.lucro < 0).length;
  const factors = [
    [resumo.resultadoRealizado >= 0, resumo.resultadoRealizado >= 0 ? 'Resultado realizado positivo' : 'Resultado realizado negativo'],
    [resumo.margemRealizada == null || resumo.margemRealizada >= 10, resumo.margemRealizada == null ? 'Margem sem base realizada' : `Margem de ${resumo.margemRealizada.toFixed(1)}%`],
    [resumo.caixaAtual >= resumo.aPagar, resumo.caixaAtual >= resumo.aPagar ? 'Caixa cobre obrigações abertas' : 'Caixa abaixo das obrigações abertas'],
    [resumo.entradas30 >= resumo.saidas30, resumo.entradas30 >= resumo.saidas30 ? 'Recebimentos futuros cobrem pagamentos' : 'Pagamentos futuros superam recebimentos'],
    [!resumo.atrasados, resumo.atrasados ? 'Existem contas vencidas' : 'Sem contas vencidas'], [!losses, losses ? `${losses} obra(s) ativa(s) com prejuízo` : 'Sem prejuízo em obras ativas'],
  ];
  const score = Math.round((factors.filter(([ok]) => ok).length / factors.length) * 100); const level = score >= 70 ? ['Saudável','text-success','bg-success'] : score >= 45 ? ['Atenção','text-warning','bg-warning'] : ['Crítica','text-destructive','bg-destructive'];
  return <section className="rounded-xl border bg-card p-4"><div className="grid gap-5 lg:grid-cols-[220px_1fr]"><div className="flex flex-col justify-center rounded-xl bg-muted/50 p-4 text-center"><p className="text-xs font-semibold uppercase text-muted-foreground">Saúde financeira</p><strong className={`mt-2 text-2xl ${level[1]}`}>{level[0]}</strong><div className="mt-3 h-3 overflow-hidden rounded-full bg-muted"><div className={`h-full ${level[2]}`} style={{ width:`${score}%` }} /></div><span className="mt-2 text-sm text-muted-foreground">Índice gerencial {score}/100</span></div><div className="grid gap-2 sm:grid-cols-2">{factors.map(([ok,text]) => <div key={text} className="flex items-center gap-2 rounded-lg border p-3 text-sm">{ok ? <CheckCircle2 className="h-4 w-4 text-success" /> : <CircleAlert className="h-4 w-4 text-warning" />}<span>{text}</span></div>)}</div></div></section>;
}