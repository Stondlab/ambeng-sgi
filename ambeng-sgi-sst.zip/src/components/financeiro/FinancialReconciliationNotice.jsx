import React from 'react';
import { AlertTriangle, CheckCircle2 } from 'lucide-react';
import { fmtMoney } from '@/lib/financeiro';

export default function FinancialReconciliationNotice({ conciliacao, cadastros }) {
  const divergencias = conciliacao.filter((item) => Math.abs(item.diferenca) > 0.01);
  if (!divergencias.length && !cadastros.length) return <div className="flex items-center gap-2 rounded-lg border border-success/30 bg-success/5 p-3 text-sm text-success"><CheckCircle2 className="h-4 w-4" />Conciliação automática: Dashboard e módulos de origem sem divergências.</div>;
  return <section className="rounded-xl border border-destructive/40 bg-destructive/5 p-4"><h2 className="flex items-center gap-2 font-semibold text-destructive"><AlertTriangle className="h-5 w-5" />Inconsistências financeiras encontradas</h2><div className="mt-3 space-y-2 text-sm">{divergencias.map((item) => <div key={item.indicador} className="rounded-lg border bg-card p-3"><strong>{item.indicador}</strong><p className="text-xs text-muted-foreground">Dashboard {fmtMoney(item.dashboard)} · Origem {fmtMoney(item.origem)} · Diferença {fmtMoney(item.diferenca)}</p></div>)}{cadastros.map((row) => <div key={`${row.tipo}-${row.id}`} className="rounded-lg border bg-card p-3"><strong>{row.nome}</strong><p className="text-xs text-muted-foreground">{row.motivos.join(' · ')} · {fmtMoney(row.valor)}</p></div>)}</div></section>;
}