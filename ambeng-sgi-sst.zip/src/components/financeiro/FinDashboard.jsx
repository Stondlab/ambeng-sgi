import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePermissoes } from '@/lib/PermissoesContext';
import { pode } from '@/lib/permissoes';
import CockpitCFO from './dash/CockpitCFO';
import { normalizarDespesa } from '@/lib/financeiro';

export default function FinDashboard() {
  const [despesas, setDespesas] = useState([]);
  const [receitas, setReceitas] = useState([]);
  const [loading, setLoading] = useState(true);
  const { perfilEfetivo } = usePermissoes();
  const podeVerReceita = pode(perfilEfetivo, 'fin_receitas', 'visualizar');

  useEffect(() => {
    (async () => {
      let d = [], r = [];
      try { d = await base44.entities.Despesas.list('-created_date', 500); } catch {}
      try { r = await base44.entities.Receitas.list('-created_date', 500); } catch {}
      setDespesas(d.map(normalizarDespesa)); setReceitas(r);
      setLoading(false);
    })();
  }, []);

  if (loading) return <div className="p-10 text-center text-slate-400 text-sm">Carregando cockpit…</div>;
  return <CockpitCFO despesas={despesas} receitas={receitas} podeVerReceita={podeVerReceita} />;
}