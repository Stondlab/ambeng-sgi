import React from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { fmtMoney } from '@/lib/financeiro';

export default function FinanceiroFormulaDialog({ indicador, onClose }) {
  if (!indicador) return null;
  return <Dialog open={!!indicador} onOpenChange={(open) => !open && onClose()}><DialogContent className="max-w-lg"><DialogHeader><DialogTitle>{indicador.label}</DialogTitle><DialogDescription>Composição do valor no período selecionado.</DialogDescription></DialogHeader><div className="rounded-lg bg-muted p-3 text-sm font-medium">{indicador.formula}</div><div className="divide-y rounded-lg border">{indicador.lines.map((line) => <div key={line.label} className="flex min-h-11 items-center justify-between gap-4 px-3 text-sm"><span className="text-muted-foreground">{line.label}</span><strong className="text-right tabular-nums" title={fmtMoney(line.value)}>{fmtMoney(line.value)}</strong></div>)}</div><div className="flex items-center justify-between border-t pt-3"><strong>Resultado</strong><strong className="text-lg text-primary" title={indicador.formatted}>{indicador.formatted}</strong></div></DialogContent></Dialog>;
}