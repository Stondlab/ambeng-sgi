import React from 'react';
import { fmtMoney } from '@/lib/financeiro';

export default function BudgetOverview({ obras }) {
  const list = obras.filter((o) => o.statusObra !== 'Concluída' && o.orcamento > 0).slice(0,8);
  return <section className="rounded-xl border bg-card p-4"><h2 className="text-lg font-semibold">Orçamento das obras</h2><div className="mt-4 grid gap-4 md:grid-cols-2">{list.map((o) => { const pct = (o.despesa/o.orcamento)*100; return <div key={o.id}><div className="mb-1 flex justify-between gap-3 text-sm"><strong>{o.nome}</strong><span className={pct > 100 ? 'text-destructive' : 'text-muted-foreground'}>{pct.toFixed(1)}%</span></div><div className="h-2 overflow-hidden rounded-full bg-muted"><div className={`h-full ${pct > 100 ? 'bg-destructive' : pct >= 90 ? 'bg-warning' : 'bg-success'}`} style={{ width:`${Math.min(100,pct)}%` }} /></div><p className="mt-1 text-xs text-muted-foreground">{o.saldoOrcamento >= 0 ? `Saldo disponível ${fmtMoney(o.saldoOrcamento)}` : `Excedente ${fmtMoney(Math.abs(o.saldoOrcamento))}`}</p></div>; })}{!list.length && <p className="text-sm text-muted-foreground">Nenhuma obra ativa possui orçamento cadastrado.</p>}</div></section>;
}