import React from 'react';
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

export default function WorkMarginChart({ obras }) {
  const data = obras.filter((o) => o.statusObra !== 'Concluída' && o.margem != null).map((o) => ({ nome: o.nome, margem: o.margem })).sort((a,b) => a.margem-b.margem).slice(0,10);
  return <section className="rounded-xl border bg-card p-4"><h2 className="text-lg font-semibold">Margem por obra</h2><div className="mt-3 h-72"><ResponsiveContainer width="100%" height="100%"><BarChart data={data} layout="vertical" margin={{ left: 20 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} /><XAxis type="number" tickFormatter={(v) => `${v}%`} /><YAxis type="category" dataKey="nome" width={115} tick={{ fontSize: 11 }} /><Tooltip formatter={(v) => `${Number(v).toFixed(1)}%`} /><Bar dataKey="margem" radius={[0,5,5,0]}>{data.map((d) => <Cell key={d.nome} fill={d.margem >= 10 ? 'hsl(var(--success))' : d.margem >= 0 ? 'hsl(var(--warning))' : 'hsl(var(--destructive))'} />)}</Bar></BarChart></ResponsiveContainer></div></section>;
}