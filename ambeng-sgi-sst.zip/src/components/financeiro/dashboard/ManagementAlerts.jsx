import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { localIso } from '@/lib/financeiroConsolidado';

export default function ManagementAlerts({ resumo, onSituation }) {
  const hoje = new Date(); const d7 = new Date(hoje); d7.setDate(d7.getDate()+7); const d30 = new Date(hoje); d30.setDate(d30.getDate()+30);
  const sumUntil = (date) => resumo.recebimentosProjetados.filter((r) => r.data_prevista <= localIso(date)).reduce((s,r) => s+r.valor_projetado,0);
  const recebimentos = [['A receber', resumo.recebimentos], ['Vencido', resumo.receitasAtrasadas.reduce((s,r) => s + Number(r.valor_parcela || r.valor || 0),0)], ['Próximos 7 dias', sumUntil(d7)], ['Próximos 30 dias', sumUntil(d30)]];
  const active = resumo.obras.filter((o) => o.statusObra !== 'Concluída');
  const obras = [['Saudáveis','saudavel','text-success'], ['Em atenção','atencao','text-warning'], ['Críticas','risco','text-destructive'], ['Concluídas','concluida','text-primary']];
  return <section className="rounded-xl border bg-card p-4"><h2 className="text-lg font-semibold">Alertas gerenciais</h2><div className="mt-3 grid gap-4 lg:grid-cols-2"><div><p className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Recebimentos</p><div className="grid grid-cols-2 gap-2">{recebimentos.map(([l,v]) => <div key={l} className="rounded-lg bg-muted/50 p-3"><p className="text-xs text-muted-foreground">{l}</p><strong className="text-sm">{fmtMoney(v)}</strong></div>)}</div></div><div><p className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Obras</p><div className="grid grid-cols-2 gap-2">{obras.map(([l,s,c]) => { const list = s === 'concluida' ? resumo.obras.filter((o) => o.statusObra === 'Concluída') : active.filter((o) => o.situacao === s); return <button key={s} onClick={() => onSituation(s)} className="min-h-14 rounded-lg border p-3 text-left"><span className={`text-xl font-semibold ${c}`}>{list.length}</span><span className="ml-2 text-xs text-muted-foreground">{l}</span></button>; })}</div></div></div></section>;
}