import React from 'react';
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { fmtMoney } from '@/lib/financeiro';

export default function RevenueCostChart({ obras }) {
  const data = obras.filter((o) => o.statusObra !== 'Concluída' && (o.receita || o.despesa)).slice(0,10).map((o) => ({ nome:o.nome, Receita:o.receita, Custo:o.despesa }));
  return <section className="rounded-xl border bg-card p-4"><h2 className="text-lg font-semibold">Receita × custo por obra</h2><div className="mt-3 h-72"><ResponsiveContainer width="100%" height="100%"><BarChart data={data}><CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="nome" tick={{ fontSize: 10 }} interval={0} angle={-18} height={60} /><YAxis tickFormatter={(v) => `${Math.round(v/1000)}k`} /><Tooltip formatter={(v) => fmtMoney(v)} /><Legend /><Bar dataKey="Receita" fill="hsl(var(--primary))" radius={[4,4,0,0]} /><Bar dataKey="Custo" fill="hsl(var(--warning))" radius={[4,4,0,0]} /></BarChart></ResponsiveContainer></div></section>;
}