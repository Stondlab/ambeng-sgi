import React from 'react';
import { useNavigate } from 'react-router-dom';
import { fmtMoney } from '@/lib/financeiro';

export default function CompletedWorks({ obras, periodo }) {
  const navigate = useNavigate(); const list = obras.filter((o) => o.statusObra === 'Concluída');
  if (!list.length) return null;
  return <section id="obras-concluidas"><div className="mb-3"><h2 className="text-lg font-semibold">Obras concluídas</h2><p className="text-sm text-muted-foreground">Resultado final separado dos riscos operacionais ativos.</p></div><div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">{list.map((o) => <button key={o.id} onClick={() => navigate(`/saude-obras/${o.id}?periodo=${periodo}`)} className="rounded-xl border border-primary/20 bg-card p-4 text-left"><span className="text-xs font-semibold text-primary">Concluída</span><h3 className="mt-1 font-semibold">{o.nome}</h3><div className="mt-3 grid grid-cols-2 gap-2 text-sm"><span>Receita<strong className="block">{fmtMoney(o.receita)}</strong></span><span>Custo final<strong className="block">{fmtMoney(o.despesa)}</strong></span><span>Resultado final<strong className="block">{o.receita > 0 ? fmtMoney(o.lucro) : 'Sem receita'}</strong></span><span>Margem final<strong className="block">{o.margem == null ? '—' : `${o.margem.toFixed(1)}%`}</strong></span></div></button>)}</div></section>;
}