import React from 'react';
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { fmtMoney } from '@/lib/financeiro';

export default function WorkResultChart({ obras }) {
  const data = obras.filter((o) => o.statusObra !== 'Concluída' && o.receita > 0).map((o) => ({ nome: o.nome, valor: o.lucro })).sort((a,b) => a.valor-b.valor).slice(0,10);
  return <section className="rounded-xl border bg-card p-4"><h2 className="text-lg font-semibold">Resultado por obra</h2><div className="mt-3 h-72"><ResponsiveContainer width="100%" height="100%"><BarChart data={data} layout="vertical" margin={{ left: 20 }}><CartesianGrid strokeDasharray="3 3" horizontal={false} /><XAxis type="number" tickFormatter={(v) => `${Math.round(v/1000)}k`} /><YAxis type="category" dataKey="nome" width={115} tick={{ fontSize: 11 }} /><Tooltip formatter={(v) => fmtMoney(v)} /><Bar dataKey="valor" radius={[0,5,5,0]}>{data.map((d) => <Cell key={d.nome} fill={d.valor >= 0 ? 'hsl(var(--success))' : 'hsl(var(--destructive))'} />)}</Bar></BarChart></ResponsiveContainer></div></section>;
}