import React from 'react';
import { Banknote, CalendarClock, CircleDollarSign, Landmark, Percent, TrendingUp, WalletCards, Waypoints } from 'lucide-react';
import { fmtMoney } from '@/lib/financeiro';

export default function ExecutiveKpis({ resumo }) {
  const items = [
    ['Caixa atual', resumo.caixaAtual, Landmark], ['A receber', resumo.recebimentos, CalendarClock], ['A pagar', resumo.aPagar, WalletCards],
    ['Receita realizada', resumo.receitaRealizada, CircleDollarSign], ['Despesas realizadas', resumo.despesaRealizada, Banknote], ['Resultado', resumo.resultadoRealizado, TrendingUp],
    ['Margem', resumo.margemRealizada, Percent, true], ['Saldo projetado', resumo.saldoProjetado, Waypoints],
  ];
  return <section><h2 className="mb-3 text-lg font-semibold">Visão executiva</h2><div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{items.map(([label, value, Icon, percent]) => { const negative = value < 0; const positiveProjection = label === 'Saldo projetado' && value >= 0; return <div key={label} className={`rounded-xl border bg-card p-4 ${negative ? 'border-destructive/30' : positiveProjection ? 'border-success/30' : ''}`}><div className="flex items-center justify-between text-muted-foreground"><span className="text-xs font-medium">{label}</span><Icon className={`h-4 w-4 ${negative ? 'text-destructive' : positiveProjection ? 'text-success' : 'text-primary'}`} /></div><strong className={`mt-2 block text-lg ${negative ? 'text-destructive' : positiveProjection ? 'text-success' : ''}`}>{percent ? (value == null ? 'Sem base' : `${value.toFixed(1)}%`) : fmtMoney(value)}</strong></div>; })}</div></section>;
}