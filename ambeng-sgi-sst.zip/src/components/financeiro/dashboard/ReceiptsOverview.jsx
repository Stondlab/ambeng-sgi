import React from 'react';
import { Link } from 'react-router-dom';
import { Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import { fmtMoney } from '@/lib/financeiro';

export default function ReceiptsOverview({ resumo }) {
  const atrasado = resumo.receitasAtrasadas.reduce((s,r) => s + Number(r.valor_parcela || r.valor || 0),0);
  const data = [{ nome:'Recebido', valor:resumo.entradas, color:'hsl(var(--success))' }, { nome:'A receber', valor:Math.max(0,resumo.recebimentos-atrasado), color:'hsl(var(--primary))' }, { nome:'Atrasado', valor:atrasado, color:'hsl(var(--destructive))' }];
  const proximos = resumo.recebimentosProjetados.slice().sort((a,b) => a.data_prevista.localeCompare(b.data_prevista)).slice(0,4);
  return <section className="rounded-xl border bg-card p-4"><h2 className="text-lg font-semibold">Recebimentos</h2><div className="grid items-center gap-4 lg:grid-cols-2"><div className="h-64"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={data} dataKey="valor" nameKey="nome" innerRadius={55} outerRadius={85}>{data.map((d) => <Cell key={d.nome} fill={d.color} />)}</Pie><Tooltip formatter={(v) => fmtMoney(v)} /><Legend /></PieChart></ResponsiveContainer></div><div><p className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Próximos recebimentos</p><div className="space-y-2">{proximos.map((r) => <Link key={r.id} to={`/financeiro/receitas?id=${r.id}`} className="flex min-h-12 items-center justify-between rounded-lg bg-muted/50 px-3"><span className="min-w-0"><strong className="block truncate text-sm">{r.cliente || r.descricao}</strong><span className="text-xs text-muted-foreground">{r.obra || 'Sem obra'} · {r.data_prevista}</span></span><strong className="text-sm">{fmtMoney(r.valor_projetado)}</strong></Link>)}{!proximos.length && <p className="text-sm text-muted-foreground">Nenhum recebimento futuro elegível.</p>}</div></div></div></section>;
}