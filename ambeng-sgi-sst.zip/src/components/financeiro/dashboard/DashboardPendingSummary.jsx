import React from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle } from 'lucide-react';

export default function DashboardPendingSummary({ resumo }) {
  const navigate = useNavigate(); const count = resumo.pendenciasClassificacao.length + resumo.divergenciasIntegridade.length;
  return <section className="flex flex-col gap-3 rounded-xl border bg-card p-4 sm:flex-row sm:items-center"><AlertTriangle className="h-5 w-5 text-warning" /><div className="flex-1"><h2 className="font-semibold">Dados pendentes</h2><p className="text-sm text-muted-foreground">{count ? `${count} lançamentos precisam de classificação ou revisão de vínculo.` : 'Nenhuma pendência cadastral identificada.'}</p></div>{count > 0 && <button onClick={() => navigate('/financeiro/auditoria-integracao')} className="min-h-11 rounded-lg border px-4 text-sm font-medium">Resolver</button>}</section>;
}