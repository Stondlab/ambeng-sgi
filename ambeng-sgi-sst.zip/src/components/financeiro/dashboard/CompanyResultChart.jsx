import React from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { fmtMoney } from '@/lib/financeiro';

export default function CompanyResultChart({ resumo }) {
  const data = [{ nome: 'Receita', valor: resumo.receitaRealizada, fill: 'hsl(var(--primary))' }, { nome: 'Despesas', valor: resumo.despesaRealizada, fill: 'hsl(var(--warning))' }, { nome: 'Resultado', valor: resumo.resultadoRealizado, fill: resumo.resultadoRealizado >= 0 ? 'hsl(var(--success))' : 'hsl(var(--destructive))' }];
  return <section className="rounded-xl border bg-card p-4"><div className="mb-3"><h2 className="text-lg font-semibold">Resultado da empresa</h2><p className="text-sm text-muted-foreground">Receita realizada × despesas realizadas × resultado.</p></div><div className="h-64"><ResponsiveContainer width="100%" height="100%"><BarChart data={data}><CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="nome" /><YAxis tickFormatter={(v) => `${Math.round(v/1000)}k`} /><Tooltip formatter={(v) => fmtMoney(v)} /><Bar dataKey="valor" radius={[6,6,0,0]} /></BarChart></ResponsiveContainer></div></section>;
}