import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { X } from 'lucide-react';
import { applyTitleCaseAll } from '@/lib/titleCase';
import { validarEmailOpcional, validarTelefoneOpcional } from '@/lib/validacao';

function Field({ label, className, children }) {
  return <div className={className}><Label>{label}</Label><div className="mt-1">{children}</div></div>;
}

export default function FornecedorForm({ record, onClose, onSave }) {
  const isNew = !record.id;
  const [erro, setErro] = useState('');
  const [form, setForm] = useState(() => {
    const init = {};
    ['nome', 'categoria', 'contato', 'telefone', 'email', 'observacoes'].forEach((k) => { init[k] = record[k] ?? ''; });
    return init;
  });
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const submit = () => {
    if (!form.nome?.trim()) return setErro('Informe o nome do fornecedor.');
    if (!validarEmailOpcional(form.email)) return setErro('Informe um e-mail válido.');
    if (!validarTelefoneOpcional(form.telefone)) return setErro('Informe um telefone com DDD e 10 ou 11 dígitos.');
    setErro('');
    onSave(applyTitleCaseAll(form), record.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-md bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">{isNew ? 'Novo Fornecedor' : 'Editar Fornecedor'}</h3><button type="button" onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div className="grid gap-3">
          <Field label="Nome *"><Input value={form.nome} onChange={(e) => set('nome', e.target.value)} /></Field>
          <Field label="Categoria"><Input value={form.categoria} onChange={(e) => set('categoria', e.target.value)} /></Field>
          <Field label="Contato"><Input value={form.contato} onChange={(e) => set('contato', e.target.value)} /></Field>
          <Field label="Telefone"><Input value={form.telefone} onChange={(e) => set('telefone', e.target.value)} /></Field>
          <Field label="E-mail"><Input type="email" value={form.email} onChange={(e) => set('email', e.target.value)} /></Field>
          <Field label="Observações"><Textarea rows={2} value={form.observacoes} onChange={(e) => set('observacoes', e.target.value)} /></Field>
        </div>
        {erro && <p className="text-sm text-red-600">{erro}</p>}
        <div className="flex justify-end gap-2 pt-2"><Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button><Button type="button" onClick={submit} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button></div>
      </div>
    </div>
  );
}