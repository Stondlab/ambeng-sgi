import React from 'react';
import { Pencil, Trash2, Phone, Mail, User, Tag } from 'lucide-react';

export default function FornecedorCard({ f, onEdit, onDelete, podeEditar = true, podeExcluir = true }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="font-semibold text-[#0b2545] truncate">{f.nome}</p>
          {f.categoria && <span className="inline-flex items-center gap-1 text-xs text-slate-500 mt-0.5"><Tag className="w-3 h-3" />{f.categoria}</span>}
        </div>
        <div className="flex gap-1 shrink-0">
          {podeEditar && <button onClick={onEdit} className="p-1.5 text-slate-400 hover:text-[#0b2545]" title="Editar"><Pencil className="w-4 h-4" /></button>}
          {podeExcluir && <button onClick={onDelete} className="p-1.5 text-slate-400 hover:text-red-500" title="Excluir"><Trash2 className="w-4 h-4" /></button>}
        </div>
      </div>
      <div className="mt-3 space-y-1.5 text-sm">
        {f.contato && <p className="flex items-center gap-2 text-slate-600"><User className="w-4 h-4 text-slate-400 shrink-0" />{f.contato}</p>}
        {f.telefone && <p className="flex items-center gap-2 text-slate-600"><Phone className="w-4 h-4 text-slate-400 shrink-0" />{f.telefone}</p>}
        {f.email && <p className="flex items-center gap-2 text-slate-600 truncate"><Mail className="w-4 h-4 text-slate-400 shrink-0" /><span className="truncate">{f.email}</span></p>}
      </div>
    </div>
  );
}