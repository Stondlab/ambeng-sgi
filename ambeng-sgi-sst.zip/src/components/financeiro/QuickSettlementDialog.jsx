import React, { useEffect, useState } from 'react';
import { CalendarCheck } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { fmtMoney, valorMes } from '@/lib/financeiro';

export default function QuickSettlementDialog({ record, type, open, onClose, onConfirm, pending }) {
  const [date, setDate] = useState('');
  useEffect(() => { if (open) setDate(new Date().toISOString().slice(0, 10)); }, [open, record?.id]);
  const isIncome = type === 'receita';
  return <Dialog open={open} onOpenChange={(value) => !value && !pending && onClose()}><DialogContent className="max-w-md"><DialogHeader><DialogTitle className="flex items-center gap-2"><CalendarCheck className="h-5 w-5" />{isIncome ? 'Marcar como recebida' : 'Marcar como paga'}</DialogTitle><DialogDescription>Confirme a data para registrar esta baixa sem abrir o lançamento.</DialogDescription></DialogHeader><div className="rounded-lg bg-muted p-3"><p className="truncate text-sm font-semibold">{record?.descricao || 'Lançamento financeiro'}</p><p className="mt-1 text-lg font-bold tabular-nums">{fmtMoney(valorMes(record || {}))}</p></div><div><Label htmlFor="settlement-date">{isIncome ? 'Data do recebimento' : 'Data do pagamento'}</Label><Input id="settlement-date" type="date" className="mt-1" value={date} onChange={(event) => setDate(event.target.value)} /></div><DialogFooter><Button type="button" variant="ghost" onClick={onClose} disabled={pending}>Cancelar</Button><Button type="button" onClick={() => onConfirm(date)} disabled={!date || pending}>{pending ? 'Registrando...' : 'Confirmar'}</Button></DialogFooter></DialogContent></Dialog>;
}