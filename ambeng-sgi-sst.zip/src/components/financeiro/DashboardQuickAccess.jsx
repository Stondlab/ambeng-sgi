import React from 'react';
import { Link } from 'react-router-dom';
import { BarChart3, CalendarCheck, FileText, TrendingDown, TrendingUp } from 'lucide-react';

const links = [
  { label: 'Receitas', text: 'Contas a receber', to: '/financeiro/receitas', icon: TrendingUp },
  { label: 'Despesas', text: 'Custos e pagamentos', to: '/financeiro/despesas', icon: TrendingDown },
  { label: 'Notas Fiscais', text: 'Fiscal e conferência', to: '/financeiro/fiscal?tab=notas', icon: FileText },
  { label: 'Relatórios', text: 'Análises gerenciais', to: '/relatorios', icon: BarChart3 },
];

export default function DashboardQuickAccess({ onRecebimentos }) {
  return <section><h2 className="mb-3 text-lg font-semibold">Acesso rápido</h2><div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5"><button onClick={onRecebimentos} className="flex min-h-20 min-w-0 items-center gap-3 rounded-lg border bg-card p-3 text-left hover:border-primary/40 hover:shadow-card"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary"><CalendarCheck className="h-5 w-5" /></span><span className="min-w-0"><strong className="block text-sm">VER RECEBIMENTOS PREVISTOS</strong><span className="block truncate text-xs text-muted-foreground">Quanto, de quem e quando</span></span></button>{links.map(({ label, text, to, icon: Icon }) => <Link key={to} to={to} className="flex min-h-20 min-w-0 items-center gap-3 rounded-lg border bg-card p-3 hover:border-primary/40 hover:shadow-card"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary"><Icon className="h-5 w-5" /></span><span className="min-w-0"><strong className="block truncate text-sm">{label}</strong><span className="block truncate text-xs text-muted-foreground">{text}</span></span></Link>)}</div></section>;
}