import React, { useState } from 'react';
import { SlidersHorizontal, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useFiltrosFinanceiro } from '@/lib/FiltrosFinanceiroContext';

export default function FinanceiroFilterShell({ partyLabel, partyValue, partyOptions, onPartyChange, statusValue, statusOptions, onStatusChange, onClear, children }) {
  const { obra, setObra, obrasPeriodo, dataInicio, setDataInicio, dataFim, setDataFim, limpar } = useFiltrosFinanceiro();
  const [open, setOpen] = useState(false);
  const clearAll = () => { onClear(); limpar(); setOpen(false); };
  return <div className="min-w-0 rounded-xl border border-border bg-card p-3 shadow-sm">
    <div className="flex min-w-0 flex-wrap items-center gap-2">
      <Select value={obra} onValueChange={setObra}><SelectTrigger className="h-10 w-full min-w-0 sm:w-auto sm:min-w-[170px] sm:flex-1 xl:w-[180px] xl:flex-none"><SelectValue placeholder="Obra" /></SelectTrigger><SelectContent><SelectItem value="geral">Todas as obras</SelectItem>{obrasPeriodo.map((item) => <SelectItem key={item.id} value={item.nome}>{item.nome}</SelectItem>)}</SelectContent></Select>
      <Select value={partyValue} onValueChange={onPartyChange}><SelectTrigger className="h-10 w-full min-w-0 sm:w-auto sm:min-w-[180px] sm:flex-1 xl:w-[210px] xl:flex-none"><SelectValue placeholder={partyLabel} /></SelectTrigger><SelectContent><SelectItem value="all">{partyLabel === 'Cliente' ? 'Todos os clientes' : 'Todos os fornecedores'}</SelectItem>{partyOptions.map((item) => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select>
      <Select value={statusValue} onValueChange={onStatusChange}><SelectTrigger className="h-10 w-full min-w-0 sm:w-auto sm:min-w-[150px] sm:flex-1 xl:w-[170px] xl:flex-none"><SelectValue placeholder="Status" /></SelectTrigger><SelectContent><SelectItem value="all">Todos os status</SelectItem>{statusOptions.map((item) => <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent></Select>
      <div className="flex w-full min-w-0 items-center gap-1.5 rounded-md border border-input bg-card px-2 sm:w-auto"><span className="shrink-0 text-[11px] font-medium text-muted-foreground">Período</span><Input aria-label="Data inicial" type="date" className="h-9 w-0 min-w-0 flex-1 border-0 px-1 shadow-none sm:w-[125px]" value={dataInicio} onChange={(event) => setDataInicio(event.target.value)} /><span className="text-muted-foreground">—</span><Input aria-label="Data final" type="date" className="h-9 w-0 min-w-0 flex-1 border-0 px-1 shadow-none sm:w-[125px]" value={dataFim} onChange={(event) => setDataFim(event.target.value)} /></div>
      <Popover open={open} onOpenChange={setOpen}><PopoverTrigger asChild><Button variant="outline" className="h-10 flex-1 sm:flex-none"><SlidersHorizontal className="h-4 w-4" />Mais filtros</Button></PopoverTrigger><PopoverContent align="end" className="w-[calc(100vw-2rem)] max-w-4xl p-4">{children}</PopoverContent></Popover>
      <Button variant="ghost" className="h-10 flex-1 sm:flex-none" onClick={clearAll}><X className="h-4 w-4" />Limpar</Button>
    </div>
  </div>;
}