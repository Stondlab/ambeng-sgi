import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePerm } from '@/hooks/usePerm';
import { useFiltrosFinanceiro } from '@/lib/FiltrosFinanceiroContext';
import { useToast } from '@/components/ui/use-toast';
import { calcParcelas, addMeses } from '@/lib/financeiro';
import ReceitasCentral from './receitas/central/ReceitasCentral';
import { mensagemAmigavelErro } from '@/lib/validacao';

export default function ReceitasTab() {
  const { podeCriar, podeEditar, podeExcluir } = usePerm('fin_receitas');
  const { obrasPeriodo, obrasAtivas } = useFiltrosFinanceiro();
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [despesas, setDespesas] = useState([]);
  const [clientes, setClientes] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    let r = [];
    try { r = await base44.entities.Receitas.list('-created_date', 2000); } catch {}
    setItems(r);
    setLoading(false);
  };
  const prepararFormulario = async () => {
    if (clientes.length) return;
    try { setClientes(await base44.entities.ClientesTomadores.list('razao_social', 500)); } catch {}
  };
  const prepararAnalise = async () => {
    if (despesas.length) return;
    try { setDespesas(await base44.entities.Despesas.list('-created_date', 3000)); } catch {}
  };
  useEffect(() => { load(); }, []);

  const save = async (form, id) => {
    const num = (k) => (form[k] === '' || form[k] == null) ? null : Number(form[k]);
    const total = Number(form.valor) || 0;
    const n = Math.max(1, parseInt(form.total_parcelas) || 1);
    const parcelas = calcParcelas(total, n);
    const soma = parcelas.reduce((s, v) => s + v, 0);
    if (Math.abs(soma - total) > 0.01) {
      toast({ title: 'Valor total não bate com o parcelamento.', variant: 'destructive' });
      return false;
    }
    try {
      if (id) {
        const payload = { ...form };
        ['valor', 'valor_parcela', 'parcela_atual', 'total_parcelas'].forEach((k) => { payload[k] = num(k); });
        if (payload.status_aprovacao === '') payload.status_aprovacao = null;
        await base44.entities.Receitas.update(id, payload);
        toast({ title: 'Receita atualizada.' });
        load();
        return true;
      }
      const primeira = form.data_prevista;
      const baseFields = {
        cliente: form.cliente || null, cliente_id: form.cliente_id || null,
        tipo: form.tipo || null, status: form.status || 'Prevista',
        forma_recebimento: form.forma_recebimento || null, tipo_pagamento: form.tipo_pagamento || 'À vista',
        obra: form.obra || null, obra_id: form.obra_id || null,
        data_emissao: form.data_emissao || null, anexos: form.anexos || null,
        observacoes: form.observacoes || null, valor: total, total_parcelas: n,
      };
      const records = [];
      for (let k = 1; k <= n; k++) {
        records.push({
          ...baseFields,
          descricao: n > 1 ? `${form.descricao} (${k}/${n})` : form.descricao,
          valor_parcela: parcelas[k - 1],
          parcela_atual: k,
          data_prevista: addMeses(primeira, k - 1),
        });
      }
      if (records.length > 1) await base44.entities.Receitas.bulkCreate(records);
      else await base44.entities.Receitas.create(records[0]);
      toast({ title: n > 1 ? `Receita criada em ${n} parcelas.` : 'Receita criada.' });
      load();
      return true;
    } catch (e) {
      toast({ title: 'Não foi possível salvar a receita.', description: mensagemAmigavelErro(e), variant: 'destructive' });
      return false;
    }
  };
  const del = async (id) => {
    try { await base44.entities.Receitas.delete(id); toast({ title: 'Receita excluída.' }); load(); }
    catch (e) { toast({ title: 'Não foi possível excluir a receita.', description: mensagemAmigavelErro(e), variant: 'destructive' }); }
  };

  if (loading) return <div className="p-10 text-center text-slate-400 text-sm">Carregando receitas…</div>;
  return (
    <ReceitasCentral
      items={items} despesas={despesas} obras={obrasPeriodo} obrasAtivas={obrasAtivas} clientesCadastro={clientes}
      podeCriar={podeCriar} podeEditar={podeEditar} podeExcluir={podeExcluir}
      onSave={save} onDelete={del} onPrepareForm={prepararFormulario} onAnalisar={prepararAnalise}
    />
  );
}