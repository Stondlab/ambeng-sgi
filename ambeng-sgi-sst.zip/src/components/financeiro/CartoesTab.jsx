import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { useFiltrosFinanceiro } from '@/lib/FiltrosFinanceiroContext';
import SortSelect from './SortSelect';
import CartaoCard from './cartoes/CartaoCard';

const SORT_OPTIONS = [
  { value: 'data_recente', label: 'Data (Recente)' },
  { value: 'banco', label: 'Banco' },
  { value: 'valor_maior', label: 'Valor (Maior>Menor)' },
];
import CartaoForm from './cartoes/CartaoForm';
import CartaoTransacoesModal from './cartoes/CartaoTransacoesModal';

export default function CartoesTab() {
  const [cartoes, setCartoes] = useState([]);
  const [despesas, setDespesas] = useState([]);
  const [edit, setEdit] = useState(null);
  const [transacoesCartao, setTransacoesCartao] = useState(null);
  const [sortKey, setSortKey] = useState('data_recente');
  const { obra: obraGlobal } = useFiltrosFinanceiro();

  const cartoesFiltrados = React.useMemo(() => {
    let result = cartoes;
    if (obraGlobal !== 'geral') {
      const obrasComDespesa = new Set(despesas.filter((d) => d.obra === obraGlobal).map((d) => d.cartao).filter(Boolean));
      result = cartoes.filter((c) => obrasComDespesa.has(c.nome));
    }
    const sorted = [...result];
    sorted.sort((a, b) => {
      let cmp = 0;
      if (sortKey === 'banco') cmp = (a.banco || a.nome || '').localeCompare(b.banco || b.nome || '');
      else if (sortKey === 'data_recente') cmp = (b.created_date || '').localeCompare(a.created_date || '');
      else if (sortKey === 'valor_maior') cmp = (Number(b.saldo) || 0) - (Number(a.saldo) || 0);
      return cmp;
    });
    return sorted;
  }, [cartoes, despesas, obraGlobal, sortKey]);

  const load = async () => {
    let c = [], d = [];
    try { c = await base44.entities.Cartoes.list('-created_date', 500); } catch {}
    try { d = await base44.entities.Despesas.list('-created_date', 500); } catch {}
    setCartoes(c); setDespesas(d);
  };
  useEffect(() => { load(); }, []);

  const save = async (form, id) => {
    const payload = { ...form };
    ['limite', 'dia_vencimento', 'dia_fechamento', 'saldo'].forEach((k) => { payload[k] = (payload[k] === '' || payload[k] == null) ? null : Number(payload[k]); });
    if (id) await base44.entities.Cartoes.update(id, payload);
    else await base44.entities.Cartoes.create(payload);
    setEdit(null); load();
  };
  const del = async (id) => { await base44.entities.Cartoes.delete(id); load(); };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Button onClick={() => setEdit({})} className="bg-amber-400 text-[#0b2545] hover:bg-amber-300 min-h-[44px]"><Plus className="w-4 h-4 mr-1" />Novo Cartão</Button>
        <div className="ml-auto"><SortSelect value={sortKey} onChange={setSortKey} options={SORT_OPTIONS} /></div>
      </div>

      {obraGlobal !== 'geral' && cartoesFiltrados.length === 0
        ? <p className="text-sm text-slate-400 text-center py-10">Nenhum cartão para a obra selecionada.</p>
        : cartoesFiltrados.length === 0
        ? <p className="text-sm text-slate-400 text-center py-10">Nenhum cartão cadastrado.</p>
        : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {cartoesFiltrados.map((c) => (
              <CartaoCard
                key={c.id}
                c={c}
                despesas={despesas}
                podeEditar
                podeExcluir
                onEdit={() => setEdit(c)}
                onDelete={() => del(c.id)}
                onClick={() => setTransacoesCartao(c)}
              />
            ))}
          </div>
        )}

      {edit && <CartaoForm record={edit} onClose={() => setEdit(null)} onSave={save} />}
      {transacoesCartao && (
        <CartaoTransacoesModal
          cartao={transacoesCartao}
          despesas={despesas}
          open={!!transacoesCartao}
          onClose={() => setTransacoesCartao(null)}
        />
      )}
    </div>
  );
}