import React from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, ChevronRight } from 'lucide-react';
import { fmtMoney } from '@/lib/financeiro';

export default function PendingClassificationCard({ rows }) {
  if (!rows.length) return null;
  const total = rows.reduce((sum, row) => sum + row.valor, 0);
  return <section className="rounded-xl border border-warning/40 bg-warning/5 p-4"><div className="flex items-start justify-between gap-3"><div><h2 className="flex items-center gap-2 font-semibold text-warning"><AlertTriangle className="h-5 w-5" />Lançamentos pendentes de classificação</h2><p className="mt-1 text-sm text-muted-foreground">{rows.length} lançamento(s) · {fmtMoney(total)}. Estes valores não estão ocultos; precisam de correção cadastral.</p></div></div><div className="mt-3 grid gap-2 lg:grid-cols-2">{rows.slice(0, 6).map((row) => <Link key={`${row.tipo}-${row.id}`} to={`${row.path}?id=${row.id}`} className="flex min-h-14 items-center justify-between rounded-lg border bg-card p-3 text-sm hover:border-primary/40"><span className="min-w-0"><strong className="block truncate">{row.nome}</strong><span className="block truncate text-xs text-muted-foreground">{row.motivos.join(' · ')}</span></span><span className="ml-3 flex shrink-0 items-center gap-2 font-semibold">{fmtMoney(row.valor)}<ChevronRight className="h-4 w-4" /></span></Link>)}</div>{rows.length > 6 && <p className="mt-3 text-xs text-muted-foreground">Mais {rows.length - 6} lançamento(s) disponíveis nos módulos de origem.</p>}</section>;
}