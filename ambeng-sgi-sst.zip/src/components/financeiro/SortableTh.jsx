import React from 'react';
import { ArrowUp, ArrowDown, ArrowUpDown } from 'lucide-react';

/**
 * Sortable table header cell with 3-state sort icons.
 * Active column shows ↑ (asc) or ↓ (desc); inactive shows ↑↓ in grey.
 */
export default function SortableTh({ field, label, sortField, sortDir, onSort, align = 'left', className = '' }) {
  const active = sortField === field;
  const alignClass = align === 'right' ? 'justify-end text-right' : 'justify-start text-left';
  return (
    <th
      className={`cursor-pointer hover:text-[#0b2545] select-none whitespace-nowrap ${alignClass} ${className}`}
      onClick={() => onSort(field)}
    >
      <span className="inline-flex items-center gap-1">
        {label}
        {active
          ? (sortDir === 'asc'
              ? <ArrowUp className="w-3 h-3 text-[#0b2545]" />
              : <ArrowDown className="w-3 h-3 text-[#0b2545]" />)
          : <ArrowUpDown className="w-3 h-3 text-slate-300" />}
      </span>
    </th>
  );
}