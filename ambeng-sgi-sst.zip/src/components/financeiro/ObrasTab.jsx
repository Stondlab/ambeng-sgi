import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePerm } from '@/hooks/usePerm';
import ObrasFinanceiro from './obras/ObrasFinanceiro';
import { normalizarDespesa } from '@/lib/financeiro';

export default function ObrasTab() {
  const { podeCriar, podeEditar, podeExcluir } = usePerm('fin_obras');
  const [obras, setObras] = useState([]);
  const [receitas, setReceitas] = useState([]);
  const [despesas, setDespesas] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    let o = [], r = [], d = [];
    try { o = await base44.entities.Obras.list('-created_date', 500); } catch {}
    try { r = await base44.entities.Receitas.list('-created_date', 500); } catch {}
    try { d = await base44.entities.Despesas.list('-created_date', 500); } catch {}
    setObras(o); setReceitas(r); setDespesas(d.map(normalizarDespesa));
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const save = async (form, id) => {
    const payload = { ...form };
    payload.orcamento = (payload.orcamento === '' || payload.orcamento == null) ? null : Number(payload.orcamento);
    if (id) await base44.entities.Obras.update(id, payload);
    else await base44.entities.Obras.create(payload);
    load();
  };
  const del = async (id) => { await base44.entities.Obras.delete(id); load(); };

  if (loading) return <div className="p-10 text-center text-slate-400 text-sm">Carregando obras…</div>;
  return <ObrasFinanceiro obras={obras} receitas={receitas} despesas={despesas} podeCriar={podeCriar} podeEditar={podeEditar} podeExcluir={podeExcluir} onSave={save} onDelete={del} />;
}