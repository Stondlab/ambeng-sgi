import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import FornecedorCard from './fornecedores/FornecedorCard';
import FornecedorForm from './fornecedores/FornecedorForm';
import { usePerm } from '@/hooks/usePerm';
import { useToast } from '@/components/ui/use-toast';

export default function FornecedoresTab() {
  const { podeCriar, podeEditar, podeExcluir } = usePerm('fin_fornecedores');
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [edit, setEdit] = useState(null);

  const load = async () => { let f = []; try { f = await base44.entities.Fornecedores.list('nome', 500); } catch {} setItems(f); };
  useEffect(() => { load(); }, []);

  const save = async (form, id) => {
    try {
      if (id) await base44.entities.Fornecedores.update(id, form);
      else await base44.entities.Fornecedores.create(form);
      toast({ title: id ? 'Fornecedor atualizado.' : 'Fornecedor criado.' });
      setEdit(null); load();
    } catch (e) {
      toast({ title: 'Não foi possível salvar o fornecedor.', description: e?.message, variant: 'destructive' });
    }
  };
  const del = async (id) => {
    try { await base44.entities.Fornecedores.delete(id); toast({ title: 'Fornecedor excluído.' }); load(); }
    catch (e) { toast({ title: 'Não foi possível excluir o fornecedor.', description: e?.message, variant: 'destructive' }); }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        {podeCriar && <Button onClick={() => setEdit({})} className="bg-amber-400 text-[#0b2545] hover:bg-amber-300 min-h-[44px]"><Plus className="w-4 h-4 mr-1" />Novo Fornecedor</Button>}
      </div>

      {items.length === 0
        ? <p className="text-sm text-slate-400 text-center py-10">Nenhum fornecedor cadastrado.</p>
        : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {items.map((f) => <FornecedorCard key={f.id} f={f} podeEditar={podeEditar} podeExcluir={podeExcluir} onEdit={() => setEdit(f)} onDelete={() => del(f.id)} />)}
          </div>
        )}

      {edit && <FornecedorForm record={edit} onClose={() => setEdit(null)} onSave={save} />}
    </div>
  );
}