import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Upload, FileText, Trash2, AlertCircle, Check } from 'lucide-react';
import { calcParcelas, addMeses, fmtMoney } from '@/lib/financeiro';
import { applyTitleCaseAll } from '@/lib/titleCase';
import { incluirObraVinculada } from '@/lib/obraDisponibilidade';
import { validarDataOpcional, validarNumeroOpcional } from '@/lib/validacao';

const TIPOS = ['Contrato', 'Medição', 'Reembolso', 'Adiantamento'];
const FORMAS = ['Pix', 'Cartão', 'Boleto', 'TED'];
const TIPO_PAG = ['À vista', 'Parcelado'];

function Field({ label, className, children, hint }) {
  return <div className={className}><Label>{label}</Label><div className="mt-1">{children}</div>{hint && <p className="text-[11px] text-slate-400 mt-1">{hint}</p>}</div>;
}

export default function ReceitaForm({ record, obras, clientes = [], onClose, onSave }) {
  const isNew = !record.id;
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState(() => {
    const init = {};
    ['descricao', 'cliente', 'cliente_id', 'tipo', 'forma_recebimento', 'tipo_pagamento', 'observacoes', 'obra', 'obra_id', 'anexos'].forEach((k) => { init[k] = record[k] ?? ''; });
    ['valor', 'total_parcelas'].forEach((k) => { init[k] = record[k] ?? ''; });
    ['data_emissao', 'data_prevista'].forEach((k) => { init[k] = record[k] ?? ''; });
    if (isNew) {
      if (!init.tipo_pagamento) init.tipo_pagamento = 'À vista';
      if (!init.total_parcelas) init.total_parcelas = 1;
    }
    return init;
  });
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  const selecionarObra = (id) => { const obra = obras.find((item) => item.id === id); setForm((p) => ({ ...p, obra_id: id, obra: obra?.nome || '' })); };
  const selecionarCliente = (id) => { const cliente = clientes.find((item) => item.id === id); setForm((p) => ({ ...p, cliente_id: id, cliente: cliente?.nome_fantasia || cliente?.razao_social || '' })); };

  const obrasSelect = incluirObraVinculada(obras, obras, record.obra);
  const anexos = (() => { try { return form.anexos ? JSON.parse(form.anexos) : []; } catch { return []; } })();
  const isParcelado = form.tipo_pagamento === 'Parcelado';
  const valorTotal = Number(form.valor) || 0;
  const nParc = isParcelado ? Math.max(2, parseInt(form.total_parcelas) || 2) : 1;
  const parcelasArr = calcParcelas(valorTotal, nParc);
  const somaParcelas = parcelasArr.reduce((s, v) => s + v, 0);
  const valorBate = Math.abs(somaParcelas - valorTotal) < 0.01;

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const novo = { url: file_url, nome: file.name, tipo: 'Anexo', data: new Date().toISOString() };
      set('anexos', JSON.stringify([...anexos, novo]));
    } catch { /* ignore */ } finally { setUploading(false); e.target.value = ''; }
  };

  const removeAnexo = (idx) => {
    const novos = anexos.filter((_, i) => i !== idx);
    set('anexos', novos.length ? JSON.stringify(novos) : '');
  };

  const handleTipoPagamento = (v) => {
    set('tipo_pagamento', v);
    if (v === 'À vista') set('total_parcelas', 1);
  };

  const erros = (() => {
    const e = [];
    if (!form.cliente) e.push('Cliente é obrigatório');
    if (!form.obra || !form.obra_id) e.push('Obra válida é obrigatória');
    if (!form.descricao) e.push('Descrição é obrigatória');
    if (!validarNumeroOpcional(form.valor, 0.01) || valorTotal <= 0) e.push('Valor total deve ser um número maior que zero');
    if (!form.data_prevista) e.push('Data de vencimento é obrigatória');
    if (!validarDataOpcional(form.data_emissao) || !validarDataOpcional(form.data_prevista)) e.push('Informe datas válidas');
    if (form.data_emissao && form.data_prevista && form.data_prevista < form.data_emissao) e.push('Data de vencimento não pode ser anterior à data da venda');
    if (isParcelado && nParc <= 1) e.push('Se Parcelado, Quantidade de Parcelas deve ser maior que 1');
    return e;
  })();

  const submit = () => {
    if (erros.length || !valorBate) return;
    const p = { ...form };
    p.total_parcelas = isParcelado ? nParc : 1;
    p.valor_parcela = isParcelado ? parcelasArr[0] : valorTotal;
    const payload = applyTitleCaseAll(p);
    Object.assign(payload, { cliente: form.cliente, cliente_id: form.cliente_id, obra: form.obra, obra_id: form.obra_id });
    onSave(payload, record.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-xl bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">{isNew ? 'Nova Receita' : 'Editar Receita'}</h3><button type="button" onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="Cliente *"><Select value={form.cliente_id} onValueChange={selecionarCliente}><SelectTrigger><SelectValue placeholder="Selecione o cliente" /></SelectTrigger><SelectContent>{clientes.map((c) => <SelectItem key={c.id} value={c.id}>{c.nome_fantasia || c.razao_social}</SelectItem>)}</SelectContent></Select></Field>
          <Field label="Obra *"><Select value={form.obra_id} onValueChange={selecionarObra}><SelectTrigger><SelectValue placeholder="Selecione a obra" /></SelectTrigger><SelectContent>{obrasSelect.map((o) => <SelectItem key={o.id} value={o.id}>{o.nome}</SelectItem>)}</SelectContent></Select></Field>
          {/* 2. Descrição */}
          <Field className="sm:col-span-2" label="Descrição *"><Input value={form.descricao} onChange={(e) => set('descricao', e.target.value)} /></Field>
          {/* 3. Data Venda */}
          <Field label="Data Venda"><Input type="date" value={form.data_emissao} onChange={(e) => set('data_emissao', e.target.value)} /></Field>
          {/* 4. Tipo de Receita */}
          <Field label="Tipo de Receita"><Select value={form.tipo} onValueChange={(v) => set('tipo', v)}><SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{TIPOS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select></Field>
          {/* 5. Forma de Pagamento */}
          <Field label="Forma de Pagamento"><Select value={form.forma_recebimento} onValueChange={(v) => set('forma_recebimento', v)}><SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{FORMAS.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent></Select></Field>
          {/* 6. Tipo de Pagamento */}
          <Field label="Tipo de Pagamento"><Select value={form.tipo_pagamento || 'À vista'} onValueChange={handleTipoPagamento}><SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{TIPO_PAG.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select></Field>
          {/* 7. [IF PARCELADO: Quantidade de Parcelas] */}
          {isParcelado && <Field label="Quantidade de Parcelas"><Input type="number" min="2" value={form.total_parcelas} onChange={(e) => set('total_parcelas', e.target.value)} /></Field>}
          {/* 7/8. Data de Vencimento */}
          <Field label="Data de Vencimento *"><Input type="date" value={form.data_prevista} onChange={(e) => set('data_prevista', e.target.value)} /></Field>
          {/* 9. Valor Total */}
          <Field label="Valor Total (R$) *"><Input type="number" step="0.01" value={form.valor} onChange={(e) => set('valor', e.target.value)} /></Field>
          {/* 10. Observação */}
          <Field className="sm:col-span-2" label="Observação"><Textarea rows={2} value={form.observacoes} onChange={(e) => set('observacoes', e.target.value)} /></Field>
          {/* 11. Anexo */}
          <Field className="sm:col-span-2" label="Anexo">
            <div className="space-y-2">
              {anexos.map((a, i) => (
                <div key={i} className="flex items-center gap-2 p-2 rounded-lg border border-slate-200 bg-slate-50">
                  <FileText className="w-4 h-4 text-slate-500" />
                  <a href={a.url} target="_blank" rel="noreferrer" className="text-sm text-[#0b2545] hover:underline flex-1 truncate">{a.nome}</a>
                  <button type="button" onClick={() => removeAnexo(i)} className="text-red-500 hover:text-red-700"><Trash2 className="w-4 h-4" /></button>
                </div>
              ))}
              <label className="flex items-center gap-2 cursor-pointer text-sm text-[#0b2545]">
                <Upload className="w-4 h-4" />
                {uploading ? 'Enviando...' : 'Adicionar anexo'}
                <input type="file" className="hidden" onChange={handleUpload} disabled={uploading} />
              </label>
            </div>
          </Field>
        </div>

        {/* Validation + Preview */}
        {isParcelado && valorTotal > 0 && (
          <div className={`rounded-lg border p-3 text-xs ${valorBate ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-red-50 border-red-200 text-red-700'}`}>
            <div className="flex items-center gap-1.5 font-semibold">
              {valorBate ? <Check className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
              {valorBate ? 'Valor confere com o parcelamento' : 'Valor NÃO confere com o parcelamento'}
            </div>
            <div className="mt-1 text-slate-600">{nParc}x de {fmtMoney(parcelasArr[0])} = {fmtMoney(somaParcelas)} (total: {fmtMoney(valorTotal)})</div>
            {form.data_prevista && (
              <div className="mt-1 text-slate-500">Vencimentos: {Array.from({ length: nParc }, (_, i) => addMeses(form.data_prevista, i)).map((d) => d.split('-').reverse().join('/')).join(', ')}</div>
            )}
          </div>
        )}

        {erros.length > 0 && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-xs text-red-700">
            <div className="flex items-center gap-1.5 font-semibold mb-1"><AlertCircle className="w-3.5 h-3.5" />Corrija os erros antes de salvar:</div>
            <ul className="list-disc ml-4 space-y-0.5">
              {erros.map((e, i) => <li key={i}>{e}</li>)}
            </ul>
          </div>
        )}
        <div className="flex justify-end gap-2 pt-2"><Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button><Button type="button" onClick={submit} disabled={erros.length > 0 || !valorBate} className="bg-emerald-600 hover:bg-emerald-700">Salvar</Button></div>
      </div>
    </div>
  );
}