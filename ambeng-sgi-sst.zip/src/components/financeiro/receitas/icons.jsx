import { FileText, Ruler, RotateCcw, ArrowUpRight, Zap, ArrowLeftRight, Wallet } from 'lucide-react';

export const TIPO_META = {
  'Contrato': { Icon: FileText, color: 'text-blue-600', bg: 'bg-blue-50' },
  'Medição': { Icon: Ruler, color: 'text-violet-600', bg: 'bg-violet-50' },
  'Reembolso': { Icon: RotateCcw, color: 'text-amber-600', bg: 'bg-amber-50' },
  'Adiantamento': { Icon: ArrowUpRight, color: 'text-emerald-600', bg: 'bg-emerald-50' },
};

export const FORMA_META = {
  'Pix': { Icon: Zap, label: 'PIX' },
  'TED': { Icon: ArrowLeftRight, label: 'TED' },
  'Dinheiro': { Icon: Wallet, label: 'Dinheiro' },
};

export const tipoMeta = (t) => TIPO_META[t] || { Icon: FileText, color: 'text-slate-500', bg: 'bg-slate-100' };
export const formaMeta = (f) => FORMA_META[f] || { Icon: Wallet, label: f || '—' };