import React from 'react';
import { fmtMoney, shortDate } from '@/lib/financeiro';
import { tipoMeta, formaMeta } from './icons';
import { CheckCircle2, Clock, Pencil, Trash2, Link2 } from 'lucide-react';

const ST = {
  'Recebida': { badge: 'bg-emerald-100 text-emerald-700', Icon: CheckCircle2, label: 'Recebido' },
  'Prevista': { badge: 'bg-amber-100 text-amber-700', Icon: Clock, label: 'Previsto' },
};

export default function ReceitaItem({ r, onEdit, onDelete, podeEditar = true, podeExcluir = true }) {
  const st = ST[r.status] || ST['Prevista'];
  const StIcon = st.Icon;
  const tipo = tipoMeta(r.tipo);
  const TipoIcon = tipo.Icon;
  const forma = formaMeta(r.forma_recebimento);
  const FormaIcon = forma.Icon;

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex items-start gap-3">
        <span className={`shrink-0 w-10 h-10 rounded-lg flex items-center justify-center ${tipo.bg}`}><TipoIcon className={`w-5 h-5 ${tipo.color}`} /></span>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="font-semibold text-[#0b2545] truncate">{r.descricao}</p>
              <p className="text-xs text-slate-500 truncate">{r.cliente ? `Cliente: ${r.cliente}` : ''}{r.obra ? `${r.cliente ? ' · ' : ''}Obra: ${r.obra}` : ''}</p>
              {r.fornecedor && (
                <p className="text-xs truncate mt-0.5">
                  <span className={r.fornecedor_id ? 'text-slate-500' : 'text-amber-600'}>Credor: {r.fornecedor}{r.fornecedor_id ? '' : ' (não vinculado)'}</span>
                </p>
              )}
            </div>
            <p className="text-lg font-bold text-emerald-700 whitespace-nowrap">{fmtMoney(r.valor)}</p>
          </div>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 mt-2">
            <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium inline-flex items-center gap-1 ${st.badge}`}><StIcon className="w-3 h-3" />{st.label}</span>
            <span>{r.tipo}</span>
            {r.forma_recebimento && <span className="inline-flex items-center gap-1"><FormaIcon className="w-3.5 h-3.5" />{forma.label}</span>}
          </div>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400 mt-1">
            <span>Prev.: {shortDate(r.data_prevista)}</span>
            {r.data_recebimento && <span>Recebido: {shortDate(r.data_recebimento)}</span>}
          </div>
        </div>
        <div className="flex flex-col gap-1 shrink-0">
          {podeEditar && r.fornecedor && !r.fornecedor_id && <button onClick={onEdit} className="p-1.5 text-amber-500 hover:text-amber-700" title="Vincular credor"><Link2 className="w-4 h-4" /></button>}
          {podeEditar && <button onClick={onEdit} className="p-1.5 text-slate-400 hover:text-[#0b2545]" title="Editar"><Pencil className="w-4 h-4" /></button>}
          {podeExcluir && <button onClick={onDelete} className="p-1.5 text-slate-400 hover:text-red-500" title="Excluir"><Trash2 className="w-4 h-4" /></button>}
        </div>
      </div>
    </div>
  );
}