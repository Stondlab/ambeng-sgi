import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { receitasPorCliente } from '@/lib/receitasCentral';

export default function ReceitasPorCliente({ items, onFilter }) {
  const data = receitasPorCliente(items);
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <h3 className="font-semibold text-[#0b2545] mb-3">Clientes — Maior valor em aberto</h3>
      <div className="overflow-x-auto max-h-72 overflow-y-auto">
        <table className="w-full text-sm">
          <thead className="text-xs uppercase text-slate-500 bg-slate-50 sticky top-0"><tr><th className="text-left px-3 py-2">Cliente</th><th className="text-right px-3 py-2">Previsto</th><th className="text-right px-3 py-2">Recebido</th><th className="text-right px-3 py-2">Em aberto</th><th className="text-right px-3 py-2">Atrasado</th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {data.map((c) => (
              <tr key={c.nome} className="hover:bg-slate-50 cursor-pointer" onClick={() => onFilter({ cliente: c.nome })}>
                <td className="px-3 py-2.5 text-[#0b2545] font-medium truncate max-w-[160px]">{c.nome}</td>
                <td className="px-3 py-2.5 text-right text-blue-700">{fmtMoney(c.previsto)}</td>
                <td className="px-3 py-2.5 text-right text-emerald-700">{fmtMoney(c.recebido)}</td>
                <td className="px-3 py-2.5 text-right font-semibold text-slate-700">{fmtMoney(c.emAberto)}</td>
                <td className="px-3 py-2.5 text-right text-red-700">{fmtMoney(c.atrasado)}</td>
              </tr>
            ))}
            {!data.length && <tr><td colSpan={5} className="px-3 py-8 text-center text-slate-400">Sem receitas.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}