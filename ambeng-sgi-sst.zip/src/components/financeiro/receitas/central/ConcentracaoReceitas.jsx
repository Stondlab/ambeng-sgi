import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { concentracaoReceitas } from '@/lib/receitasCentral';

export default function ConcentracaoReceitas({ items }) {
  const data = concentracaoReceitas(items, 5);
  const totalPct = data.reduce((s, c) => s + c.pct, 0);
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <h3 className="font-semibold text-[#0b2545] mb-3">Concentração de Receitas</h3>
      {data.length === 0 ? <p className="text-sm text-slate-400 py-6 text-center">Sem dados.</p> : (
        <div className="space-y-2.5">
          {data.map((c) => (
            <div key={c.nome}>
              <div className="flex justify-between text-sm"><span className="text-slate-600 truncate">{c.nome}</span><span className="font-medium text-[#0b2545]">{fmtMoney(c.previsto)} · {c.pct.toFixed(0)}%</span></div>
              <div className="h-2 rounded-full bg-slate-100 overflow-hidden mt-1"><div className="h-full bg-blue-500" style={{ width: `${Math.min(100, c.pct)}%` }} /></div>
            </div>
          ))}
          <p className="text-xs text-slate-400 pt-1">Top {data.length} clientes concentram {totalPct.toFixed(0)}% da receita prevista.</p>
        </div>
      )}
    </div>
  );
}