import React from 'react';
import { AlertTriangle, Info, CheckCircle2, TrendingUp } from 'lucide-react';

const META = {
  risco: { Icon: AlertTriangle, cls: 'border-red-200 bg-red-50 text-red-700', ic: 'text-red-500' },
  atencao: { Icon: AlertTriangle, cls: 'border-amber-200 bg-amber-50 text-amber-700', ic: 'text-amber-500' },
  info: { Icon: Info, cls: 'border-blue-200 bg-blue-50 text-blue-700', ic: 'text-blue-500' },
  sucesso: { Icon: TrendingUp, cls: 'border-emerald-200 bg-emerald-50 text-emerald-700', ic: 'text-emerald-500' },
  ok: { Icon: CheckCircle2, cls: 'border-emerald-200 bg-emerald-50 text-emerald-700', ic: 'text-emerald-500' },
};

export default function AnaliseFinanceiraReceitas({ insights }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex items-center gap-2 mb-3"><Info className="w-4 h-4 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Análise Financeira</h3></div>
      <div className="grid sm:grid-cols-2 gap-2">
        {insights.map((it, i) => {
          const m = META[it.tipo] || META.info; const Icon = m.Icon;
          return (
            <div key={i} className={`flex items-start gap-2 rounded-lg border px-3 py-2.5 ${m.cls}`}>
              <Icon className={`w-4 h-4 shrink-0 mt-0.5 ${m.ic}`} />
              <span className="text-sm">{it.texto}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}