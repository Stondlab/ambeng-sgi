import React, { useMemo } from 'react';
import { comparativoMensal, entradasFuturas, recebimentosAtrasados, aguardandoLiberacao, receitasPorObra, receitasPorCliente, insightsReceitas } from '@/lib/receitasCentral';
import ReceitasMes from './ReceitasMes';
import EntradasFuturas from './EntradasFuturas';
import FluxoEntradas from './FluxoEntradas';
import ReceitasPorObra from './ReceitasPorObra';
import ReceitasPorCliente from './ReceitasPorCliente';
import ConcentracaoReceitas from './ConcentracaoReceitas';
import ContratadoVsRecebido from './ContratadoVsRecebido';
import ReceitasVsDespesas from './ReceitasVsDespesas';
import AnaliseFinanceiraReceitas from './AnaliseFinanceiraReceitas';

export default function ReceitasAnalise({ items, futureItems, despesas, resumo, podeVerEstrategico, range, obraGlobal, setObra, applyFilter, onPeriod }) {
  const comparativo = useMemo(() => comparativoMensal(items), [items]);
  const entradas = useMemo(() => entradasFuturas(futureItems), [futureItems]);
  const aguard = useMemo(() => aguardandoLiberacao(items), [items]);
  const atras = useMemo(() => recebimentosAtrasados(items), [items]);
  const obraData = useMemo(() => receitasPorObra(items), [items]);
  const clientes = useMemo(() => receitasPorCliente(items), [items]);
  const insights = useMemo(() => insightsReceitas(items, comparativo, entradas, clientes, atras, aguard, obraData), [items, comparativo, entradas, clientes, atras, aguard, obraData]);
  const despesasPeriodo = useMemo(() => despesas.filter((d) => {
    if (obraGlobal !== 'geral' && d.obra !== obraGlobal) return false;
    const data = d.data_vencimento || d.data_compra;
    return !range?.start || (data && data >= range.start && data <= range.end);
  }), [despesas, range, obraGlobal]);
  return <div className="space-y-4">
    <ReceitasMes comp={comparativo} resumo={resumo} />
    <EntradasFuturas items={futureItems} onPeriod={onPeriod} />
    <FluxoEntradas items={items} onPeriod={onPeriod} />
    <div className="grid gap-4 lg:grid-cols-2"><ReceitasPorObra items={items} onFilter={(patch) => patch.obra ? setObra(patch.obra) : applyFilter(patch)} /><ReceitasPorCliente items={items} onFilter={applyFilter} /></div>
    {podeVerEstrategico && <div className="grid gap-4 lg:grid-cols-2"><ConcentracaoReceitas items={items} /><ContratadoVsRecebido items={items} /></div>}
    {podeVerEstrategico && <ReceitasVsDespesas receitas={items} despesas={despesasPeriodo} />}
    {podeVerEstrategico && <AnaliseFinanceiraReceitas insights={insights} />}
  </div>;
}