import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { resultadoCaixa } from '@/lib/receitasCentral';

export default function ReceitasVsDespesas({ receitas, despesas }) {
  const r = resultadoCaixa(receitas, despesas);
  const positivo = r.resultado >= 0;
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <h3 className="font-semibold text-[#0b2545] mb-3">Receitas × Despesas — Resultado de Caixa</h3>
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-emerald-50 rounded-lg p-3 text-center"><p className="text-xs text-emerald-700">Receitas recebidas</p><p className="text-base font-bold text-emerald-700 mt-1">{fmtMoney(r.recRecebido)}</p></div>
        <div className="bg-slate-50 rounded-lg p-3 text-center"><p className="text-xs text-slate-600">Despesas pagas</p><p className="text-base font-bold text-slate-700 mt-1">{fmtMoney(r.despPago)}</p></div>
        <div className={`rounded-lg p-3 text-center ${positivo ? 'bg-emerald-50' : 'bg-red-50'}`}><p className={`text-xs ${positivo ? 'text-emerald-700' : 'text-red-700'}`}>Resultado de caixa</p><p className={`text-base font-bold mt-1 ${positivo ? 'text-emerald-700' : 'text-red-700'}`}>{fmtMoney(r.resultado)}</p></div>
      </div>
      <p className="text-xs text-slate-400 mt-2">Indicador de caixa (não é lucro contábil).</p>
    </div>
  );
}