import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { TrendingUp, TrendingDown } from 'lucide-react';

export default function ReceitasMes({ comp, resumo }) {
  const variacao = comp.variacao;
  const subiu = variacao != null && variacao > 0;
  const caiu = variacao != null && variacao < 0;
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-3">Receitas Deste Mês</p>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-blue-50 rounded-lg p-3"><p className="text-xs text-blue-700">Previsto</p><p className="text-lg font-bold text-blue-700 mt-1">{fmtMoney(resumo.previsto)}</p></div>
        <div className="bg-emerald-50 rounded-lg p-3"><p className="text-xs text-emerald-700">Recebido</p><p className="text-lg font-bold text-emerald-700 mt-1">{fmtMoney(resumo.recebido)}</p></div>
        <div className="bg-slate-50 rounded-lg p-3"><p className="text-xs text-slate-600">Em aberto</p><p className="text-lg font-bold text-slate-700 mt-1">{fmtMoney(resumo.aReceber)}</p></div>
        <div className="rounded-lg p-3 border border-slate-200">
          <p className="text-xs text-slate-500">vs. mês anterior</p>
          <p className={`text-lg font-bold mt-1 inline-flex items-center gap-1 ${subiu ? 'text-emerald-700' : caiu ? 'text-amber-700' : 'text-slate-500'}`}>
            {subiu ? <TrendingUp className="w-4 h-4" /> : caiu ? <TrendingDown className="w-4 h-4" /> : null}
            {variacao == null ? '—' : `${variacao > 0 ? '+' : ''}${variacao.toFixed(1)}%`}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Anterior: {fmtMoney(comp.anterior)}</p>
        </div>
      </div>
    </div>
  );
}