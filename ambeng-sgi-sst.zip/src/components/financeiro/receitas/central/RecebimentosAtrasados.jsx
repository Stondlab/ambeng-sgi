import React from 'react';
import { fmtMoney, shortDate, valorMes, parcelaLabel } from '@/lib/financeiro';
import { recebimentosAtrasados } from '@/lib/receitasCentral';
import { useColumnSort } from '@/lib/useColumnSort';
import SortableTh from '@/components/financeiro/SortableTh';

export default function RecebimentosAtrasados({ items, onOpen }) {
  const { sortField, sortDir, toggleSort, sortRows } = useColumnSort();

  const rowsRaw = recebimentosAtrasados(items);
  const rows = sortRows(rowsRaw, {
    cliente: (a, b) => (a.cliente || '').localeCompare(b.cliente || ''),
    descricao: (a, b) => (a.descricao || '').localeCompare(b.descricao || ''),
    valor: (a, b) => valorMes(a) - valorMes(b),
    vencimento: (a, b) => (a.data_prevista || '').localeCompare(b.data_prevista || ''),
    diasAtraso: (a, b) => (a.diasAtraso || 0) - (b.diasAtraso || 0),
  });
  const total = rows.reduce((s, r) => s + valorMes(r), 0);

  return (
    <div className="bg-white border border-red-200 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-red-700">Recebimentos Atrasados</h3>
        <div className="text-right"><p className="text-xs text-slate-500">{rows.length} recebimento(s)</p><p className="text-lg font-bold text-red-700">{fmtMoney(total)}</p></div>
      </div>
      <div className="min-w-0 max-h-80 overflow-y-auto">
        <div className="divide-y divide-border md:hidden">{rows.map((r) => <button key={r.id} className="block w-full py-3 text-left" onClick={() => onOpen(r)}><div className="flex items-start justify-between gap-3"><p className="min-w-0 font-medium text-foreground">{r.descricao || 'Não informado'}</p><p className="shrink-0 font-semibold text-red-700">{fmtMoney(valorMes(r))}</p></div><p className="mt-1 text-xs text-muted-foreground">{r.obra || 'Sem obra'} · {r.cliente || 'Sem cliente'}</p><div className="mt-2 flex justify-between text-xs"><span>{shortDate(r.data_prevista)}</span><span className="font-medium text-red-600">{r.diasAtraso}d em atraso</span></div></button>)}{!rows.length && <p className="py-8 text-center text-sm text-muted-foreground">Nenhum recebimento atrasado.</p>}</div>
        <table className="hidden w-full table-fixed text-sm md:table">
          <thead className="text-xs uppercase text-slate-500 bg-slate-50 sticky top-0">
            <tr>
              <SortableTh field="descricao" label="Descrição" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="w-1/4 px-3 py-2" />
              <th className="text-left px-3 py-2">Obra</th>
              <SortableTh field="cliente" label="Cliente" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
              <SortableTh field="valor" label="Valor" align="right" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
              <SortableTh field="vencimento" label="Vencimento" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
              <SortableTh field="diasAtraso" label="Dias atraso" align="right" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((r) => (
              <tr key={r.id} className="hover:bg-red-50/40 cursor-pointer" onClick={() => onOpen(r)}>
                <td className="px-3 py-2.5 text-[#0b2545] font-medium truncate">{r.descricao || 'Não informado'}</td>
                <td className="px-3 py-2.5 text-slate-500 truncate">{r.obra || '—'}</td>
                <td className="px-3 py-2.5 text-slate-600 truncate">{r.cliente || '—'}{parcelaLabel(r) ? ` · ${parcelaLabel(r)}` : ''}</td>
                <td className="px-3 py-2.5 text-right font-semibold text-red-700">{fmtMoney(valorMes(r))}</td>
                <td className="px-3 py-2.5 text-slate-600 whitespace-nowrap">{shortDate(r.data_prevista)}</td>
                <td className="px-3 py-2.5 text-right text-red-600 font-medium">{r.diasAtraso}d</td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan={6} className="px-3 py-8 text-center text-slate-400">Nenhum recebimento atrasado. 🟢</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}