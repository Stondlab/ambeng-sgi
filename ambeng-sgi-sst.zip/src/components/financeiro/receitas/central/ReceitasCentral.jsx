import React, { lazy, Suspense, useEffect, useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { fmtMoney, valorMes } from '@/lib/financeiro';
import { useColumnSort } from '@/lib/useColumnSort';
import SortBar from '@/components/financeiro/SortBar';
import { useFiltrosFinanceiro } from '@/lib/FiltrosFinanceiroContext';
import { usePermissoes } from '@/lib/PermissoesContext';
import { pode } from '@/lib/permissoes';
import { filterReceitas, resumoReceitas } from '@/lib/receitasCentral';
import FiltrosReceitasBar from './FiltrosReceitasBar';
import ResumoReceitas from './ResumoReceitas';
import ProximasEntradas from './ProximasEntradas';
import RecebimentosAtrasados from './RecebimentosAtrasados';
import AguardandoLiberacao from './AguardandoLiberacao';
import ReceitaItemCompact from './ReceitaItemCompact';
import ReceitaModal from './ReceitaModal';
import ReceitaForm from '../ReceitaForm';
import QuickSettlementDialog from '@/components/financeiro/QuickSettlementDialog';

const ReceitasAnalise = lazy(() => import('./ReceitasAnalise'));

const EMPTY = {
  busca: '', cliente: 'all', tipo: 'all', status: 'all', forma: 'all', responsavel: 'all', aprovacao: 'all',
  contrato: '', medicao: '', prevInicio: '', prevFim: '', recebInicio: '', recebFim: '',
};

export default function ReceitasCentral({ items, despesas, obras, obrasAtivas, clientesCadastro, podeCriar, podeEditar, podeExcluir, onSave, onDelete, onPrepareForm, onAnalisar }) {
  const { perfilEfetivo } = usePermissoes();
  const podeVerEstrategico = pode(perfilEfetivo, 'fin_receitas', 'visualizar');
  const { obra: obraGlobal, setObra, dataInicio, dataFim, range } = useFiltrosFinanceiro();
  const [filtros, setFiltros] = useState(EMPTY);
  const [detail, setDetail] = useState(null);
  const [edit, setEdit] = useState(null);
  const [view, setView] = useState('operacional');
  const [settlement, setSettlement] = useState(null);
  const [settling, setSettling] = useState(false);
  const { sortField, sortDir, toggleSort, sortRows } = useColumnSort();
  useEffect(() => { const id = new URLSearchParams(window.location.search).get('id'); if (id) setDetail(items.find((row) => row.id === id) || null); }, [items]);

  const itemsObra = useMemo(() => items.filter((r) => obraGlobal === 'geral' || r.obra === obraGlobal), [items, obraGlobal]);
  const itemsPeriodo = useMemo(() => itemsObra.filter((r) => {
    if (range && range.start) { const dt = r.data_prevista || r.data_emissao; if (!dt || dt < range.start || dt > range.end) return false; }
    return true;
  }), [itemsObra, range]);

  const filteredRaw = useMemo(() => filterReceitas(itemsPeriodo, filtros, null), [itemsPeriodo, filtros]);
  const filtered = useMemo(() => sortRows(filteredRaw, {
    cliente: (a, b) => (a.cliente || '').localeCompare(b.cliente || ''),
    descricao: (a, b) => (a.descricao || '').localeCompare(b.descricao || ''),
    valor: (a, b) => valorMes(a) - valorMes(b),
    vencimento: (a, b) => (a.data_prevista || '').localeCompare(b.data_prevista || ''),
  }), [filteredRaw, sortField, sortDir]);
  const totalValor = filtered.reduce((s, r) => s + valorMes(r), 0);

  const resumo = useMemo(() => resumoReceitas(itemsPeriodo), [itemsPeriodo]);

  const clientes = useMemo(() => [...new Set(items.map((r) => r.cliente).filter(Boolean))], [items]);
  const responsaveis = useMemo(() => [...new Set(items.map((r) => r.responsavel).filter(Boolean))], [items]);

  const applyFilter = (patch) => setFiltros((p) => ({ ...p, ...patch }));
  const onPeriod = (key) => {
    const dias = { d7: 7, d15: 15, d30: 30, d60: 60, d90: 90 }[key];
    const e = new Date(); e.setDate(e.getDate() + dias); const eIso = e.toISOString().slice(0, 10); const tIso = new Date().toISOString().slice(0, 10);
    setFiltros((p) => ({ ...p, prevInicio: tIso, prevFim: eIso, status: 'all', aprovacao: 'all' }));
  };
  const openDetail = (r) => setDetail(r);
  const onEdit = async (r) => { setDetail(null); await onPrepareForm?.(); setEdit(r); };
  const markReceived = async (date) => { const { id, created_date, updated_date, created_by_id, ...fields } = settlement; setSettling(true); const ok = await onSave({ ...fields, status: 'Recebida', data_recebimento: date }, id); setSettling(false); if (ok) setSettlement(null); };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-end gap-2">
        {podeCriar && <Button onClick={async () => { await onPrepareForm?.(); setEdit({}); }} className="bg-emerald-600 hover:bg-emerald-700 min-h-[44px]"><Plus className="w-4 h-4 mr-1" />Nova Receita</Button>}
      </div>

      <div className="grid grid-cols-2 rounded-xl border border-border bg-muted p-1"><button onClick={() => setView('operacional')} className={`min-h-11 rounded-lg text-sm font-medium ${view === 'operacional' ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground'}`}>Operacional</button><button onClick={() => { setView('analisar'); onAnalisar?.(); }} className={`min-h-11 rounded-lg text-sm font-medium ${view === 'analisar' ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground'}`}>Analisar</button></div>

      {view === 'operacional' ? <>
        <FiltrosReceitasBar filtros={filtros} setFiltros={setFiltros} clientes={clientes} responsaveis={responsaveis} onClear={() => setFiltros(EMPTY)} />
        <ResumoReceitas resumo={resumo} onFilter={applyFilter} />
        <div className="space-y-4"><ProximasEntradas items={itemsObra} onOpen={openDetail} /><RecebimentosAtrasados items={itemsPeriodo} onOpen={openDetail} /></div>
        <AguardandoLiberacao items={itemsPeriodo} onOpen={openDetail} />
        <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-white px-4 py-3"><p className="text-sm text-slate-500">{filtered.length} receita(s)</p><p className="text-sm font-semibold text-[#0b2545]">Total: {fmtMoney(totalValor)}</p></div>
        <SortBar columns={[{ key: 'cliente', label: 'Cliente', flex: true }, { key: 'descricao', label: 'Descrição' }, { key: 'valor', label: 'Valor' }, { key: 'vencimento', label: 'Vencimento' }]} sortField={sortField} sortDir={sortDir} onSort={toggleSort} />
        <div className="space-y-2.5">{filtered.length === 0 ? <p className="py-10 text-center text-sm text-slate-400">Nenhuma receita encontrada com os filtros atuais.</p> : filtered.map((r) => <ReceitaItemCompact key={r.id} r={r} onOpen={openDetail} podeEditar={podeEditar} onMarkReceived={setSettlement} />)}</div>
      </> : <Suspense fallback={<p className="py-10 text-center text-sm text-muted-foreground">Carregando análises…</p>}><ReceitasAnalise items={itemsPeriodo} futureItems={itemsObra} despesas={despesas} resumo={resumo} podeVerEstrategico={podeVerEstrategico} range={range} obraGlobal={obraGlobal} setObra={setObra} applyFilter={applyFilter} onPeriod={onPeriod} /></Suspense>}

      <QuickSettlementDialog record={settlement} type="receita" open={!!settlement} onClose={() => setSettlement(null)} onConfirm={markReceived} pending={settling} />
      <ReceitaModal r={detail} open={!!detail} onClose={() => setDetail(null)} onSave={onSave} onDelete={onDelete} obras={obras} podeEditar={podeEditar} podeExcluir={podeExcluir} />
      {edit && <ReceitaForm record={edit} obras={obrasAtivas} clientes={clientesCadastro} onClose={() => setEdit(null)} onSave={(f, id) => { onSave(f, id); setEdit(null); }} />}
    </div>
  );
}