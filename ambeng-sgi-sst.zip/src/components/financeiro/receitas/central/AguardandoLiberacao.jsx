import React from 'react';
import { fmtMoney, shortDate } from '@/lib/financeiro';
import { aguardandoLiberacao } from '@/lib/receitasCentral';

export default function AguardandoLiberacao({ items, onOpen }) {
  const rows = aguardandoLiberacao(items);
  const total = rows.reduce((s, r) => s + (Number(r.valor) || 0), 0);
  return (
    <div className="bg-white border border-amber-200 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-amber-700">Aguardando Liberação</h3>
        <div className="text-right"><p className="text-xs text-slate-500">{rows.length} receita(s)</p><p className="text-lg font-bold text-amber-700">{fmtMoney(total)}</p></div>
      </div>
      <div className="space-y-2 max-h-80 overflow-y-auto">
        {rows.map((r) => (
          <div key={r.id} className="flex items-center gap-2 rounded-lg border border-slate-100 px-3 py-2 hover:bg-amber-50/40 cursor-pointer" onClick={() => onOpen(r)}>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-[#0b2545] truncate">{r.descricao || 'Não informado'}</p>
              <p className="text-xs text-slate-500 truncate">{r.cliente || '—'}{r.obra ? ` · ${r.obra}` : ''} · Prev. {shortDate(r.data_prevista)}{r.responsavel ? ` · Resp.: ${r.responsavel}` : ''}</p>
            </div>
            <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 whitespace-nowrap">{r.status_aprovacao}</span>
            <span className="text-sm font-semibold text-[#0b2545] whitespace-nowrap">{fmtMoney(r.valor)}</span>
          </div>
        ))}
        {!rows.length && <p className="text-sm text-slate-400 text-center py-6">Nenhuma receita aguardando liberação.</p>}
      </div>
    </div>
  );
}