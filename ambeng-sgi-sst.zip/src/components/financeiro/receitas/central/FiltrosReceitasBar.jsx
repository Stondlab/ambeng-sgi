import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import FinanceiroFilterShell from '@/components/financeiro/FinanceiroFilterShell';
import { Search } from 'lucide-react';

const TIPOS = ['Contrato', 'Medição', 'Reembolso', 'Adiantamento'];
const FORMAS = ['Pix', 'TED', 'Dinheiro'];
const APROVACOES = [{ value: 'nao', label: 'Não informado' }, 'Aguardando medição', 'Aguardando aprovação', 'Aguardando faturamento', 'Aguardando documento', 'Aguardando contrato', 'Outros'];
const STATUS = [{ value: 'Recebida', label: 'Recebida' }, { value: 'Prevista', label: 'Prevista' }, { value: 'Atrasada', label: 'Atrasada' }];
const FilterSelect = ({ value, onChange, placeholder, all, options }) => <Select value={value} onValueChange={onChange}><SelectTrigger className="h-10 w-full"><SelectValue placeholder={placeholder} /></SelectTrigger><SelectContent><SelectItem value="all">{all}</SelectItem>{options.map((item) => { const option = typeof item === 'string' ? { value: item, label: item } : item; return <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>; })}</SelectContent></Select>;

export default function FiltrosReceitasBar({ filtros, setFiltros, clientes, responsaveis, onClear }) {
  const set = (key, value) => setFiltros((current) => ({ ...current, [key]: value }));
  return <FinanceiroFilterShell partyLabel="Cliente" partyValue={filtros.cliente} partyOptions={clientes} onPartyChange={(value) => set('cliente', value)} statusValue={filtros.status} statusOptions={STATUS} onStatusChange={(value) => set('status', value)} onClear={onClear}>
    <div className="grid min-w-0 grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
      <div className="relative sm:col-span-2"><Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><Input className="pl-9" value={filtros.busca} onChange={(e) => set('busca', e.target.value)} placeholder="Buscar descrição, cliente ou obra" /></div>
      <FilterSelect value={filtros.aprovacao} onChange={(v) => set('aprovacao', v)} placeholder="Aprovação" all="Toda aprovação" options={APROVACOES} />
      <FilterSelect value={filtros.tipo} onChange={(v) => set('tipo', v)} placeholder="Tipo" all="Todos os tipos" options={TIPOS} />
      <FilterSelect value={filtros.forma} onChange={(v) => set('forma', v)} placeholder="Forma de recebimento" all="Todas as formas" options={FORMAS} />
      <FilterSelect value={filtros.responsavel} onChange={(v) => set('responsavel', v)} placeholder="Responsável" all="Todos os responsáveis" options={responsaveis} />
      <Input placeholder="Contrato" value={filtros.contrato} onChange={(e) => set('contrato', e.target.value)} />
      <Input placeholder="Medição" value={filtros.medicao} onChange={(e) => set('medicao', e.target.value)} />
      <div className="sm:col-span-2"><Label className="mb-1.5 block text-xs text-muted-foreground">Data de recebimento</Label><div className="grid grid-cols-2 gap-2"><Input type="date" value={filtros.recebInicio} onChange={(e) => set('recebInicio', e.target.value)} /><Input type="date" value={filtros.recebFim} onChange={(e) => set('recebFim', e.target.value)} /></div></div>
    </div>
  </FinanceiroFilterShell>;
}