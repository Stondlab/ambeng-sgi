import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { receitasPorObra } from '@/lib/receitasCentral';

export default function ReceitasPorObra({ items, onFilter }) {
  const data = receitasPorObra(items);
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <h3 className="font-semibold text-[#0b2545] mb-3">Receitas por Obra</h3>
      <div className="overflow-x-auto max-h-72 overflow-y-auto">
        <table className="w-full text-sm">
          <thead className="text-xs uppercase text-slate-500 bg-slate-50 sticky top-0"><tr><th className="text-left px-3 py-2">Obra</th><th className="text-right px-3 py-2">Previsto</th><th className="text-right px-3 py-2">Recebido</th><th className="text-right px-3 py-2">A receber</th><th className="text-left px-3 py-2 w-28">% recebido</th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {data.map((o) => (
              <tr key={o.nome} className="hover:bg-slate-50 cursor-pointer" onClick={() => onFilter({ obra: o.nome })}>
                <td className="px-3 py-2.5 text-[#0b2545] font-medium truncate max-w-[160px]">{o.nome}</td>
                <td className="px-3 py-2.5 text-right text-blue-700">{fmtMoney(o.previsto)}</td>
                <td className="px-3 py-2.5 text-right text-emerald-700">{fmtMoney(o.recebido)}</td>
                <td className="px-3 py-2.5 text-right text-slate-700">{fmtMoney(o.aReceber)}</td>
                <td className="px-3 py-2.5"><div className="flex items-center gap-2"><div className="h-1.5 rounded-full bg-slate-100 flex-1 overflow-hidden"><div className="h-full bg-emerald-500" style={{ width: `${Math.min(100, o.pct)}%` }} /></div><span className="text-xs text-slate-500 w-10 text-right">{o.pct.toFixed(0)}%</span></div></td>
              </tr>
            ))}
            {!data.length && <tr><td colSpan={5} className="px-3 py-8 text-center text-slate-400">Sem receitas.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}