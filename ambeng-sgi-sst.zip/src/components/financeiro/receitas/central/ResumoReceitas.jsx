import React from 'react';
import { fmtMoney } from '@/lib/financeiro';

const tone = (label) => {
  const base = 'min-w-0 rounded-xl border p-3 transition hover:shadow-card-hover text-left cursor-pointer min-h-[84px] overflow-hidden';
  switch (label) {
    case 'Recebido no Período': return `${base} bg-emerald-50 border-emerald-200 text-emerald-700`;
    case 'A Receber': return `${base} bg-blue-50 border-blue-200 text-blue-700`;
    case 'Atrasado': return `${base} bg-red-50 border-red-200 text-red-700`;
    case 'Previsto': return `${base} bg-slate-50 border-slate-200 text-slate-700`;
    case 'Aguardando Liberação': return `${base} bg-amber-50 border-amber-200 text-amber-700`;
    default: return base;
  }
};

const CARDS = [
  { key: 'recebido', label: 'Recebido no Período', filter: { status: 'Recebida' } },
  { key: 'previsto', label: 'Previsto', filter: null },
  { key: 'aReceber', label: 'A Receber', filter: { status: 'Prevista' } },
  { key: 'atrasado', label: 'Atrasado', filter: { status: 'Atrasada' } },
  { key: 'aguardando', label: 'Aguardando Liberação', filter: { aprovacao: 'any' } },
];

export default function ResumoReceitas({ resumo, onFilter }) {
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
      {CARDS.map((c) => (
        <button key={c.key} onClick={() => c.filter && onFilter(c.filter)} className={tone(c.label)}>
          <p className="text-[11px] opacity-80 leading-tight">{c.label}</p>
          <p className={`${fmtMoney(resumo[c.key]).length > 15 ? 'text-sm' : fmtMoney(resumo[c.key]).length > 12 ? 'text-base' : 'text-lg'} mt-2 break-words font-bold leading-tight`}>{fmtMoney(resumo[c.key])}</p>
        </button>
      ))}
    </div>
  );
}