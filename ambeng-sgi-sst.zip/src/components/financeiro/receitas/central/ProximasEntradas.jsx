import React, { useState } from 'react';
import { fmtMoney, shortDate, valorMes, parcelaLabel } from '@/lib/financeiro';
import { proximasEntradas } from '@/lib/receitasCentral';
import { useColumnSort } from '@/lib/useColumnSort';
import SortableTh from '@/components/financeiro/SortableTh';

const TABS = [7, 15, 30, 60, 90];
const ST_BADGE = { Recebida: 'bg-emerald-100 text-emerald-700', Prevista: 'bg-amber-100 text-amber-700', Atrasada: 'bg-red-100 text-red-700' };
const stLabel = (r) => r.status === 'Recebida' || r.data_recebimento ? 'Recebida' : 'Prevista';

export default function ProximasEntradas({ items, onOpen }) {
  const [tab, setTab] = useState(30);
  const { sortField, sortDir, toggleSort, sortRows } = useColumnSort();

  const rowsRaw = proximasEntradas(items, tab);
  const rows = sortRows(rowsRaw, {
    cliente: (a, b) => (a.cliente || '').localeCompare(b.cliente || ''),
    descricao: (a, b) => (a.descricao || '').localeCompare(b.descricao || ''),
    valor: (a, b) => valorMes(a) - valorMes(b),
    vencimento: (a, b) => (a.data_prevista || '').localeCompare(b.data_prevista || ''),
  });

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <h3 className="font-semibold text-[#0b2545]">Próximas Entradas</h3>
        <div className="flex gap-1 flex-wrap">
          {TABS.map((d) => <button key={d} onClick={() => setTab(d)} className={`text-xs px-3 py-1.5 rounded-lg ${tab === d ? 'bg-[#0b2545] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>{d} dias</button>)}
        </div>
      </div>
      <div className="min-w-0 max-h-80 overflow-y-auto">
        <div className="divide-y divide-border md:hidden">{rows.map((r) => <button key={r.id} className="block w-full py-3 text-left" onClick={() => onOpen(r)}><div className="flex items-start justify-between gap-3"><p className="min-w-0 font-medium text-foreground">{r.descricao || 'Não informado'}</p><p className="shrink-0 font-semibold text-emerald-700">{fmtMoney(valorMes(r))}</p></div><p className="mt-1 text-xs text-muted-foreground">{r.obra || 'Sem obra'} · {r.cliente || 'Sem cliente'}</p><div className="mt-2 flex items-center justify-between text-xs"><span>{shortDate(r.data_prevista)}</span><span className={`rounded-full px-2 py-0.5 font-medium ${ST_BADGE[stLabel(r)]}`}>{stLabel(r)}</span></div></button>)}{!rows.length && <p className="py-8 text-center text-sm text-muted-foreground">Nenhuma entrada prevista no período.</p>}</div>
        <table className="hidden w-full table-fixed text-sm md:table">
          <thead className="text-xs uppercase text-slate-500 bg-slate-50 sticky top-0">
            <tr>
              <SortableTh field="descricao" label="Descrição" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="w-1/4 px-3 py-2" />
              <th className="text-left px-3 py-2">Obra</th>
              <SortableTh field="cliente" label="Cliente" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
              <SortableTh field="valor" label="Valor" align="right" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
              <th className="text-left px-3 py-2">Vencimento</th>
              <th className="text-left px-3 py-2">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((r) => {
              const critico = valorMes(r) > 5000;
              const parcela = parcelaLabel(r);
              return (
                <tr key={r.id} className="hover:bg-slate-50 cursor-pointer" onClick={() => onOpen(r)}>
                  <td className="px-3 py-2.5 text-[#0b2545] font-medium truncate">{r.descricao || 'Não informado'}</td>
                  <td className="px-3 py-2.5 text-slate-500 truncate">{r.obra || '—'}</td>
                  <td className="px-3 py-2.5 text-slate-600 truncate">{r.cliente || '—'}{parcela ? ` · ${parcela}` : ''}</td>
                  <td className={`px-3 py-2.5 text-right font-semibold whitespace-nowrap ${critico ? 'text-emerald-700' : 'text-slate-700'}`}>{fmtMoney(valorMes(r))}</td>
                  <td className="px-3 py-2.5 whitespace-nowrap text-slate-600">{shortDate(r.data_prevista)}</td>
                  <td className="px-3 py-2.5"><span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${ST_BADGE[stLabel(r)]}`}>{stLabel(r)}</span></td>
                </tr>
              );
            })}
            {!rows.length && <tr><td colSpan={6} className="px-3 py-8 text-center text-slate-400">Nenhuma entrada prevista no período.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}