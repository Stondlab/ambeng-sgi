import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { contratadoVsRecebido } from '@/lib/receitasCentral';

export default function ContratadoVsRecebido({ items }) {
  const d = contratadoVsRecebido(items);
  if (!d) return null;
  const pct = d.contratado > 0 ? (d.recebido / d.contratado) * 100 : 0;
  const rows = [
    { label: 'Valor contratado', value: d.contratado, color: 'text-blue-700' },
    { label: 'Valor faturado', value: d.faturado, color: 'text-slate-500', na: d.faturado == null },
    { label: 'Valor recebido', value: d.recebido, color: 'text-emerald-700' },
    { label: 'Saldo a faturar', value: d.saldoFaturar, color: 'text-slate-500', na: d.saldoFaturar == null },
    { label: 'Saldo a receber', value: d.saldoReceber, color: 'text-amber-700' },
  ];
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <h3 className="font-semibold text-[#0b2545] mb-3">Contratado × Recebido</h3>
      <div className="space-y-1.5">
        {rows.map((r) => (
          <div key={r.label} className="flex justify-between text-sm border-b border-slate-50 py-1.5">
            <span className="text-slate-500">{r.label}</span>
            <span className={`font-medium ${r.na ? 'text-slate-400' : r.color}`}>{r.na ? 'Não informado' : fmtMoney(r.value)}</span>
          </div>
        ))}
      </div>
      <div className="mt-3"><div className="flex justify-between text-xs mb-1"><span className="text-slate-500">Progresso recebido</span><span className="font-medium text-[#0b2545]">{pct.toFixed(0)}%</span></div><div className="h-2 rounded-full bg-slate-100 overflow-hidden"><div className="h-full bg-emerald-500" style={{ width: `${Math.min(100, pct)}%` }} /></div></div>
    </div>
  );
}