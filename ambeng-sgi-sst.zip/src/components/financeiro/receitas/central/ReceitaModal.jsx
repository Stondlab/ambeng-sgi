import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { Receipt, Pencil, Plus, Trash2, FileText, FileCheck2, Paperclip, Upload, Save, CheckCircle2, CalendarClock } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { fmtMoney, valorMes, calcParcelas, addMeses } from '@/lib/financeiro';
import { isRecebida, isAtrasada } from '@/lib/receitasCentral';
import { nomeUsuario } from '@/lib/usuarioNome';

const TIPOS = ['Contrato', 'Medição', 'Reembolso', 'Adiantamento'];
const FORMAS = ['Pix', 'Cartão', 'Boleto', 'TED', 'Dinheiro'];
const STATUS_APROV = [
  { v: '', l: 'Não informado' },
  { v: 'Aguardando medição', l: 'Aguardando medição' },
  { v: 'Aguardando aprovação', l: 'Aguardando aprovação' },
  { v: 'Aguardando faturamento', l: 'Aguardando faturamento' },
  { v: 'Aguardando documento', l: 'Aguardando documento' },
  { v: 'Aguardando contrato', l: 'Aguardando contrato' },
  { v: 'Outros', l: 'Outros' },
];
const TIPOS_ANEXO = ['Nota Fiscal', 'Contrato', 'Boleto', 'Comprovante', 'Outros'];
const CAMPOS_HIST = {
  descricao: 'Descrição', cliente: 'Cliente', fornecedor: 'Credor', obra: 'Obra', tipo: 'Tipo de receita',
  forma_recebimento: 'Forma de recebimento', numero_contrato: 'Contrato', medicao: 'Medição',
  status: 'Status', status_aprovacao: 'Status da aprovação', responsavel: 'Responsável',
  data_emissao: 'Data de emissão', data_prevista: 'Vencimento', data_recebimento: 'Data de recebimento',
  observacoes: 'Observação', valor: 'Valor total', valor_parcela: 'Valor da parcela',
  parcela_atual: 'Parcela atual', total_parcelas: 'Total de parcelas',
};

const fmtDate = (iso) => iso ? new Date(iso + 'T00:00').toLocaleDateString('pt-BR') : '—';

function initForm(d) {
  if (!d) d = {};
  const f = {};
  ['descricao', 'cliente', 'cliente_id', 'fornecedor', 'obra', 'obra_id', 'tipo', 'forma_recebimento', 'status', 'status_aprovacao',
    'responsavel', 'numero_contrato', 'medicao', 'observacoes', 'data_emissao', 'data_prevista', 'data_recebimento', 'anexos', 'historico']
    .forEach((k) => { f[k] = d[k] ?? ''; });
  ['valor', 'valor_parcela', 'parcela_atual', 'total_parcelas'].forEach((k) => { f[k] = d[k] ?? ''; });
  return f;
}
function parseJSON(v, fb) { try { return v ? JSON.parse(v) : fb; } catch { return fb; } }
function appendHist(histStr, entries) {
  const arr = parseJSON(histStr, []);
  entries.forEach((e) => arr.push({ ...e, data_hora: new Date().toISOString() }));
  return JSON.stringify(arr);
}

function InlineField({ label, value, display, type = 'text', inputType, options, onCommit, readOnly, placeholder }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  useEffect(() => { setDraft(value); }, [value]);
  const shown = display != null ? display : (value || '');
  const renderValue = () => shown ? <span className="text-slate-700">{shown}</span> : <span className="text-slate-300 italic">Não informado</span>;
  if (readOnly) {
    return (<div className="py-1.5"><div className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">{label}</div><div className="text-sm mt-0.5">{renderValue()}</div></div>);
  }
  if (editing) {
    return (
      <div className="py-1.5">
        <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">{label}</div>
        {type === 'select' ? (
          <Select value={draft ?? ''} onValueChange={(v) => { onCommit(v); setEditing(false); }}>
            <SelectTrigger className="h-9 mt-1 text-sm"><SelectValue placeholder={placeholder || 'Selecione'} /></SelectTrigger>
            <SelectContent>{options}</SelectContent>
          </Select>
        ) : type === 'textarea' ? (
          <Textarea autoFocus rows={2} className="mt-1 text-sm" value={draft ?? ''} onChange={(e) => setDraft(e.target.value)}
            onBlur={() => { setEditing(false); if ((draft || '') !== (value || '')) onCommit(draft); }}
            onKeyDown={(e) => { if (e.key === 'Escape') { setDraft(value); setEditing(false); } }} />
        ) : (
          <Input autoFocus type={inputType || 'text'} className="h-9 mt-1 text-sm" value={draft ?? ''}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={() => { setEditing(false); if ((draft ?? '') !== (value ?? '')) onCommit(draft); }}
            onKeyDown={(e) => { if (e.key === 'Enter') { setEditing(false); if ((draft ?? '') !== (value ?? '')) onCommit(draft); } if (e.key === 'Escape') { setDraft(value); setEditing(false); } }} />
        )}
      </div>
    );
  }
  return (
    <button type="button" onClick={() => setEditing(true)} className="w-full text-left py-1.5 rounded-lg px-1.5 -mx-1.5 hover:bg-slate-50 transition group">
      <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">{label}</div>
      <div className="text-sm mt-0.5 flex items-center justify-between gap-2">
        <span className="min-w-0 truncate">{renderValue()}</span>
        <Pencil className="w-3 h-3 text-slate-300 group-hover:text-[#0b2545] shrink-0" />
      </div>
    </button>
  );
}

function Card({ title, action, children, className }) {
  return (
    <div className={`bg-white border border-slate-200 rounded-xl shadow-card ${className || ''}`}>
      <div className="px-4 py-2.5 border-b border-slate-100 flex items-center justify-between">
        <h4 className="text-xs font-bold uppercase tracking-wider text-[#0b2545]">{title}</h4>
        {action}
      </div>
      <div className="p-4">{children}</div>
    </div>
  );
}
function ResumoCard({ label, value, sub, accent }) {
  return (
    <div className={`rounded-xl border p-3 ${accent || 'border-slate-200 bg-white'}`}>
      <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">{label}</div>
      <div className="text-lg font-bold text-[#0b2545] mt-0.5 leading-tight">{value}</div>
      {sub && <div className="text-[11px] text-slate-500 mt-0.5">{sub}</div>}
    </div>
  );
}

export default function ReceitaModal({ r, open, onClose, onSave, onDelete, obras, podeEditar, podeExcluir }) {
  const { toast } = useToast();
  const [form, setForm] = useState(() => initForm(r));
  const [base, setBase] = useState(() => initForm(r));
  const [user, setUser] = useState(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [novoTipo, setNovoTipo] = useState('Nota Fiscal');
  const fileRef = useRef(null);

  useEffect(() => { if (open) { setUser(null); (async () => { try { setUser(await base44.auth.me()); } catch {} })(); } }, [open]);
  useEffect(() => { if (r) { const f = initForm(r); setForm(f); setBase(f); } }, [r]);

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  const readOnly = !podeEditar;

  const stOf = (rec) => (isRecebida(rec) ? 'Recebido' : isAtrasada(rec) ? 'Atrasado' : 'Previsto');
  const st = stOf(form);
  const stAprov = form.status_aprovacao || 'Não informado';
  const parcelado = Number(form.total_parcelas) > 1;
  const valorCompetencia = valorMes(form);
  const recebidoValor = isRecebida(form) ? valorMes(form) : 0;
  const saldoValor = valorMes(form) - recebidoValor;
  const tituloCurto = (form.descricao || 'Receita').replace(/\s*\(\d+\/\d+\)\s*$/, '');

  const dirty = useMemo(() => Object.keys(CAMPOS_HIST).some((k) => String(form[k] ?? '') !== String(base[k] ?? '')), [form, base]);

  const ST = { Recebido: 'bg-emerald-100 text-emerald-700', Previsto: 'bg-amber-100 text-amber-700', Atrasado: 'bg-red-100 text-red-700' };
  const ST_APROV = {
    'Aguardando aprovação': 'bg-amber-100 text-amber-700', 'Aguardando medição': 'bg-amber-100 text-amber-700',
    'Aguardando faturamento': 'bg-sky-100 text-sky-700', 'Aguardando documento': 'bg-sky-100 text-sky-700',
    'Aguardando contrato': 'bg-sky-100 text-sky-700', 'Outros': 'bg-slate-100 text-slate-500',
    'Não informado': 'bg-slate-100 text-slate-500',
  };

  // Cronograma de parcelas (projeção: calcParcelas + addMeses a partir do primeiro vencimento)
  const N = Math.max(1, parseInt(form.total_parcelas) || 1);
  const parcelaAtual = parseInt(form.parcela_atual) || (parcelado ? 1 : 1);
  const primeiroVenc = parcelado && form.data_prevista ? addMeses(form.data_prevista, -(parcelaAtual - 1)) : form.data_prevista;
  const proximoVenc = form.data_prevista;
  const parcelasArr = calcParcelas(Number(form.valor) || 0, N);
  const schedule = Array.from({ length: N }, (_, i) => {
    const k = i + 1;
    const venc = addMeses(primeiroVenc, i);
    const status = k === parcelaAtual ? st : (k < parcelaAtual ? (isRecebida(form) && k === parcelaAtual ? 'Recebido' : 'Previsto') : 'Previsto');
    return { k, venc, valor: parcelasArr[i], status: k === parcelaAtual ? st : 'Previsto' };
  });

  // ANEXOS
  const anexos = parseJSON(form.anexos, []);
  const addAnexo = async (file) => {
    if (!file || !r?.id) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const arr = [...anexos, { url: file_url, nome: file.name, tipo: novoTipo, data: new Date().toISOString() }];
      const str = JSON.stringify(arr);
      set('anexos', str);
      const hist = appendHist(form.historico, [{ usuario: nomeUsuario(user), campo: 'Documento', anterior: '—', novo: file.name }]);
      set('historico', hist);
      await base44.entities.Receitas.update(r.id, { anexos: str, historico: hist });
      toast({ title: 'Documento adicionado.' });
    } catch (e) { toast({ title: 'Falha ao enviar documento.', description: e?.message, variant: 'destructive' }); }
    setUploading(false);
    if (fileRef.current) fileRef.current.value = '';
  };
  const removeAnexo = async (idx) => {
    if (!confirm('Remover este documento?')) return;
    const arr = anexos.filter((_, i) => i !== idx);
    const str = JSON.stringify(arr);
    set('anexos', str);
    const hist = appendHist(form.historico, [{ usuario: nomeUsuario(user), campo: 'Documento', anterior: anexos[idx]?.nome || '—', novo: '—' }]);
    set('historico', hist);
    if (r?.id) await base44.entities.Receitas.update(r.id, { anexos: str, historico: hist });
    toast({ title: 'Documento removido.' });
  };

  // REGISTRAR RECEBIMENTO da parcela corrente
  const registrarRecebimento = async () => {
    if (!r?.id || readOnly) return;
    const hoje = new Date().toISOString().slice(0, 10);
    const hist = appendHist(form.historico, [{ usuario: nomeUsuario(user), campo: 'Recebimento', anterior: form.data_recebimento || '—', novo: hoje }]);
    const payload = { data_recebimento: hoje, status: 'Recebida', historico: hist };
    set('data_recebimento', hoje); set('status', 'Recebida'); set('historico', hist);
    await base44.entities.Receitas.update(r.id, payload);
    setBase((b) => ({ ...b, data_recebimento: hoje, status: 'Recebida', historico: hist }));
    toast({ title: 'Recebimento registrado.' });
  };

  // SALVAR
  const salvar = async () => {
    if (!r?.id) return;
    setSaving(true);
    try {
      const diff = [];
      Object.keys(CAMPOS_HIST).forEach((k) => {
        const ant = base[k] ?? ''; const nv = form[k] ?? '';
        if (String(ant) !== String(nv)) diff.push({ usuario: nomeUsuario(user), campo: CAMPOS_HIST[k], campoKey: k, anterior: ant || '—', novo: nv || '—' });
      });
      const payload = { ...form };
      ['valor', 'valor_parcela', 'parcela_atual', 'total_parcelas'].forEach((k) => { payload[k] = payload[k] === '' ? null : Number(payload[k]); });
      if (payload.status_aprovacao === '') payload.status_aprovacao = null;
      if (diff.length) payload.historico = appendHist(form.historico, diff.map(({ campo, ...x }) => ({ ...x, campo })));
      const ok = await onSave(payload, r.id);
      if (ok) { setBase({ ...form }); toast({ title: 'Alterações salvas.' }); }
    } catch (e) { toast({ title: 'Erro ao salvar.', description: e?.message, variant: 'destructive' }); }
    setSaving(false);
  };
  const excluir = async () => { if (!confirm('Excluir esta receita?')) return; await onDelete(r.id); onClose(); };

  const hist = parseJSON(form.historico, []);
  const iconAnexo = (tipo) => /nota/i.test(tipo) ? FileText : /boleto|contrato/i.test(tipo) ? FileCheck2 : Paperclip;
  const AnexoIcon = (t) => { const Ic = iconAnexo(t); return <Ic className="w-4 h-4 text-slate-500" />; };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-5xl w-[92vw] max-h-[92vh] p-0 gap-0 overflow-hidden flex flex-col">
        {/* Cabeçalho */}
        <div className="px-6 py-4 border-b border-slate-200 bg-gradient-to-r from-emerald-700 to-emerald-600 text-white shrink-0">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0"><Receipt className="w-5 h-5" /></div>
              <div className="min-w-0">
                <h2 className="text-lg font-bold leading-tight truncate">RECEITA — {tituloCurto}{parcelado ? ` (${form.parcela_atual || 0}/${form.total_parcelas})` : ''}</h2>
                <p className="text-sm text-white/80 mt-0.5 truncate">{[form.cliente, form.obra, form.tipo].filter(Boolean).join(' · ') || 'Sem dados cadastrais'}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className={`px-2.5 py-1 rounded-full text-[11px] font-semibold ${ST[st]}`}>{st}</span>
              {form.status_aprovacao && <span className={`px-2.5 py-1 rounded-full text-[11px] font-semibold ${ST_APROV[stAprov] || 'bg-slate-100 text-slate-500'}`}>{stAprov}</span>}
            </div>
          </div>
        </div>

        {/* Corpo */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5 bg-slate-50/60">

          {/* Resumo financeiro */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <ResumoCard label="Valor total" value={fmtMoney(form.valor)} />
            <ResumoCard label="Parcela" value={parcelado ? `${form.parcela_atual || 0}/${form.total_parcelas}` : 'À vista'} />
            <ResumoCard label="Valor da competência" value={fmtMoney(valorCompetencia)} sub="Impacto mensal" accent="border-emerald-600/30 bg-emerald-50" />
            <ResumoCard label="Recebido" value={fmtMoney(recebidoValor)} accent={recebidoValor > 0 ? 'border-emerald-300 bg-emerald-50' : ''} />
            <ResumoCard label="Saldo" value={fmtMoney(saldoValor)} accent={saldoValor > 0 ? 'border-amber-300 bg-amber-50' : ''} />
            <ResumoCard label="Status" value={st} />
          </div>

          <div className="grid lg:grid-cols-2 gap-5">
            {/* Dados da receita */}
            <Card title="Dados da receita">
              <div className="divide-y divide-slate-50">
                <InlineField label="Cliente" value={form.cliente} onCommit={(v) => set('cliente', v)} readOnly={readOnly} />
                <InlineField label="Descrição" value={form.descricao} onCommit={(v) => set('descricao', v)} readOnly={readOnly} />
                <InlineField label="Obra" value={form.obra_id || form.obra} display={form.obra || ''} type="select" readOnly={readOnly}
                  onCommit={(v) => { const obra = obras.find((o) => o.id === v); setForm((p) => ({ ...p, obra: obra?.nome || '', obra_id: v })); }}
                  options={obras.map((o) => <SelectItem key={o.id} value={o.id}>{o.nome}</SelectItem>)} />
                <InlineField label="Tipo de receita" value={form.tipo} display={form.tipo || ''} type="select" readOnly={readOnly}
                  onCommit={(v) => set('tipo', v)}
                  options={TIPOS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)} />
                <InlineField label="Forma de Pagamento" value={form.forma_recebimento} display={form.forma_recebimento || ''} type="select" readOnly={readOnly}
                  onCommit={(v) => set('forma_recebimento', v)}
                  options={FORMAS.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)} />
                <InlineField label="Data Venda" value={form.data_emissao} display={fmtDate(form.data_emissao)} type="text" inputType="date" readOnly={readOnly} onCommit={(v) => set('data_emissao', v)} />
                <InlineField label="Observação" value={form.observacoes} type="textarea" readOnly={readOnly} onCommit={(v) => set('observacoes', v)} />
              </div>
            </Card>

            {/* Parcelamento */}
            {parcelado ? (
            <Card title="Parcelamento">
              <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                <InlineField label="Quantidade" value={form.total_parcelas} type="text" inputType="number" readOnly={readOnly} onCommit={(v) => set('total_parcelas', v)} />
                <InlineField label="Parcela atual" value={form.parcela_atual} type="text" inputType="number" readOnly={readOnly} onCommit={(v) => set('parcela_atual', v)} />
                <InlineField label="Valor da parcela" value={form.valor_parcela} display={fmtMoney(form.valor_parcela)} type="text" inputType="number" readOnly={readOnly} onCommit={(v) => set('valor_parcela', v)} />
                <InlineField label="Vencimento (parcela)" value={form.data_prevista} display={fmtDate(form.data_prevista)} type="text" inputType="date" readOnly={readOnly} onCommit={(v) => set('data_prevista', v)} />
                <div className="py-1.5"><div className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">Primeiro vencimento</div><div className="text-sm mt-0.5 text-slate-700">{fmtDate(primeiroVenc)}</div></div>
                <div className="py-1.5"><div className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">Data de recebimento</div><div className="text-sm mt-0.5 text-slate-700">{fmtDate(form.data_recebimento)}</div></div>
              </div>
            </Card>
            ) : (
            <Card title="Pagamento à vista">
              <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                <InlineField label="Valor total" value={form.valor} display={fmtMoney(form.valor)} type="text" inputType="number" readOnly={readOnly} onCommit={(v) => set('valor', v)} />
                <InlineField label="Vencimento" value={form.data_prevista} display={fmtDate(form.data_prevista)} type="text" inputType="date" readOnly={readOnly} onCommit={(v) => set('data_prevista', v)} />
                <div className="py-1.5"><div className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">Data de recebimento</div><div className="text-sm mt-0.5 text-slate-700">{fmtDate(form.data_recebimento)}</div></div>
              </div>
            </Card>
            )}
          </div>

          {/* Recebimentos (cronograma) */}
          <Card title="Recebimentos" action={!readOnly && !isRecebida(form) && (
            <Button size="sm" onClick={registrarRecebimento} className="bg-emerald-600 hover:bg-emerald-700 h-8"><CheckCircle2 className="w-3.5 h-3.5" />Registrar recebimento</Button>
          )}>
            {parcelado ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-xs uppercase text-slate-500 bg-slate-50"><tr>
                    <th className="text-left px-3 py-2">Parcela</th><th className="text-left px-3 py-2">Vencimento</th>
                    <th className="text-right px-3 py-2">Valor</th><th className="text-left px-3 py-2">Status</th>
                  </tr></thead>
                  <tbody className="divide-y divide-slate-100">
                    {schedule.map((p) => (
                      <tr key={p.k} className={p.k === parcelaAtual ? 'bg-emerald-50/50' : ''}>
                        <td className="px-3 py-2 font-medium text-[#0b2545]">{p.k}/{N}{p.k === parcelaAtual && <span className="ml-1 text-[10px] text-emerald-700">(atual)</span>}</td>
                        <td className="px-3 py-2 text-slate-600"><CalendarClock className="w-3.5 h-3.5 inline mr-1 text-slate-400" />{fmtDate(p.venc)}</td>
                        <td className="px-3 py-2 text-right font-semibold text-slate-700">{fmtMoney(p.valor)}</td>
                        <td className="px-3 py-2"><span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${ST[p.status] || 'bg-slate-100 text-slate-500'}`}>{p.status}</span></td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot><tr className="border-t border-slate-200"><td className="px-3 py-2 font-semibold text-slate-500" colSpan={2}>Total</td><td className="px-3 py-2 text-right font-bold text-[#0b2545]">{fmtMoney(parcelasArr.reduce((s, v) => s + v, 0))}</td><td /></tr></tfoot>
                </table>
                <p className="text-[11px] text-slate-400 mt-2">Soma das parcelas = valor total. Cada parcela é um registro próprio no Contas a Receber.</p>
              </div>
            ) : (
              <div className="flex items-center justify-between py-2">
                <div className="text-sm text-slate-600">À vista — vencimento {fmtDate(form.data_prevista)} · {fmtMoney(valorCompetencia)}</div>
                {!readOnly && !isRecebida(form) && <Button size="sm" onClick={registrarRecebimento} className="bg-emerald-600 hover:bg-emerald-700 h-8"><CheckCircle2 className="w-3.5 h-3.5" />Registrar recebimento</Button>}
              </div>
            )}
          </Card>

          {/* Documentos */}
          <Card title="Documentos" action={!readOnly && (
            <div className="flex items-center gap-2">
              <Select value={novoTipo} onValueChange={setNovoTipo}>
                <SelectTrigger className="h-8 w-[140px] text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>{TIPOS_ANEXO.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
              <Button size="sm" variant="outline" onClick={() => fileRef.current?.click()} disabled={uploading} className="h-8">
                {uploading ? <><Upload className="w-3.5 h-3.5" />Enviando…</> : <><Plus className="w-3.5 h-3.5" />Adicionar</>}
              </Button>
              <input ref={fileRef} type="file" className="hidden" onChange={(e) => e.target.files?.[0] && addAnexo(e.target.files[0])} />
            </div>
          )}>
            {anexos.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-4">Nenhum documento. {podeEditar && 'Toque em "Adicionar".'}</p>
            ) : (
              <div className="space-y-2">
                {anexos.map((a, i) => (
                  <div key={i} className="flex items-center gap-3 p-2 rounded-lg border border-slate-200 bg-slate-50/60">
                    {AnexoIcon(a.tipo)}
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium text-slate-700 truncate">{a.nome}</div>
                      <div className="text-[11px] text-slate-500">{a.tipo} · {new Date(a.data).toLocaleDateString('pt-BR')}</div>
                    </div>
                    <a href={a.url} target="_blank" rel="noreferrer" className="text-xs text-[#0b2545] font-medium hover:underline">Abrir</a>
                    {!readOnly && <button onClick={() => removeAnexo(i)} className="p-1 text-slate-400 hover:text-rose-500"><Trash2 className="w-4 h-4" /></button>}
                  </div>
                ))}
              </div>
            )}
          </Card>

          {/* Histórico */}
          <Card title="Histórico">
            {hist.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-4">Sem alterações registradas.</p>
            ) : (
              <div className="space-y-1.5">
                {hist.slice().reverse().map((h, i) => {
                  const dt = new Date(h.data_hora);
                  return (
                    <div key={i} className="flex items-start gap-3 text-sm py-1 border-b border-slate-50 last:border-0">
                      <div className="w-20 shrink-0 text-xs font-bold text-[#0b2545] uppercase truncate">{h.usuario || '—'}</div>
                      <div className="text-xs text-slate-400 w-36 shrink-0">{dt.toLocaleDateString('pt-BR')} {dt.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                      <div className="min-w-0 flex-1">
                        <span className="text-slate-500">{h.campo}: </span>
                        <span className="text-slate-400 line-through">{h.anterior}</span> <span className="text-slate-400">→</span> <span className="text-slate-700 font-medium">{h.novo}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>

        {/* Rodapé */}
        <div className="px-6 py-3 border-t border-slate-200 bg-white flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-500">{dirty ? 'Você tem alterações não salvas.' : 'Alterações salvas.'}</div>
          <div className="flex items-center gap-2">
            {podeExcluir && <Button variant="destructive" onClick={excluir} className="min-h-[44px]"><Trash2 className="w-4 h-4 mr-1" />Excluir</Button>}
            {!readOnly && <Button onClick={salvar} disabled={saving || !dirty} className="bg-emerald-600 hover:bg-emerald-700 min-h-[44px]"><Save className="w-4 h-4 mr-1" />{saving ? 'Salvando…' : 'Salvar alterações'}</Button>}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}