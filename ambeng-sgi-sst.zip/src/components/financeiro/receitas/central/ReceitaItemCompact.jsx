import React from 'react';
import { fmtMoney, shortDate, valorMes, parcelaLabel } from '@/lib/financeiro';
import { isRecebida, isAtrasada } from '@/lib/receitasCentral';
import { tipoMeta, formaMeta } from '../icons';
import { CheckCircle2, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ST_BADGE = { Recebida: 'bg-emerald-100 text-emerald-700', Prevista: 'bg-amber-100 text-amber-700', Atrasada: 'bg-red-100 text-red-700' };
const stOf = (r) => (isRecebida(r) ? 'Recebida' : isAtrasada(r) ? 'Atrasada' : 'Prevista');

export default function ReceitaItemCompact({ r, onOpen, onMarkReceived, podeEditar }) {
  const tipo = tipoMeta(r.tipo);
  const forma = formaMeta(r.forma_recebimento);
  const st = stOf(r);
  const parcelado = Number(r.total_parcelas) > 1;
  const parcela = parcelaLabel(r);
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-3.5 hover:shadow-card-hover transition cursor-pointer" onClick={() => onOpen(r)}>
      <div className="flex items-start gap-3">
        <span className={`shrink-0 w-9 h-9 rounded-lg flex items-center justify-center ${tipo.bg}`}><tipo.Icon className={`w-4 h-4 ${tipo.color}`} /></span>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="font-semibold text-[#0b2545] truncate">{r.descricao || 'Não informado'}</p>
              <p className="text-xs text-slate-500 truncate">{r.cliente || '—'}{r.obra ? ` · ${r.obra}` : ''}{r.tipo ? ` · ${r.tipo}` : ''}</p>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold text-emerald-700 whitespace-nowrap">{fmtMoney(valorMes(r))}</p>
              {parcelado && <p className="text-[11px] text-slate-400 -mt-0.5">Total: {fmtMoney(r.valor)}</p>}
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs mt-2">
            <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${ST_BADGE[st]}`}>{st}</span>
            {r.forma_recebimento && <span className="text-slate-400 inline-flex items-center gap-1"><forma.Icon className="w-3.5 h-3.5" />{forma.label}</span>}
            {r.data_prevista && <span className="text-slate-400">Prev.: {shortDate(r.data_prevista)}</span>}
            {r.data_recebimento && <span className="text-emerald-600">Recebido: {shortDate(r.data_recebimento)}</span>}
            {parcelado && <span className="text-slate-400">{r.parcela_atual || 0}/{r.total_parcelas}x</span>}
            {r.status_aprovacao && <span className="text-amber-600">{r.status_aprovacao}</span>}
            {podeEditar && ['Prevista', 'A receber'].includes(r.status) && <Button type="button" size="sm" variant="outline" className="ml-auto min-h-9 text-emerald-700" onClick={(event) => { event.stopPropagation(); onMarkReceived(r); }}><CheckCircle2 className="h-4 w-4" />Marcar como recebida</Button>}
          </div>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-300 shrink-0 mt-1" />
      </div>
    </div>
  );
}