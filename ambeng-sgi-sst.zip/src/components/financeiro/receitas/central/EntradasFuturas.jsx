import React from 'react';
import { fmtMoney } from '@/lib/financeiro';
import { entradasFuturas } from '@/lib/receitasCentral';

export default function EntradasFuturas({ items, onPeriod }) {
  const e = entradasFuturas(items);
  const rows = [
    { key: 'd7', label: 'Próximos 7 dias' },
    { key: 'd15', label: 'Próximos 15 dias' },
    { key: 'd30', label: 'Próximos 30 dias' },
    { key: 'd60', label: 'Próximos 60 dias' },
    { key: 'd90', label: 'Próximos 90 dias' },
  ];
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <h3 className="font-semibold text-[#0b2545] mb-3">Entradas Futuras</h3>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {rows.map((r) => (
          <button key={r.key} onClick={() => onPeriod(r.key)} className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-left hover:shadow-card-hover transition">
            <p className="text-xs text-emerald-700">{r.label}</p>
            <p className="text-base font-bold text-emerald-700 mt-1">{fmtMoney(e[r.key])}</p>
          </button>
        ))}
      </div>
    </div>
  );
}