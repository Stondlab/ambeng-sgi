import React from 'react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X } from 'lucide-react';

const TIPOS = ['Contrato', 'Medição', 'Reembolso', 'Adiantamento'];
const MESES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

export default function FiltrosReceitas({ filtros, setFiltros, obras, onClear, obraGlobal, setObraGlobal }) {
  const set = (k, v) => setFiltros((p) => ({ ...p, [k]: v }));
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Filtros</p>
        <button onClick={onClear} className="text-xs text-slate-400 hover:text-red-500 inline-flex items-center gap-1"><X className="w-3.5 h-3.5" />Limpar</button>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div>
          <Label>Status</Label>
          <Select value={filtros.status} onValueChange={(v) => set('status', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todos</SelectItem><SelectItem value="Recebida">Recebido</SelectItem><SelectItem value="Prevista">Previsto</SelectItem></SelectContent></Select>
        </div>
        <div>
          <Label>Tipo</Label>
          <Select value={filtros.tipo} onValueChange={(v) => set('tipo', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todos</SelectItem>{TIPOS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select>
        </div>
        <div>
          <Label>Obra</Label>
          <Select value={obraGlobal} onValueChange={setObraGlobal}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="geral">Todas</SelectItem>{obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}</SelectContent></Select>
        </div>
        <div>
          <Label>Mês (previsão)</Label>
          <Select value={filtros.mes} onValueChange={(v) => set('mes', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todos</SelectItem>{MESES.map((m, i) => <SelectItem key={i + 1} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent></Select>
        </div>
      </div>
    </div>
  );
}