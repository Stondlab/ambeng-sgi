import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { fmtMoney, valorMes } from '@/lib/financeiro';
import { BarChart3 } from 'lucide-react';

export default function GastosPorObra({ despesas }) {
  const data = useMemo(() => {
    const map = {};
    despesas.forEach((d) => { const k = d.obra || 'Sem obra'; map[k] = (map[k] || 0) + valorMes(d); });
    return Object.entries(map).map(([obra, valor]) => ({ obra, valor })).sort((a, b) => b.valor - a.valor).slice(0, 8);
  }, [despesas]);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><BarChart3 className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Gastos por Obra</h3></div>
      {data.length === 0 ? (
        <p className="text-sm text-slate-400">Sem dados de despesas.</p>
      ) : (
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={data} margin={{ top: 8, right: 8, left: 8, bottom: 8 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eef2f7" />
            <XAxis dataKey="obra" tick={{ fontSize: 11, fill: '#64748b' }} interval={0} angle={-15} textAnchor="end" height={64} />
            <YAxis tick={{ fontSize: 11, fill: '#64748b' }} tickFormatter={(v) => `R$ ${(v / 1000).toFixed(0)}k`} />
            <Tooltip formatter={(v) => fmtMoney(v)} contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 12 }} />
            <Bar dataKey="valor" fill="#0b2545" radius={[6, 6, 0, 0]} maxBarSize={48} />
          </BarChart>
        </ResponsiveContainer>
      )}
    </section>
  );
}