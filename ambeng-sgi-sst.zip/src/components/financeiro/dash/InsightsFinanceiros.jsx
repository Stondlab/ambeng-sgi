import React, { useMemo } from 'react';
import { geraInsights } from '@/lib/financeiroCockpit';
import { Lightbulb } from 'lucide-react';

export default function InsightsFinanceiros({ despesas, receitas, obras, vencimentos30 = null }) {
  const insights = useMemo(() => geraInsights(despesas, receitas, obras, vencimentos30), [despesas, receitas, obras, vencimentos30]);
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><Lightbulb className="w-4 h-4 text-amber-500" /><h3 className="font-semibold text-[#0b2545]">Insights Financeiros</h3></div>
      <ul className="space-y-2">
        {insights.map((t, i) => (
          <li key={i} className="flex items-start gap-2 text-sm text-slate-700">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 shrink-0" />
            {t}
          </li>
        ))}
      </ul>
    </section>
  );
}