import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { calculaKpis, proximosVencimentos } from '@/lib/financeiroCockpit';
import { useFiltrosFinanceiro } from '@/lib/FiltrosFinanceiroContext';
import VisaoFinanceira from './VisaoFinanceira';
import SaudeFinanceira from './SaudeFinanceira';
import FluxoCaixa from './FluxoCaixa';
import ProximosVencimentos30 from './ProximosVencimentos30';
import AlertasFinanceiros from './AlertasFinanceiros';
import InsightsFinanceiros from './InsightsFinanceiros';

export default function CockpitCFO({ despesas, receitas, podeVerReceita }) {
  const { obra, obrasPeriodo, range, filtraObra } = useFiltrosFinanceiro();
  const navigate = useNavigate();
  const d = filtraObra(despesas);
  const r = filtraObra(receitas);
  const obrasF = obra === 'geral' ? obrasPeriodo : obrasPeriodo.filter((o) => o.nome === obra);
  const kpis = useMemo(() => calculaKpis(d, r, range), [d, r, range]);
  const vencimentos30 = useMemo(() => proximosVencimentos(d, r, 30), [d, r]);

  return (
    <div className="space-y-5">
      <VisaoFinanceira kpis={kpis} podeVerReceita={podeVerReceita} onNavigate={navigate} />
      <SaudeFinanceira despesas={d} receitas={r} />
      <FluxoCaixa despesas={d} receitas={r} />
      <ProximosVencimentos30 despesas={d} receitas={r} podeVerReceita={podeVerReceita} resultado={vencimentos30} />
      <AlertasFinanceiros despesas={d} receitas={r} obras={obrasF} />
      <InsightsFinanceiros despesas={d} receitas={r} obras={obrasF} vencimentos30={vencimentos30} />
    </div>
  );
}