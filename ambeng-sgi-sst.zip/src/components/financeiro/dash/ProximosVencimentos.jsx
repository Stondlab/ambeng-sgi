import React from 'react';
import { fmtMoney, diffDays, shortDate, valorMes, descricaoParcela } from '@/lib/financeiro';
import { CalendarClock } from 'lucide-react';

export default function ProximosVencimentos({ despesas }) {
  // Somente parcelas futuras, não pagas, não canceladas (spec §10).
  // Atrasadas permanecem em "Despesas Atrasadas".
  const prox = despesas
    .filter((d) => d.status !== 'Pago' && d.status_aprovacao !== 'Cancelada' && d.data_vencimento)
    .map((d) => ({ ...d, dd: diffDays(d.data_vencimento) }))
    .filter((d) => d.dd >= 0)
    .sort((a, b) => new Date(a.data_vencimento) - new Date(b.data_vencimento))
    .slice(0, 6);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><CalendarClock className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Próximos Vencimentos</h3></div>
      {prox.length === 0 ? (
        <p className="text-sm text-slate-400">Nenhum vencimento pendente.</p>
      ) : (
        <div className="divide-y divide-slate-100">
          {prox.map((d) => (
            <div key={d.id} className="py-2.5 flex items-center gap-3">
              <div className="text-center w-12 shrink-0">
                <p className="text-xs font-semibold text-[#0b2545]">{shortDate(d.data_vencimento)}</p>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-[#0b2545] truncate">{descricaoParcela(d)}</p>
                <p className="text-xs text-slate-400">{d.fornecedor || d.obra || '—'}</p>
              </div>
              <span className={`text-xs font-medium whitespace-nowrap ${d.dd <= 7 ? 'text-amber-600' : 'text-slate-400'}`}>{d.dd === 0 ? 'Hoje' : `em ${d.dd}d`}</span>
              <span className="text-sm font-semibold text-[#0b2545] w-28 text-right">{fmtMoney(valorMes(d))}</span>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}