import React, { useMemo } from 'react';
import { calculaAlertas } from '@/lib/financeiroCockpit';
import { AlertTriangle, Info, CheckCircle2 } from 'lucide-react';

const META = {
  risco: { Icon: AlertTriangle, cls: 'border-red-200 bg-red-50 text-red-700', ic: 'text-red-500' },
  atencao: { Icon: AlertTriangle, cls: 'border-amber-200 bg-amber-50 text-amber-700', ic: 'text-amber-500' },
  ok: { Icon: CheckCircle2, cls: 'border-emerald-200 bg-emerald-50 text-emerald-700', ic: 'text-emerald-500' },
};

export default function AlertasFinanceiros({ despesas, receitas, obras }) {
  const alertas = useMemo(() => calculaAlertas(despesas, receitas, obras), [despesas, receitas, obras]);
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><Info className="w-4 h-4 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Alertas</h3></div>
      <div className="space-y-2">
        {alertas.map((a, i) => {
          const m = META[a.tipo] || META.ok;
          const Icon = m.Icon;
          return (
            <div key={i} className={`flex items-start gap-2 rounded-lg border px-3 py-2 ${m.cls}`}>
              <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${m.ic}`} />
              <div className="text-sm"><span className="font-medium">{a.titulo}</span><span className="opacity-80"> — {a.detalhe}</span></div>
            </div>
          );
        })}
      </div>
    </section>
  );
}