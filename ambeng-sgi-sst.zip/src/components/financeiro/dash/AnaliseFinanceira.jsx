import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { fmtMoney, bucketCat, CATEGORIAS, STATUS_OBRA, valorMes } from '@/lib/financeiro';
import { PieChart as PieIcon, TrendingUp } from 'lucide-react';

const CAT_HEX = { 'Material': '#3b82f6', 'Mão de Obra': '#10b981', 'Serviço': '#f59e0b', 'ADM': '#8b5cf6', 'Outros': '#94a3b8' };
const ST_HEX = { 'Planejamento': '#94a3b8', 'Em andamento': '#3b82f6', 'Pausada': '#f59e0b', 'Concluída': '#10b981' };

export default function AnaliseFinanceira({ despesas, receitas, obras, podeVerReceita = true }) {
  const catData = useMemo(() => {
    const map = {}; const total = despesas.reduce((s, d) => s + valorMes(d), 0);
    CATEGORIAS.forEach((c) => { map[c] = 0; });
    despesas.forEach((d) => { map[bucketCat(d.categoria)] += valorMes(d); });
    return CATEGORIAS.map((c) => ({ name: c, value: map[c], pct: total > 0 ? (map[c] / total * 100) : 0 })).filter((x) => x.value > 0);
  }, [despesas]);

  const porObra = useMemo(() => {
    const set = new Set([...obras.map((o) => o.nome), ...despesas.map((d) => d.obra), ...receitas.map((r) => r.obra)].filter(Boolean));
    return [...set].map((nome) => {
      const desp = despesas.filter((d) => d.obra === nome).reduce((s, d) => s + valorMes(d), 0);
      const rec = receitas.filter((r) => r.obra === nome).reduce((s, r) => s + (Number(r.valor) || 0), 0);
      return { nome, desp, rec, lucro: rec - desp };
    }).filter((x) => x.desp > 0 || x.rec > 0);
  }, [despesas, receitas, obras]);

  const statusCount = useMemo(() => {
    const cnt = { 'Planejamento': 0, 'Em andamento': 0, 'Pausada': 0, 'Concluída': 0 };
    obras.forEach((o) => { if (o.status in cnt) cnt[o.status]++; });
    return cnt;
  }, [obras]);
  const totalObras = obras.length || 1;

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><PieIcon className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Análise Financeira</h3></div>
      <div className="grid lg:grid-cols-2 gap-6">
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-3">Gastos por Categoria (%)</h4>
          {catData.length === 0 ? <p className="text-sm text-slate-400">Sem dados.</p> : (
            <div className="flex items-center gap-4">
              <ResponsiveContainer width={160} height={160}>
                <PieChart>
                  <Pie data={catData} dataKey="value" nameKey="name" innerRadius={42} outerRadius={70} paddingAngle={2}>
                    {catData.map((e, i) => <Cell key={i} fill={CAT_HEX[e.name]} />)}
                  </Pie>
                  <Tooltip formatter={(v) => fmtMoney(v)} contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1.5 flex-1">
                {catData.map((c) => (
                  <div key={c.name} className="flex items-center gap-2 text-sm">
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: CAT_HEX[c.name] }} />
                    <span className="flex-1 text-slate-600">{c.name}</span>
                    <span className="font-medium text-[#0b2545]">{c.pct.toFixed(1)}%</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-3">Status das Obras</h4>
          {obras.length === 0 ? <p className="text-sm text-slate-400">Nenhuma obra cadastrada.</p> : (
            <div className="space-y-2.5">
              {STATUS_OBRA.map((s) => {
                const cnt = statusCount[s]; const pct = (cnt / totalObras) * 100;
                return (
                  <div key={s}>
                    <div className="flex justify-between text-sm mb-1"><span className="text-slate-600">{s}</span><span className="font-medium text-[#0b2545]">{cnt} ({pct.toFixed(0)}%)</span></div>
                    <div className="h-2 rounded-full bg-slate-100 overflow-hidden"><div className="h-full" style={{ width: `${pct}%`, background: ST_HEX[s] }} /></div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="lg:col-span-2">
          <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-3 flex items-center gap-1"><TrendingUp className="w-3.5 h-3.5" />{podeVerReceita ? 'Receitas vs Despesas por Obra' : 'Despesas por Obra'}</h4>
          {porObra.length === 0 ? <p className="text-sm text-slate-400">Sem dados.</p> : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-xs uppercase text-slate-500 bg-slate-50"><tr><th className="text-left px-3 py-2">Obra</th>{podeVerReceita && <th className="text-right px-3 py-2">Receitas</th>}<th className="text-right px-3 py-2">Despesas</th>{podeVerReceita && <th className="text-right px-3 py-2">Lucro</th>}</tr></thead>
                <tbody className="divide-y divide-slate-100">
                  {porObra.map((o) => (
                    <tr key={o.nome}>
                      <td className="px-3 py-2.5 font-medium text-[#0b2545]">{o.nome}</td>
                      {podeVerReceita && <td className="px-3 py-2.5 text-right text-emerald-700">{fmtMoney(o.rec)}</td>}
                      <td className="px-3 py-2.5 text-right text-red-600">{fmtMoney(o.desp)}</td>
                      {podeVerReceita && <td className={`px-3 py-2.5 text-right font-semibold ${o.lucro >= 0 ? 'text-emerald-700' : 'text-red-600'}`}>{fmtMoney(o.lucro)}</td>}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}