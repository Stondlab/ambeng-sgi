import React from 'react';
import { fmt, fmtMoney, nextFaturaDate, valorMes } from '@/lib/financeiro';
import { CreditCard } from 'lucide-react';

export default function FaturasCartoes({ cartoes, despesas }) {
  const credito = cartoes.filter((c) => (c.tipo || '').toLowerCase().includes('crédito') || (c.tipo || '').toLowerCase().includes('credito'));
  if (!credito.length) return null;
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><CreditCard className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Faturas dos Cartões</h3></div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {credito.map((c) => {
          const itens = despesas.filter((d) => d.cartao && d.cartao === c.nome);
          const valor = itens.reduce((s, d) => s + valorMes(d), 0);
          const venc = nextFaturaDate(c.dia_vencimento || 1);
          return (
            <div key={c.id} className="rounded-xl border border-slate-200 p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="font-semibold text-[#0b2545] truncate">{c.nome}</p>
                <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded whitespace-nowrap">{c.bandeira || c.banco || c.tipo}</span>
              </div>
              <p className="text-xs text-slate-400">{itens.length} despesa(s) neste cartão</p>
              <div className="flex items-end justify-between mt-2">
                <div><p className="text-xs text-slate-400">Próx. fatura</p><p className="text-lg font-bold text-[#0b2545]">{fmtMoney(valor)}</p></div>
                <div className="text-right"><p className="text-xs text-slate-400">Vencimento</p><p className="text-sm font-medium text-slate-700">{fmt(venc)}</p></div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}