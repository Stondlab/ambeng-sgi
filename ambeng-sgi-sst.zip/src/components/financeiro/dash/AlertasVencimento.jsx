import React from 'react';
import { fmt, fmtMoney, diffDays } from '@/lib/financeiro';
import { AlertTriangle } from 'lucide-react';

const DOT = { red: 'bg-red-500', amber: 'bg-amber-500', green: 'bg-emerald-500' };
const TXT = { red: 'text-red-700', amber: 'text-amber-700', green: 'text-emerald-700' };

function Grupo({ itens, titulo, tone, suffix }) {
  if (!itens.length) return null;
  return (
    <div className="mb-4 last:mb-0">
      <div className="flex items-center gap-2 mb-1.5">
        <span className={`w-2.5 h-2.5 rounded-full ${DOT[tone]}`} />
        <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500">{titulo} ({itens.length})</h4>
      </div>
      <div className="divide-y divide-slate-100">
        {itens.map((d) => (
          <div key={d.id} className="py-2.5 flex items-center gap-3">
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-[#0b2545] truncate">{d.descricao}</p>
              <p className="text-xs text-slate-400">{d.fornecedor ? `${d.fornecedor} · ` : ''}Venc.: {fmt(d.data_vencimento)}</p>
            </div>
            <span className={`text-xs font-medium whitespace-nowrap ${TXT[tone]}`}>{suffix(d.dd)}</span>
            <span className="text-sm font-semibold text-[#0b2545] w-28 text-right">{fmtMoney(d.valor)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function AlertasVencimento({ despesas }) {
  const pend = despesas
    .filter((d) => d.status !== 'Pago' && d.data_vencimento)
    .map((d) => ({ ...d, dd: diffDays(d.data_vencimento) }))
    .sort((a, b) => new Date(a.data_vencimento) - new Date(b.data_vencimento));

  const atrasadas = pend.filter((d) => d.dd < 0);
  const hoje = pend.filter((d) => d.dd === 0);
  const aVencer = pend.filter((d) => d.dd > 0);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <AlertTriangle className="w-5 h-5 text-amber-500" />
        <h3 className="font-semibold text-[#0b2545]">Alertas de Vencimento</h3>
      </div>
      {pend.length === 0 ? (
        <p className="text-sm text-slate-400">Nenhuma despesa pendente. Tudo em dia!</p>
      ) : (
        <>
          <Grupo itens={atrasadas} titulo="Atrasadas" tone="red" suffix={(dd) => `${Math.abs(dd)} dia(s) em atraso`} />
          <Grupo itens={hoje} titulo="Vencendo hoje" tone="amber" suffix={() => 'Hoje'} />
          <Grupo itens={aVencer} titulo="A vencer" tone="green" suffix={(dd) => `em ${dd} dia(s)`} />
        </>
      )}
    </section>
  );
}