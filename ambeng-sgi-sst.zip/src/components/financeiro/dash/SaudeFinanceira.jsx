import React, { useMemo } from 'react';
import { calculaSaude } from '@/lib/financeiroCockpit';

const cor = (v) => (v >= 75 ? 'bg-emerald-500' : v >= 50 ? 'bg-amber-500' : 'bg-red-500');

export default function SaudeFinanceira({ despesas, receitas }) {
  const saude = useMemo(() => calculaSaude(despesas, receitas), [despesas, receitas]);
  const corScore = cor(saude.score);
  const label = saude.score >= 75 ? 'Saudável' : saude.score >= 50 ? 'Atenção' : 'Risco';

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><h3 className="font-semibold text-[#0b2545]">Saúde Financeira</h3></div>
      <div className="flex flex-col sm:flex-row items-center gap-6">
        <div className="text-center shrink-0">
          <div className={`w-28 h-28 rounded-full flex items-center justify-center ${corScore} text-white`}>
            <span className="text-4xl font-bold leading-none">{saude.score}</span>
          </div>
          <p className="text-sm font-medium text-slate-600 mt-2">{label}</p>
        </div>
        <div className="flex-1 w-full space-y-2.5">
          {saude.factors.map((f) => (
            <div key={f.label}>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-600">{f.label}</span>
                <span className="text-slate-400">{f.info}</span>
              </div>
              <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                <div className={`h-full ${cor(f.valor)}`} style={{ width: `${Math.max(2, f.valor)}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}