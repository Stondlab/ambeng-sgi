import React from 'react';
import { fmtMoney, bucketCat, CATEGORIAS, despesaStatus, valorMes } from '@/lib/financeiro';
import { Wallet } from 'lucide-react';

const CAT_COLOR = { 'Material': 'bg-blue-500', 'Mão de Obra': 'bg-emerald-500', 'Serviço': 'bg-amber-500', 'ADM': 'bg-violet-500', 'Outros': 'bg-slate-400' };
const ST = {
  'Pago': { c: 'text-emerald-700', bg: 'bg-emerald-500' },
  'Pendente': { c: 'text-amber-700', bg: 'bg-amber-500' },
  'Atrasado': { c: 'text-red-700', bg: 'bg-red-500' },
};

export default function VisaoGeral({ despesas }) {
  const total = despesas.reduce((s, d) => s + valorMes(d), 0);
  const porCat = {};
  despesas.forEach((d) => { const k = bucketCat(d.categoria); porCat[k] = (porCat[k] || 0) + valorMes(d); });
  const porStatus = { 'Pago': 0, 'Pendente': 0, 'Atrasado': 0 };
  const cntStatus = { 'Pago': 0, 'Pendente': 0, 'Atrasado': 0 };
  despesas.forEach((d) => { const s = despesaStatus(d); porStatus[s] += valorMes(d); cntStatus[s]++; });

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><Wallet className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Visão Geral</h3></div>
      <div className="rounded-lg bg-[#0b2545] text-white p-4 mb-5">
        <p className="text-xs opacity-70">Total Geral</p>
        <p className="text-2xl font-bold">{fmtMoney(total)}</p>
      </div>
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-3">Por Categoria</h4>
          <div className="space-y-2.5">
            {CATEGORIAS.map((cat) => {
              const v = porCat[cat] || 0; const pct = total > 0 ? (v / total * 100) : 0;
              return (
                <div key={cat}>
                  <div className="flex justify-between text-sm mb-1"><span className="text-slate-600">{cat}</span><span className="font-medium text-[#0b2545]">{fmtMoney(v)}</span></div>
                  <div className="h-2 rounded-full bg-slate-100 overflow-hidden"><div className={`h-full ${CAT_COLOR[cat]}`} style={{ width: `${pct}%` }} /></div>
                </div>
              );
            })}
          </div>
        </div>
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-3">Por Status</h4>
          <div className="space-y-2.5">
            {Object.keys(porStatus).map((s) => {
              const v = porStatus[s]; const pct = total > 0 ? (v / total * 100) : 0; const st = ST[s];
              return (
                <div key={s}>
                  <div className="flex justify-between text-sm mb-1"><span className="text-slate-600">{s} <span className="text-slate-400">({cntStatus[s]})</span></span><span className={`font-medium ${st.c}`}>{fmtMoney(v)}</span></div>
                  <div className="h-2 rounded-full bg-slate-100 overflow-hidden"><div className={`h-full ${st.bg}`} style={{ width: `${pct}%` }} /></div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}