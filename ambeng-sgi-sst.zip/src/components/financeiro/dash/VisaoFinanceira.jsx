import React from 'react';
import { fmtMoney } from '@/lib/financeiro';

const TONE = {
  navy: 'bg-[#0b2545] text-white',
  emerald: 'bg-emerald-50 border border-emerald-200 text-emerald-700',
  red: 'bg-red-50 border border-red-200 text-red-700',
  blue: 'bg-blue-50 border border-blue-200 text-blue-700',
  amber: 'bg-amber-50 border border-amber-200 text-amber-700',
};

export default function VisaoFinanceira({ kpis, podeVerReceita = true, onNavigate }) {
  const cards = [
    { label: 'Caixa Disponível', valor: kpis.caixa, tone: 'navy', to: '/financeiro' },
    podeVerReceita && { label: 'A Receber', valor: kpis.aReceber, tone: 'emerald', to: '/financeiro/receitas' },
    { label: 'A Pagar', valor: kpis.aPagar, tone: 'red', to: '/financeiro/despesas' },
    podeVerReceita && { label: 'Resultado Previsto', valor: kpis.previsto, tone: 'blue', to: '/financeiro/obras' },
    podeVerReceita && { label: 'Resultado Realizado', valor: kpis.realizado, tone: kpis.realizado >= 0 ? 'emerald' : 'red', to: '/financeiro/obras' },
    podeVerReceita && { label: 'Margem', valor: kpis.margem, percent: true, tone: kpis.margem >= 15 ? 'emerald' : 'amber', to: '/financeiro/obras' },
  ].filter(Boolean);

  return (
    <section>
      <div className="flex items-center gap-2 mb-3">
        <h3 className="font-semibold text-[#0b2545]">Visão Financeira</h3>
        <span className="text-xs text-slate-400">— clique para detalhar</span>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        {cards.map((c) => (
          <button
            key={c.label}
            onClick={() => onNavigate(c.to)}
            className={`text-left rounded-xl p-4 transition hover:shadow-card-hover ${TONE[c.tone]}`}
          >
            <p className="text-xs opacity-80">{c.label}</p>
            <p className="text-2xl font-bold mt-1 leading-none">{c.percent ? `${c.valor.toFixed(1)}%` : fmtMoney(c.valor)}</p>
          </button>
        ))}
      </div>
    </section>
  );
}