import React, { useMemo, useState } from 'react';
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { calculaFluxo } from '@/lib/financeiroCockpit';
import { fmtMoney } from '@/lib/financeiro';

const MODO = [{ id: 'realizado', label: 'Realizado' }, { id: 'projetado', label: 'Projetado' }, { id: 'ambos', label: 'Realizado + Projetado' }];

export default function FluxoCaixa({ despesas, receitas }) {
  const [modo, setModo] = useState('ambos');
  const data = useMemo(() => calculaFluxo(despesas, receitas, modo), [despesas, receitas, modo]);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <h3 className="font-semibold text-[#0b2545]">Fluxo de Caixa</h3>
        <div className="flex gap-1">
          {MODO.map((m) => (
            <button key={m.id} onClick={() => setModo(m.id)} className={`text-xs px-3 py-1.5 rounded-lg transition ${modo === m.id ? 'bg-[#0b2545] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>{m.label}</button>
          ))}
        </div>
      </div>
      <ResponsiveContainer width="100%" height={300}>
        <ComposedChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#64748b' }} />
          <YAxis tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v)} tick={{ fontSize: 11, fill: '#64748b' }} />
          <Tooltip formatter={(v) => fmtMoney(v)} contentStyle={{ borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 12 }} />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Bar dataKey="entradas" name="Entradas" fill="#10b981" radius={[4, 4, 0, 0]} />
          <Bar dataKey="saidas" name="Saídas" fill="#ef4444" radius={[4, 4, 0, 0]} />
          <Line type="monotone" dataKey="saldo" name="Saldo acumulado" stroke="#0b2545" strokeWidth={2} dot={false} />
        </ComposedChart>
      </ResponsiveContainer>
    </section>
  );
}