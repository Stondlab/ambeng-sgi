import React, { useMemo } from 'react';
import { proximosVencimentos } from '@/lib/financeiroCockpit';
import { fmtMoney, shortDate } from '@/lib/financeiro';
import { AlertTriangle } from 'lucide-react';

const ST_BADGE = { Atrasado: 'bg-red-100 text-red-700', Pendente: 'bg-amber-100 text-amber-700', Recebido: 'bg-emerald-100 text-emerald-700' };

export default function ProximosVencimentos30({ despesas, receitas, podeVerReceita = true, resultado = null }) {
  const calculado = useMemo(() => resultado || proximosVencimentos(despesas, receitas, 30), [despesas, receitas, resultado]);
  const { items, totalEntradas, totalSaidas, saldoProj } = calculado;

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-3">Próximos 30 dias</h3>
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="bg-emerald-50 rounded-lg p-3 text-center"><p className="text-lg font-bold text-emerald-700">{fmtMoney(totalEntradas)}</p><p className="text-xs text-emerald-700">Entradas previstas</p></div>
        <div className="bg-red-50 rounded-lg p-3 text-center"><p className="text-lg font-bold text-red-700">{fmtMoney(totalSaidas)}</p><p className="text-xs text-red-700">Saídas previstas</p></div>
        <div className={`rounded-lg p-3 text-center ${saldoProj >= 0 ? 'bg-slate-50' : 'bg-red-50'}`}><p className={`text-lg font-bold ${saldoProj >= 0 ? 'text-[#0b2545]' : 'text-red-700'}`}>{fmtMoney(saldoProj)}</p><p className={`text-xs ${saldoProj >= 0 ? 'text-slate-500' : 'text-red-700'}`}>Saldo projetado</p></div>
      </div>
      <div className="overflow-x-auto max-h-80">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-500 text-xs uppercase sticky top-0">
            <tr><th className="text-left px-3 py-2">Data</th><th className="text-left px-3 py-2">Descrição</th><th className="text-left px-3 py-2">Obra</th>{podeVerReceita && <th className="text-right px-3 py-2">Entrada</th>}<th className="text-right px-3 py-2">Saída</th><th className="text-left px-3 py-2">Status</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {items.slice(0, 60).map((it, i) => {
              const atrasado = it.status === 'Atrasado';
              return (
                <tr key={i} className={atrasado ? 'bg-red-50/60' : 'hover:bg-slate-50'}>
                  <td className={`px-3 py-2 ${atrasado ? 'text-red-700 font-medium' : 'text-slate-600'}`}>{shortDate(it.data)}{atrasado && <AlertTriangle className="w-3.5 h-3.5 inline ml-1 text-red-500" />}</td>
                  <td className="px-3 py-2 text-slate-700 truncate max-w-[220px]">{it.descricao || '—'}</td>
                  <td className="px-3 py-2 text-slate-500 truncate max-w-[160px]">{it.obra || '—'}</td>
                  {podeVerReceita && <td className="px-3 py-2 text-right text-emerald-700">{it.entrada ? fmtMoney(it.entrada) : '—'}</td>}
                  <td className="px-3 py-2 text-right text-red-600">{it.saida ? fmtMoney(it.saida) : '—'}</td>
                  <td className="px-3 py-2"><span className={`text-xs px-2 py-0.5 rounded-full ${ST_BADGE[it.status] || 'bg-slate-100 text-slate-600'}`}>{it.status}</span></td>
                </tr>
              );
            })}
            {!items.length && <tr><td colSpan={podeVerReceita ? 6 : 5} className="px-3 py-8 text-center text-slate-400">Nenhum vencimento previsto.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  );
}