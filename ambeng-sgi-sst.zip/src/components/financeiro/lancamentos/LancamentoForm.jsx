import React, { useMemo, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { X, Upload, Save, Trash2 } from 'lucide-react';
import { CATEGORIAS, calcParcelas, fmtMoney, today } from '@/lib/financeiro';
import { calcVencimentoCartao, vencimentoParcela } from '@/lib/cicloCartao';
import { nomeUsuario } from '@/lib/usuarioNome';

const TIPO_DESP = ['Fixa', 'Variável', 'Eventual'];

function Field({ label, className, children, hint }) {
  return (
    <div className={className}>
      <Label className="text-xs font-semibold text-slate-600">{label}</Label>
      <div className="mt-1">{children}</div>
      {hint && <p className="text-[11px] text-slate-400 mt-1">{hint}</p>}
    </div>
  );
}

export default function LancamentoForm({ record, obras, cartoes, fornecedores, onClose, onSave }) {
  const { toast } = useToast();
  const isNew = !record.id;
  const fileRef = useRef(null);

  const [form, setForm] = useState(() => {
    const init = {};
    ['descricao', 'fornecedor', 'obra', 'categoria', 'tipo_despesa', 'forma_pagamento', 'cartao', 'observacoes', 'numero_nota_fiscal', 'status', 'anexos']
      .forEach((k) => { init[k] = record[k] ?? ''; });
    ['valor', 'total_parcelas'].forEach((k) => { init[k] = record[k] ?? ''; });
    init.data_compra = record.data_compra ?? today();
    init.data_vencimento = record.data_vencimento ?? '';
    init.tipo_pagamento = Number(record.total_parcelas) > 1 ? 'Parcelado' : 'À Vista';
    if (!init.total_parcelas) init.total_parcelas = 1;
    if (!init.status) init.status = 'Pendente';
    return init;
  });

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  // Forma de pagamento dinâmica: PIX, Boleto, Transferência, Dinheiro + cartões cadastrados
  const formasPagamento = useMemo(() => {
    const base = ['Pix', 'Boleto', 'Transferência', 'Dinheiro'];
    cartoes.forEach((c) => base.push(`Cartão: ${c.nome}`));
    return base;
  }, [cartoes]);

  const isCartao = form.forma_pagamento.startsWith('Cartão: ');
  const cartaoSelecionado = isCartao ? cartoes.find((c) => `Cartão: ${c.nome}` === form.forma_pagamento) : null;
  const isParcelado = form.tipo_pagamento === 'Parcelado';
  const totalParcNum = Math.max(1, parseInt(form.total_parcelas) || 1);
  const valorTotalNum = Number(form.valor) || 0;
  const parcelasArr = calcParcelas(valorTotalNum, totalParcNum);

  // Auto-cálculo de vencimento
  // - Cartão: calculado pelo ciclo do cartão (não editável manualmente)
  // - PIX/Boleto/Outros: editável manualmente
  const vencimentoAuto = useMemo(() => {
    if (isCartao && cartaoSelecionado && form.data_compra) {
      return calcVencimentoCartao(cartaoSelecionado, form.data_compra);
    }
    return '';
  }, [isCartao, cartaoSelecionado, form.data_compra]);

  const vencimentoFinal = isCartao ? vencimentoAuto : form.data_vencimento;

  // Anexos
  const anexos = (() => { try { return form.anexos ? JSON.parse(form.anexos) : []; } catch { return []; } })();
  const [uploading, setUploading] = useState(false);

  const addAnexo = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const arr = [...anexos, { url: file_url, nome: file.name, tipo: 'Comprovante', data: new Date().toISOString() }];
      set('anexos', JSON.stringify(arr));
      toast({ title: 'Anexo adicionado.' });
    } catch (e) { toast({ title: 'Falha no upload.', description: e?.message, variant: 'destructive' }); }
    setUploading(false);
    if (fileRef.current) fileRef.current.value = '';
  };
  const removeAnexo = (idx) => {
    const arr = anexos.filter((_, i) => i !== idx);
    set('anexos', JSON.stringify(arr));
  };

  const handleTipoPagamento = (v) => {
    set('tipo_pagamento', v);
    if (v === 'À Vista') set('total_parcelas', 1);
  };

  const submit = async () => {
    if (!form.descricao || !form.valor || !vencimentoFinal) {
      toast({ title: 'Preencha descrição, valor e vencimento.', variant: 'destructive' });
      return;
    }
    const userNome = isNew ? (await base44.auth.me().then(nomeUsuario).catch(() => '')) : '';
    const payload = {
      ...form,
      valor: Number(form.valor) || 0,
      total_parcelas: isParcelado ? totalParcNum : 1,
      parcela_atual: 1,
      valor_parcela: parcelasArr[0] || 0,
      data_vencimento: vencimentoFinal,
      data_compra: form.data_compra,
      status: form.status || 'Pendente',
      categoria: form.categoria || 'Outros',
      tipo_despesa: form.tipo_despesa || null,
      forma_pagamento: isCartao ? 'Cartão Crédito' : (form.forma_pagamento || 'Pix'),
      cartao: isCartao ? cartaoSelecionado?.nome : '',
      responsavel: userNome,
    };
    if (!payload.status_aprovacao) payload.status_aprovacao = null;

    const ok = await onSave(payload, record.id);
    if (ok) onClose();
  };

  const removeRecord = async () => {
    if (!record.id) return;
    if (!confirm('Excluir este lançamento?')) return;
    await base44.entities.Despesas.delete(record.id);
    toast({ title: 'Lançamento excluído.' });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-2xl bg-white rounded-t-2xl sm:rounded-2xl max-h-[92vh] flex flex-col">
        {/* Cabeçalho com botão X */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 shrink-0">
          <h3 className="font-semibold text-[#0b2545]">{isNew ? 'Novo Lançamento' : 'Editar Lançamento'}</h3>
          <button type="button" onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-5 h-5" /></button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
          <Field label="Obra">
            <Select value={form.obra} onValueChange={(v) => set('obra', v)}>
              <SelectTrigger className="h-11"><SelectValue placeholder="Selecione a obra" /></SelectTrigger>
              <SelectContent>{obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}</SelectContent>
            </Select>
          </Field>

          <Field label="Descrição *">
            <Input className="h-11" value={form.descricao} onChange={(e) => set('descricao', e.target.value)} placeholder="Ex: Compra de cimento" />
          </Field>

          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="Nota Fiscal (nº)">
              <Input className="h-11" value={form.numero_nota_fiscal} onChange={(e) => set('numero_nota_fiscal', e.target.value)} placeholder="000.000.000" />
            </Field>
            <Field label="Data de Compra *">
              <Input type="date" className="h-11" value={form.data_compra} onChange={(e) => set('data_compra', e.target.value)} />
            </Field>
          </div>

          <Field label="Fornecedor">
            <Input
              className="h-11"
              list="fornecedores-list"
              value={form.fornecedor}
              onChange={(e) => set('fornecedor', e.target.value)}
              placeholder="Digite ou selecione"
            />
            <datalist id="fornecedores-list">
              {fornecedores.map((f) => <option key={f} value={f} />)}
            </datalist>
          </Field>

          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="Tipo de Despesa">
              <Select value={form.tipo_despesa} onValueChange={(v) => set('tipo_despesa', v)}>
                <SelectTrigger className="h-11"><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>{TIPO_DESP.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Categoria">
              <Select value={form.categoria} onValueChange={(v) => set('categoria', v)}>
                <SelectTrigger className="h-11"><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>{CATEGORIAS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
          </div>

          <Field label="Forma de Pagamento">
            <Select value={form.forma_pagamento} onValueChange={(v) => set('forma_pagamento', v)}>
              <SelectTrigger className="h-11"><SelectValue placeholder="Selecione" /></SelectTrigger>
              <SelectContent>{formasPagamento.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent>
            </Select>
          </Field>

          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="Tipo de Pagamento">
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant={form.tipo_pagamento === 'À Vista' ? 'default' : 'outline'}
                  className="h-11 flex-1"
                  onClick={() => handleTipoPagamento('À Vista')}
                >À Vista</Button>
                <Button
                  type="button"
                  variant={form.tipo_pagamento === 'Parcelado' ? 'default' : 'outline'}
                  className="h-11 flex-1"
                  onClick={() => handleTipoPagamento('Parcelado')}
                >Parcelado</Button>
              </div>
            </Field>
            {isParcelado && (
              <Field label="Quantidade de Parcelas" hint={isCartao ? 'Calculado pelo ciclo do cartão' : ''}>
                <Input type="number" min="2" className="h-11" value={form.total_parcelas} onChange={(e) => set('total_parcelas', e.target.value)} />
              </Field>
            )}
          </div>

          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="Valor (R$) *">
              <Input type="number" step="0.01" className="h-11" value={form.valor} onChange={(e) => set('valor', e.target.value)} placeholder="0,00" />
            </Field>
            <Field
              label="Data de Vencimento *"
              hint={isCartao ? 'Auto-calculado pelo ciclo do cartão (não editável)' : 'Editável manualmente'}
            >
              <Input
                type="date"
                className="h-11"
                value={vencimentoFinal}
                readOnly={isCartao}
                onChange={(e) => set('data_vencimento', e.target.value)}
              />
            </Field>
          </div>

          {isParcelado && totalParcNum > 1 && (
            <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs text-slate-600">
              <p className="font-semibold mb-1">Resumo do parcelamento:</p>
              <p>{totalParcNum} parcelas de {fmtMoney(parcelasArr[0])} (última: {fmtMoney(parcelasArr[totalParcNum - 1])}).</p>
              <p className="mt-1">1º vencimento: {vencimentoFinal || '—'}{totalParcNum > 1 ? ` · último: ${vencimentoParcela(vencimentoFinal, totalParcNum - 1)}` : ''}</p>
              <p className="mt-1 font-medium">Total: {fmtMoney(parcelasArr.reduce((s, v) => s + v, 0))}</p>
            </div>
          )}

          <Field label="Status do Pagamento">
            <Select value={form.status} onValueChange={(v) => set('status', v)}>
              <SelectTrigger className="h-11"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Pendente">Pendente</SelectItem>
                <SelectItem value="Pago">Pago</SelectItem>
                <SelectItem value="Atrasado">Atrasado</SelectItem>
              </SelectContent>
            </Select>
          </Field>

          <Field label="Observação">
            <Textarea rows={2} value={form.observacoes} onChange={(e) => set('observacoes', e.target.value)} placeholder="Notas adicionais..." />
          </Field>

          {/* Anexos */}
          <Field label="Anexos">
            <div className="flex items-center gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => fileRef.current?.click()} disabled={uploading} className="h-9">
                {uploading ? <><Upload className="w-3.5 h-3.5" />Enviando…</> : <><Upload className="w-3.5 h-3.5" />Adicionar arquivo</>}
              </Button>
              <input ref={fileRef} type="file" className="hidden" onChange={(e) => e.target.files?.[0] && addAnexo(e.target.files[0])} />
            </div>
            {anexos.length > 0 && (
              <div className="mt-2 space-y-1.5">
                {anexos.map((a, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5">
                    <a href={a.url} target="_blank" rel="noreferrer" className="text-[#0b2545] font-medium hover:underline truncate flex-1">{a.nome}</a>
                    <button type="button" onClick={() => removeAnexo(i)} className="text-slate-400 hover:text-red-500 p-1"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                ))}
              </div>
            )}
          </Field>
        </div>

        {/* Rodapé */}
        <div className="flex items-center justify-between gap-2 px-5 py-3 border-t border-slate-200 shrink-0">
          {!isNew ? (
            <Button type="button" variant="ghost" onClick={removeRecord} className="text-red-600 hover:bg-red-50"><Trash2 className="w-4 h-4 mr-1" />Excluir</Button>
          ) : <span />}
          <div className="flex gap-2">
            <Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button>
            <Button type="button" onClick={submit} className="bg-[#0b2545] hover:bg-[#16365f]"><Save className="w-4 h-4 mr-1" />Salvar</Button>
          </div>
        </div>
      </div>
    </div>
  );
}