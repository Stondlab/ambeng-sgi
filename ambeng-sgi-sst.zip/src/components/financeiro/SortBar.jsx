import React from 'react';
import { ArrowUp, ArrowDown, ArrowUpDown } from 'lucide-react';

/**
 * Sortable column header bar for card-based lists.
 * columns: [{ key, label, flex }]
 */
export default function SortBar({ columns, sortField, sortDir, onSort }) {
  return (
    <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs uppercase tracking-wide text-slate-500">
      {columns.map((col) => {
        const active = sortField === col.key;
        return (
          <button
            key={col.key}
            onClick={() => onSort(col.key)}
            className={`inline-flex items-center gap-1 px-2 py-1 rounded transition hover:text-[#0b2545] ${active ? 'text-[#0b2545] font-semibold' : ''} ${col.flex ? 'flex-1' : ''}`}
          >
            {col.label}
            {active
              ? (sortDir === 'asc'
                  ? <ArrowUp className="w-3 h-3" />
                  : <ArrowDown className="w-3 h-3" />)
              : <ArrowUpDown className="w-3 h-3 text-slate-300" />}
          </button>
        );
      })}
    </div>
  );
}