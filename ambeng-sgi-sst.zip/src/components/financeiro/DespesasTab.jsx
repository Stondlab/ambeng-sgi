import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { usePerm } from '@/hooks/usePerm';
import { useFiltrosFinanceiro } from '@/lib/FiltrosFinanceiroContext';
import DespesasCentral from './despesas/central/DespesasCentral';
import { useToast } from '@/components/ui/use-toast';
import { calcParcelas, addMeses, normalizarDespesa } from '@/lib/financeiro';
import { vencimentoParcela } from '@/lib/cicloCartao';
import { mensagemAmigavelErro } from '@/lib/validacao';

export default function DespesasTab() {
  const { podeCriar, podeEditar, podeExcluir } = usePerm('fin_despesas');
  const { obrasPeriodo, obrasAtivas, cartoes } = useFiltrosFinanceiro();
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [fornecedores, setFornecedores] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    let d = [];
    try { d = await base44.entities.Despesas.list('-created_date', 3000); } catch {}
    setItems(d.map(normalizarDespesa));
    setLoading(false);
  };
  const prepararFormulario = async () => {
    if (fornecedores.length) return;
    try { setFornecedores(await base44.entities.Fornecedores.list('nome', 500)); } catch {}
  };
  useEffect(() => { load(); }, []);

  const save = async (form, id) => {
    const text = (value) => typeof value === 'string' && value.trim() ? value.trim() : null;
    const number = (value) => value === '' || value == null || Number.isNaN(Number(value)) ? null : Number(value);
    const stringFields = ['descricao', 'fornecedor', 'categoria', 'status', 'status_aprovacao', 'responsavel', 'forma_pagamento', 'cartao', 'obra', 'observacoes', 'data_compra', 'data_vencimento', 'data_pagamento', 'data_aprovacao', 'anexos', 'historico', 'fornecedor_id', 'cartao_id', 'obra_id', 'tipo_pagamento', 'tipo_despesa', 'beneficiario', 'funcionario', 'funcionario_id', 'origem_tipo', 'origem_id', 'numero_nota_fiscal'];
    const numberFields = ['valor', 'valor_parcela', 'valor_pago', 'parcela_atual', 'total_parcelas'];
    const normalized = {};
    stringFields.forEach((key) => { normalized[key] = text(form[key]); });
    numberFields.forEach((key) => { normalized[key] = number(form[key]); });

    try {
      if (id) {
        if (normalized.forma_pagamento !== 'Cartão Crédito') {
          normalized.cartao = null;
          normalized.cartao_id = null;
        }
        await base44.entities.Despesas.update(id, normalized);
        toast({ title: 'Despesa atualizada.' });
        load();
        return true;
      }

      const n = normalized.total_parcelas && normalized.total_parcelas > 1 ? Math.floor(normalized.total_parcelas) : 1;
      const parcelas = normalized.valor == null ? [] : calcParcelas(normalized.valor, n);
      const datasParcelas = Array.isArray(form.datas_parcelas) ? form.datas_parcelas : [];
      const records = Array.from({ length: n }, (_, index) => {
        const parcela = index + 1;
        let vencimento = null;
        if (datasParcelas[index]) vencimento = datasParcelas[index];
        else if (normalized.data_vencimento) vencimento = normalized.forma_pagamento === 'Cartão Crédito'
          ? vencimentoParcela(normalized.data_vencimento, index)
          : addMeses(normalized.data_vencimento, index);
        return {
          ...normalized,
          descricao: n > 1 && normalized.descricao ? `${normalized.descricao} (${parcela}/${n})` : normalized.descricao,
          valor_parcela: parcelas[index] ?? null,
          valor_pago: parcela === 1 ? normalized.valor_pago : null,
          parcela_atual: n > 1 ? parcela : normalized.parcela_atual,
          total_parcelas: n > 1 ? n : normalized.total_parcelas,
          data_vencimento: vencimento,
          cartao: normalized.forma_pagamento === 'Cartão Crédito' ? normalized.cartao : null,
          cartao_id: normalized.forma_pagamento === 'Cartão Crédito' ? normalized.cartao_id : null,
        };
      });
      if (records.length > 1) await base44.entities.Despesas.bulkCreate(records);
      else await base44.entities.Despesas.create(records[0]);
      toast({ title: n > 1 ? `Despesa criada em ${n} parcelas.` : 'Despesa criada.' });
      load();
      return true;
    } catch (e) {
      toast({ title: 'Não foi possível salvar a despesa.', description: mensagemAmigavelErro(e), variant: 'destructive' });
      return false;
    }
  };
  const criarFornecedor = async (nome) => {
    const criado = await base44.entities.Fornecedores.create({ nome, ativa: true });
    setFornecedores((lista) => [...lista, criado].sort((a, b) => a.nome.localeCompare(b.nome)));
    return criado;
  };
  const del = async (id) => {
    try { await base44.entities.Despesas.delete(id); toast({ title: 'Despesa excluída.' }); load(); }
    catch (e) { toast({ title: 'Não foi possível excluir a despesa.', description: e?.message, variant: 'destructive' }); }
  };
  const aprovar = async (d) => {
    try { await base44.entities.Despesas.update(d.id, { status_aprovacao: 'Aprovada' }); toast({ title: 'Despesa aprovada.' }); load(); }
    catch (e) { toast({ title: 'Erro ao aprovar.', description: e?.message, variant: 'destructive' }); }
  };
  const reprovar = async (d) => {
    try { await base44.entities.Despesas.update(d.id, { status_aprovacao: 'Reprovada' }); toast({ title: 'Despesa reprovada.' }); load(); }
    catch (e) { toast({ title: 'Erro ao reprovar.', description: e?.message, variant: 'destructive' }); }
  };

  if (loading) return <div className="p-10 text-center text-slate-400 text-sm">Carregando despesas…</div>;

  return (
    <DespesasCentral
      items={items} obras={obrasPeriodo} obrasAtivas={obrasAtivas} cartoes={cartoes} fornecedores={fornecedores} onCriarFornecedor={criarFornecedor}
      podeCriar={podeCriar} podeEditar={podeEditar} podeExcluir={podeExcluir}
      onSave={save} onDelete={del} onAprovar={aprovar} onReprovar={reprovar} onPrepareForm={prepararFormulario}
    />
  );
}