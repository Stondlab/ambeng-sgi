import React, { useState } from 'react';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Building2, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useFiltrosFinanceiro } from '@/lib/FiltrosFinanceiroContext';

const MESES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
const ANOS = [2024, 2025, 2026, 2027, 2028, 2029, 2030];

const fmtDt = (iso) => iso ? format(parseISO(iso), 'dd/MM/yyyy') : '—';

function CalendarPeriodo({ value, onSelect, onClose }) {
  const dt = value ? parseISO(value) : new Date();
  const [mes, setMes] = useState(dt.getMonth());
  const [ano, setAno] = useState(dt.getFullYear());
  const monthDate = new Date(ano, mes, 1);
  const titulo = `${MESES[mes]} ${ano}`;
  return (
    <div className="p-2">
      <div className="text-center text-sm font-bold text-[#0b2545] mb-2">{titulo}</div>
      <div className="flex items-center justify-center gap-1 mb-2">
        <Select value={String(mes)} onValueChange={(v) => setMes(Number(v))}>
          <SelectTrigger className="h-8 w-28 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>{MESES.map((m, i) => <SelectItem key={i} value={String(i)}>{m}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={String(ano)} onValueChange={(v) => setAno(Number(v))}>
          <SelectTrigger className="h-8 w-20 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>{ANOS.map((a) => <SelectItem key={a} value={String(a)}>{a}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      <Calendar
        mode="single"
        month={monthDate}
        onMonthChange={(d) => { setMes(d.getMonth()); setAno(d.getFullYear()); }}
        selected={value ? parseISO(value) : undefined}
        onSelect={(d) => { if (d) { onSelect(format(d, 'yyyy-MM-dd')); onClose(); } }}
        locale={ptBR}
        initialFocus
      />
    </div>
  );
}

export default function FiltroGlobalBar() {
  const { obra, setObra, obrasPeriodo, dataInicio, setDataInicio, dataFim, setDataFim, mesLabel, mesAnterior, proximoMes, limpar } = useFiltrosFinanceiro();
  const [mesOpen, setMesOpen] = useState(false);
  const [inicioOpen, setInicioOpen] = useState(false);
  const [fimOpen, setFimOpen] = useState(false);

  const dt = new Date(dataInicio + 'T00:00:00');
  const [selMes, setSelMes] = useState(dt.getMonth());
  const [selAno, setSelAno] = useState(dt.getFullYear());

  const aplicarMesAno = () => {
    const novo = new Date(selAno, selMes, 1);
    const fim = new Date(selAno, selMes + 1, 0);
    setDataInicio(novo.toISOString().slice(0, 10));
    setDataFim(fim.toISOString().slice(0, 10));
    setMesOpen(false);
  };

  return (
    <div className="flex flex-wrap items-center gap-2 mb-5 bg-white border border-slate-200 rounded-xl p-3">
      <Building2 className="w-4 h-4 text-slate-400" />
      <Select value={obra} onValueChange={setObra}>
        <SelectTrigger className="w-44 h-9"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="geral">Todas as obras</SelectItem>
          {obrasPeriodo.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}
        </SelectContent>
      </Select>

      <div className="flex items-center gap-1.5 ml-auto">
        <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wide hidden sm:inline">Período</span>

        <Button variant="outline" size="sm" onClick={mesAnterior} className="h-9 px-2" title="Mês anterior">
          <ChevronLeft className="w-4 h-4" />
        </Button>

        {/* MODO 1: clicar no mês/ano abre dropdown rápido */}
        <Popover open={mesOpen} onOpenChange={setMesOpen}>
          <PopoverTrigger asChild>
            <button type="button" className="text-sm font-bold text-[#0b2545] min-w-[105px] text-center hover:bg-slate-50 rounded px-1 py-1.5 transition" title="Selecionar mês/ano">
              {mesLabel}
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-2" align="center">
            <div className="flex items-center gap-1">
              <Select value={String(selMes)} onValueChange={(v) => setSelMes(Number(v))}>
                <SelectTrigger className="h-8 w-28 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>{MESES.map((m, i) => <SelectItem key={i} value={String(i)}>{m}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={String(selAno)} onValueChange={(v) => setSelAno(Number(v))}>
                <SelectTrigger className="h-8 w-20 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>{ANOS.map((a) => <SelectItem key={a} value={String(a)}>{a}</SelectItem>)}</SelectContent>
              </Select>
              <Button size="sm" className="h-8 px-2 bg-emerald-600 hover:bg-emerald-700" onClick={aplicarMesAno}>OK</Button>
            </div>
          </PopoverContent>
        </Popover>

        <Button variant="outline" size="sm" onClick={proximoMes} className="h-9 px-2" title="Próximo mês">
          <ChevronRight className="w-4 h-4" />
        </Button>

        {/* MODO 2: clicar nas datas abre calendário customizado */}
        <div className="flex items-center gap-1 text-sm">
          <Popover open={inicioOpen} onOpenChange={setInicioOpen}>
            <PopoverTrigger asChild>
              <button type="button" className="text-[#0b2545] font-medium hover:underline px-1" title="Data inicial">
                {fmtDt(dataInicio)}
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="center">
              <CalendarPeriodo value={dataInicio} onSelect={setDataInicio} onClose={() => setInicioOpen(false)} />
            </PopoverContent>
          </Popover>
          <span className="text-slate-400 text-xs">até</span>
          <Popover open={fimOpen} onOpenChange={setFimOpen}>
            <PopoverTrigger asChild>
              <button type="button" className="text-[#0b2545] font-medium hover:underline px-1" title="Data final">
                {fmtDt(dataFim)}
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="center">
              <CalendarPeriodo value={dataFim} onSelect={setDataFim} onClose={() => setFimOpen(false)} />
            </PopoverContent>
          </Popover>
        </div>

        <Button variant="ghost" size="sm" onClick={limpar} className="h-9 px-2" title="Limpar período">
          <X className="w-3.5 h-3.5" />
        </Button>
      </div>
    </div>
  );
}