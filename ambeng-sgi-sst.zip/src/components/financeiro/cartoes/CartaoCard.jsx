import React from 'react';
import { fmt, fmtMoney, nextFaturaDate } from '@/lib/financeiro';
import { CreditCard, Pencil, Trash2 } from 'lucide-react';
import { useFiltrosFinanceiro } from '@/lib/FiltrosFinanceiroContext';

const BANDEIRA_COLOR = {
  'Visa': 'bg-blue-50 text-blue-700',
  'Mastercard': 'bg-orange-50 text-orange-700',
  'Elo': 'bg-yellow-50 text-yellow-700',
  'Amex': 'bg-green-50 text-green-700',
  'Hipercard': 'bg-red-50 text-red-700',
};

export default function CartaoCard({ c, despesas, onEdit, onDelete, onClick, podeEditar = true, podeExcluir = true }) {
  const { range } = useFiltrosFinanceiro();
  const despesasPeriodo = despesas.filter((d) => {
    const ref = d.data_compra || d.data_vencimento || '';
    return ref >= range.start && ref <= range.end;
  });
  const total = despesasPeriodo.filter((d) => d.cartao === c.nome).reduce((s, d) => s + (Number(d.valor) || 0), 0);
  const venc = nextFaturaDate(c.dia_vencimento || 1);
  const masc = c.numero ? `**** **** **** ${String(c.numero).slice(-4)}` : '**** **** **** ****';

  return (
    <div onClick={onClick} className={`bg-white border border-slate-200 rounded-xl p-4 ${onClick ? 'cursor-pointer hover:border-[#0b2545]/40 hover:shadow-card-hover transition' : ''}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-9 h-9 rounded-lg bg-[#0b2545] text-white flex items-center justify-center shrink-0"><CreditCard className="w-5 h-5" /></span>
          <div className="min-w-0">
            <p className="font-semibold text-[#0b2545] truncate">{c.nome}</p>
            <p className="text-xs text-slate-500">{c.banco || '—'} · {c.tipo || '—'}</p>
          </div>
        </div>
        <div className="flex gap-1 shrink-0">
          {podeEditar && <button onClick={onEdit} className="p-1.5 text-slate-400 hover:text-[#0b2545]" title="Editar"><Pencil className="w-4 h-4" /></button>}
          {podeExcluir && <button onClick={onDelete} className="p-1.5 text-slate-400 hover:text-red-500" title="Excluir"><Trash2 className="w-4 h-4" /></button>}
        </div>
      </div>

      <div className="flex items-center justify-between mt-3">
        <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${BANDEIRA_COLOR[c.bandeira] || 'bg-slate-100 text-slate-600'}`}>{c.bandeira || 'Cartão'}</span>
        <span className="font-mono text-sm text-slate-500 tracking-wider">{masc}</span>
      </div>

      <div className="grid grid-cols-2 gap-3 mt-3 text-sm">
        <div><p className="text-xs text-slate-400">Fechamento</p><p className="font-medium text-[#0b2545]">dia {c.dia_fechamento || '—'}</p></div>
        <div><p className="text-xs text-slate-400">Vencimento</p><p className="font-medium text-[#0b2545]">dia {c.dia_vencimento || '—'}</p></div>
      </div>

      <div className="mt-3 pt-3 border-t border-slate-100 flex items-end justify-between">
        <div><p className="text-xs text-slate-400">Total gasto</p><p className="text-lg font-bold text-[#0b2545]">{fmtMoney(total)}</p></div>
        <div className="text-right"><p className="text-xs text-slate-400">Próx. fatura vence</p><p className="text-sm font-medium text-slate-700">{fmt(venc)}</p></div>
      </div>
    </div>
  );
}