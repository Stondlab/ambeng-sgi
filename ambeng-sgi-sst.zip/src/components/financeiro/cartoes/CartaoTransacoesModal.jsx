import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { fmtMoney, shortDate } from '@/lib/financeiro';
import { Receipt } from 'lucide-react';
import { useColumnSort } from '@/lib/useColumnSort';
import SortableTh from '@/components/financeiro/SortableTh';

export default function CartaoTransacoesModal({ cartao, despesas, open, onClose }) {
  const { sortField, sortDir, toggleSort, sortRows } = useColumnSort();

  const transacoesRaw = despesas.filter((d) => d.cartao === cartao?.nome);
  const transacoes = sortRows(transacoesRaw, {
    data: (a, b) => (a.data_vencimento || a.data_compra || '').localeCompare(b.data_vencimento || b.data_compra || ''),
    banco: (a, b) => (a.fornecedor || '').localeCompare(b.fornecedor || ''),
    valor: (a, b) => (Number(a.valor) || 0) - (Number(b.valor) || 0),
    descricao: (a, b) => (a.descricao || '').localeCompare(b.descricao || ''),
  });
  const total = transacoes.reduce((s, d) => s + (Number(d.valor) || 0), 0);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl w-[92vw] max-h-[88vh] p-0 gap-0 overflow-hidden flex flex-col">
        <DialogHeader className="px-5 py-4 border-b border-slate-200 bg-gradient-to-r from-[#0b2545] to-[#16365f] text-white">
          <DialogTitle className="flex items-center gap-2 text-white">
            <Receipt className="w-5 h-5" />
            <span>TRANSAÇÕES — {cartao?.nome || ''}</span>
          </DialogTitle>
          <p className="text-sm text-white/70 mt-0.5">{cartao?.banco || '—'} · {cartao?.bandeira || '—'} · {transacoes.length} lançamento(s)</p>
        </DialogHeader>

        <div className="flex-1 overflow-auto bg-slate-50/60">
          {transacoes.length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-10">Nenhuma transação neste cartão.</p>
          ) : (
            <table className="w-full text-sm">
              <thead className="text-xs uppercase text-slate-500 bg-slate-100 sticky top-0">
                <tr>
                  <SortableTh field="data" label="Data" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
                  <SortableTh field="banco" label="Banco" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
                  <SortableTh field="descricao" label="Descrição" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
                  <SortableTh field="valor" label="Valor" align="right" sortField={sortField} sortDir={sortDir} onSort={toggleSort} className="px-3 py-2" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {transacoes.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50">
                    <td className="px-3 py-2.5 whitespace-nowrap text-slate-600">{shortDate(d.data_vencimento || d.data_compra)}</td>
                    <td className="px-3 py-2.5 text-slate-600 truncate max-w-[120px]">{d.fornecedor || '—'}</td>
                    <td className="px-3 py-2.5 text-[#0b2545] font-medium truncate max-w-[220px]">{d.descricao || '—'}</td>
                    <td className="px-3 py-2.5 text-right font-bold text-[#0b2545]">{fmtMoney(d.valor)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="px-5 py-3 border-t border-slate-200 bg-white flex items-center justify-between shrink-0">
          <span className="text-sm text-slate-500">Total gasto no cartão</span>
          <span className="text-lg font-bold text-[#0b2545]">{fmtMoney(total)}</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}