import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X } from 'lucide-react';
import { applyTitleCaseAll } from '@/lib/titleCase';

const TIPOS = ['Crédito', 'Débito'];
const BANDEIRAS = ['Visa', 'Mastercard', 'Elo', 'Amex', 'Hipercard', 'Outros'];

function Field({ label, className, children }) {
  return <div className={className}><Label>{label}</Label><div className="mt-1">{children}</div></div>;
}

export default function CartaoForm({ record, onClose, onSave }) {
  const isNew = !record.id;
  const [form, setForm] = useState(() => {
    const init = {};
    ['nome', 'tipo', 'banco', 'bandeira', 'numero', 'observacoes'].forEach((k) => { init[k] = record[k] ?? ''; });
    ['limite', 'dia_vencimento', 'dia_fechamento', 'saldo'].forEach((k) => { init[k] = record[k] ?? ''; });
    return init;
  });
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const submit = () => {
    if (!form.nome) return;
    onSave(applyTitleCaseAll(form), record.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">{isNew ? 'Novo Cartão' : 'Editar Cartão'}</h3><button type="button" onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field className="sm:col-span-2" label="Nome *"><Input value={form.nome} onChange={(e) => set('nome', e.target.value)} /></Field>
          <Field label="Tipo"><Select value={form.tipo} onValueChange={(v) => set('tipo', v)}><SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{TIPOS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select></Field>
          <Field label="Bandeira"><Select value={form.bandeira} onValueChange={(v) => set('bandeira', v)}><SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{BANDEIRAS.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent></Select></Field>
          <Field label="Banco"><Input value={form.banco} onChange={(e) => set('banco', e.target.value)} /></Field>
          <Field label="Número (últimos 4)"><Input value={form.numero} onChange={(e) => set('numero', e.target.value)} maxLength={4} /></Field>
          <Field label="Limite (R$)"><Input type="number" step="0.01" value={form.limite} onChange={(e) => set('limite', e.target.value)} /></Field>
          <Field label="Dia fechamento"><Input type="number" value={form.dia_fechamento} onChange={(e) => set('dia_fechamento', e.target.value)} /></Field>
          <Field label="Dia vencimento"><Input type="number" value={form.dia_vencimento} onChange={(e) => set('dia_vencimento', e.target.value)} /></Field>
          <Field className="sm:col-span-2" label="Observações"><Textarea rows={2} value={form.observacoes} onChange={(e) => set('observacoes', e.target.value)} /></Field>
        </div>
        <div className="flex justify-end gap-2 pt-2"><Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button><Button type="button" onClick={submit} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button></div>
      </div>
    </div>
  );
}