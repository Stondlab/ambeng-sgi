import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { fmt } from '@/lib/sst';
import { Plus, X, Pencil, Trash2 } from 'lucide-react';
import { usePerm } from '@/hooks/usePerm';

export const fmtMoney = (v) => (v == null || v === '' || isNaN(Number(v))) ? '—' : Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

export default function CrudTab({ entity, fields, columns, sortField = '-created_date', addLabel = 'Novo registro', emptyLabel = 'Nenhum registro.', moduloId }) {
  const [items, setItems] = useState([]);
  const [edit, setEdit] = useState(null);
  const { podeCriar, podeEditar, podeExcluir } = usePerm(moduloId);

  const load = async () => { let all = []; try { all = await base44.entities[entity].list(sortField, 500); } catch {} setItems(all); };
  useEffect(() => { load(); }, [entity]);

  const save = async (form, id) => {
    const payload = { ...form };
    fields.forEach((f) => {
      if (f.type === 'number' || f.money) {
        payload[f.name] = (payload[f.name] === '' || payload[f.name] == null) ? null : Number(payload[f.name]);
      }
    });
    if (id) await base44.entities[entity].update(id, payload);
    else await base44.entities[entity].create(payload);
    setEdit(null); load();
  };
  const del = async (id) => { await base44.entities[entity].delete(id); load(); };

  return (
    <div>
      <div className="flex justify-end mb-3">
        {podeCriar && <Button onClick={() => setEdit({})} className="bg-amber-400 text-[#0b2545] hover:bg-amber-300 font-semibold min-h-[44px]"><Plus className="w-4 h-4 mr-1" />{addLabel}</Button>}
      </div>
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
              <tr>
                {columns.map((c) => <th key={c.field} className="text-left px-4 py-3">{c.label}</th>)}
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {items.length === 0 && <tr><td colSpan={columns.length + 1} className="px-4 py-10 text-center text-slate-400">{emptyLabel}</td></tr>}
              {items.map((it) => (
                <tr key={it.id}>
                  {columns.map((c) => (
                    <td key={c.field} className="px-4 py-3 text-slate-700">
                      {c.type === 'money' ? fmtMoney(it[c.field]) : c.type === 'date' ? fmt(it[c.field]) : c.type === 'boolean' ? (it[c.field] ? 'Sim' : 'Não') : c.type === 'percent' ? `${Number(it[c.field] || 0)}%` : (it[c.field] ?? '—')}
                    </td>
                  ))}
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    {podeEditar && <button onClick={() => setEdit(it)} className="text-slate-400 hover:text-[#0b2545] p-1.5 rounded" title="Editar"><Pencil className="w-4 h-4" /></button>}
                    {podeExcluir && <button onClick={() => del(it.id)} className="text-slate-400 hover:text-red-500 p-1.5 rounded" title="Excluir"><Trash2 className="w-4 h-4" /></button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {edit && <CrudForm fields={fields} record={edit} onClose={() => setEdit(null)} onSave={save} />}
    </div>
  );
}

function CrudForm({ fields, record, onClose, onSave }) {
  const isNew = !record.id;
  const [form, setForm] = useState(() => {
    const init = {};
    fields.forEach((f) => {     init[f.name] = record[f.name] ?? (f.type === 'select' ? (f.options?.[0] || '') : f.type === 'boolean' ? (f.default ?? true) : ''); });
    return init;
  });
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  const submit = () => {
    const missing = fields.find((f) => f.required && (form[f.name] === '' || form[f.name] == null));
    if (missing) return;
    onSave(form, record.id);
  };
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">{isNew ? 'Novo' : 'Editar'}</h3><button type="button" onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div className="grid sm:grid-cols-2 gap-3">
          {fields.map((f) => (
            <div key={f.name} className={f.type === 'textarea' ? 'sm:col-span-2' : ''}>
              <Label>{f.label}{f.required && <span className="text-destructive"> *</span>}</Label>
              {f.type === 'boolean' ? (
                <div className="mt-2 flex items-center gap-2"><Switch checked={!!form[f.name]} onCheckedChange={(v) => set(f.name, v)} /><span className="text-sm text-slate-600">{form[f.name] ? 'Sim' : 'Não'}</span></div>
              ) : f.type === 'select' ? (
                <Select value={form[f.name] || ''} onValueChange={(v) => set(f.name, v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{f.options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select>
              ) : f.type === 'textarea' ? (
                <Textarea className="mt-1" rows={2} value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
              ) : (
                <Input className="mt-1" type={f.type || 'text'} value={form[f.name] || ''} onChange={(e) => set(f.name, e.target.value)} />
              )}
            </div>
          ))}
        </div>
        <div className="flex justify-end gap-2 pt-2"><Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button><Button type="button" onClick={submit} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button></div>
      </div>
    </div>
  );
}