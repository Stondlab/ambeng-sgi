import React, { useState } from 'react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar as CalendarIcon } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

// Seletor de data visual: calendário com navegação por mês/ano, formato brasileiro DD/MM/AAAA.
export default function DataPicker({ value, onChange, placeholder = 'Data', className }) {
  const [open, setOpen] = useState(false);
  const selected = value ? parseISO(value) : undefined;
  const anoAtual = new Date().getFullYear();

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          className={cn('h-9 justify-start font-normal text-sm gap-1.5', !value && 'text-slate-400', className)}
        >
          <CalendarIcon className="w-4 h-4 text-slate-400" />
          {value ? format(parseISO(value), 'dd/MM/yyyy') : placeholder}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar
          mode="single"
          selected={selected}
          onSelect={(d) => { if (d) { onChange(format(d, 'yyyy-MM-dd')); setOpen(false); } }}
          locale={ptBR}
          captionLayout="dropdown"
          fromYear={2000}
          toYear={anoAtual + 5}
          initialFocus
        />
      </PopoverContent>
    </Popover>
  );
}