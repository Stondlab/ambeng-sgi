import React, { useEffect, useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { fmt, getStatus } from '@/lib/sst';
import { conformidade, taxaAcidentesMes, pendencias } from '@/lib/relatorios';
import { fmtMoney, valorMes } from '@/lib/financeiro';
import { Users, Stethoscope, GraduationCap, AlertTriangle, ClipboardCheck, Wallet, TrendingUp, TrendingDown, FileText, Printer, ShieldAlert } from 'lucide-react';

const num = (v) => Number(v) || 0;
const hoje = new Date().toISOString().slice(0, 10);
const mesAtual = new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });

function baixar(nome, conteudo, mime) {
  const blob = new Blob([conteudo], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = nome; a.click();
  URL.revokeObjectURL(url);
}

function csv(head, rows) {
  return head.join(';') + '\n' + rows.map((r) => r.map((c) => String(c ?? '').replace(/;/g, ',')).join(';')).join('\n');
}

export default function TemplatesMensais({ data }) {
  const [ativo, setAtivo] = useState('sst');
  const [despesas, setDespesas] = useState([]);
  const [receitas, setReceitas] = useState([]);

  useEffect(() => {
    if (ativo !== 'financeiro') return;
    (async () => {
      const [d, r] = await Promise.all([
        base44.entities.Despesas.list('-created_date', 1000).catch(() => []),
        base44.entities.Receitas.list('-created_date', 1000).catch(() => []),
      ]);
      setDespesas(d);
      setReceitas(r);
    })();
  }, [ativo]);

  const relatorioSST = useMemo(() => {
    if (!data || ativo !== 'sst') return null;
    const conf = conformidade(data);
    const acc = taxaAcidentesMes(data);
    const ativos = data.funcionarios.filter((f) => f.status === 'Ativo').length;
    const asosVenc = data.asos.filter((a) => getStatus(a.data_validade) === 'Vencido').length;
    const asosPend = data.asos.filter((a) => getStatus(a.data_validade) === 'A vencer').length;
    const treiVenc = data.treinamentos.filter((t) => getStatus(t.data_validade) === 'Vencido').length;
    const treiPend = data.treinamentos.filter((t) => getStatus(t.data_validade) === 'A vencer').length;
    const nc = data.ocorrencias.filter((o) => o.tipo === 'Não Conformidade' && o.situacao !== 'Encerrada' && o.situacao !== 'Resolvida').length;
    const dds = data.dds.length;
    const pend = pendencias(data).length;
    return { conf, acc, ativos, asosVenc, asosPend, treiVenc, treiPend, nc, dds, pend };
  }, [data, ativo]);

  const relatorioRH = useMemo(() => {
    if (!data || ativo !== 'rh') return null;
    const ativos = data.funcionarios.filter((f) => f.status === 'Ativo').length;
    const afastados = data.funcionarios.filter((f) => f.status === 'Afastado').length;
    const demitidos = data.funcionarios.filter((f) => f.status === 'Demitido').length;
    const semASO = data.funcionarios.filter((f) => f.status === 'Ativo' && !data.asos.some((a) => a.funcionario_id === f.id)).length;
    const semTrei = data.funcionarios.filter((f) => f.status === 'Ativo' && !data.treinamentos.some((t) => t.funcionario_id === f.id)).length;
    const semEPI = data.funcionarios.filter((f) => f.status === 'Ativo' && !data.epis.some((e) => e.funcionario_id === f.id)).length;
    const integracoes = data.integracoes.length;
    const dds = data.dds.length;
    return { ativos, afastados, demitidos, semASO, semTrei, semEPI, integracoes, dds };
  }, [data, ativo]);

  const relatorioFin = useMemo(() => {
    if (ativo !== 'financeiro') return null;
    const d = despesas;
    const r = receitas;
    const pago = d.filter((x) => x.status === 'Pago').reduce((s, x) => s + valorMes(x), 0);
    const pendente = d.filter((x) => x.status === 'Pendente').reduce((s, x) => s + valorMes(x), 0);
    const atrasado = d.filter((x) => x.status === 'Atrasado').reduce((s, x) => s + valorMes(x), 0);
    const recebido = r.filter((x) => x.status === 'Recebida').reduce((s, x) => s + num(x.valor), 0);
    const aReceber = r.filter((x) => x.status === 'Prevista').reduce((s, x) => s + num(x.valor), 0);
    const saldo = recebido - pago;
    const despFixa = d.filter((x) => x.tipo_despesa === 'Fixa').reduce((s, x) => s + valorMes(x), 0);
    const despVar = d.filter((x) => x.tipo_despesa === 'Variável').reduce((s, x) => s + valorMes(x), 0);
    return { pago, pendente, atrasado, recebido, aReceber, saldo, despFixa, despVar, totalDesp: pago + pendente + atrasado };
  }, [despesas, receitas, ativo]);

  const templates = [
    { id: 'sst', label: 'SST Mensal', icon: ShieldAlert },
    { id: 'rh', label: 'RH Mensal', icon: Users },
    { id: 'financeiro', label: 'Financeiro Mensal', icon: Wallet },
  ];

  const exportar = (tipo) => {
    if (tipo === 'financeiro') {
      const rows = despesas.map((d) => [d.descricao, d.fornecedor || '—', fmt(d.data_vencimento), valorMes(d), d.status]);
      baixar(`relatorio_financeiro_${hoje}.csv`, csv(['Descrição', 'Fornecedor', 'Vencimento', 'Valor', 'Status'], rows), 'text/csv');
    } else if (tipo === 'rh') {
      const rows = data.funcionarios.map((f) => [f.nome, f.funcao || '—', f.empresa || '—', f.obra || '—', f.status]);
      baixar(`relatorio_rh_${hoje}.csv`, csv(['Nome', 'Cargo', 'Empresa', 'Obra', 'Status'], rows), 'text/csv');
    } else {
      const rows = [
        ['Funcionários Ativos', relatorioSST?.ativos || 0],
        ['% Conformidade', relatorioSST ? `${relatorioSST.conf.indice}%` : '—'],
        ['ASOs Vencidos', relatorioSST?.asosVenc || 0],
        ['Treinamentos Vencidos', relatorioSST?.treiVenc || 0],
        ['NCs Abertas', relatorioSST?.nc || 0],
        ['Acidentes no Mês', relatorioSST?.acc.acidentesMes || 0],
        ['DDS Realizados', relatorioSST?.dds || 0],
        ['Pendências', relatorioSST?.pend || 0],
      ];
      baixar(`relatorio_sst_${hoje}.csv`, csv(['Indicador', 'Valor'], rows), 'text/csv');
    }
  };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-[#0b2545]" />
          <h3 className="font-semibold text-[#0b2545]">Templates Mensais Pré-preenchidos</h3>
        </div>
        <span className="text-xs text-slate-400">Competência: {mesAtual}</span>
      </div>

      <div className="flex gap-2 mb-4">
        {templates.map((t) => (
          <button key={t.id} onClick={() => setAtivo(t.id)}
            className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition ${ativo === t.id ? 'bg-[#0b2545] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
            <t.icon className="w-4 h-4" />{t.label}
          </button>
        ))}
      </div>

      {ativo === 'sst' && relatorioSST && (
        <div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
            <MiniStat icon={Users} label="Ativos" value={relatorioSST.ativos} tone="navy" />
            <MiniStat icon={Stethoscope} label="ASO Vencidos" value={relatorioSST.asosVenc} tone={relatorioSST.asosVenc ? 'red' : 'green'} />
            <MiniStat icon={GraduationCap} label="Trei. Vencidos" value={relatorioSST.treiVenc} tone={relatorioSST.treiVenc ? 'red' : 'green'} />
            <MiniStat icon={AlertTriangle} label="NCs Abertas" value={relatorioSST.nc} tone={relatorioSST.nc ? 'red' : 'green'} />
            <MiniStat icon={ClipboardCheck} label="Pendências" value={relatorioSST.pend} tone="amber" />
            <MiniStat icon={ClipboardCheck} label="DDS" value={relatorioSST.dds} tone="navy" />
            <MiniStat icon={AlertTriangle} label="Acidentes/mês" value={relatorioSST.acc.acidentesMes} tone={relatorioSST.acc.acidentesMes ? 'red' : 'green'} />
            <MiniStat icon={TrendingUp} label="% Conformidade" value={`${relatorioSST.conf.indice ?? '—'}%`} tone={relatorioSST.conf.indice >= 80 ? 'green' : 'amber'} />
          </div>
          <div className="flex justify-end gap-2">
            <Button size="sm" variant="outline" onClick={() => exportar('sst')}><Printer className="w-4 h-4 mr-1" />Exportar CSV</Button>
          </div>
        </div>
      )}

      {ativo === 'rh' && relatorioRH && (
        <div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
            <MiniStat icon={Users} label="Ativos" value={relatorioRH.ativos} tone="navy" />
            <MiniStat icon={Users} label="Afastados" value={relatorioRH.afastados} tone="amber" />
            <MiniStat icon={Users} label="Demitidos" value={relatorioRH.demitidos} tone="red" />
            <MiniStat icon={Stethoscope} label="Sem ASO" value={relatorioRH.semASO} tone={relatorioRH.semASO ? 'red' : 'green'} />
            <MiniStat icon={GraduationCap} label="Sem Trein." value={relatorioRH.semTrei} tone={relatorioRH.semTrei ? 'red' : 'green'} />
            <MiniStat icon={ClipboardCheck} label="Sem EPI" value={relatorioRH.semEPI} tone={relatorioRH.semEPI ? 'red' : 'green'} />
            <MiniStat icon={Users} label="Integrações" value={relatorioRH.integracoes} tone="navy" />
            <MiniStat icon={ClipboardCheck} label="DDS" value={relatorioRH.dds} tone="navy" />
          </div>
          <div className="flex justify-end gap-2">
            <Button size="sm" variant="outline" onClick={() => exportar('rh')}><Printer className="w-4 h-4 mr-1" />Exportar CSV</Button>
          </div>
        </div>
      )}

      {ativo === 'financeiro' && (
        <div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
            <MiniStat icon={TrendingUp} label="Recebido" value={fmtMoney(relatorioFin.recebido)} tone="green" />
            <MiniStat icon={TrendingDown} label="Pago" value={fmtMoney(relatorioFin.pago)} tone="red" />
            <MiniStat icon={Wallet} label="Saldo" value={fmtMoney(relatorioFin.saldo)} tone={relatorioFin.saldo >= 0 ? 'green' : 'red'} />
            <MiniStat icon={Wallet} label="A Receber" value={fmtMoney(relatorioFin.aReceber)} tone="navy" />
            <MiniStat icon={TrendingDown} label="Pendente" value={fmtMoney(relatorioFin.pendente)} tone="amber" />
            <MiniStat icon={TrendingDown} label="Atrasado" value={fmtMoney(relatorioFin.atrasado)} tone="red" />
            <MiniStat icon={TrendingDown} label="Desp. Fixas" value={fmtMoney(relatorioFin.despFixa)} tone="navy" />
            <MiniStat icon={TrendingDown} label="Desp. Variável" value={fmtMoney(relatorioFin.despVar)} tone="navy" />
          </div>
          <div className="flex justify-end gap-2">
            <Button size="sm" variant="outline" onClick={() => exportar('financeiro')}><Printer className="w-4 h-4 mr-1" />Exportar CSV</Button>
          </div>
        </div>
      )}
    </section>
  );
}

function MiniStat({ icon: Icon, label, value, tone }) {
  const tones = { navy: 'border-l-[#0b2545]', green: 'border-l-emerald-500', amber: 'border-l-amber-500', red: 'border-l-red-500' };
  return (
    <div className={`bg-white border border-slate-200 border-l-4 ${tones[tone]} rounded-r-lg p-3`}>
      <div className="flex items-center gap-1.5 mb-1"><Icon className="w-3.5 h-3.5 text-slate-400" /><span className="text-[11px] uppercase tracking-wide text-slate-500">{label}</span></div>
      <p className="text-lg font-bold text-[#0b2545]">{value}</p>
    </div>
  );
}