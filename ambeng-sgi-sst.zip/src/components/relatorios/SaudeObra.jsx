import React, { useMemo, useState } from 'react';
import { conformidade } from '@/lib/relatorios';
import { obrasAtivasParaLancamento } from '@/lib/obraDisponibilidade';

function toneColor(indice) {
  return indice >= 90 ? '#059669' : indice >= 70 ? '#d97706' : '#dc2626';
}

function indiceObra(data, obra) {
  const ids = new Set(data.funcionarios.filter((f) => f.obra === obra).map((f) => f.id));
  const sub = (arr) => arr.filter((r) => ids.has(r.funcionario_id));
  return conformidade({
    ...data,
    funcionarios: data.funcionarios.filter((f) => f.obra === obra),
    asos: sub(data.asos),
    treinamentos: sub(data.treinamentos),
    epis: sub(data.epis),
    integracoes: sub(data.integracoes),
    dds: sub(data.dds),
    documentos: sub(data.documentos),
    ocorrencias: sub(data.ocorrencias),
  }).indice;
}

function Bar({ label, indice, extra }) {
  const color = toneColor(indice);
  return (
    <div>
      <div className="flex items-center justify-between text-sm mb-1 gap-2">
        <span className="font-medium text-[#0b2545] truncate">{label}</span>
        <span className="text-slate-500 text-xs shrink-0">{extra ? `${extra} · ` : ''}{indice}%</span>
      </div>
      <div className="h-3 rounded-full bg-slate-100 overflow-hidden">
        <div className="h-full rounded-full transition-all" style={{ width: `${indice}%`, background: color }} />
      </div>
    </div>
  );
}

function GeralView({ indice }) {
  const color = toneColor(indice);
  const status = indice >= 90 ? 'Excelente' : indice >= 80 ? 'Bom' : indice >= 70 ? 'Regular' : 'Crítico';
  return (
    <div className="flex flex-col items-center py-1">
      <div className="text-4xl font-bold" style={{ color }}>{indice}%</div>
      <div className="text-sm text-slate-500 mt-1">Índice geral de conformidade</div>
      <div className="mt-3 w-full">
        <Bar label="Empresa (Geral)" indice={indice} />
      </div>
      <p className="mt-2 text-sm font-semibold" style={{ color }}>{status}</p>
    </div>
  );
}

export default function SaudeObra({ data, resultadoConformidade = null }) {
  const [view, setView] = useState('obra');
  const { geral, obrasData } = useMemo(() => {
    const indiceGeral = (resultadoConformidade || conformidade(data)).indice;
    const nomesAtivos = new Set(obrasAtivasParaLancamento(data.obras || []).map((obra) => obra.nome));
    const obras = [...new Set(data.funcionarios.map((f) => f.obra).filter((nome) => nome && nomesAtivos.has(nome)))].sort();
    return {
      geral: indiceGeral,
      obrasData: obras.map((o) => ({
        obra: o,
        indice: indiceObra(data, o),
        n: data.funcionarios.filter((f) => f.obra === o).length,
      })),
    };
  }, [data, resultadoConformidade]);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center justify-between gap-2 mb-4">
        <h3 className="font-semibold text-[#0b2545]">Saúde da Obra</h3>
        <div className="flex bg-slate-100 rounded-lg p-0.5 text-xs">
          <button
            onClick={() => setView('obra')}
            className={`px-3 py-1.5 rounded-md min-h-[32px] ${view === 'obra' ? 'bg-white shadow text-[#0b2545] font-semibold' : 'text-slate-500'}`}
          >
            Por obra
          </button>
          <button
            onClick={() => setView('geral')}
            className={`px-3 py-1.5 rounded-md min-h-[32px] ${view === 'geral' ? 'bg-white shadow text-[#0b2545] font-semibold' : 'text-slate-500'}`}
          >
            Geral da empresa
          </button>
        </div>
      </div>

      {view === 'geral' ? (
        <GeralView indice={geral} />
      ) : (
        <div className="space-y-3">
          {obrasData.length === 0 && (
            <p className="text-sm text-slate-400">Nenhuma obra cadastrada nos funcionários.</p>
          )}
          {obrasData.map((o) => (
            <Bar key={o.obra} label={o.obra} indice={o.indice} extra={`${o.n} colab.`} />
          ))}
        </div>
      )}
    </section>
  );
}