import React, { useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { conformidade, pendencias } from '@/lib/relatorios';
import { fmt } from '@/lib/sst';
import { Printer, FileSpreadsheet, FileText } from 'lucide-react';
import { obrasDisponiveisNoPeriodo } from '@/lib/obraDisponibilidade';

const PERIODOS = ['Hoje', 'Semana', 'Mês', 'Ano', 'Personalizado'];
const INCLUIR = ['Fotos', 'Indicadores', 'Gráficos', 'Assinaturas', 'Histórico', 'Pendências'];
const CAMPOS = ['obra', 'empresa', 'cliente', 'supervisor', 'funcao'];

function distinct(arr, key) { return [...new Set(arr.map((x) => x[key]).filter(Boolean))]; }

function csv(rows, cols) {
  const head = cols.map((c) => c.label).join(';');
  const body = rows.map((r) => cols.map((c) => (c.render ? String(c.render(r) ?? '') : String(r[c.key] ?? '')).replace(/;/g, ',')).join(';')).join('\n');
  return head + '\n' + body;
}
function baixar(nome, conteudo, mime) {
  const blob = new Blob([conteudo], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = nome; a.click();
  URL.revokeObjectURL(url);
}

export default function GeradorRelatorio({ data }) {
  const [periodo, setPeriodo] = useState('Mês');
  const [de, setDe] = useState('');
  const [ate, setAte] = useState('');
  const [filtros, setFiltros] = useState({});
  const [formato, setFormato] = useState('PDF');
  const [incluir, setIncluir] = useState(['Indicadores', 'Pendências']);
  const [gerado, setGerado] = useState(null);

  const hoje = new Date().toISOString().slice(0, 10);
  const obrasPeriodo = useMemo(() => obrasDisponiveisNoPeriodo(data.obras || [], periodo === 'Personalizado' && de ? de : hoje, periodo === 'Personalizado' && ate ? ate : hoje), [data, periodo, de, ate]);
  const opcoes = useMemo(() => ({
    obra: obrasPeriodo.map((obra) => obra.nome), empresa: distinct(data.funcionarios, 'empresa'),
    cliente: distinct(data.funcionarios, 'cliente'), supervisor: distinct(data.funcionarios, 'supervisor'),
    funcao: distinct(data.funcionarios, 'funcao'),
  }), [data, obrasPeriodo]);

  const toggle = (k) => setIncluir((p) => p.includes(k) ? p.filter((x) => x !== k) : [...p, k]);
  const setF = (k, v) => setFiltros((p) => ({ ...p, [k]: v === 'Todos' ? '' : v }));

  const filtrar = (arr) => {
    if (!filtros.funcionario) return arr;
    const f = data.funcionarios.find((x) => x.id === filtros.funcionario);
    return arr.filter((r) => r.funcionario_id === filtros.funcionario);
  };

  const gerar = () => {
    const fcols = [
      { key: 'nome', label: 'Nome' }, { key: 'matricula', label: 'Matrícula' }, { key: 'funcao', label: 'Cargo' },
      { key: 'obra', label: 'Obra' }, { key: 'empresa', label: 'Empresa' }, { key: 'status', label: 'Status' },
    ];
    const nomesObras = new Set(obrasPeriodo.map((obra) => obra.nome));
    const funcs = data.funcionarios.filter((f) => (!f.obra || nomesObras.has(f.obra)) && CAMPOS.every((k) => !filtros[k] || f[k] === filtros[k]) && (!filtros.funcionario || f.id === filtros.funcionario));
    const report = {
      titulo: 'Relatório do SGI SST', periodo, filtros, funcionarios: funcs,
      asos: filtrar(data.asos), treinamentos: filtrar(data.treinamentos), epis: filtrar(data.epis),
      dds: filtrar(data.dds), integracoes: filtrar(data.integracoes), ocorrencias: filtrar(data.ocorrencias),
      fcols, incluir,
    };
    setGerado(report);
  };

  const exportar = (fmtTipo) => {
    if (!gerado) return;
    if (fmtTipo === 'Excel') { baixar('relatorio_sgi.csv', csv(gerado.funcionarios, gerado.fcols), 'text/csv'); return; }
    if (fmtTipo === 'Word') { baixar('relatorio_sgi.doc', `<h1>${gerado.titulo}</h1><p>Período: ${gerado.periodo}</p><table border=1><tr>${gerado.fcols.map((c) => `<th>${c.label}</th>`).join('')}</tr>${gerado.funcionarios.map((r) => `<tr>${gerado.fcols.map((c) => `<td>${r[c.key] ?? ''}</td>`).join('')}</tr>`).join('')}</table>`, 'application/msword'); return; }
    window.print();
  };

  const { indice, tone } = conformidade(data);
  const TXT = { green: 'text-emerald-700', amber: 'text-amber-700', red: 'text-red-700' };

  return (
    <div className="space-y-4">
      <section className="bg-white border border-slate-200 rounded-xl p-5">
        <h3 className="font-semibold text-[#0b2545] mb-4">Gerador de Relatórios Personalizados</h3>
        <div className="grid gap-4 md:grid-cols-3">
          <div>
            <Label>Período</Label>
            <Select value={periodo} onValueChange={setPeriodo}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{PERIODOS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent></Select>
          </div>
          {periodo === 'Personalizado' && (
            <>
              <div><Label>De</Label><Input className="mt-1" type="date" value={de} onChange={(e) => setDe(e.target.value)} /></div>
              <div><Label>Até</Label><Input className="mt-1" type="date" value={ate} onChange={(e) => setAte(e.target.value)} /></div>
            </>
          )}
          {CAMPOS.map((k) => (
            <div key={k}>
              <Label>{k.charAt(0).toUpperCase() + k.slice(1)}</Label>
              <Select value={filtros[k] || 'Todos'} onValueChange={(v) => setF(k, v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>
                <SelectItem value="Todos">Todos</SelectItem>{opcoes[k].map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
              </SelectContent></Select>
            </div>
          ))}
          <div>
            <Label>Funcionário</Label>
            <Select value={filtros.funcionario || 'Todos'} onValueChange={(v) => setFiltros((p) => ({ ...p, funcionario: v === 'Todos' ? '' : v }))}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>
              <SelectItem value="Todos">Todos</SelectItem>{data.funcionarios.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}
            </SelectContent></Select>
          </div>
          <div>
            <Label>Formato</Label>
            <Select value={formato} onValueChange={setFormato}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{['PDF', 'Excel', 'Word'].map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent></Select>
          </div>
        </div>
        <div className="mt-4">
          <Label>Incluir no relatório</Label>
          <div className="flex flex-wrap gap-4 mt-2">
            {INCLUIR.map((k) => (
              <label key={k} className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                <Checkbox checked={incluir.includes(k)} onCheckedChange={() => toggle(k)} />{k}
              </label>
            ))}
          </div>
        </div>
        <div className="flex justify-end mt-4">
          <Button onClick={gerar} className="bg-[#0b2545] hover:bg-[#16365f]">Gerar Relatório</Button>
        </div>
      </section>

      {gerado && (
        <section className="bg-white border border-slate-200 rounded-xl p-5 print:shadow-none print:border-0">
          <div className="flex items-center justify-between mb-4 no-print">
            <h3 className="font-semibold text-[#0b2545]">{gerado.titulo}</h3>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => exportar('PDF')}><Printer className="w-4 h-4 mr-1" />PDF</Button>
              <Button size="sm" variant="outline" onClick={() => exportar('Excel')}><FileSpreadsheet className="w-4 h-4 mr-1" />Excel</Button>
              <Button size="sm" variant="outline" onClick={() => exportar('Word')}><FileText className="w-4 h-4 mr-1" />Word</Button>
            </div>
          </div>
          <div className="border-b border-slate-100 pb-3 mb-4">
            <h1 className="text-xl font-bold text-[#0b2545]">SGI SST — {gerado.titulo}</h1>
            <p className="text-sm text-slate-500">Período: {gerado.periodo}{periodo === 'Personalizado' && de && ate ? ` (${fmt(de)} a ${fmt(ate)})` : ''} · Gerado em {fmt(new Date().toISOString().slice(0, 10))}</p>
            {Object.entries(gerado.filtros).filter(([, v]) => v).length > 0 && (
              <p className="text-xs text-slate-400 mt-1">Filtros: {Object.entries(gerado.filtros).filter(([, v]) => v).map(([k]) => k).join(', ')}</p>
            )}
          </div>
          {gerado.incluir.includes('Indicadores') && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
              {[['Funcionários', gerado.funcionarios.length], ['ASOs', gerado.asos.length], ['Treinamentos', gerado.treinamentos.length], ['EPIs', gerado.epis.length], ['DDS', gerado.dds.length], ['Integrações', gerado.integracoes.length], ['Ocorrências', gerado.ocorrencias.length], ['Índice conformidade', `${indice}%`]].map(([l, v]) => (
                <div key={l} className="border border-slate-100 rounded-lg p-3"><p className="text-xs text-slate-400">{l}</p><p className={`text-lg font-semibold ${l.includes('conformidade') ? TXT[tone] : 'text-[#0b2545]'}`}>{v}</p></div>
              ))}
            </div>
          )}
          <table className="w-full text-sm mb-4">
            <thead className="text-xs text-slate-400 border-b border-slate-100"><tr>{gerado.fcols.map((c) => <th key={c.key} className="text-left py-2 pr-4">{c.label}</th>)}</tr></thead>
            <tbody className="divide-y divide-slate-50">
              {gerado.funcionarios.map((r) => (<tr key={r.id}>{gerado.fcols.map((c) => <td key={c.key} className="py-2 pr-4 text-slate-700">{r[c.key] ?? '—'}</td>)}</tr>))}
            </tbody>
          </table>
          {gerado.incluir.includes('Pendências') && <PendenciasMini data={data} />}
          {gerado.incluir.includes('Assinaturas') && (
            <div className="grid grid-cols-2 gap-8 mt-8 pt-6 border-t border-slate-100">
              <div className="border-t border-slate-400 pt-1 text-xs text-slate-500">Técnico de Segurança</div>
              <div className="border-t border-slate-400 pt-1 text-xs text-slate-500">Responsável</div>
            </div>
          )}
        </section>
      )}
    </div>
  );
}

function PendenciasMini({ data }) {
  const list = pendencias(data);
  if (!list.length) return null;
  const DOT = { red: 'bg-red-500', amber: 'bg-amber-500', green: 'bg-emerald-500' };
  return (
    <div className="mb-4">
      <p className="text-sm font-semibold text-[#0b2545] mb-2">Pendências</p>
      <ul className="text-sm space-y-1">{list.map((p, i) => (<li key={i} className="flex items-center gap-2"><span className={`w-2 h-2 rounded-full ${DOT[p.tone]}`} />{p.label} — <span className="text-slate-400">{p.detalhe}</span></li>))}</ul>
    </div>
  );
}