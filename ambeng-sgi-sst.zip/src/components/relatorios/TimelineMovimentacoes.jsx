import React from 'react';
import { timeline } from '@/lib/relatorios';
import { fmt } from '@/lib/sst';
import { Clock } from 'lucide-react';

const DOT = { DDS: '#0b2545', Integração: '#0ea5e9', EPI: '#f59e0b', Ocorrência: '#dc2626', Treinamento: '#059669', ASO: '#8b5cf6' };

export default function TimelineMovimentacoes({ data }) {
  const ev = timeline(data);
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <Clock className="w-5 h-5 text-[#0b2545]" />
        <h3 className="font-semibold text-[#0b2545]">Últimas Movimentações</h3>
      </div>
      {ev.length === 0 ? <p className="text-sm text-slate-400">Sem movimentações.</p> : (
        <div className="space-y-3">
          {ev.map((e, i) => (
            <div key={i} className="flex gap-3">
              <div className="flex flex-col items-center">
                <span className="w-2.5 h-2.5 rounded-full mt-1" style={{ background: DOT[e.tipo] || '#64748b' }} />
                <span className="w-px flex-1 bg-slate-100" />
              </div>
              <div className="pb-1">
                <p className="text-sm text-slate-700">{e.titulo}</p>
                <p className="text-xs text-slate-400">{fmt(e.data)} · {e.funcionario} · {e.obra}{e.responsavel !== '—' ? ` · Resp: ${e.responsavel}` : ''}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}