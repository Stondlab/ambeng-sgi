import React, { useMemo } from 'react';
import { statusLiberacao, STATUS_LIB } from '@/lib/liberacao';
import { Button } from '@/components/ui/button';
import { Printer, FileSpreadsheet } from 'lucide-react';

function baixar(nome, conteudo, mime) { const b = new Blob([conteudo], { type: mime }); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = nome; a.click(); URL.revokeObjectURL(u); }
const diasDesde = (d) => (d ? Math.max(0, Math.round((Date.now() - new Date(d)) / 86400000)) : 0);

export default function ColaboradoresPendentesLiberacao({ data }) {
  const rows = useMemo(() => {
    const { funcionarios, asos, treinamentos, epis, integracoes, documentos, pendencias } = data;
    return funcionarios.map((f) => {
      const ctx = {
        asos: asos.filter((a) => a.funcionario_id === f.id),
        treinamentos: treinamentos.filter((t) => t.funcionario_id === f.id),
        epis: epis.filter((e) => e.funcionario_id === f.id),
        integracoes: integracoes.filter((i) => i.funcionario_id === f.id),
        documentos: documentos.filter((d) => d.funcionario_id === f.id),
      };
      const r = statusLiberacao(f, ctx);
      const pend = pendencias.filter((p) => p.funcionario_id === f.id && p.status !== 'Concluída');
      return { nome: f.nome, obra: f.obra || '—', cargo: f.funcao || '—', admissao: f.data_admissao || '—', pendencias: r.pendentes.map((p) => p.label).join(', ') || '—', status: STATUS_LIB[r.status], responsavel: pend[0]?.responsavel || pend[0]?.setor || '—', dias: diasDesde(f.created_date) };
    }).filter((r) => ['Pendente de Liberação', 'Bloqueado', 'Cadastro Incompleto'].includes(r.status));
  }, [data]);

  const exportCSV = () => {
    const head = ['Nome', 'Obra', 'Cargo', 'Admissão', 'Pendências', 'Status', 'Responsável', 'Dias'].join(';');
    const body = rows.map((r) => [r.nome, r.obra, r.cargo, r.admissao, r.pendencias, r.status, r.responsavel, r.dias].map((c) => String(c).replace(/;/g, ',')).join(';')).join('\n');
    baixar('colaboradores_pendentes_liberacao.csv', head + '\n' + body, 'text/csv');
  };
  const exportPDF = () => {
    const w = window.open('', '_blank');
    const html = `<html><head><title>Colaboradores Pendentes de Liberação</title></head><body style="font-family:Arial;padding:32px">
      <h1 style="color:#0b2545">Colaboradores Pendentes de Liberação</h1><p>Gerado em ${new Date().toLocaleString('pt-BR')}</p>
      <table border="1" cellpadding="4" cellspacing="0" style="border-collapse:collapse;font-size:11px"><tr><th>Nome</th><th>Obra</th><th>Cargo</th><th>Admissão</th><th>Pendências</th><th>Status</th><th>Responsável</th><th>Dias</th></tr>
      ${rows.map((r) => '<tr><td>' + r.nome + '</td><td>' + r.obra + '</td><td>' + r.cargo + '</td><td>' + r.admissao + '</td><td>' + r.pendencias + '</td><td>' + r.status + '</td><td>' + r.responsavel + '</td><td>' + r.dias + '</td></tr>').join('')}</table>
      </body></html>`;
    w.document.write(html); w.document.close(); w.print();
  };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <h3 className="font-semibold text-[#0b2545]">Colaboradores Pendentes de Liberação</h3>
        <div className="ml-auto flex gap-2">
          <Button variant="outline" onClick={exportCSV}><FileSpreadsheet className="w-4 h-4 mr-1" />Excel</Button>
          <Button variant="outline" onClick={exportPDF}><Printer className="w-4 h-4 mr-1" />PDF</Button>
        </div>
      </div>
      {rows.length === 0 ? <p className="text-sm text-emerald-700">Nenhum colaborador pendente de liberação.</p> : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs text-slate-400 border-b border-slate-100">
              <tr><th className="text-left py-2 pr-3">Nome</th><th className="text-left px-2">Obra</th><th className="text-left px-2">Cargo</th><th className="text-left px-2">Admissão</th><th className="text-left px-2">Pendências</th><th className="text-left px-2">Status</th><th className="text-left px-2">Responsável</th><th className="text-right pl-2">Dias</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {rows.map((r, i) => (
                <tr key={i}>
                  <td className="py-2 pr-3 font-medium text-[#0b2545]">{r.nome}</td>
                  <td className="px-2 text-slate-600">{r.obra}</td>
                  <td className="px-2 text-slate-600">{r.cargo}</td>
                  <td className="px-2 text-slate-600">{r.admissao}</td>
                  <td className="px-2 text-slate-600">{r.pendencias}</td>
                  <td className="px-2 text-slate-600">{r.status}</td>
                  <td className="px-2 text-slate-600">{r.responsavel}</td>
                  <td className="pl-2 text-right text-slate-600">{r.dias}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}