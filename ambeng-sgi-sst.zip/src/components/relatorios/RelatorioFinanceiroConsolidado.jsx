import React, { useMemo, useState } from 'react';
import useFinanceiroDashboardData from '@/hooks/useFinanceiroDashboardData';
import { calcularFinanceiro, PERIODOS_FINANCEIROS } from '@/lib/financeiroConsolidado';
import { fmtMoney } from '@/lib/financeiro';
import ObrasExecutiveTable from '@/components/financeiro/ObrasExecutiveTable';

const fimEm30Dias = () => { const d = new Date(); d.setDate(d.getDate() + 30); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
export default function RelatorioFinanceiroConsolidado() {
  const [periodo, setPeriodo] = useState('ano');
  const { data, loading } = useFinanceiroDashboardData();
  const resumo = useMemo(() => calcularFinanceiro(data, periodo, null, fimEm30Dias()), [data, periodo]);
  if (loading) return <p className="py-10 text-center text-sm text-muted-foreground">Carregando relatório financeiro...</p>;
  const totais = [['Faturamento', resumo.receitaCompetencia], ['Recebido', resumo.entradas], ['A receber', resumo.recebimentos], ['Custos', resumo.custoPeriodo], ['A pagar', resumo.aPagar], ['Resultado', resumo.resultado]];
  return <div className="space-y-4"><div className="flex flex-wrap items-center justify-between gap-3"><div><h3 className="font-semibold text-primary">Relatório financeiro consolidado</h3><p className="text-sm text-muted-foreground">Mesma fonte de Receitas, Despesas, Dashboard e Saúde das Obras.</p></div><div className="flex rounded-lg border bg-card p-1">{PERIODOS_FINANCEIROS.filter((p) => p.id !== 'custom').map((p) => <button key={p.id} onClick={() => setPeriodo(p.id)} className={`min-h-10 rounded px-3 text-sm ${periodo === p.id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}>{p.label}</button>)}</div></div><div className="grid grid-cols-2 gap-3 lg:grid-cols-6">{totais.map(([label, value]) => <div key={label} className="rounded-lg border bg-card p-3"><p className="text-xs text-muted-foreground">{label}</p><strong className="mt-1 block break-words">{fmtMoney(value)}</strong></div>)}</div>{resumo.divergenciasIntegridade.length > 0 && <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">Inconsistência financeira encontrada: {resumo.divergenciasIntegridade[0].nome} não está vinculada aos indicadores de uma obra válida.</div>}<ObrasExecutiveTable obras={resumo.obras} onOpen={(obra) => window.location.assign(`/saude-obras/${obra.id}?periodo=${periodo}`)} /></div>;
}