import React, { useMemo, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, ShieldCheck, Cpu, Wrench, History } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { avaliarTudo, alertasPorSeveridade, gerarResumoRegras } from '@/lib/regrasEngine';
import { COR_NIVEL } from '@/lib/sst';

const SEV_TONE = {
  Crítica: 'bg-red-100 text-red-700 border-red-200',
  Alta: 'bg-orange-100 text-orange-700 border-orange-200',
  Média: 'bg-amber-100 text-amber-800 border-amber-200',
  Baixa: 'bg-yellow-50 text-yellow-700 border-yellow-200',
};

export default function MotorRegrasPanel({ data }) {
  const alertas = useMemo(() => avaliarTudo(data), [data]);
  const sev = useMemo(() => alertasPorSeveridade(data), [data]);
  const resumo = useMemo(() => gerarResumoRegras(data), [data]);
  const criticos = alertas.filter((a) => ['Crítica', 'Alta'].includes(a.severidade)).slice(0, 6);

  const [logs, setLogs] = useState([]);
  useEffect(() => {
    (async () => {
      try {
        const l = await base44.entities.LogAutomacoes.list('-data_hora', 6);
        setLogs(l);
      } catch (e) { setLogs([]); }
    })();
  }, []);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 mb-8">
      <div className="flex items-center gap-2 mb-1">
        <ShieldCheck className="w-5 h-5 text-[#0b2545]" />
        <h2 className="text-lg font-semibold text-[#0b2545]">Motor de Regras SGI</h2>
        <span className="ml-auto text-xs text-slate-400">{alertas.length} alerta(s) ativos</span>
      </div>
      <p className="text-sm text-slate-500 mb-4 leading-relaxed">{resumo}</p>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        {['Crítica', 'Alta', 'Média', 'Baixa'].map((s) => (
          <div key={s} className={`rounded-lg border p-3 ${SEV_TONE[s]}`}>
            <div className="text-2xl font-bold">{sev[s] || 0}</div>
            <div className="text-xs font-medium">{s}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-3 mb-5">
        <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 flex items-center gap-2">
          <Wrench className="w-4 h-4 text-slate-500" />
          <div><div className="text-sm font-semibold text-[#0b2545]">{(data.inspecoes || []).length}</div><div className="text-xs text-slate-400">Inspeções</div></div>
        </div>
        <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 flex items-center gap-2">
          <Cpu className="w-4 h-4 text-slate-500" />
          <div><div className="text-sm font-semibold text-[#0b2545]">{(data.maquinas || []).length}</div><div className="text-xs text-slate-400">Máquinas</div></div>
        </div>
        <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-slate-500" />
          <div><div className="text-sm font-semibold text-[#0b2545]">{criticos.length}</div><div className="text-xs text-slate-400">Críticos/Altos</div></div>
        </div>
      </div>

      {criticos.length > 0 && (
        <div className="space-y-2">
          {criticos.map((a, i) => (
            <div key={i} className="flex items-center gap-2 text-sm border-b border-slate-50 pb-2 last:border-0">
              <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${COR_NIVEL[a.nivel]}`}>{a.nivelLabel}</span>
              <span className="text-slate-600 flex-1 truncate"><span className="font-medium text-[#0b2545]">{a.nome}</span> · {a.item}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full border ${SEV_TONE[a.severidade]}`}>{a.severidade}</span>
              {a.funcionario_id && <Link to={`/funcionarios/${a.funcionario_id}`} className="text-xs text-[#0b2545] hover:underline">ver</Link>}
            </div>
          ))}
        </div>
      )}

      {logs.length > 0 && (
        <div className="mt-4 pt-3 border-t border-slate-100">
          <div className="flex items-center gap-1.5 mb-2"><History className="w-4 h-4 text-slate-400" /><span className="text-xs font-medium text-slate-500">Histórico de automações</span></div>
          <div className="space-y-1.5">
            {logs.map((l) => (
              <div key={l.id} className="flex items-center gap-2 text-xs text-slate-500">
                <span className="text-slate-400 whitespace-nowrap">{new Date(l.data_hora).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>
                <span className="font-medium text-[#0b2545]">{l.regra}</span>
                <span className="text-slate-400 truncate">· {l.registro_afetado}</span>
                <span className="ml-auto text-emerald-600">{l.resultado}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
        <span className="text-xs text-slate-400">Regras centralizadas · editáveis em RegrasSST</span>
        <Link to="/relatorios" className="text-xs font-medium text-[#0b2545] hover:underline">Ver relatórios →</Link>
      </div>
    </section>
  );
}