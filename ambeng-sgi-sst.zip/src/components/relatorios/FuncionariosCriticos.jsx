import React, { useMemo } from 'react';
import { getStatus } from '@/lib/sst';
import { UserX } from 'lucide-react';

const BADGE = { red: 'bg-red-50 text-red-700 border-red-200', amber: 'bg-amber-50 text-amber-700 border-amber-200' };

export default function FuncionariosCriticos({ data }) {
  const rows = useMemo(() => {
    const map = {};
    const get = (id) => { if (!map[id]) map[id] = { f: data.funcionarios.find((x) => x.id === id), list: [] }; return map[id]; };
    data.asos.filter((a) => getStatus(a.data_validade) === 'Vencido').forEach((a) => get(a.funcionario_id).list.push({ t: 'ASO vencido', tone: 'red' }));
    data.treinamentos.filter((t) => getStatus(t.data_validade) === 'Vencido').forEach((t) => get(t.funcionario_id).list.push({ t: 'Treinamento vencido', tone: 'red' }));
    const comInt = new Set(data.integracoes.map((i) => i.funcionario_id));
    const comEpi = new Set(data.epis.map((e) => e.funcionario_id));
    data.funcionarios.forEach((f) => { if (!comInt.has(f.id)) get(f.id).list.push({ t: 'Sem integração', tone: 'amber' }); if (!comEpi.has(f.id)) get(f.id).list.push({ t: 'Sem EPI', tone: 'amber' }); });
    data.ocorrencias.filter((o) => o.situacao !== 'Encerrada').forEach((o) => get(o.funcionario_id).list.push({ t: 'Ocorrência aberta', tone: 'red' }));
    return Object.values(map).filter((r) => r.f && r.list.length > 0).sort((a, b) => b.list.length - a.list.length);
  }, [data]);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 mb-4">
      <div className="flex items-center gap-2 mb-4"><UserX className="w-5 h-5 text-red-600" /><h3 className="font-semibold text-[#0b2545]">Funcionários Críticos</h3><span className="ml-auto text-xs text-slate-400">{rows.length} colaborador(es)</span></div>
      {rows.length === 0 ? <p className="text-sm text-emerald-700">Nenhum colaborador crítico. Todos em conformidade.</p> : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {rows.map((r) => (
            <div key={r.f.id} className="border border-slate-100 rounded-lg p-3">
              <p className="text-sm font-medium text-[#0b2545]">{r.f.nome}</p>
              <p className="text-xs text-slate-400 mb-2">{r.f.funcao || '—'} · {r.f.obra || '—'}</p>
              <div className="flex flex-wrap gap-1.5">
                {r.list.map((p, i) => <span key={i} className={`text-[11px] px-2 py-0.5 rounded-full border ${BADGE[p.tone]}`}>{p.t}</span>)}
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}