import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from 'recharts';
import GravidadeChart from '@/components/GravidadeChart';
import { getStatus } from '@/lib/sst';

function countBy(arr, key) {
  const m = {};
  arr.forEach((i) => { const v = i[key] || 'Não informado'; m[v] = (m[v] || 0) + 1; });
  return Object.entries(m).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 8);
}

const STATUS_COLORS = { 'Em dia': '#059669', 'A vencer': '#d97706', 'Vencido': '#dc2626' };

function StatusDonut({ itens, titulo }) {
  const data = useMemo(() => {
    const c = { 'Em dia': 0, 'A vencer': 0, 'Vencido': 0 };
    itens.forEach((i) => c[getStatus(i.data_validade)]++);
    return Object.entries(c).map(([name, value]) => ({ name, value }));
  }, [itens]);
  const total = data.reduce((s, d) => s + d.value, 0);
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-1">{titulo}</h3>
      <p className="text-xs text-slate-400 mb-3">{total} registro(s)</p>
      {total === 0 ? <p className="text-sm text-slate-400 py-10 text-center">Sem dados.</p> : (
        <ResponsiveContainer width="100%" height={220}>
          <PieChart><Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={45} outerRadius={80} paddingAngle={2}>
            {data.map((d) => <Cell key={d.name} fill={STATUS_COLORS[d.name]} />)}
          </Pie><Tooltip /><Legend /></PieChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

function BarCard({ titulo, data }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-3">{titulo}</h3>
      {data.length === 0 ? <p className="text-sm text-slate-400 py-10 text-center">Sem dados.</p> : (
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={data} margin={{ top: 5, right: 10, left: -15, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} />
            <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: '#64748b' }} />
            <Tooltip />
            <Bar dataKey="value" fill="#0b2545" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

export default function RelatoriosGerenciais({ data }) {
  return (
    <div className="space-y-4">
      <div className="grid lg:grid-cols-3 gap-4">
        <StatusDonut itens={data.asos} titulo="Status dos ASOs" />
        <StatusDonut itens={data.treinamentos} titulo="Status dos Treinamentos" />
        <StatusDonut itens={data.epis} titulo="Status dos EPIs" />
      </div>
      <div className="grid lg:grid-cols-2 gap-4">
        <BarCard titulo="Funcionários por obra" data={countBy(data.funcionarios, 'obra')} />
        <BarCard titulo="Funcionários por empresa" data={countBy(data.funcionarios, 'empresa')} />
        <BarCard titulo="Funcionários por cargo" data={countBy(data.funcionarios, 'funcao')} />
        <GravidadeChart ocorrencias={data.ocorrencias} />
      </div>
    </div>
  );
}