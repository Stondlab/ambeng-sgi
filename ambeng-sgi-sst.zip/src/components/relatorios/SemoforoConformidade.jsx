import React from 'react';
import { semaforo } from '@/lib/relatorios';

const DOT = { green: 'bg-emerald-500', amber: 'bg-amber-500', red: 'bg-red-500', gray: 'bg-slate-300' };
const TXT = { green: 'text-emerald-700', amber: 'text-amber-700', red: 'text-red-700', gray: 'text-slate-400' };
const LABEL = { green: 'Conforme', amber: 'Atenção', red: 'Crítico', gray: 'Sem cadastro' };
const KEY = { 'Treinamentos': 'treinamentos', 'ASOs': 'asos', 'EPIs': 'epis', 'DDS': 'dds', 'Integrações': 'integracoes', 'Documentação': 'documentos', 'Ocorrências': 'ocorrencias' };

export default function SemoforoConformidade({ data, onNav, resultadoConformidade = null }) {
  const items = semaforo(data, resultadoConformidade);
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-4">Semáforo de Conformidade</h3>
      <div className="grid grid-cols-2 gap-2">
        {items.map((it) => (
          <button key={it.label} disabled={it.disabled} onClick={() => !it.disabled && onNav('operacionais', KEY[it.label])}
            className="flex items-center justify-between gap-2 border border-slate-100 rounded-lg p-3 hover:bg-slate-50 disabled:opacity-60 text-left">
            <span className="text-sm text-slate-700">{it.label}</span>
            <span className={`flex items-center gap-1.5 text-xs font-medium ${TXT[it.tone]}`}>
              <span className={`w-2.5 h-2.5 rounded-full ${DOT[it.tone]}`} />{LABEL[it.tone]}
            </span>
          </button>
        ))}
      </div>
    </section>
  );
}