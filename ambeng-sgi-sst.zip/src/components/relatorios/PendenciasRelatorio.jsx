import React from 'react';
import { pendencias } from '@/lib/relatorios';
import { CheckCircle2 } from 'lucide-react';

const DOT = { red: 'bg-red-500', amber: 'bg-amber-500', green: 'bg-emerald-500' };
const TXT = { red: 'text-red-700', amber: 'text-amber-700', green: 'text-emerald-700' };
const PRIO = { 1: 'Alta', 2: 'Média', 3: 'Baixa' };

export default function PendenciasRelatorio({ data }) {
  const list = pendencias(data);
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-[#0b2545]">Painel de Pendências</h3>
        <span className="text-sm text-slate-400">{list.length} item(ns)</span>
      </div>
      {list.length === 0 ? (
        <div className="flex items-center gap-2 text-emerald-700"><CheckCircle2 className="w-5 h-5" /><span className="text-sm">Nenhuma pendência. Tudo em dia.</span></div>
      ) : (
        <table className="w-full text-sm">
          <thead className="text-xs text-slate-400 border-b border-slate-100">
            <tr><th className="text-left py-2 font-medium">Prioridade</th><th className="text-left font-medium">Tipo</th><th className="text-left font-medium">Descrição</th><th className="text-left font-medium">Situação</th><th className="text-left font-medium">Detalhe</th></tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {list.map((p, i) => (
              <tr key={i}>
                <td className="py-2"><span className={`inline-flex items-center gap-1.5 ${TXT[p.tone]} font-medium`}><span className={`w-2 h-2 rounded-full ${DOT[p.tone]}`} />{PRIO[p.prio]}</span></td>
                <td className="text-slate-600">{p.tipo}</td>
                <td className="text-slate-700">{p.label}</td>
                <td className="text-slate-500">{p.status}</td>
                <td className="text-slate-400 text-xs">{p.detalhe}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}