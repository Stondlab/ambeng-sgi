import React, { useMemo } from 'react';
import { getStatus } from '@/lib/sst';
import { CheckCircle2, Circle, ListChecks } from 'lucide-react';

export default function TarefasDoDia({ data, onNav }) {
  const hoje = new Date().toISOString().slice(0, 10);
  const tasks = useMemo(() => {
    const ddsHoje = data.dds.filter((d) => d.data === hoje).length;
    const trePend = data.treinamentos.filter((t) => ['Vencido', 'A vencer'].includes(getStatus(t.data_validade))).length;
    const nc = data.ocorrencias.filter((o) => o.tipo === 'Não Conformidade' && o.situacao !== 'Encerrada').length;
    const semInt = data.funcionarios.length - new Set(data.integracoes.map((i) => i.funcionario_id)).size;
    return [
      { label: 'Realizar DDS', done: ddsHoje > 0, nav: ['operacionais', 'dds'] },
      { label: 'Executar APR', done: false, nav: null },
      { label: 'Inspecionar máquinas', done: false, nav: null },
      { label: 'Registrar integração', done: semInt === 0, nav: ['operacionais', 'integracoes'] },
      { label: 'Atualizar treinamentos', done: trePend === 0, nav: ['operacionais', 'treinamentos'] },
      { label: 'Fechar não conformidades', done: nc === 0, nav: ['operacionais', 'nc'] },
    ];
  }, [data, hoje]);

  const pend = tasks.filter((t) => !t.done).length;
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><ListChecks className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Tarefas do Dia</h3><span className="ml-auto text-xs text-slate-400">{pend} pendente(s)</span></div>
      <div className="space-y-2">
        {tasks.map((t, i) => (
          <button key={i} disabled={!t.nav} onClick={() => t.nav && onNav(...t.nav)} className="w-full flex items-center gap-3 border border-slate-100 rounded-lg p-3 text-left hover:bg-slate-50 disabled:opacity-70">
            {t.done ? <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" /> : <Circle className="w-5 h-5 text-amber-500 shrink-0" />}
            <span className={`text-sm ${t.done ? 'text-slate-400 line-through' : 'text-slate-700'}`}>{t.label}</span>
          </button>
        ))}
      </div>
    </section>
  );
}