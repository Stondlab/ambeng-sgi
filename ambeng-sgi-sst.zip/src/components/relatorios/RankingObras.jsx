import React, { useMemo } from 'react';
import { getStatus } from '@/lib/sst';
import { obrasAtivasParaLancamento } from '@/lib/obraDisponibilidade';

export default function RankingObras({ data }) {
  const rows = useMemo(() => {
    const map = {};
    const nomesAtivos = new Set(obrasAtivasParaLancamento(data.obras || []).map((obra) => obra.nome));
    const obraPorFuncionario = new Map();
    data.funcionarios.filter((f) => !f.obra || nomesAtivos.has(f.obra)).forEach((f) => {
      const k = f.obra || 'Sem obra';
      obraPorFuncionario.set(f.id, k);
      if (!map[k]) map[k] = { obra: k, ids: new Set(), pend: 0, nc: 0, tre: 0, dds: 0, asos: 0, lastAcc: null };
      map[k].ids.add(f.id);
    });
    const fObra = (id) => obraPorFuncionario.get(id) || null;
    data.treinamentos.forEach((t) => { const k = fObra(t.funcionario_id); if (k && map[k]) map[k].tre++; });
    data.dds.forEach((d) => { const k = fObra(d.funcionario_id); if (k && map[k]) map[k].dds++; });
    data.asos.forEach((a) => { const k = fObra(a.funcionario_id); if (k && map[k]) map[k].asos++; });
    data.asos.forEach((a) => { const k = fObra(a.funcionario_id); if (k && map[k] && getStatus(a.data_validade) === 'Vencido') map[k].pend++; });
    data.treinamentos.forEach((t) => { const k = fObra(t.funcionario_id); if (k && map[k] && getStatus(t.data_validade) === 'Vencido') map[k].pend++; });
    data.epis.forEach((e) => { const k = fObra(e.funcionario_id); if (k && map[k] && getStatus(e.data_validade) === 'Vencido') map[k].pend++; });
    data.ocorrencias.forEach((o) => { const k = fObra(o.funcionario_id); if (k && map[k]) { if (o.tipo === 'Não Conformidade') map[k].nc++; if (o.tipo === 'Acidente') { const d = new Date(o.data); if (!map[k].lastAcc || d > map[k].lastAcc) map[k].lastAcc = d; } } });
    return Object.values(map).map((r) => ({ obra: r.obra, funcs: r.ids.size, conformidade: Math.max(0, 100 - r.pend * 10), pend: r.pend, nc: r.nc, tre: r.tre, dds: r.dds, asos: r.asos, dias: r.lastAcc ? Math.max(0, Math.round((Date.now() - r.lastAcc) / 86400000)) : '—' })).sort((a, b) => b.conformidade - a.conformidade);
  }, [data]);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-4">Ranking das Obras</h3>
      {rows.length === 0 ? <p className="text-sm text-slate-400">Sem dados.</p> : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs text-slate-400 border-b border-slate-100">
              <tr><th className="text-left py-2 pr-3">Obra</th><th className="text-right px-2">Funcs</th><th className="text-right px-2">Conf.</th><th className="text-right px-2">Pend</th><th className="text-right px-2">NC</th><th className="text-right px-2">Dias s/acc</th><th className="text-right px-2">Trein</th><th className="text-right px-2">DDS</th><th className="text-right pl-2">ASOs</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {rows.map((r) => (
                <tr key={r.obra}>
                  <td className="py-2 pr-3 font-medium text-slate-700">{r.obra}</td>
                  <td className="text-right px-2 text-slate-600">{r.funcs}</td>
                  <td className={`text-right px-2 font-medium ${r.conformidade >= 90 ? 'text-emerald-700' : r.conformidade >= 70 ? 'text-amber-700' : 'text-red-700'}`}>{r.conformidade}%</td>
                  <td className="text-right px-2 text-slate-600">{r.pend}</td>
                  <td className="text-right px-2 text-slate-600">{r.nc}</td>
                  <td className="text-right px-2 text-slate-600">{r.dias}</td>
                  <td className="text-right px-2 text-slate-600">{r.tre}</td>
                  <td className="text-right px-2 text-slate-600">{r.dds}</td>
                  <td className="text-right pl-2 text-slate-600">{r.asos}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}