import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { diasRestantes, fmt } from '@/lib/sst';
import { CalendarClock } from 'lucide-react';

function corEvento(data_validade) {
  const d = diasRestantes(data_validade);
  if (d === null) return { cor: 'bg-emerald-500', label: 'Em dia' };
  if (d < 0) return { cor: 'bg-slate-900', label: 'Vencido' };
  if (d <= 7) return { cor: 'bg-red-500', label: 'Até 7 dias' };
  if (d <= 15) return { cor: 'bg-orange-500', label: 'Até 15 dias' };
  if (d <= 30) return { cor: 'bg-amber-400', label: 'Até 30 dias' };
  return { cor: 'bg-emerald-500', label: 'Em dia' };
}

export default function CalendarioSST({ data }) {
  const events = useMemo(() => {
    const nome = (id) => data.funcionarios.find((x) => x.id === id)?.nome || '—';
    const ev = [];
    const add = (date, tipo, titulo, funcId, extra = '') =>
      date && ev.push({ date, tipo, titulo: titulo || tipo, funcId, func: nome(funcId), extra });

    data.asos.forEach((a) => add(a.data_validade, 'ASO', `Venc. ASO ${a.tipo || ''}`, a.funcionario_id));
    data.treinamentos.forEach((t) => add(t.data_validade, 'Treinamento', `Venc. ${t.norma_curso || 'Treinamento'}`, t.funcionario_id));
    data.epis.forEach((e) => add(e.data_validade, 'EPI', `Venc. EPI ${e.item || ''}`, e.funcionario_id));
    data.integracoes.forEach((i) => add(i.data, 'Integração', i.tipo || 'Integração', i.funcionario_id));
    data.inspecoes.forEach((i) => add(i.data_proxima, 'Inspeção', i.tipo || 'Inspeção', i.funcionario_id));
    data.maquinas.forEach((m) => {
      add(m.proxima_inspecao, 'Máquina', `Inspeção ${m.nome || ''}`, null, m.tag);
      add(m.proxima_manutencao, 'Máquina', `Manutenção ${m.nome || ''}`, null, m.tag);
      add(m.proxima_calibracao, 'Calibração', `Calibração ${m.nome || ''}`, null, m.tag);
    });
    data.documentos.forEach((d) => add(d.data_upload, 'Documento', d.nome || 'Documento', d.funcionario_id));
    data.funcionarios.forEach((f) => add(f.cnh_validade, 'CNH', `Venc. CNH ${f.nome || ''}`, f.id));
    return ev
      .filter((e) => e.date)
      .map((e) => ({ ...e, ...corEvento(e.date) }))
      .sort((a, b) => new Date(a.date) - new Date(b.date))
      .slice(0, 20);
  }, [data]);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4"><CalendarClock className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Calendário SST</h3></div>
      <div className="flex flex-wrap gap-2 mb-3 text-[11px]">
        {[['bg-emerald-500', 'Em dia'], ['bg-amber-400', 'Até 30d'], ['bg-orange-500', 'Até 15d'], ['bg-red-500', 'Até 7d'], ['bg-slate-900', 'Vencido']].map(([c, l]) => (
          <span key={l} className="inline-flex items-center gap-1 text-slate-500"><span className={`w-2.5 h-2.5 rounded-full ${c}`} />{l}</span>
        ))}
      </div>
      {events.length === 0 ? <p className="text-sm text-slate-400">Nenhum evento próximo.</p> : (
        <div className="space-y-2 max-h-80 overflow-y-auto">
          {events.map((e, i) => {
            const inner = (
              <>
                <div className="text-center w-12 shrink-0"><p className="text-lg font-bold text-[#0b2545] leading-none">{fmt(e.date).slice(0, 2)}</p><p className="text-[10px] text-slate-400 uppercase">{fmt(e.date).slice(3, 5)}</p></div>
                <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${e.cor}`} />
                <div className="flex-1 min-w-0"><p className="text-sm text-slate-700 truncate">{e.titulo}</p><p className="text-xs text-slate-400">{e.tipo} · {e.func}{e.extra ? ` · ${e.extra}` : ''}</p></div>
              </>
            );
            return e.funcId ? (
              <Link key={i} to={`/funcionarios/${e.funcId}`} className="flex items-center gap-3 border border-slate-100 rounded-lg p-2.5 hover:bg-slate-50 transition-colors">{inner}</Link>
            ) : (
              <div key={i} className="flex items-center gap-3 border border-slate-100 rounded-lg p-2.5">{inner}</div>
            );
          })}
        </div>
      )}
    </section>
  );
}