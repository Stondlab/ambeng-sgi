import React, { useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import { conformidade } from '@/lib/relatorios';
import { getStatus } from '@/lib/sst';
import { Sparkles, Send } from 'lucide-react';

export default function AssistenteSGI({ data }) {
  const [q, setQ] = useState('');
  const [obra, setObra] = useState('Todas as obras');
  const [resp, setResp] = useState('');
  const [loading, setLoading] = useState(false);
  const { indice } = conformidade(data);

  const obras = useMemo(() => (data.obras || []).filter((item) => item.ativa !== false).map((item) => item.nome).filter(Boolean), [data.obras]);
  const ctx = useMemo(() => {
    const todas = obra === 'Todas as obras';
    const funcionarios = todas ? data.funcionarios : data.funcionarios.filter((f) => f.obra === obra || f.obra_padrao === obra);
    const ids = new Set(funcionarios.map((f) => f.id));
    const porPessoa = (rows) => todas ? rows : rows.filter((r) => ids.has(r.funcionario_id));
    const ocorrencias = todas ? data.ocorrencias : data.ocorrencias.filter((r) => r.obra === obra);
    const inspecoes = todas ? (data.inspecoes || []) : (data.inspecoes || []).filter((r) => r.obra === obra);
    const treinamentos = porPessoa(data.treinamentos);
    const epis = porPessoa(data.epis);
    const asos = porPessoa(data.asos);
    const acidentes = ocorrencias.filter((r) => String(r.tipo || '').toLowerCase().includes('acidente')).length;
    const treinamentosVencidos = treinamentos.filter((r) => getStatus(r.data_validade) === 'Vencido').length;
    const episVencidos = epis.filter((r) => getStatus(r.data_validade) === 'Vencido').length;
    const asosVencidos = asos.filter((r) => getStatus(r.data_validade) === 'Vencido').length;
    const naoConformidades = inspecoes.filter((r) => r.status === 'Não Conforme').length + ocorrencias.filter((r) => r.tipo === 'Não Conformidade' && !['Resolvida','Cancelada'].includes(r.situacao)).length;
    return `Escopo: ${obra}. Funcionários: ${funcionarios.length}. Acidentes registrados: ${acidentes}. Treinamentos vencidos: ${treinamentosVencidos}. EPIs desatualizados ou vencidos: ${episVencidos}. ASOs vencidos: ${asosVencidos}. Não conformidades abertas: ${naoConformidades}. Índice geral de conformidade SST: ${indice}%.`;
  }, [data, indice, obra]);

  const sugeridas = ['Teve acidente?', 'Há treinamentos vencidos?', 'Quais EPIs estão desatualizados?', 'Como está a conformidade SST?', 'Gere um resumo executivo com riscos e ações.'];

  const ask = async (pergunta) => {
    if (!pergunta.trim()) return;
    setLoading(true); setResp('');
    try {
      const r = await base44.integrations.Core.InvokeLLM({ prompt: `Você é o Assistente SGI de Segurança e Saúde do Trabalho. Responda em português, de forma curta e objetiva, usando apenas os dados fornecidos. Identifique riscos, sugira ações práticas e, quando solicitado, gere um resumo executivo com prioridades por obra.\n\nDados: ${ctx}\n\nPergunta: ${pergunta}` });
      setResp(typeof r === 'string' ? r : JSON.stringify(r));
    } catch (e) { setResp('Não foi possível obter resposta agora.'); }
    setLoading(false);
  };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-3"><Sparkles className="w-5 h-5 text-amber-500" /><h3 className="font-semibold text-[#0b2545]">Assistente SGI</h3></div>
      <p className="text-sm text-slate-500 mb-3">Selecione a obra e pergunte sobre acidentes, treinamentos, EPIs, conformidade, riscos e ações.</p>
      <label className="mb-3 block text-sm font-medium text-foreground">Qual obra?<select value={obra} onChange={(e)=>setObra(e.target.value)} className="mt-1 flex h-11 w-full rounded-md border border-input bg-card px-3 text-sm"><option>Todas as obras</option>{obras.map((nome)=><option key={nome}>{nome}</option>)}</select></label>
      <div className="flex flex-wrap gap-2 mb-3">
        {sugeridas.map((s) => <button key={s} onClick={() => { setQ(s); ask(s); }} className="text-xs px-3 py-1 rounded-full border border-slate-200 text-slate-600 hover:border-[#0b2545] hover:text-[#0b2545]">{s}</button>)}
      </div>
      <div className="flex gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && ask(q)} placeholder="Digite sua pergunta..." className="flex-1 h-9 rounded-md border border-input bg-transparent px-3 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" />
        <Button onClick={() => ask(q)} disabled={loading}><Send className="w-4 h-4" /></Button>
      </div>
      {loading && <p className="text-sm text-slate-400 mt-3">Analisando...</p>}
      {resp && !loading && <div className="mt-3 bg-slate-50 border border-slate-100 rounded-lg p-3 text-sm text-slate-700 whitespace-pre-wrap">{resp}</div>}
    </section>
  );
}