import React from 'react';
import { conformidade } from '@/lib/relatorios';
import StatCard from '@/components/StatCard';
import { Users, Stethoscope, GraduationCap, HardHat, CalendarCheck, Users as UsersIcon, AlertTriangle, ClipboardList } from 'lucide-react';
import { getStatus } from '@/lib/sst';

const TXT = { green: 'text-emerald-700', amber: 'text-amber-700', red: 'text-red-700' };
const BAR = { green: 'bg-emerald-500', amber: 'bg-amber-500', red: 'bg-red-500' };

export default function RelatorioExecutivo({ data }) {
  const { indice, tone, areas } = conformidade(data);
  const pend = [...data.asos, ...data.treinamentos, ...data.epis].filter((i) => getStatus(i.data_validade) !== 'Em dia').length;
  const stats = [
    { label: 'Funcionários', value: data.funcionarios.length, icon: Users, tone: 'navy' },
    { label: 'ASOs', value: data.asos.length, icon: Stethoscope, tone: 'navy' },
    { label: 'Treinamentos', value: data.treinamentos.length, icon: GraduationCap, tone: 'navy' },
    { label: 'EPIs', value: data.epis.length, icon: HardHat, tone: 'navy' },
    { label: 'DDS', value: data.dds.length, icon: CalendarCheck, tone: 'navy' },
    { label: 'Integrações', value: data.integracoes.length, icon: UsersIcon, tone: 'navy' },
    { label: 'Ocorrências', value: data.ocorrencias.length, icon: AlertTriangle, tone: 'navy' },
    { label: 'Pendências', value: pend, icon: ClipboardList, tone: 'amber' },
  ];
  const conclusao = tone === 'green'
    ? 'O sistema apresenta bom nível de conformidade. Recomenda-se manter as rotinas de monitoramento.'
    : tone === 'amber'
    ? 'Atenção: existem pendências que exigem ações corretivas para elevar o índice de conformidade.'
    : 'Conformidade crítica. Ações imediatas são necessárias para regularizar vencimentos e pendências.';
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {stats.map((s) => <StatCard key={s.label} {...s} />)}
      </div>
      <section className="bg-white border border-slate-200 rounded-xl p-5 flex items-center gap-6">
        <div className="text-center">
          <p className="text-xs text-slate-400 mb-1">Índice Geral de Conformidade</p>
          <p className={`text-5xl font-bold ${TXT[tone]}`}>{indice}%</p>
        </div>
        <div className="flex-1">
          <div className="h-3 bg-slate-100 rounded-full overflow-hidden"><div className={`h-full ${BAR[tone]}`} style={{ width: `${indice}%` }} /></div>
          <p className="text-sm text-slate-600 mt-2">{conclusao}</p>
        </div>
      </section>
      <section className="bg-white border border-slate-200 rounded-xl p-5">
        <h3 className="font-semibold text-[#0b2545] mb-4">Conformidade por área</h3>
        <div className="space-y-3">
          {areas.map((a) => (
            <div key={a.area} className="flex items-center gap-3">
              <div className="w-36 text-sm text-slate-600 shrink-0">{a.area}</div>
              <div className="flex-1 h-2.5 bg-slate-100 rounded-full overflow-hidden"><div className={`h-full ${BAR[a.tone]}`} style={{ width: `${a.pct}%` }} /></div>
              <div className="w-14 text-right text-sm font-medium"><span className={TXT[a.tone]}>{a.pct}%</span></div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}