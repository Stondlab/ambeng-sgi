import React, { useMemo } from 'react';

export default function RankingEmpresas({ data }) {
  const rows = useMemo(() => {
    const map = {};
    const empresaPorFuncionario = new Map();
    data.funcionarios.forEach((f) => {
      const k = f.empresa || 'Sem empresa';
      empresaPorFuncionario.set(f.id, k);
      if (!map[k]) map[k] = { empresa: k, ids: new Set(), tre: 0, int: 0, asos: 0, oco: 0, pend: 0 };
      map[k].ids.add(f.id);
    });
    const fEmp = (id) => empresaPorFuncionario.get(id) || null;
    data.treinamentos.forEach((t) => { const k = fEmp(t.funcionario_id); if (k && map[k]) map[k].tre++; });
    data.integracoes.forEach((i) => { const k = fEmp(i.funcionario_id); if (k && map[k]) map[k].int++; });
    data.asos.forEach((a) => { const k = fEmp(a.funcionario_id); if (k && map[k]) map[k].asos++; });
    data.ocorrencias.forEach((o) => { const k = fEmp(o.funcionario_id); if (k && map[k]) map[k].oco++; });
    return Object.values(map).map((r) => {
      return { empresa: r.empresa, funcs: r.ids.size, tre: r.tre, int: r.int, asos: r.asos, oco: r.oco, conformidade: Math.max(0, 100 - r.oco * 5 - r.pend * 5) };
    }).sort((a, b) => b.conformidade - a.conformidade);
  }, [data]);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-4">Ranking das Empresas Terceiras</h3>
      {rows.length === 0 ? <p className="text-sm text-slate-400">Sem dados.</p> : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs text-slate-400 border-b border-slate-100">
              <tr><th className="text-left py-2 pr-3">Empresa</th><th className="text-right px-2">Funcs</th><th className="text-right px-2">Trein</th><th className="text-right px-2">Integr.</th><th className="text-right px-2">ASOs</th><th className="text-right px-2">Ocorr.</th><th className="text-right pl-2">Conf.</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {rows.map((r) => (
                <tr key={r.empresa}>
                  <td className="py-2 pr-3 font-medium text-slate-700">{r.empresa}</td>
                  <td className="text-right px-2 text-slate-600">{r.funcs}</td>
                  <td className="text-right px-2 text-slate-600">{r.tre}</td>
                  <td className="text-right px-2 text-slate-600">{r.int}</td>
                  <td className="text-right px-2 text-slate-600">{r.asos}</td>
                  <td className="text-right px-2 text-slate-600">{r.oco}</td>
                  <td className={`text-right pl-2 font-medium ${r.conformidade >= 90 ? 'text-emerald-700' : r.conformidade >= 70 ? 'text-amber-700' : 'text-red-700'}`}>{r.conformidade}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}