import React from 'react';
import { Button } from '@/components/ui/button';
import { getStatus } from '@/lib/sst';
import { conformidade } from '@/lib/relatorios';
import { AlertOctagon, AlertTriangle, Info } from 'lucide-react';

const HDR = { red: 'text-red-700 bg-red-50', amber: 'text-amber-700 bg-amber-50', green: 'text-emerald-700 bg-emerald-50' };

export default function RecomendacoesInteligentes({ data, onNav }) {
  const crit = [], aten = [], info = [];
  const asosV = data.asos.filter((a) => getStatus(a.data_validade) === 'Vencido').length;
  const treV = data.treinamentos.filter((t) => getStatus(t.data_validade) === 'Vencido').length;
  const epiV = data.epis.filter((e) => getStatus(e.data_validade) === 'Vencido').length;
  const nc = data.ocorrencias.filter((o) => o.tipo === 'Não Conformidade' && o.situacao !== 'Encerrada').length;
  if (asosV > 0) crit.push({ titulo: 'ASOs vencidos', desc: `Existem ${asosV} ASO(s) vencido(s) exigindo recadastro.`, acao: 'Gerar Relatório', nav: ['operacionais', 'asos'] });
  if (treV > 0) crit.push({ titulo: 'Treinamentos vencidos', desc: `Existem ${treV} treinamento(s) vencido(s).`, acao: 'Gerar Relatório', nav: ['operacionais', 'treinamentos'] });
  if (epiV > 0) crit.push({ titulo: 'EPIs vencidos', desc: `Existem ${epiV} EPI(s) com validade vencida.`, acao: 'Gerar Relatório', nav: ['operacionais', 'epis'] });
  if (nc > 0) crit.push({ titulo: 'Não Conformidades abertas', desc: `Há ${nc} NC(s) sem encerramento.`, acao: 'Ver Ocorrências', nav: ['operacionais', 'nc'] });

  const treA = data.treinamentos.filter((t) => getStatus(t.data_validade) === 'A vencer').length;
  const asosA = data.asos.filter((a) => getStatus(a.data_validade) === 'A vencer').length;
  const semInt = data.funcionarios.length - new Set(data.integracoes.map((i) => i.funcionario_id)).size;
  const hoje = new Date().toISOString().slice(0, 10);
  const ddsHoje = data.dds.filter((d) => d.data === hoje).length;
  if (treA > 0) aten.push({ titulo: 'Treinamentos vencendo', desc: `${treA} treinamento(s) vencendo em até 30 dias.`, acao: 'Gerar Relatório', nav: ['operacionais', 'treinamentos'] });
  if (asosA > 0) aten.push({ titulo: 'ASOs vencendo', desc: `${asosA} ASO(s) vencendo em até 30 dias.`, acao: 'Gerar Relatório', nav: ['operacionais', 'asos'] });
  if (semInt > 0) aten.push({ titulo: 'Integrações pendentes', desc: `${semInt} colaborador(es) sem integração.`, acao: 'Ver Integrações', nav: ['operacionais', 'integracoes'] });
  if (ddsHoje === 0) aten.push({ titulo: 'DDS do dia', desc: 'DDS de hoje ainda não registrado.', acao: 'Ver DDS', nav: ['operacionais', 'dds'] });

  const { indice } = conformidade(data);
  info.push({ titulo: 'Índice de conformidade', desc: `A obra está com índice geral de ${indice}%.`, acao: 'Ver Auditoria', nav: ['auditorias'] });

  const groups = [['Crítico', 'red', AlertOctagon, crit], ['Atenção', 'amber', AlertTriangle, aten], ['Informativo', 'green', Info, info]];
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 mb-4">
      <h3 className="font-semibold text-[#0b2545] mb-4">Recomendações Inteligentes</h3>
      <div className="grid lg:grid-cols-3 gap-4">
        {groups.map(([titulo, tone, Icon, list]) => (
          <div key={titulo}>
            <div className={`flex items-center gap-2 rounded-lg px-3 py-2 mb-3 ${HDR[tone]}`}>
              <Icon className="w-4 h-4" /><span className="text-sm font-semibold">{titulo}</span>
              <span className="ml-auto text-xs opacity-70">{list.length}</span>
            </div>
            <div className="space-y-2">
              {list.length === 0 ? <p className="text-xs text-slate-400 px-3">Nenhuma recomendação.</p> :
                list.map((r, i) => (
                  <div key={i} className="border border-slate-100 rounded-lg p-3">
                    <p className="text-sm font-medium text-[#0b2545]">{r.titulo}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{r.desc}</p>
                    <Button size="sm" variant="outline" className="mt-2 h-7 text-xs" onClick={() => onNav(...r.nav)}>{r.acao}</Button>
                  </div>
                ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}