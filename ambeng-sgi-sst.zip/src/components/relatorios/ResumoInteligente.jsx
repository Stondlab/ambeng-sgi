import React from 'react';
import { resumoText } from '@/lib/relatorios';
import { FileText } from 'lucide-react';

export default function ResumoInteligente({ data }) {
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-3">
        <FileText className="w-5 h-5 text-[#0b2545]" />
        <h3 className="font-semibold text-[#0b2545]">Resumo Inteligente do SGI</h3>
      </div>
      <p className="text-sm leading-relaxed text-slate-700">{resumoText(data)}</p>
      <p className="text-xs text-slate-400 mt-3">Atualizado automaticamente conforme os dados cadastrados.</p>
    </section>
  );
}