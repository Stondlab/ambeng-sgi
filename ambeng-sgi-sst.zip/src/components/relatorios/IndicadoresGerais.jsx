import React from 'react';
import StatCard from '@/components/StatCard';
import GravidadeChart from '@/components/GravidadeChart';
import StatusMesChart from '@/components/StatusMesChart';
import { getStatus } from '@/lib/sst';
import { Users, Stethoscope, GraduationCap, HardHat, CalendarCheck, Users as UsersIcon, AlertTriangle, ClipboardCheck, ShieldAlert } from 'lucide-react';
import { taxaAcidentesMes } from '@/lib/relatorios';

export default function IndicadoresGerais({ data }) {
  const valid = (arr) => arr.filter((i) => getStatus(i.data_validade) === 'Em dia').length;
  const pend = (arr) => arr.filter((i) => getStatus(i.data_validade) !== 'Em dia').length;
  const acc = taxaAcidentesMes(data);
  const stats = [
    { label: 'Funcionários', value: data.funcionarios.length, icon: Users, tone: 'navy' },
    { label: 'ASOs em dia', value: valid(data.asos), icon: Stethoscope, tone: 'green' },
    { label: 'Treinamentos válidos', value: valid(data.treinamentos), icon: GraduationCap, tone: 'green' },
    { label: 'EPIs ativos', value: valid(data.epis), icon: HardHat, tone: 'green' },
    { label: 'DDS realizados', value: data.dds.length, icon: CalendarCheck, tone: 'navy' },
    { label: 'Integrações', value: data.integracoes.length, icon: UsersIcon, tone: 'navy' },
    { label: 'Ocorrências', value: data.ocorrencias.length, icon: AlertTriangle, tone: 'red' },
    { label: 'Pendências', value: pend([...data.asos, ...data.treinamentos, ...data.epis]), icon: ClipboardCheck, tone: 'amber' },
    { label: 'Acidentes no mês', value: acc.acidentesMes, icon: ShieldAlert, tone: acc.acidentesMes > 0 ? 'red' : 'green', hint: `Taxa: ${acc.taxa}% / 100 colab.` },
  ];
  return (
    <div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
        {stats.map((s) => <StatCard key={s.label} {...s} />)}
      </div>
      <div className="grid lg:grid-cols-2 gap-4">
        <GravidadeChart ocorrencias={data.ocorrencias} />
        <StatusMesChart itens={[...data.asos, ...data.treinamentos, ...data.epis]} />
      </div>
    </div>
  );
}