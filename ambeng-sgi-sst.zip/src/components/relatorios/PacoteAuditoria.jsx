import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { conformidade, pendencias } from '@/lib/relatorios';
import { Package, FileSpreadsheet, Printer } from 'lucide-react';

function baixar(nome, conteudo, mime) { const b = new Blob([conteudo], { type: mime }); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = nome; a.click(); URL.revokeObjectURL(u); }

export default function PacoteAuditoria({ data }) {
  const [loading, setLoading] = useState(false);
  const { indice } = conformidade(data);
  const cols = ['nome', 'matricula', 'funcao', 'obra', 'empresa', 'status'];

  const csvFuncs = () => { const head = cols.join(';'); const body = data.funcionarios.map((f) => cols.map((c) => String(f[c] ?? '').replace(/;/g, ',')).join(';')).join('\n'); baixar('pacote_auditoria_funcionarios.csv', head + '\n' + body, 'text/csv'); };
  const csvAll = () => {
    const secoes = [['ASOs', data.asos, ['tipo', 'medico', 'clinica', 'data_exame', 'data_validade']], ['Treinamentos', data.treinamentos, ['norma_curso', 'data_realizacao', 'data_validade']], ['EPIs', data.epis, ['item', 'data_entrega', 'data_validade']], ['DDS', data.dds, ['tema', 'data', 'responsavel']], ['Integracoes', data.integracoes, ['tipo', 'data', 'responsavel']], ['Ocorrencias', data.ocorrencias, ['tipo', 'gravidade', 'data', 'situacao']]];
    let out = '';
    secoes.forEach(([nome, arr, fields]) => { out += '\n' + nome + '\n' + fields.join(';') + '\n' + arr.map((r) => fields.map((f) => String(r[f] ?? '').replace(/;/g, ',')).join(';')).join('\n') + '\n'; });
    baixar('pacote_auditoria_completo.csv', out, 'text/csv');
  };

  const gerar = () => {
    setLoading(true);
    const html = `<html><head><title>Pacote de Auditoria SGI</title></head><body style="font-family:Arial,sans-serif;padding:32px">
      <h1 style="color:#0b2545">Pacote de Auditoria SGI SST</h1>
      <p>Gerado em ${new Date().toLocaleString('pt-BR')}</p>
      <h2 style="color:#0b2545">Resumo Executivo</h2>
      <p>Índice de conformidade: <b>${indice}%</b> · Pendências: ${pendencias(data).length}</p>
      <p>Funcionários: ${data.funcionarios.length} · ASOs: ${data.asos.length} · Treinamentos: ${data.treinamentos.length} · EPIs: ${data.epis.length} · DDS: ${data.dds.length} · Integrações: ${data.integracoes.length} · Ocorrências: ${data.ocorrencias.length}</p>
      <h2 style="color:#0b2545">Funcionários</h2>
      <table border="1" cellpadding="4" cellspacing="0" style="border-collapse:collapse;font-size:11px"><tr>${cols.map((c) => '<th>' + c + '</th>').join('')}</tr>${data.funcionarios.map((f) => '<tr>' + cols.map((c) => '<td>' + (f[c] || '') + '</td>').join('') + '</tr>').join('')}</table>
      <h2 style="color:#0b2545">Ocorrências</h2>
      <table border="1" cellpadding="4" cellspacing="0" style="border-collapse:collapse;font-size:11px"><tr><th>Data</th><th>Tipo</th><th>Gravidade</th><th>Situação</th></tr>${data.ocorrencias.map((o) => '<tr><td>' + (o.data || '') + '</td><td>' + o.tipo + '</td><td>' + o.gravidade + '</td><td>' + o.situacao + '</td></tr>').join('')}</table>
      </body></html>`;
    const w = window.open('', '_blank');
    w.document.write(html); w.document.close(); w.print();
    setLoading(false);
  };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-2"><Package className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Pacote para Auditoria</h3></div>
      <p className="text-sm text-slate-600 mb-4">Gera um pacote completo com funcionários, ASOs, treinamentos, DDS, integrações, EPIs, ocorrências, não conformidades, indicadores e resumo executivo.</p>
      <div className="flex flex-wrap gap-2">
        <Button onClick={gerar} disabled={loading} className="bg-[#0b2545] hover:bg-[#16365f]"><Printer className="w-4 h-4 mr-1" />{loading ? 'Gerando...' : 'Gerar Pacote (PDF)'}</Button>
        <Button variant="outline" onClick={csvFuncs}><FileSpreadsheet className="w-4 h-4 mr-1" />Funcionários (CSV)</Button>
        <Button variant="outline" onClick={csvAll}><FileSpreadsheet className="w-4 h-4 mr-1" />Completo (CSV)</Button>
      </div>
    </section>
  );
}