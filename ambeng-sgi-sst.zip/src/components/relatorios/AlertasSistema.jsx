import React from 'react';
import { pendencias } from '@/lib/relatorios';
import { Button } from '@/components/ui/button';
import { AlertOctagon, AlertTriangle, Info } from 'lucide-react';

const DOT = { red: 'bg-red-500', amber: 'bg-amber-500', green: 'bg-emerald-500' };
const HDR = {
  red: { c: 'text-red-700 bg-red-50', Icon: AlertOctagon, l: 'Crítico' },
  amber: { c: 'text-amber-700 bg-amber-50', Icon: AlertTriangle, l: 'Atenção' },
  green: { c: 'text-emerald-700 bg-emerald-50', Icon: Info, l: 'Informativo' },
};
const MAP = {
  ASO: ['operacionais', 'asos'], Treinamento: ['operacionais', 'treinamentos'], EPI: ['operacionais', 'epis'],
  Integração: ['operacionais', 'integracoes'], DDS: ['operacionais', 'dds'],
  'Não Conformidade': ['operacionais', 'nc'], Ocorrência: ['operacionais', 'ocorrencias'], Documento: ['pendencias'],
};

export default function AlertasSistema({ data, onNav }) {
  const list = pendencias(data);
  const groups = ['red', 'amber', 'green'].map((t) => ({ tone: t, items: list.filter((p) => p.tone === t) })).filter((g) => g.items.length > 0);
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-4">Central de Alertas</h3>
      {groups.length === 0 ? <p className="text-sm text-emerald-700">Nenhum alerta ativo. Sistema em conformidade.</p> : (
        <div className="space-y-4">
          {groups.map((g) => {
            const h = HDR[g.tone];
            return (
              <div key={g.tone}>
                <div className={`flex items-center gap-2 rounded-lg px-3 py-2 mb-2 ${h.c}`}>
                  <h.Icon className="w-4 h-4" /><span className="text-sm font-semibold">{h.l}</span>
                  <span className="ml-auto text-xs opacity-70">{g.items.length}</span>
                </div>
                <div className="space-y-1.5">
                  {g.items.map((a, i) => {
                    const nav = MAP[a.tipo];
                    return (
                      <div key={i} className="flex items-center gap-2 border border-slate-100 rounded-lg p-2">
                        <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${DOT[a.tone]}`} />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm text-slate-700 truncate">{a.label}</p>
                          <p className="text-xs text-slate-400">{a.detalhe}</p>
                        </div>
                        {nav && <Button size="sm" variant="outline" className="h-7 text-xs shrink-0" onClick={() => onNav(...nav)}>Abrir</Button>}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}