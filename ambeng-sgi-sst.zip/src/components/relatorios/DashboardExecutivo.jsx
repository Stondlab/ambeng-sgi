import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import PainelIndicadores from '@/components/dashboard/PainelIndicadores';

// Dashboard Executivo — indicadores clicáveis com drill-down real.
// Reaproveita o mesmo motor de indicadores do SGI (cards clicáveis, drill-down,
// explicações, filtros, permissões e cálculo do índice de conformidade).
// Os números dos cards e as listas detalhadas vêm da mesma base (useSstData),
// garantindo consistência entre o indicador e seu detalhamento.
export default function DashboardExecutivo() {
  const [demands, setDemands] = useState([]);

  useEffect(() => {
    let alive = true;
    base44.entities.Demandas.list('-created_date', 500)
      .then((d) => alive && setDemands(d))
      .catch(() => alive && setDemands([]));
    return () => { alive = false; };
  }, []);

  return <PainelIndicadores demands={demands} />;
}