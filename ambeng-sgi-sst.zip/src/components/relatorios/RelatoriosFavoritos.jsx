import React from 'react';
import { Users, Building2, GraduationCap, Stethoscope, HardHat, UsersRound, CalendarCheck, AlertTriangle, FileWarning, Cog, ClipboardCheck, BarChart3, FileSearch, Search, Camera } from 'lucide-react';

export default function RelatoriosFavoritos({ onNav }) {
  const favs = [
    { label: 'Funcionários Ativos', icon: Users, nav: ['operacionais', 'f_ativos'] },
    { label: 'Funcionários por Obra', icon: Building2, nav: ['operacionais', 'f_obra'] },
    { label: 'Treinamentos', icon: GraduationCap, nav: ['operacionais', 'treinamentos'] },
    { label: 'ASOs', icon: Stethoscope, nav: ['operacionais', 'asos'] },
    { label: 'EPIs', icon: HardHat, nav: ['operacionais', 'epis'] },
    { label: 'Integrações', icon: UsersRound, nav: ['operacionais', 'integracoes'] },
    { label: 'DDS', icon: CalendarCheck, nav: ['operacionais', 'dds'] },
    { label: 'Ocorrências', icon: AlertTriangle, nav: ['operacionais', 'ocorrencias'] },
    { label: 'Não Conformidades', icon: FileWarning, nav: ['operacionais', 'nc'] },
    { label: 'Máquinas', icon: Cog, nav: null, disabled: true },
    { label: 'APR', icon: ClipboardCheck, nav: null, disabled: true },
    { label: 'Inspeções', icon: Search, nav: null, disabled: true },
    { label: 'Relatório Fotográfico', icon: Camera, nav: null, disabled: true },
    { label: 'Relatório Executivo', icon: BarChart3, nav: ['executivos'] },
    { label: 'Relatório de Auditoria', icon: FileSearch, nav: ['auditorias'] },
  ];
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 mb-4">
      <h3 className="font-semibold text-[#0b2545] mb-4">Relatórios Favoritos</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {favs.map((f) => {
          const Icon = f.icon;
          return (
            <button key={f.label} disabled={f.disabled} onClick={() => f.nav && onNav(...f.nav)}
              className="flex flex-col items-center gap-2 border border-slate-100 rounded-xl p-3 hover:border-[#0b2545] hover:shadow-sm transition disabled:opacity-50">
              <Icon className="w-6 h-6 text-[#0b2545]" />
              <span className="text-xs text-center text-slate-600">{f.label}</span>
            </button>
          );
        })}
      </div>
    </section>
  );
}