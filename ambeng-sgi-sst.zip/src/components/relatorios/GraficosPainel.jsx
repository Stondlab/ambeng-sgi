import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { format, subMonths, endOfMonth, startOfWeek, addWeeks, endOfWeek } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { conformidade } from '@/lib/relatorios';

function monthly(items, dateKey, meses = 6) {
  const now = new Date(); const points = [];
  for (let i = meses - 1; i >= 0; i--) {
    const ref = endOfMonth(subMonths(now, i));
    const m = ref.getMonth(), y = ref.getFullYear();
    const count = items.filter((it) => { if (!it[dateKey]) return false; const d = new Date(it[dateKey]); return d.getMonth() === m && d.getFullYear() === y; }).length;
    points.push({ mes: format(ref, 'MMM', { locale: ptBR }), total: count });
  }
  return points;
}

function Card({ titulo, data, color = '#0b2545' }) {
  const empty = data.every((d) => d.total === 0);
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-3">{titulo}</h3>
      {empty ? <p className="text-sm text-slate-400 py-10 text-center">Sem dados.</p> : (
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={data} margin={{ top: 5, right: 10, left: -15, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="mes" tick={{ fontSize: 11, fill: '#64748b' }} />
            <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: '#64748b' }} />
            <Tooltip />
            <Bar dataKey="total" fill={color} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

// Distribui itens (com data_validade) em 12 baldes semanais, contando quantos
// vencem em cada semana — curva preditiva para planejamento de agenda.
function curvaSemanal(items, semanas = 12) {
  const inicio = startOfWeek(new Date(), { weekStartsOn: 1 });
  const baldes = Array.from({ length: semanas }, (_, i) => {
    const s = addWeeks(inicio, i);
    return { inicio: s, fim: endOfWeek(s, { weekStartsOn: 1 }), total: 0 };
  });
  items.forEach((it) => {
    if (!it.data_validade) return;
    const d = new Date(it.data_validade + 'T00:00:00');
    if (d < inicio) return;
    const idx = baldes.findIndex((b) => d >= b.inicio && d <= b.fim);
    if (idx >= 0) baldes[idx].total++;
  });
  return baldes.map((b) => ({ semana: format(b.inicio, 'dd/MM'), total: b.total }));
}

function contarPorCampo(items, campo, top = 8) {
  const m = {};
  items.forEach((it) => { const k = it[campo] || 'Sem classificação'; m[k] = (m[k] || 0) + 1; });
  return Object.entries(m).sort((a, b) => b[1] - a[1]).slice(0, top).map(([name, total]) => ({ name, total }));
}

function CardHoriz({ titulo, data }) {
  const empty = data.every((d) => d.total === 0);
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-3">{titulo}</h3>
      {empty ? <p className="text-sm text-slate-400 py-10 text-center">Sem dados.</p> : (
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={data} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis type="number" allowDecimals={false} tick={{ fontSize: 12, fill: '#64748b' }} />
            <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 11, fill: '#64748b' }} />
            <Tooltip />
            <Bar dataKey="total" fill="#0b2545" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

export default function GraficosPainel({ data, resultadoConformidade = null }) {
  const ocoMes = useMemo(() => monthly(data.ocorrencias, 'data'), [data]);
  const ddsMes = useMemo(() => monthly(data.dds, 'data'), [data]);
  const treMes = useMemo(() => monthly(data.treinamentos, 'data_realizacao'), [data]);
  const asoMes = useMemo(() => monthly(data.asos, 'data_exame'), [data]);
  const ncMes = useMemo(() => monthly(data.ocorrencias.filter((o) => o.tipo === 'Não Conformidade'), 'data'), [data]);
  const { areas } = resultadoConformidade || conformidade(data);
  const confData = areas.map((a) => ({ name: a.area, pct: a.pct }));
  const funcObra = useMemo(() => { const m = {}; data.funcionarios.forEach((f) => { const k = f.obra || 'Sem obra'; m[k] = (m[k] || 0) + 1; }); return Object.entries(m).map(([name, total]) => ({ name, total })); }, [data]);
  const funcEmp = useMemo(() => { const m = {}; data.funcionarios.forEach((f) => { const k = f.empresa || 'Sem empresa'; m[k] = (m[k] || 0) + 1; }); return Object.entries(m).map(([name, total]) => ({ name, total })); }, [data]);

  // Visão por tipo de ASO e por norma NR — os campos já existem no schema mas não eram usados no painel.
  const asoPorTipo = useMemo(() => contarPorCampo(data.asos, 'tipo'), [data]);
  const nrPorNorma = useMemo(() => contarPorCampo(data.treinamentos, 'norma_curso'), [data]);

  // Curva de vencimentos nos próximos 90 dias (12 semanas) — ASO / NR / EPI separados.
  const curvaAso = useMemo(() => curvaSemanal(data.asos), [data]);
  const curvaNr = useMemo(() => curvaSemanal(data.treinamentos), [data]);
  const curvaEpi = useMemo(() => curvaSemanal(data.epis), [data]);

  return (
    <section className="mb-4">
      <h3 className="font-semibold text-[#0b2545] mb-3">Curva de Vencimentos — próximas 12 semanas</h3>
      <div className="grid lg:grid-cols-3 gap-4 mb-6">
        <Card titulo="ASO — vencimentos por semana" data={curvaAso.map((c) => ({ mes: c.semana, total: c.total }))} color="#8b5cf6" />
        <Card titulo="NR — vencimentos por semana" data={curvaNr.map((c) => ({ mes: c.semana, total: c.total }))} color="#059669" />
        <Card titulo="EPI — vencimentos por semana" data={curvaEpi.map((c) => ({ mes: c.semana, total: c.total }))} color="#d97706" />
      </div>

      <h3 className="font-semibold text-[#0b2545] mb-3">Indicadores Gráficos</h3>
      <div className="grid lg:grid-cols-2 gap-4">
        <CardHoriz titulo="ASO por tipo" data={asoPorTipo} />
        <CardHoriz titulo="Treinamentos por norma (NR)" data={nrPorNorma} />
        <Card titulo="Ocorrências por mês" data={ocoMes} color="#dc2626" />
        <Card titulo="DDS por mês" data={ddsMes} color="#0b2545" />
        <Card titulo="Treinamentos realizados" data={treMes} color="#059669" />
        <Card titulo="ASOs por mês" data={asoMes} color="#8b5cf6" />
        <Card titulo="Não Conformidades por mês" data={ncMes} color="#ea580c" />
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <h3 className="font-semibold text-[#0b2545] mb-3">Índice de conformidade por área</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={confData} margin={{ top: 5, right: 10, left: -15, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: '#64748b' }} />
              <Tooltip />
              <Bar dataKey="pct" fill="#0b2545" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <CardHoriz titulo="Funcionários por obra" data={funcObra} />
        <CardHoriz titulo="Funcionários por empresa" data={funcEmp} />
      </div>
    </section>
  );
}