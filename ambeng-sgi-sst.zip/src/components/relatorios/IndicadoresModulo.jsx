import React from 'react';
import { conformidade } from '@/lib/relatorios';

const BAR = { green: 'bg-emerald-500', amber: 'bg-amber-500', red: 'bg-red-500' };
const TXT = { green: 'text-emerald-700', amber: 'text-amber-700', red: 'text-red-700' };

export default function IndicadoresModulo({ data, onNav }) {
  const { areas } = conformidade(data);
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <h3 className="font-semibold text-[#0b2545] mb-4">Indicadores por Módulo</h3>
      <div className="space-y-3">
        {areas.map((a) => (
          <button key={a.area} onClick={() => onNav('auditorias')} className="w-full text-left">
            <div className="flex justify-between text-sm mb-1">
              <span className="text-slate-600">{a.area}</span>
              <span className={`font-medium ${TXT[a.tone]}`}>{a.pct}%</span>
            </div>
            <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
              <div className={`h-full ${BAR[a.tone]}`} style={{ width: `${a.pct}%` }} />
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}