import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { getStatus, fmt, diasRestantes } from '@/lib/sst';
import { AlertTriangle, ArrowRight } from 'lucide-react';

const toneColor = { red: 'text-red-600', amber: 'text-amber-600', green: 'text-emerald-600' };
const toneBg = { red: 'bg-red-50 border-red-200', amber: 'bg-amber-50 border-amber-200', green: 'bg-emerald-50 border-emerald-200' };

export default function ResumoInteligenteRanking({ data }) {
  const items = useMemo(() => {
    const nome = (id) => data.funcionarios.find((f) => f.id === id)?.nome || '—';
    const list = [];

    data.asos.forEach((a) => {
      const s = getStatus(a.data_validade);
      if (s !== 'Em dia') list.push({
        o_que: `Renovar ASO ${a.tipo || ''}`,
        por_que: s === 'Vencido' ? `Documento vencido há ${Math.abs(diasRestantes(a.data_validade))} dia(s)` : `Vence em ${diasRestantes(a.data_validade)} dia(s)`,
        fator: `Saúde — ${nome(a.funcionario_id)}`,
        urg: s === 'Vencido' ? 3 : 2, tone: s === 'Vencido' ? 'red' : 'amber',
        para: '/funcionarios/asos',
      });
    });
    data.treinamentos.forEach((t) => {
      const s = getStatus(t.data_validade);
      if (s !== 'Em dia') list.push({
        o_que: `Reciclar ${t.norma_curso || 'treinamento'}`,
        por_que: s === 'Vencido' ? `Vencido há ${Math.abs(diasRestantes(t.data_validade))} dia(s)` : `Vence em ${diasRestantes(t.data_validade)} dia(s)`,
        fator: `Treinamento — ${nome(t.funcionario_id)}`,
        urg: s === 'Vencido' ? 3 : 2, tone: s === 'Vencido' ? 'red' : 'amber',
        para: '/treinamentos',
      });
    });
    data.epis.forEach((e) => {
      const s = getStatus(e.data_validade);
      if (s !== 'Em dia') list.push({
        o_que: `Repor EPI ${e.item || ''}`,
        por_que: s === 'Vencido' ? `Vencido há ${Math.abs(diasRestantes(e.data_validade))} dia(s)` : `Vence em ${diasRestantes(e.data_validade)} dia(s)`,
        fator: `EPI — ${nome(e.funcionario_id)}`,
        urg: s === 'Vencido' ? 3 : 1, tone: s === 'Vencido' ? 'red' : 'amber',
        para: '/epis',
      });
    });
    const comInt = new Set(data.integracoes.map((i) => i.funcionario_id));
    data.funcionarios.filter((f) => !comInt.has(f.id)).forEach((f) => list.push({
      o_que: 'Realizar integração do colaborador',
      por_que: 'Sem registro de integração admissional',
      fator: `Integração — ${f.nome}`,
      urg: 2, tone: 'amber', para: '/funcionarios',
    }));
    data.ocorrencias.filter((o) => o.tipo === 'Não Conformidade' && o.situacao !== 'Encerrada').forEach((o) => list.push({
      o_que: 'Encerrar Não Conformidade',
      por_que: `NC aberta desde ${fmt(o.data)}`,
      fator: `Ocorrências — ${nome(o.funcionario_id)}`,
      urg: 3, tone: 'red', para: '/ocorrencias',
    }));

    return list.sort((a, b) => b.urg - a.urg).slice(0, 5);
  }, [data]);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <AlertTriangle className="w-5 h-5 text-amber-500" />
        <h3 className="font-semibold text-[#0b2545]">Resumo Inteligente</h3>
        <span className="ml-auto text-xs text-slate-400">Ranqueado por urgência</span>
      </div>
      {items.length === 0 ? (
        <p className="text-sm text-slate-500">Tudo em dia — nenhuma ação urgente no momento.</p>
      ) : (
        <div className="space-y-3">
          {items.map((it, i) => (
            <Link key={i} to={it.para} className={`block border rounded-lg p-3 hover:shadow-sm transition-shadow ${toneBg[it.tone]}`}>
              <div className="flex items-start gap-2">
                <span className={`shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${toneColor[it.tone]} bg-white border border-current`}>{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-[#0b2545]">{it.o_que}</p>
                  <p className="text-xs text-slate-600 mt-0.5">{it.por_que}</p>
                  <p className="text-xs text-slate-400 mt-1">Fator: {it.fator}</p>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 shrink-0 mt-1" />
              </div>
            </Link>
          ))}
        </div>
      )}
    </section>
  );
}