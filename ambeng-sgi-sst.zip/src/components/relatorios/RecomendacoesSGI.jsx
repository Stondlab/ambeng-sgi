import React from 'react';
import { Button } from '@/components/ui/button';
import { recomendacoes } from '@/lib/relatorios';
import { Sparkles } from 'lucide-react';

const TONE = {
  red: 'border-l-red-500 bg-red-50',
  amber: 'border-l-amber-500 bg-amber-50',
  green: 'border-l-emerald-500 bg-emerald-50',
};

export default function RecomendacoesSGI({ data, onAcao }) {
  const recs = recomendacoes(data);
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 mb-4">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="w-5 h-5 text-amber-500" />
        <h3 className="font-semibold text-[#0b2545]">Recomendações do SGI</h3>
      </div>
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {recs.map((r, i) => (
          <div key={i} className={`border-l-4 ${TONE[r.tone]} rounded-r-lg p-3`}>
            <p className="text-sm text-slate-700 mb-2">{r.label}</p>
            <Button size="sm" variant="outline" onClick={() => onAcao(r.tipo)}>{r.acao}</Button>
          </div>
        ))}
      </div>
    </section>
  );
}