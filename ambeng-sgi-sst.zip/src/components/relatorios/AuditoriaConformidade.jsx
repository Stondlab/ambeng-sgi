import React from 'react';
import { conformidade } from '@/lib/relatorios';

const BAR = { green: 'bg-emerald-500', amber: 'bg-amber-500', red: 'bg-red-500', slate: 'bg-slate-300' };
const TXT = { green: 'text-emerald-700', amber: 'text-amber-700', red: 'text-red-700', slate: 'text-slate-500' };

export default function AuditoriaConformidade({ data }) {
  const { areas, indice, tone, totConf, totPend, totVenc, semRegistro } = conformidade(data);
  return (
    <div className="space-y-4">
      <section className="bg-white border border-slate-200 rounded-xl p-5">
        <div className="flex items-center gap-6 mb-4">
          <div className="text-center shrink-0">
            <p className="text-xs text-slate-400 mb-1">Índice Geral de Conformidade</p>
            <p className={`text-5xl font-bold ${TXT[tone]}`}>{indice == null ? '—' : `${indice}%`}</p>
            <p className="text-xs text-slate-400 mt-1">{indice == null ? 'Sem registros analisáveis' : tone === 'green' ? 'Conforme' : tone === 'amber' ? 'Atenção' : 'Não conforme'}</p>
          </div>
          <div className="flex-1">
            <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
              <div className={`h-full ${BAR[tone]}`} style={{ width: `${indice ?? 0}%` }} />
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <div className="rounded-lg bg-emerald-50 p-2 text-center"><p className="text-xl font-bold text-emerald-700">{totConf}</p><p className="text-[10px] text-slate-500">Conformes</p></div>
          <div className="rounded-lg bg-amber-50 p-2 text-center"><p className="text-xl font-bold text-amber-700">{totPend}</p><p className="text-[10px] text-slate-500">Pendentes</p></div>
          <div className="rounded-lg bg-red-50 p-2 text-center"><p className="text-xl font-bold text-red-700">{totVenc}</p><p className="text-[10px] text-slate-500">Vencidos</p></div>
          <div className="rounded-lg bg-slate-100 p-2 text-center"><p className="text-xl font-bold text-slate-500">{semRegistro}</p><p className="text-[10px] text-slate-500">Sem registro</p></div>
        </div>
      </section>
      <section className="bg-white border border-slate-200 rounded-xl p-5">
        <h3 className="font-semibold text-[#0b2545] mb-4">Checklist de Auditoria</h3>
        <div className="space-y-3">
          {areas.map((a) => (
            <div key={a.area} className="flex items-center gap-3">
              <div className="w-36 text-sm text-slate-600 shrink-0">{a.area}</div>
              <div className="flex-1 h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div className={`h-full ${BAR[a.tone]}`} style={{ width: `${a.pct}%` }} />
              </div>
              <div className="w-14 text-right text-sm font-medium"><span className={TXT[a.tone]}>{a.analisavel ? `${a.pct}%` : '—'}</span></div>
              <div className="w-44 text-right text-[11px] flex justify-end gap-2">
                <span className="text-emerald-600" title="Conformes">{a.conforme}C</span>
                <span className="text-amber-600" title="Pendentes">{a.pendente}P</span>
                <span className="text-red-600" title="Vencidos">{a.vencido}V</span>
                <span className="text-slate-400" title="Sem registro">{a.semRegistro}S</span>
              </div>
            </div>
          ))}
        </div>
        <p className="text-[11px] text-slate-400 mt-3">C = conformes · P = pendentes · V = vencidos · S = sem registro. Itens "sem registro" não são contados como não conformes nem inflacionam o índice.</p>
      </section>
    </div>
  );
}