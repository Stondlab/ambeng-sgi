import React from 'react';
import { Button } from '@/components/ui/button';
import StatusBadge from '@/components/StatusBadge';
import { fmt } from '@/lib/sst';

const NAVY = 'bg-[#0b2545] hover:bg-[#16365f]';

const RELATORIOS = [
  { grupo: 'Funcionários', items: [
    { key: 'f_ativos', label: 'Funcionários Ativos' },
    { key: 'f_afastados', label: 'Funcionários Afastados' },
    { key: 'f_desligados', label: 'Funcionários Desligados' },
    { key: 'f_obra', label: 'Funcionários por Obra' },
    { key: 'f_empresa', label: 'Funcionários por Empresa' },
    { key: 'f_cargo', label: 'Funcionários por Cargo' },
  ]},
  { grupo: 'Registros', items: [
    { key: 'treinamentos', label: 'Treinamentos' },
    { key: 'asos', label: 'ASOs' },
    { key: 'epis', label: 'EPIs' },
    { key: 'integracoes', label: 'Integrações' },
    { key: 'dds', label: 'DDS' },
    { key: 'ocorrencias', label: 'Ocorrências' },
    { key: 'nc', label: 'Não Conformidades' },
  ]},
  { grupo: 'Outros módulos', items: [
    { key: 'inspecoes', label: 'Inspeções', disabled: true },
    { key: 'maquinas', label: 'Máquinas', disabled: true },
    { key: 'apr', label: 'APR', disabled: true },
    { key: 'fotograficos', label: 'Relatórios Fotográficos', disabled: true },
  ]},
];

function nomeFunc(data, id) {
  const f = data.funcionarios.find((x) => x.id === id);
  return f ? f.nome : '—';
}

function Table({ rows, cols }) {
  if (rows.length === 0) return <p className="text-sm text-slate-400 py-6">Sem registros para este relatório.</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-xs text-slate-400 border-b border-slate-100">
          <tr>{cols.map((c) => <th key={c.key} className="text-left py-2 font-medium pr-4">{c.label}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-slate-50">
          {rows.map((r, i) => (
            <tr key={i}>
              {cols.map((c) => <td key={c.key} className="py-2 pr-4 text-slate-700">{c.render ? c.render(r) : (r[c.key] ?? '—')}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function renderRelatorio(key, data) {
  const fCol = (k, label) => ({ key: k, label });
  const fCols = [fCol('nome', 'Nome'), fCol('matricula', 'Matrícula'), fCol('funcao', 'Cargo'), fCol('obra', 'Obra'), fCol('empresa', 'Empresa'), fCol('status', 'Status')];
  switch (key) {
    case 'f_ativos': return { rows: data.funcionarios.filter((f) => f.status === 'Ativo'), cols: fCols };
    case 'f_afastados': return { rows: data.funcionarios.filter((f) => f.status === 'Afastado'), cols: fCols };
    case 'f_desligados': return { rows: data.funcionarios.filter((f) => f.status === 'Demitido'), cols: fCols };
    case 'f_obra': return { rows: [...data.funcionarios].sort((a, b) => (a.obra || '').localeCompare(b.obra || '')), cols: fCols };
    case 'f_empresa': return { rows: [...data.funcionarios].sort((a, b) => (a.empresa || '').localeCompare(b.empresa || '')), cols: fCols };
    case 'f_cargo': return { rows: [...data.funcionarios].sort((a, b) => (a.funcao || '').localeCompare(b.funcao || '')), cols: fCols };
    case 'treinamentos': return { rows: data.treinamentos, cols: [
      { key: 'func', label: 'Funcionário', render: (r) => nomeFunc(data, r.funcionario_id) },
      { key: 'norma_curso', label: 'Curso' }, { key: 'data_validade', label: 'Validade', render: (r) => fmt(r.data_validade) },
      { key: 's', label: 'Situação', render: (r) => <StatusBadge data_validade={r.data_validade} /> },
    ] };
    case 'asos': return { rows: data.asos, cols: [
      { key: 'func', label: 'Funcionário', render: (r) => nomeFunc(data, r.funcionario_id) },
      { key: 'tipo', label: 'Tipo' }, { key: 'data_validade', label: 'Validade', render: (r) => fmt(r.data_validade) },
      { key: 's', label: 'Situação', render: (r) => <StatusBadge data_validade={r.data_validade} /> },
    ] };
    case 'epis': return { rows: data.epis, cols: [
      { key: 'func', label: 'Funcionário', render: (r) => nomeFunc(data, r.funcionario_id) },
      { key: 'item', label: 'Equipamento' }, { key: 'certificado_aprovacao', label: 'CA' },
      { key: 'data_validade', label: 'Validade', render: (r) => fmt(r.data_validade) },
      { key: 's', label: 'Situação', render: (r) => <StatusBadge data_validade={r.data_validade} /> },
    ] };
    case 'integracoes': return { rows: data.integracoes, cols: [
      { key: 'func', label: 'Funcionário', render: (r) => nomeFunc(data, r.funcionario_id) },
      { key: 'data', label: 'Data', render: (r) => fmt(r.data) }, { key: 'tipo', label: 'Tipo' }, { key: 'responsavel', label: 'Responsável' },
    ] };
    case 'dds': return { rows: data.dds, cols: [
      { key: 'func', label: 'Funcionário', render: (r) => nomeFunc(data, r.funcionario_id) },
      { key: 'data', label: 'Data', render: (r) => fmt(r.data) }, { key: 'tema', label: 'Tema' }, { key: 'responsavel', label: 'Responsável' },
    ] };
    case 'ocorrencias': return { rows: data.ocorrencias, cols: [
      { key: 'func', label: 'Funcionário', render: (r) => nomeFunc(data, r.funcionario_id) },
      { key: 'data', label: 'Data', render: (r) => fmt(r.data) }, { key: 'tipo', label: 'Tipo' }, { key: 'gravidade', label: 'Gravidade' }, { key: 'situacao', label: 'Situação' },
    ] };
    case 'nc': return { rows: data.ocorrencias.filter((o) => o.tipo === 'Não Conformidade'), cols: [
      { key: 'func', label: 'Funcionário', render: (r) => nomeFunc(data, r.funcionario_id) },
      { key: 'data', label: 'Data', render: (r) => fmt(r.data) }, { key: 'situacao', label: 'Situação' }, { key: 'descricao', label: 'Descrição' },
    ] };
    default: return { rows: null, cols: null };
  }
}

export default function RelatorioOperacional({ data, sel = null, onSel }) {
  const rep = sel ? renderRelatorio(sel, data) : null;

  return (
    <div>
      {RELATORIOS.map((g) => (
        <div key={g.grupo} className="mb-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-2">{g.grupo}</p>
          <div className="flex flex-wrap gap-2">
            {g.items.map((it) => (
              <Button key={it.key} size="sm" disabled={it.disabled}
                className={it.disabled ? '' : NAVY} variant={it.disabled ? 'outline' : 'default'}
                onClick={() => !it.disabled && onSel?.(it.key)}>
                {it.label}{it.disabled && ' (n/c)'}
              </Button>
            ))}
          </div>
        </div>
      ))}
      {sel && (
        <section className="bg-white border border-slate-200 rounded-xl p-5 mt-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-[#0b2545]">{RELATORIOS.flatMap((g) => g.items).find((i) => i.key === sel)?.label}</h3>
            <span className="text-sm text-slate-400">{rep.rows?.length || 0} registro(s)</span>
          </div>
          {rep.rows === null ? <p className="text-sm text-slate-400">Módulo ainda não cadastrado no sistema.</p> : <Table rows={rep.rows} cols={rep.cols} />}
        </section>
      )}
    </div>
  );
}