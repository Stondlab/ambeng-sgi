import React from 'react';

export default function StatCard({ label, value, icon: Icon, tone = 'navy' }) {
  const tones = {
    navy: 'bg-[#0b2545] text-white',
    red: 'bg-white border border-red-200 text-red-700',
    amber: 'bg-white border border-amber-200 text-amber-700',
    green: 'bg-white border border-emerald-200 text-emerald-700',
  };
  return (
    <div className={`rounded-xl p-4 ${tones[tone]} flex items-center gap-4`}>
      <Icon className="w-8 h-8 opacity-70 shrink-0" />
      <div className="min-w-0">
        <p className="text-3xl font-semibold leading-none">{value}</p>
        <p className="text-xs mt-1.5 opacity-80">{label}</p>
      </div>
    </div>
  );
}