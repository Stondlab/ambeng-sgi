import React from 'react';
import GenericCrudPage from '@/components/config/GenericCrudPage';
import { HardHat } from 'lucide-react';

export default function ObrasConfig() {
  return (
    <GenericCrudPage
      entity="Obras"
      title="Obras"
      subtitle="Cadastre as obras usadas nos cartões da Central de Operações e nos cadastros."
      icon={HardHat}
      fields={[
        { name: 'nome', label: 'Nome', required: true },
        { name: 'codigo', label: 'Código' },
        { name: 'cliente', label: 'Cliente' },
        { name: 'endereco', label: 'Endereço' },
        { name: 'cidade', label: 'Cidade' },
        { name: 'estado', label: 'Estado' },
        { name: 'status', label: 'Status', type: 'select', options: ['Planejamento', 'Em andamento', 'Pausada', 'Concluída', 'Cancelada'] },
        { name: 'ativa', label: 'Ativa', type: 'boolean' },
      ]}
      columns={[
        { name: 'nome', label: 'Nome' },
        { name: 'codigo', label: 'Código' },
        { name: 'cliente', label: 'Cliente' },
        { name: 'cidade', label: 'Cidade' },
        { name: 'status', label: 'Status' },
        { name: 'ativa', label: 'Ativa', type: 'boolean' },
      ]}
      searchFields={['nome', 'codigo', 'cliente', 'cidade']}
    />
  );
}