import React from 'react';
import GenericCrudPage from '@/components/config/GenericCrudPage';
import { HardHat } from 'lucide-react';

export default function TiposEPIPage() {
  return (
    <GenericCrudPage
      entity="TiposEPI"
      title="Tipos de EPI"
      subtitle="Cadastre os equipamentos usados no controle de EPIs dos colaboradores."
      icon={HardHat}
      fields={[
        { name: 'nome', label: 'EPI', required: true },
        { name: 'ca', label: 'CA' },
        { name: 'descricao', label: 'Descrição', type: 'textarea' },
        { name: 'ativa', label: 'Ativo', type: 'boolean' },
      ]}
      columns={[
        { name: 'nome', label: 'EPI' },
        { name: 'ca', label: 'CA' },
        { name: 'ativa', label: 'Status', type: 'boolean' },
      ]}
      searchFields={['nome', 'ca']}
    />
  );
}