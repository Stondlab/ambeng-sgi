import React from 'react';
import GenericCrudPage from '@/components/config/GenericCrudPage';
import { Stethoscope } from 'lucide-react';

export default function TiposASOPage() {
  return (
    <GenericCrudPage
      entity="TiposASO"
      title="Tipos de ASO"
      subtitle="Cadastre os tipos de ASO usados em Saúde Ocupacional."
      icon={Stethoscope}
      fields={[
        { name: 'nome', label: 'Tipo', required: true },
        { name: 'descricao', label: 'Descrição', type: 'textarea' },
        { name: 'ativa', label: 'Ativo', type: 'boolean' },
      ]}
      columns={[
        { name: 'nome', label: 'Tipo' },
        { name: 'ativa', label: 'Status', type: 'boolean' },
      ]}
      searchFields={['nome']}
    />
  );
}