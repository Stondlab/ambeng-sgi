import React from 'react';
import GenericCrudPage from '@/components/config/GenericCrudPage';
import { AlertTriangle } from 'lucide-react';

export default function TiposOcorrenciaPage() {
  return (
    <GenericCrudPage
      entity="TiposOcorrencia"
      title="Tipos de Ocorrência"
      subtitle="Cadastre os tipos usados no módulo de Ocorrências."
      icon={AlertTriangle}
      fields={[
        { name: 'nome', label: 'Tipo', required: true },
        { name: 'descricao', label: 'Descrição', type: 'textarea' },
        { name: 'ativa', label: 'Ativo', type: 'boolean' },
      ]}
      columns={[
        { name: 'nome', label: 'Tipo' },
        { name: 'ativa', label: 'Status', type: 'boolean' },
      ]}
      searchFields={['nome']}
    />
  );
}