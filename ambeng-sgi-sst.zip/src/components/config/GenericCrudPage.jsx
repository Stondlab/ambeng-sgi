import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Plus, Pencil, Trash2, Search } from 'lucide-react';
import { usePerm } from '@/hooks/usePerm';
import { titleCase } from '@/lib/titleCase';
import MoneyInput from '@/components/funcionario/MoneyInput';
import { formatarMoeda } from '@/lib/moeda';
import { mensagemAmigavelErro, validarDataOpcional, validarNumeroOpcional } from '@/lib/validacao';

// Página de CRUD genérica para cadastros estruturais do Configurações.
// entity: nome da entidade no SDK. fields: definição do formulário. columns: colunas da listagem.
export default function GenericCrudPage({ entity, title, subtitle, fields, columns, searchFields, icon: Icon }) {
  const { podeCriar, podeEditar, podeExcluir } = usePerm('configuracoes');
  const [lista, setLista] = useState([]);
  const [busca, setBusca] = useState('');
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});
  const [delId, setDelId] = useState(null);
  const [entityOptions, setEntityOptions] = useState({});
  const [erro, setErro] = useState('');

  const load = async () => { try { setLista(await base44.entities[entity].list('-created_date', 500)); } catch {} };
  useEffect(() => { load(); }, [entity]);

  useEffect(() => {
    const entitySelectFields = fields.filter((f) => f.type === 'entity-select');
    const uniqueEntities = [...new Set(entitySelectFields.map((f) => f.entity))];
    uniqueEntities.forEach(async (ent) => {
      try {
        const data = await base44.entities[ent].list('-created_date', 500);
        setEntityOptions((p) => ({ ...p, [ent]: data }));
      } catch { setEntityOptions((p) => ({ ...p, [ent]: [] })); }
    });
  }, [fields]);

  const getEntityLabel = (entityName, id, labelField) => {
    const opts = entityOptions[entityName] || [];
    const item = opts.find((o) => o.id === id);
    if (!item) return '—';
    return item[labelField] || item.nome_fantasia || item.razao_social || item.nome || '—';
  };

  const filtrados = useMemo(() => {
    const q = busca.trim().toLowerCase();
    if (!q) return lista;
    const keys = searchFields || fields.map((f) => f.name);
    return lista.filter((r) => keys.some((k) => String(r[k] ?? '').toLowerCase().includes(q)));
  }, [lista, busca, searchFields, fields]);

  const openNew = () => { setForm({}); setErro(''); setEditing('novo'); };
  const openEdit = (r) => {
    const init = {};
    fields.forEach((f) => { init[f.name] = r[f.name] ?? (f.type === 'boolean' ? true : ''); });
    setForm(init); setEditing(r.id);
  };

  const save = async () => {
    const missing = fields.find((f) => f.required && !String(form[f.name] ?? '').trim());
    if (missing) return setErro(`Preencha o campo obrigatório: ${missing.label}.`);
    const dataInvalida = fields.find((f) => f.type === 'date' && !validarDataOpcional(form[f.name]));
    if (dataInvalida) return setErro(`Informe uma data válida em ${dataInvalida.label}.`);
    const numeroInvalido = fields.find((f) => (f.type === 'number' || f.type === 'money') && !validarNumeroOpcional(form[f.name]));
    if (numeroInvalido) return setErro(`Informe um valor numérico válido em ${numeroInvalido.label}.`);
    setErro('');
    const payload = { ...form };
    fields.forEach((f) => {
      if (f.type === 'boolean') payload[f.name] = !!payload[f.name];
      if (f.type === 'number') payload[f.name] = (payload[f.name] === '' || payload[f.name] == null) ? 0 : Number(payload[f.name]);
      if (f.type === 'money') payload[f.name] = (payload[f.name] === '' || payload[f.name] == null) ? 0 : Number(payload[f.name]);
      if (payload[f.name] && typeof payload[f.name] === 'string' && f.type !== 'date' && f.type !== 'boolean' && f.type !== 'number' && f.type !== 'money' && f.type !== 'select' && f.type !== 'entity-select') {
        payload[f.name] = titleCase(payload[f.name]);
      }
    });
    try {
      if (editing === 'novo') await base44.entities[entity].create(payload);
      else await base44.entities[entity].update(editing, payload);
      setEditing(null); load();
    } catch (e) { setErro(mensagemAmigavelErro(e)); }
  };

  const confirmDel = async () => { try { if (delId) await base44.entities[entity].delete(delId); } catch {} setDelId(null); load(); };

  const showCol = (r, f) => {
    const v = r[f.name];
    if (f.type === 'boolean') return v === false || v == null ? 'Inativo' : 'Ativo';
    if (f.type === 'money') return v != null && v !== '' ? formatarMoeda(Number(v)) : '—';
    if (f.type === 'entity-select') return getEntityLabel(f.entity, v, f.optionLabel);
    return v || '—';
  };

  return (
    <div>
      <PageHeader title={title} subtitle={subtitle} action={podeCriar ? (
        <Button onClick={openNew} className="min-h-[44px] bg-[#0b2545] hover:bg-[#16365f]"><Plus className="w-4 h-4" />Novo</Button>
      ) : null} />

      <div className="relative mb-4 sm:max-w-sm">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <Input placeholder="Pesquisar..." value={busca} onChange={(e) => setBusca(e.target.value)} className="pl-9" />
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
            <tr>
              {columns.map((c) => <th key={c.name} className="text-left px-4 py-3">{c.label}</th>)}
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtrados.map((r) => (
              <tr key={r.id} className="hover:bg-slate-50">
                {columns.map((c) => <td key={c.name} className="px-4 py-3 text-slate-700">{showCol(r, c)}</td>)}
                <td className="px-4 py-3 text-right whitespace-nowrap">
                  {podeEditar && <button onClick={() => openEdit(r)} className="p-2 min-w-[36px] min-h-[36px] rounded-md hover:bg-slate-100 text-[#0b2545]" title="Editar"><Pencil className="w-4 h-4" /></button>}
                  {podeExcluir && <button onClick={() => setDelId(r.id)} className="p-2 min-w-[36px] min-h-[36px] rounded-md hover:bg-red-50 text-slate-400 hover:text-red-500" title="Excluir"><Trash2 className="w-4 h-4" /></button>}
                </td>
              </tr>
            ))}
            {filtrados.length === 0 && <tr><td colSpan={columns.length + 1} className="px-4 py-10 text-center text-slate-400">Nenhum registro encontrado.</td></tr>}
          </tbody>
        </table>
      </div>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">{Icon && <Icon className="w-5 h-5 text-[#0b2545]" />}{editing === 'novo' ? `Novo · ${title}` : `Editar · ${title}`}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {fields.map((f) => (
              <div key={f.name} className={f.type === 'textarea' ? 'sm:col-span-2' : ''}>
                <Label>{f.label}{f.required ? ' *' : ''}</Label>
                {f.type === 'boolean' ? (
                  <div className="mt-2 flex items-center gap-2">
                    <Switch checked={!!form[f.name]} onCheckedChange={(v) => setForm((p) => ({ ...p, [f.name]: v }))} />
                    <span className="text-sm text-slate-600">{form[f.name] === false ? 'Inativo' : 'Ativo'}</span>
                  </div>
                ) : f.type === 'select' ? (
                  <Select value={form[f.name] || ''} onValueChange={(v) => setForm((p) => ({ ...p, [f.name]: v }))}>
                    <SelectTrigger className="mt-1"><SelectValue placeholder={f.placeholder || 'Selecione'} /></SelectTrigger>
                    <SelectContent>{f.options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                  </Select>
                ) : f.type === 'money' ? (
                  <MoneyInput className="mt-1" value={form[f.name] ?? ''} onChange={(v) => setForm((p) => ({ ...p, [f.name]: v }))} />
                ) : f.type === 'entity-select' ? (
                  <Select value={form[f.name] || ''} onValueChange={(v) => setForm((p) => ({ ...p, [f.name]: v }))}>
                    <SelectTrigger className="mt-1"><SelectValue placeholder={f.placeholder || 'Selecione'} /></SelectTrigger>
                    <SelectContent>
                      {(entityOptions[f.entity] || []).map((o) => {
                        const label = o[f.optionLabel] || o.nome_fantasia || o.razao_social || o.nome;
                        return label ? <SelectItem key={o.id} value={o.id}>{label}</SelectItem> : null;
                      })}
                    </SelectContent>
                  </Select>
                ) : f.type === 'textarea' ? (
                  <Textarea className="mt-1" rows={3} value={form[f.name] || ''} onChange={(e) => setForm((p) => ({ ...p, [f.name]: e.target.value }))} />
                ) : (
                  <Input className="mt-1" type={f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text'} value={form[f.name] || ''} onChange={(e) => setForm((p) => ({ ...p, [f.name]: e.target.value }))} placeholder={f.placeholder} />
                )}
              </div>
            ))}
          </div>
          {erro && <p className="text-sm text-red-600">{erro}</p>}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancelar</Button>
            <Button onClick={save} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!delId} onOpenChange={(o) => !o && setDelId(null)}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir registro</AlertDialogTitle>
            <AlertDialogDescription>Tem certeza? Esta ação não pode ser desfeita.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDel} className="bg-red-500 hover:bg-red-600 text-white">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}