import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Plus, Pencil, Trash2, Search, Building2 } from 'lucide-react';
import { usePerm } from '@/hooks/usePerm';
import { applyTitleCaseAll } from '@/lib/titleCase';

const maskCnpj = (v) => { const d = (v || '').replace(/\D/g, '').slice(0, 14); return d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5'); };
const maskTel = (v) => { const d = (v || '').replace(/\D/g, '').slice(0, 10); if (d.length <= 2) return d; if (d.length <= 6) return d.replace(/(\d{2})(\d{0,4})/, '($1) $2'); return d.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3'); };
const maskCel = (v) => { const d = (v || '').replace(/\D/g, '').slice(0, 11); if (d.length <= 2) return d; if (d.length <= 7) return d.replace(/(\d{2})(\d{0,5})/, '($1) $2'); return d.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3'); };
const maskCep = (v) => { const d = (v || '').replace(/\D/g, '').slice(0, 8); return d.length > 5 ? d.replace(/(\d{5})(\d{0,3})/, '$1-$2') : d; };
const digits = (v) => (v || '').replace(/\D/g, '');
const validarEmail = (v) => !v || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);

function validarCnpj(v) {
  const d = digits(v);
  if (d.length !== 14) return false;
  if (/^(\d)\1+$/.test(d)) return false;
  const calc = (slice, pesos) => { let s = 0; for (let i = 0; i < slice.length; i++) s += parseInt(slice[i]) * pesos[i]; const r = s % 11; return r < 2 ? 0 : 11 - r; };
  const p1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  const p2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  const d1 = calc(d.slice(0, 12), p1);
  const d2 = calc(d.slice(0, 12) + d1, p2);
  return d1 === parseInt(d[12]) && d2 === parseInt(d[13]);
}

const UF = ['AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'];

const VAZIO = { razao_social: '', nome_fantasia: '', cnpj: '', inscricao_estadual: '', inscricao_municipal: '', responsavel_nome: '', responsavel_cargo: '', telefone: '', celular: '', whatsapp: false, email: '', cep: '', logradouro: '', numero: '', complemento: '', bairro: '', cidade: '', estado: '', ativa: true };

function Section({ titulo, children }) {
  return (
    <div className="border border-slate-200 rounded-lg p-3">
      <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-3">{titulo}</h4>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">{children}</div>
    </div>
  );
}

function Field({ label, children, error, required, full }) {
  return (
    <div className={full ? 'sm:col-span-2 lg:col-span-3' : ''}>
      <Label>{label}{required ? ' *' : ''}</Label>
      <div className="mt-1">{children}</div>
      {error && <p className="text-[11px] text-red-500 mt-1">{error}</p>}
    </div>
  );
}

export default function EmpresasPage() {
  const { podeCriar, podeEditar, podeExcluir } = usePerm('configuracoes');
  const [lista, setLista] = useState([]);
  const [busca, setBusca] = useState('');
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(VAZIO);
  const [erros, setErros] = useState({});
  const [delId, setDelId] = useState(null);

  const load = async () => { try { setLista(await base44.entities.Empresas.list('-created_date', 500)); } catch {} };
  useEffect(() => { load(); }, []);

  const filtrados = useMemo(() => {
    const q = busca.trim().toLowerCase();
    if (!q) return lista;
    return lista.filter((e) => [e.razao_social, e.nome_fantasia, e.cnpj, e.cidade, e.responsavel_nome].some((x) => String(x || '').toLowerCase().includes(q)));
  }, [lista, busca]);

  const openNew = () => { setForm(VAZIO); setErros({}); setEditing('novo'); };
  const openEdit = (e) => { setForm({ ...VAZIO, ...e }); setErros({}); setEditing(e.id); };
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const validar = () => {
    const e = {};
    if (!form.razao_social.trim()) e.razao_social = 'Obrigatório';
    if (!form.nome_fantasia.trim()) e.nome_fantasia = 'Obrigatório';
    if (!form.cnpj.trim()) e.cnpj = 'Obrigatório';
    else if (!validarCnpj(form.cnpj)) e.cnpj = 'CNPJ inválido';
    else {
      const dup = lista.find((x) => x.id !== editing && digits(x.cnpj) === digits(form.cnpj));
      if (dup) e.cnpj = 'CNPJ já cadastrado';
    }
    if (form.email && !validarEmail(form.email)) e.email = 'E-mail inválido';
    setErros(e);
    return Object.keys(e).length === 0;
  };

  const save = async () => {
    if (!validar()) return;
    const payload = applyTitleCaseAll(form);
    try {
      if (editing === 'novo') await base44.entities.Empresas.create(payload);
      else await base44.entities.Empresas.update(editing, payload);
      setEditing(null); load();
    } catch { setErros((p) => ({ ...p, geral: 'Não foi possível salvar.' })); }
  };

  const confirmDel = async () => { try { if (delId) await base44.entities.Empresas.delete(delId); } catch {} setDelId(null); load(); };
  const inputCls = 'h-10';

  return (
    <div>
      <PageHeader title="Empresas" subtitle="Cadastro de empresas do grupo." action={podeCriar ? <Button onClick={openNew} className="min-h-[44px] bg-[#0b2545] hover:bg-[#16365f]"><Plus className="w-4 h-4" />Nova</Button> : null} />

      <div className="relative mb-4 sm:max-w-sm">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <Input placeholder="Pesquisar..." value={busca} onChange={(e) => setBusca(e.target.value)} className="pl-9" />
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
            <tr>
              <th className="text-left px-4 py-3">Razão Social</th>
              <th className="text-left px-4 py-3">Nome Fantasia</th>
              <th className="text-left px-4 py-3">CNPJ</th>
              <th className="text-left px-4 py-3">Cidade/UF</th>
              <th className="text-left px-4 py-3">Status</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtrados.map((e) => (
              <tr key={e.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-[#0b2545]">{e.razao_social || e.nome || '—'}</td>
                <td className="px-4 py-3 text-slate-700">{e.nome_fantasia || '—'}</td>
                <td className="px-4 py-3 text-slate-600">{e.cnpj ? maskCnpj(e.cnpj) : '—'}</td>
                <td className="px-4 py-3 text-slate-600">{[e.cidade, e.estado].filter(Boolean).join('/') || '—'}</td>
                <td className="px-4 py-3">{e.ativa === false ? 'Inativa' : 'Ativa'}</td>
                <td className="px-4 py-3 text-right whitespace-nowrap">
                  {podeEditar && <button onClick={() => openEdit(e)} className="p-2 min-w-[36px] min-h-[36px] rounded-md hover:bg-slate-100 text-[#0b2545]"><Pencil className="w-4 h-4" /></button>}
                  {podeExcluir && <button onClick={() => setDelId(e.id)} className="p-2 min-w-[36px] min-h-[36px] rounded-md hover:bg-red-50 text-slate-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>}
                </td>
              </tr>
            ))}
            {filtrados.length === 0 && <tr><td colSpan={6} className="px-4 py-10 text-center text-slate-400">Nenhuma empresa encontrada.</td></tr>}
          </tbody>
        </table>
      </div>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Building2 className="w-5 h-5 text-[#0b2545]" />{editing === 'novo' ? 'Nova Empresa' : 'Editar Empresa'}</DialogTitle></DialogHeader>
          <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
            <Section titulo="Dados da Empresa">
              <Field label="Razão Social" required error={erros.razao_social}><Input className={inputCls} value={form.razao_social} onChange={(e) => set('razao_social', e.target.value)} /></Field>
              <Field label="Nome Fantasia" required error={erros.nome_fantasia}><Input className={inputCls} value={form.nome_fantasia} onChange={(e) => set('nome_fantasia', e.target.value)} /></Field>
              <Field label="CNPJ" required error={erros.cnpj}><Input className={inputCls} value={form.cnpj} onChange={(e) => set('cnpj', maskCnpj(e.target.value))} placeholder="00.000.000/0000-00" /></Field>
              <Field label="Inscrição Estadual"><Input className={inputCls} value={form.inscricao_estadual} onChange={(e) => set('inscricao_estadual', e.target.value)} /></Field>
              <Field label="Inscrição Municipal"><Input className={inputCls} value={form.inscricao_municipal} onChange={(e) => set('inscricao_municipal', e.target.value)} /></Field>
            </Section>
            <Section titulo="Contato">
              <Field label="Nome do responsável"><Input className={inputCls} value={form.responsavel_nome} onChange={(e) => set('responsavel_nome', e.target.value)} /></Field>
              <Field label="Cargo/Função do responsável"><Input className={inputCls} value={form.responsavel_cargo} onChange={(e) => set('responsavel_cargo', e.target.value)} /></Field>
              <Field label="Telefone"><Input className={inputCls} value={form.telefone} onChange={(e) => set('telefone', maskTel(e.target.value))} placeholder="(00) 0000-0000" /></Field>
              <Field label="Celular/WhatsApp"><Input className={inputCls} value={form.celular} onChange={(e) => set('celular', maskCel(e.target.value))} placeholder="(00) 00000-0000" /></Field>
              <Field label="É WhatsApp?"><label className="flex items-center gap-2 h-10"><Switch checked={!!form.whatsapp} onCheckedChange={(v) => set('whatsapp', v)} /><span className="text-sm text-slate-600">{form.whatsapp ? 'Sim' : 'Não'}</span></label></Field>
              <Field label="E-mail" error={erros.email}><Input className={inputCls} value={form.email} onChange={(e) => set('email', e.target.value)} placeholder="nome@empresa.com" /></Field>
            </Section>
            <Section titulo="Endereço">
              <Field label="CEP"><Input className={inputCls} value={form.cep} onChange={(e) => set('cep', maskCep(e.target.value))} placeholder="00000-000" /></Field>
              <Field label="Logradouro" full><Input className={inputCls} value={form.logradouro} onChange={(e) => set('logradouro', e.target.value)} /></Field>
              <Field label="Número"><Input className={inputCls} value={form.numero} onChange={(e) => set('numero', e.target.value)} /></Field>
              <Field label="Complemento"><Input className={inputCls} value={form.complemento} onChange={(e) => set('complemento', e.target.value)} /></Field>
              <Field label="Bairro"><Input className={inputCls} value={form.bairro} onChange={(e) => set('bairro', e.target.value)} /></Field>
              <Field label="Cidade"><Input className={inputCls} value={form.cidade} onChange={(e) => set('cidade', e.target.value)} /></Field>
              <Field label="Estado"><Select value={form.estado || ''} onValueChange={(v) => set('estado', v)}><SelectTrigger className={inputCls}><SelectValue placeholder="UF" /></SelectTrigger><SelectContent>{UF.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent></Select></Field>
            </Section>
            <Section titulo="Situação">
              <Field label="Ativa / Inativa"><label className="flex items-center gap-2 h-10"><Switch checked={form.ativa !== false} onCheckedChange={(v) => set('ativa', v)} /><span className="text-sm text-slate-600">{form.ativa === false ? 'Inativa' : 'Ativa'}</span></label></Field>
            </Section>
            {erros.geral && <p className="text-sm text-red-600">{erros.geral}</p>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancelar</Button>
            <Button onClick={save} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!delId} onOpenChange={(o) => !o && setDelId(null)}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader><AlertDialogTitle>Excluir empresa</AlertDialogTitle><AlertDialogDescription>Tem certeza? Esta ação não pode ser desfeita.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={confirmDel} className="bg-red-500 hover:bg-red-600 text-white">Excluir</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}