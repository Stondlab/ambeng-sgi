import React from 'react';
import { Check, MonitorCog, Moon, Sun } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import { useTheme } from '@/lib/ThemeContext';

const options = [
  { value: 'claro', label: 'Claro', description: 'Usar sempre o tema claro', Icon: Sun },
  { value: 'escuro', label: 'Escuro', description: 'Usar sempre o tema escuro', Icon: Moon },
  { value: 'automatico', label: 'Automático', description: 'Seguir o sistema operacional', Icon: MonitorCog },
];
export default function AparenciaPage() {
  const { preference, setPreference } = useTheme();
  return <div><PageHeader title="Aparência" subtitle="Escolha como o sistema deve ser exibido para você." /><div className="grid gap-3 sm:grid-cols-3">{options.map(({ value, label, description, Icon }) => { const selected = preference === value; return <button key={value} onClick={() => setPreference(value)} className={`min-h-32 rounded-xl border p-4 text-left transition-colors ${selected ? 'border-primary bg-primary/5 ring-2 ring-primary/15' : 'border-border bg-card hover:bg-muted'}`}><div className="flex items-center justify-between"><Icon className={`h-6 w-6 ${selected ? 'text-primary' : 'text-muted-foreground'}`} />{selected && <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground"><Check className="h-4 w-4" /></span>}</div><p className="mt-4 font-semibold text-foreground">{label}</p><p className="mt-1 text-sm text-muted-foreground">{description}</p></button>; })}</div></div>;
}