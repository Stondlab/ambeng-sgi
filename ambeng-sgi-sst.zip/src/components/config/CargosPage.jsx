import React from 'react';
import GenericCrudPage from '@/components/config/GenericCrudPage';
import { UserCog } from 'lucide-react';

export default function CargosPage() {
  return (
    <GenericCrudPage
      entity="CargosFuncoes"
      title="Cadastro de Funções"
      subtitle="Cadastre as funções com salário base, benefícios e empresa vinculada."
      icon={UserCog}
      fields={[
        { name: 'nome', label: 'Nome da Função', required: true },
        { name: 'cbo', label: 'CBO', required: true },
        { name: 'salario_base', label: 'Salário Base (R$)', type: 'money', required: true },
        { name: 'vt_diario', label: 'VT Diário (R$)', type: 'money', required: true },
        { name: 'vr_diario', label: 'VR Diário (R$)', type: 'money', required: true },
        { name: 'empresa_id', label: 'Empresa', type: 'entity-select', entity: 'Empresas', optionLabel: 'nome_fantasia', required: true },
        { name: 'descricao', label: 'Descrição', type: 'textarea' },
        { name: 'ativa', label: 'Ativo', type: 'boolean' },
      ]}
      columns={[
        { name: 'nome', label: 'Nome' },
        { name: 'cbo', label: 'CBO' },
        { name: 'salario_base', label: 'Salário Base', type: 'money' },
        { name: 'vt_diario', label: 'VT Diário', type: 'money' },
        { name: 'vr_diario', label: 'VR Diário', type: 'money' },
        { name: 'empresa_id', label: 'Empresa', type: 'entity-select', entity: 'Empresas', optionLabel: 'nome_fantasia' },
      ]}
      searchFields={['nome', 'cbo']}
    />
  );
}