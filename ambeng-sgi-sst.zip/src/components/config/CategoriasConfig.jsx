import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CORES_ETIQUETA, corEtiqueta } from '@/lib/quadro';
import { Pencil, Trash2 } from 'lucide-react';
import PageHeader from '@/components/PageHeader';

export default function CategoriasConfig() {
  const [lista, setLista] = useState([]);
  const [nome, setNome] = useState('');
  const [cor, setCor] = useState('cinza');
  const [editId, setEditId] = useState(null);

  const load = async () => { try { setLista(await base44.entities.Categorias.list('nome', 500)); } catch {} };
  useEffect(() => { load(); }, []);

  const salvar = async () => {
    if (!nome.trim()) return;
    if (editId) await base44.entities.Categorias.update(editId, { nome: nome.trim(), cor });
    else await base44.entities.Categorias.create({ nome: nome.trim(), cor });
    setNome(''); setCor('cinza'); setEditId(null); load();
  };
  const editar = (c) => { setEditId(c.id); setNome(c.nome); setCor(c.cor || 'cinza'); };
  const excluir = async (id) => { await base44.entities.Categorias.delete(id); load(); };
  const cancelar = () => { setEditId(null); setNome(''); setCor('cinza'); };

  return (
    <div>
      <PageHeader title="Categorias" subtitle="Cadastre as categorias usadas nos cartões da Central de Operações." />
      <div className="bg-white border border-slate-200 rounded-xl p-4 mb-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
          <div><Label>Nome</Label><Input className="mt-1" value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Ex.: Segurança" /></div>
          <div><Label>Cor</Label><Select value={cor} onValueChange={setCor}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{CORES_ETIQUETA.map((c) => <SelectItem key={c.key} value={c.key}>{c.label}</SelectItem>)}</SelectContent></Select></div>
          <div className="flex gap-2">
            <Button onClick={salvar} className="bg-[#0b2545] hover:bg-[#16365f]">{editId ? 'Atualizar' : 'Adicionar'}</Button>
            {editId && <Button variant="ghost" onClick={cancelar}>Cancelar</Button>}
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {lista.map((c) => { const cc = corEtiqueta(c.cor); return (
          <div key={c.id} className="bg-white border border-slate-200 rounded-xl p-3 flex items-center gap-3">
            <span className={`w-3 h-8 rounded ${cc.dot}`} />
            <div className="flex-1 min-w-0"><p className="text-sm font-medium text-[#0b2545] truncate">{c.nome}</p><p className="text-xs text-slate-400">{cc.label}</p></div>
            <button onClick={() => editar(c)} className="p-1.5 text-slate-400 hover:text-[#0b2545]"><Pencil className="w-4 h-4" /></button>
            <button onClick={() => excluir(c.id)} className="p-1.5 text-slate-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
          </div>
        ); })}
        {lista.length === 0 && <p className="text-sm text-slate-400 col-span-full text-center py-6">Nenhuma categoria cadastrada.</p>}
      </div>
    </div>
  );
}