import { useLocation } from 'react-router-dom';
import { usePermissoes } from '@/lib/PermissoesContext';
import { podeAcessar } from '@/lib/permissoes';
import { ShieldAlert } from 'lucide-react';

// Guardião de rota por perfil. Bloqueia acesso direto (URL) a páginas cujo módulo
// o perfil não pode visualizar. Não basta esconder o menu — a rota é bloqueada aqui
// e os dados admin-only vêm de funções de backend que validam o perfil novamente.
export default function RoleGuard({ children }) {
  const { perfilEfetivo } = usePermissoes();
  const loc = useLocation();
  if (!podeAcessar(perfilEfetivo, loc.pathname)) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center px-6">
        <ShieldAlert className="w-12 h-12 text-amber-500 mb-3" />
        <h2 className="text-lg font-semibold text-[#0b2545]">Acesso restrito ao Administrador.</h2>
        <p className="text-sm text-slate-500 mt-1">Seu perfil não tem permissão para visualizar esta página.</p>
      </div>
    );
  }
  return children;
}