import React from 'react';
import { fmtMoney } from '@/lib/financeiro';

const mesLabel = (mes) => new Date(`${mes}-01T00:00:00`).toLocaleDateString('pt-BR', { month: 'short', year: '2-digit' });

export default function EvolucaoFuncionarios({ detalhe }) {
  return <section className="rounded-xl border bg-card p-5"><div className="mb-4"><h3 className="font-semibold text-primary">Evolução por funcionário</h3><p className="text-sm text-muted-foreground">Custo mensal apropriado exclusivamente à obra selecionada.</p></div>
    <div className="overflow-x-auto"><table className="w-full min-w-[560px] text-sm"><thead><tr className="border-b text-left text-xs text-muted-foreground"><th className="py-2 pr-3">Funcionário</th>{detalhe.meses.map((mes) => <th key={mes} className="px-3 py-2 text-right">{mesLabel(mes)}</th>)}<th className="py-2 pl-3 text-right">Total</th></tr></thead>
      <tbody>{detalhe.funcionarios.map((f) => <tr key={f.id} className="border-b"><td className="py-2.5 pr-3 font-medium text-primary">{f.nome}</td>{detalhe.meses.map((mes) => <td key={mes} className="px-3 py-2.5 text-right">{fmtMoney(f.meses[mes] || 0)}</td>)}<td className="py-2.5 pl-3 text-right font-semibold">{fmtMoney(f.custo)}</td></tr>)}</tbody>
    </table></div>
  </section>;
}