import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { fmtMoney } from '@/lib/financeiro';

const visual = { saudavel: ['Saudável', 'bg-emerald-100 text-emerald-700', 'bg-emerald-500'], atencao: ['Atenção', 'bg-amber-100 text-amber-700', 'bg-amber-500'], risco: ['Crítico', 'bg-red-100 text-red-700', 'bg-red-500'], sem_receita: ['Sem receita cadastrada', 'bg-amber-100 text-amber-700', 'bg-amber-500'], sem_movimento: ['Sem movimentação', 'bg-muted text-muted-foreground', 'bg-muted-foreground'], concluida: ['Concluída', 'bg-primary/10 text-primary', 'bg-primary'] };
export default function ObraSaudeCard({ obra, search }) {
  const f = obra.fin;
  const [label, badge, dot] = visual[f.situacao];
  const margem = f.margemResultado == null ? 'Sem receita / N/A' : `${f.margemResultado.toFixed(1)}%`;
  return <Link to={`/saude-obras/${obra.id}${search}`} className="block rounded-xl border bg-card p-4 shadow-card transition hover:shadow-card-hover">
    <div className="flex items-start justify-between gap-3"><div><div className="flex items-center gap-2"><span className={`h-2.5 w-2.5 rounded-full ${dot}`} /><h2 className="font-semibold text-primary">{obra.nome}</h2></div><p className="mt-1 text-xs text-muted-foreground">{obra.cliente || obra.status || 'Obra'}</p></div><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${badge}`}>{label}</span></div>
    <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3"><Metric label="Receita" value={f.receitaPrevista > 0 ? fmtMoney(f.receitaPrevista) : 'Sem receita cadastrada'} /><Metric label="Custo total" value={fmtMoney(f.custoRealizado)} /><Metric label="Resultado" value={f.receitaPrevista > 0 ? fmtMoney(f.resultado) : '—'} negative={f.receitaPrevista > 0 && f.resultado < 0} /><Metric label="Margem" value={margem} /><Metric label="Orçamento" value={f.temOrc ? fmtMoney(f.custoPrevisto) : 'Não informado'} /><Metric label="Valor consumido" value={fmtMoney(f.custoRealizado)} /><Metric label="Saldo do orçamento" value={f.temOrc ? fmtMoney(f.custoPrevisto - f.custoRealizado) : 'N/A'} negative={f.temOrc && f.custoPrevisto - f.custoRealizado < 0} /><Metric label="% consumido" value={f.pctOrc == null ? 'N/A' : `${f.pctOrc.toFixed(1)}%`} /></div>
    <div className="mt-4 flex items-center justify-end border-t pt-3 text-xs font-medium text-primary">Ver detalhamento <ChevronRight className="ml-1 h-4 w-4" /></div>
  </Link>;
}
function Metric({ label, value, negative }) { return <div><p className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</p><p className={`mt-0.5 text-sm font-bold ${negative ? 'text-red-600' : 'text-foreground'}`}>{value}</p></div>; }