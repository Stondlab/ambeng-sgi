import React from 'react';
import { ChevronRight, HardHat, ReceiptText, Package } from 'lucide-react';
import { fmtMoney } from '@/lib/financeiro';

const icons = { 'mao-obra': HardHat, materiais: Package, adm: ReceiptText, equipamentos: ReceiptText, terceiros: ReceiptText, operacionais: ReceiptText, outros: ReceiptText };
export default function ComposicaoCusto({ composicao, onSelect }) {
  return <section id="composicao-custo" className="rounded-xl border bg-card p-5">
    <div className="mb-4"><h2 className="font-semibold text-primary">Composição do custo da obra</h2><p className="text-sm text-muted-foreground">Clique em um componente para chegar aos registros que formam o valor.</p></div>
    <div className="divide-y">{composicao.itens.map((item) => { const Icon = icons[item.id] || ReceiptText; return <button key={item.id} onClick={() => onSelect(item.id)} className="flex min-h-[64px] w-full items-center gap-3 py-3 text-left hover:bg-muted/40"><span className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted text-primary"><Icon className="h-5 w-5" /></span><span className="flex-1"><strong className="block text-sm text-foreground">{item.label}</strong><span className="text-xs text-muted-foreground">{item.percentual.toFixed(1)}% do custo</span></span><strong className="text-sm text-primary">{fmtMoney(item.valor)}</strong><ChevronRight className="h-4 w-4 text-muted-foreground" /></button>; })}</div>
    <div className="flex items-center justify-between border-t-2 pt-3"><strong>Total</strong><strong className="text-lg text-primary">{fmtMoney(composicao.total)}</strong></div>
  </section>;
}