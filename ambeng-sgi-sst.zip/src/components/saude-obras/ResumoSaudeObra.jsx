import React from 'react';
import { fmtMoney } from '@/lib/financeiro';

const status = { saudavel: ['Saudável', 'bg-emerald-100 text-emerald-700'], atencao: ['Atenção', 'bg-amber-100 text-amber-700'], risco: ['Crítico', 'bg-red-100 text-red-700'], sem_receita: ['Sem receita cadastrada', 'bg-amber-100 text-amber-700'], sem_movimento: ['Sem movimentação', 'bg-muted text-muted-foreground'], concluida: ['Concluída', 'bg-primary/10 text-primary'] };
export default function ResumoSaudeObra({ obra, onSelect }) {
  const f = obra.fin;
  const [label, cor] = status[f.situacao];
  const cards = [
    ['Faturamento', fmtMoney(f.receitaPrevista), 'receita'], ['Recebido', fmtMoney(f.receitaRecebida), 'recebido'], ['A receber', fmtMoney(Math.max(0, f.receitaPrevista - f.receitaRecebida)), 'a-receber'], ['Custo', fmtMoney(f.custoRealizado), 'custo'], ['A pagar', fmtMoney(f.aPagar), 'a-pagar'], ['Resultado', f.receitaPrevista > 0 ? fmtMoney(f.resultado) : 'Sem receita cadastrada', 'resultado', f.receitaPrevista > 0 && f.resultado < 0],
    ['Margem', f.margemResultado == null ? 'Sem receita / N/A' : `${f.margemResultado.toFixed(1)}%`, 'margem'], ['Orçamento', f.temOrc ? fmtMoney(f.custoPrevisto) : 'Não informado', 'orcamento'], ['Valor consumido', fmtMoney(f.custoRealizado), 'consumido'], ['Saldo do orçamento', f.temOrc ? fmtMoney(f.custoPrevisto - f.custoRealizado) : 'N/A', 'saldo'], ['% consumido', f.pctOrc == null ? 'N/A' : `${f.pctOrc.toFixed(1)}%`, 'percentual'],
  ];
  return <><div className="mb-4 flex items-center gap-2"><span className={`rounded-full px-3 py-1 text-sm font-semibold ${cor}`}>{label}</span><span className="text-sm text-muted-foreground">Saúde econômica no período</span></div><div className="grid grid-cols-2 gap-3 lg:grid-cols-3 xl:grid-cols-5">{cards.map(([nome, valor, id, negativo]) => <button key={nome} onClick={() => onSelect(id)} className="rounded-xl border bg-card p-4 text-left hover:border-primary/40 hover:shadow-card"><p className="text-xs text-muted-foreground">{nome}</p><p className={`mt-1 max-w-full break-words text-[clamp(0.85rem,1.4vw,1.125rem)] font-bold leading-tight ${negativo ? 'text-red-600' : 'text-primary'}`} title={valor}>{valor}</p></button>)}</div></>;
}