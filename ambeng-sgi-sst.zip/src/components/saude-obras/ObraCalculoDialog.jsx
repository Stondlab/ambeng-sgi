import React from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { fmtMoney } from '@/lib/financeiro';

export default function ObraCalculoDialog({ obra, indicador, onClose }) {
  if (!indicador) return null; const f = obra.fin;
  const dados = {
    receita: { titulo: 'Receita', formula: 'Soma das parcelas de receita vinculadas à obra no período', linhas: [['Receita prevista', f.receitaPrevista], ['Receita recebida', f.receitaRecebida]] },
    custo: { titulo: 'Custo', formula: 'Despesas financeiras válidas + mão de obra apropriada por horas', linhas: [['Despesas', f.custoDespesas], ['Mão de obra apropriada', f.custoMaoObra]] },
    resultado: { titulo: 'Resultado', formula: 'Receita prevista − custo realizado', linhas: [['Receita prevista', f.receitaPrevista], ['Custo realizado', f.custoRealizado]] },
    margem: { titulo: 'Margem', formula: 'Resultado ÷ receita prevista × 100', linhas: [['Resultado', f.resultado], ['Receita prevista', f.receitaPrevista]] },
    orcamento: { titulo: 'Orçamento', formula: 'Valor de orçamento cadastrado na obra', linhas: [['Orçamento', f.custoPrevisto]] },
    consumido: { titulo: 'Valor consumido', formula: 'Despesas financeiras válidas + mão de obra apropriada', linhas: [['Valor consumido', f.custoRealizado]] },
    saldo: { titulo: 'Saldo do orçamento', formula: 'Orçamento − valor consumido', linhas: [['Orçamento', f.custoPrevisto], ['Valor consumido', f.custoRealizado]] },
    percentual: { titulo: 'Percentual consumido', formula: 'Valor consumido ÷ orçamento × 100', linhas: [['Valor consumido', f.custoRealizado], ['Orçamento', f.custoPrevisto]] },
  }[indicador];
  const resultado = ['orcamento', 'saldo', 'percentual'].includes(indicador) && !f.temOrc ? 'N/A' : indicador === 'margem' ? (f.margemResultado == null ? 'N/A' : `${f.margemResultado.toFixed(1)}%`) : indicador === 'percentual' ? `${f.pctOrc.toFixed(1)}%` : fmtMoney(indicador === 'receita' ? f.receitaPrevista : indicador === 'custo' || indicador === 'consumido' ? f.custoRealizado : indicador === 'resultado' ? f.resultado : indicador === 'orcamento' ? f.custoPrevisto : f.custoPrevisto - f.custoRealizado);
  return <Dialog open={!!indicador} onOpenChange={(open) => !open && onClose()}><DialogContent className="max-w-lg"><DialogHeader><DialogTitle>{dados.titulo}</DialogTitle><DialogDescription>Composição referente à obra {obra.nome}.</DialogDescription></DialogHeader><div className="rounded-lg bg-muted p-3 text-sm font-medium">{dados.formula}</div><div className="divide-y rounded-lg border">{dados.linhas.map(([label, value]) => <div key={label} className="flex min-h-11 items-center justify-between gap-3 px-3 text-sm"><span className="text-muted-foreground">{label}</span><strong>{fmtMoney(value)}</strong></div>)}</div><div className="flex justify-between border-t pt-3"><strong>Total</strong><strong className="text-lg text-primary">{resultado}</strong></div></DialogContent></Dialog>;
}