import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import { composicaoCusto, detalharMaoObra } from '@/lib/saudeObras';
import ResumoSaudeObra from './ResumoSaudeObra';
import ComposicaoCusto from './ComposicaoCusto';
import LancamentosCustoObra from './LancamentosCustoObra';
import LancamentosReceitaObra from './LancamentosReceitaObra';
import MaoObraPorFuncionario from './MaoObraPorFuncionario';
import RelatorioFinanceiroObra from './RelatorioFinanceiroObra';
import ObraCalculoDialog from './ObraCalculoDialog';

export default function DetalhamentoSaudeObra({ obra, analise, search, range }) {
  const [aberto, setAberto] = useState(null);
  const [indicador, setIndicador] = useState(null);
  const detalheMaoObra = useMemo(() => detalharMaoObra(obra, analise.geraisPorMes), [obra, analise.geraisPorMes]);
  const composicao = useMemo(() => composicaoCusto(obra, analise.despesas, detalheMaoObra.total), [obra, analise.despesas, detalheMaoObra.total]);
  const itemAberto = composicao.itens.find((item) => item.id === aberto);
  const periodoLabel = `${new Date(`${range.inicio}T00:00:00`).toLocaleDateString('pt-BR')} a ${new Date(`${range.fim}T00:00:00`).toLocaleDateString('pt-BR')}`;
  const irComposicao = () => document.getElementById('composicao-custo')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  return <div className="space-y-5"><Link to={`/saude-obras${search}`} className="inline-flex min-h-[44px] items-center gap-2 text-sm font-medium text-primary"><ArrowLeft className="h-4 w-4" />Voltar para Saúde das Obras</Link><PageHeader title={obra.nome} subtitle="Detalhamento da saúde econômica e origem dos custos da obra." /><ResumoSaudeObra obra={obra} onSelect={(id) => { if (id === 'custo') irComposicao(); setIndicador(id); }} /><LancamentosReceitaObra registros={obra.fin.rec} /><ComposicaoCusto composicao={composicao} onSelect={setAberto} />
    {aberto === 'mao-obra' && <><MaoObraPorFuncionario obra={obra.nome} detalhe={detalheMaoObra} periodo={periodoLabel} />{itemAberto?.registros?.length > 0 && <LancamentosCustoObra titulo="Lançamentos financeiros de mão de obra" registros={itemAberto.registros} />}</>}
    {['materiais', 'adm', 'equipamentos', 'terceiros', 'operacionais', 'outros'].includes(aberto) && <LancamentosCustoObra titulo={itemAberto?.label || 'Lançamentos'} registros={itemAberto?.registros || []} />}
    <LancamentosCustoObra titulo="Todas as despesas da obra" registros={obra.fin.desp} />
    <RelatorioFinanceiroObra obra={obra} detalhe={detalheMaoObra} composicao={composicao} periodo={periodoLabel} />
    <ObraCalculoDialog obra={obra} indicador={indicador} onClose={() => setIndicador(null)} />
  </div>;
}