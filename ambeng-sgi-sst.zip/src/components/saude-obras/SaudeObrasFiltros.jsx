import React from 'react';
import { PERIODOS } from '@/lib/dashboardFinanceiro';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function SaudeObrasFiltros({ periodo, setPeriodo, custom, setCustom, obra, setObra, obras }) {
  return <section className="rounded-xl border bg-card p-4">
    <div className="flex flex-wrap items-center gap-2">
      <span className="mr-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Período</span>
      {PERIODOS.map((p) => <button key={p.id} onClick={() => setPeriodo(p.id)} className={`min-h-[40px] rounded-full border px-3 text-xs font-medium ${periodo === p.id ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-muted-foreground'}`}>{p.label}</button>)}
    </div>
    {periodo === 'mes' && <input type="month" value={custom.inicio.slice(0, 7)} onChange={(e) => setCustom({ inicio: `${e.target.value}-01`, fim: `${e.target.value}-01` })} className="mt-3 h-11 rounded-lg border bg-card px-3 text-sm" />}
    {periodo === 'custom' && <div className="mt-3 grid gap-3 sm:grid-cols-2"><input type="date" value={custom.inicio} onChange={(e) => setCustom((c) => ({ ...c, inicio: e.target.value }))} className="h-11 rounded-lg border bg-card px-3 text-sm" /><input type="date" value={custom.fim} onChange={(e) => setCustom((c) => ({ ...c, fim: e.target.value }))} className="h-11 rounded-lg border bg-card px-3 text-sm" /></div>}
    <div className="mt-3 max-w-sm"><Select value={obra} onValueChange={setObra}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="todas">Todas as obras</SelectItem>{obras.map((o) => <SelectItem key={o.id} value={o.id}>{o.nome}</SelectItem>)}</SelectContent></Select></div>
  </section>;
}