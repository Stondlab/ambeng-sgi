import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { statusLiberacao, STATUS_LIB } from '@/lib/liberacao';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { ArrowRight } from 'lucide-react';

const BADGE = {
  'Cadastro Incompleto': 'bg-slate-100 text-slate-700 border-slate-200',
  'Pendente de Liberação': 'bg-amber-50 text-amber-700 border-amber-200',
  'Bloqueado': 'bg-red-50 text-red-700 border-red-200',
  'Liberado para Trabalho': 'bg-emerald-50 text-emerald-700 border-emerald-200',
};
const STAT_TONE = {
  'Cadastro Incompleto': 'text-slate-600',
  'Pendente de Liberação': 'text-amber-600',
  'Bloqueado': 'text-red-600',
  'Liberado para Trabalho': 'text-emerald-600',
};

const diasDesde = (d) => (d ? Math.max(0, Math.round((Date.now() - new Date(d)) / 86400000)) : 0);

export default function ColaboradoresPendentesCard({ funcionarios, asos, treinamentos, epis, integracoes, documentos, pendencias }) {
  const [fStatus, setFStatus] = useState('all');
  const [fObra, setFObra] = useState('all');

  const todas = useMemo(() => {
    return funcionarios.map((f) => {
      const ctx = {
        asos: asos.filter((a) => a.funcionario_id === f.id),
        treinamentos: treinamentos.filter((t) => t.funcionario_id === f.id),
        epis: epis.filter((e) => e.funcionario_id === f.id),
        integracoes: integracoes.filter((i) => i.funcionario_id === f.id),
        documentos: documentos.filter((d) => d.funcionario_id === f.id),
      };
      const r = statusLiberacao(f, ctx);
      const pend = pendencias.filter((p) => p.funcionario_id === f.id && p.status !== 'Concluída');
      return { f, status: r.status, label: STATUS_LIB[r.status], pendentes: r.pendentes, pend, dias: diasDesde(f.created_date) };
    });
  }, [funcionarios, asos, treinamentos, epis, integracoes, documentos, pendencias]);

  const pendentesRows = todas.filter((r) => ['pendente', 'bloqueado', 'cadastro_incompleto'].includes(r.status));
  const resumo = useMemo(() => {
    const c = { 'Cadastro Incompleto': 0, 'Pendente de Liberação': 0, 'Bloqueado': 0, 'Liberado para Trabalho': 0 };
    todas.forEach((r) => { c[r.label] = (c[r.label] || 0) + 1; });
    return c;
  }, [todas]);

  const obras = useMemo(() => Array.from(new Set(todas.map((r) => r.f.obra).filter(Boolean))), [todas]);

  const rows = pendentesRows.filter((r) => (fStatus === 'all' || r.label === fStatus) && (fObra === 'all' || r.f.obra === fObra));

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 mb-8">
      <div className="flex flex-wrap items-center gap-2 mb-4">
        <h2 className="text-lg font-semibold text-[#0b2545]">Colaboradores Pendentes de Liberação</h2>
        <div className="flex flex-wrap gap-3 ml-auto text-xs">
          {Object.entries(resumo).map(([k, v]) => (
            <span key={k} className={`flex items-center gap-1 ${STAT_TONE[k] || 'text-slate-500'}`}><span className="font-bold text-sm">{v}</span>{k}</span>
          ))}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 mb-3">
        <Select value={fStatus} onValueChange={setFStatus}>
          <SelectTrigger className="w-44 h-8 text-xs"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os status</SelectItem>
            <SelectItem value="Bloqueado">Bloqueado</SelectItem>
            <SelectItem value="Pendente de Liberação">Pendente de Liberação</SelectItem>
            <SelectItem value="Cadastro Incompleto">Cadastro Incompleto</SelectItem>
          </SelectContent>
        </Select>
        <Select value={fObra} onValueChange={setFObra}>
          <SelectTrigger className="w-44 h-8 text-xs"><SelectValue placeholder="Obra" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as obras</SelectItem>
            {obras.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
          </SelectContent>
        </Select>
        <Link to="/relatorios" className="ml-auto inline-flex items-center gap-1 text-xs font-medium text-[#0b2545] hover:underline">Ver relatório completo <ArrowRight className="w-3 h-3" /></Link>
      </div>

      {rows.length === 0 ? <p className="text-sm text-emerald-700">Nenhum colaborador pendente de liberação.</p> : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs text-slate-400 border-b border-slate-100">
              <tr><th className="text-left py-2 pr-3">Nome</th><th className="text-left px-2">Obra</th><th className="text-left px-2">Pendência</th><th className="text-left px-2">Responsável</th><th className="text-right px-2">Dias</th><th className="text-left pl-2">Status</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {rows.map((r) => (
                <tr key={r.f.id}>
                  <td className="py-2 pr-3"><Link to={`/funcionarios/${r.f.id}`} className="font-medium text-[#0b2545] hover:underline">{r.f.nome}</Link></td>
                  <td className="px-2 text-slate-600">{r.f.obra || '—'}</td>
                  <td className="px-2 text-slate-600">{r.pendentes[0]?.label || '—'}</td>
                  <td className="px-2 text-slate-600">{r.pend[0]?.responsavel || r.pend[0]?.setor || '—'}</td>
                  <td className="px-2 text-right text-slate-600">{r.dias}</td>
                  <td className="pl-2"><span className={`text-xs px-2 py-0.5 rounded-full border ${BADGE[r.label]}`}>{r.label}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}