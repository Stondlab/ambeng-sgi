import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { statusLiberacao, checklistLiberacao, STATUS_LIB } from '@/lib/liberacao';
import { fmt } from '@/lib/sst';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { CheckCircle2, XCircle, ShieldCheck, AlertTriangle, Ban, Clock, UserPlus } from 'lucide-react';

const BADGE = {
  'Cadastro Incompleto': 'bg-slate-100 text-slate-700 border-slate-200',
  'Pendente de Liberação': 'bg-amber-50 text-amber-700 border-amber-200',
  'Liberado para Trabalho': 'bg-emerald-50 text-emerald-700 border-emerald-200',
  'Bloqueado': 'bg-red-50 text-red-700 border-red-200',
  'Desligado': 'bg-slate-200 text-slate-600 border-slate-300',
};
const PRIORIDADES = ['Baixa', 'Média', 'Alta', 'Crítica'];
const CATEGORIAS = ['Documentação', 'ASO', 'Treinamento', 'EPI', 'Integração', 'Cadastro', 'Outro'];

export default function LiberacaoPanel({ func, ctx, demandas = [], onUpdated }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ titulo: '', responsavel: func.supervisor || '', prazo: '', prioridade: 'Média', categoria: 'Cadastro', descricao: '' });
  const result = statusLiberacao(func, ctx);
  const items = checklistLiberacao(func, ctx);
  const label = STATUS_LIB[result.status];

  useEffect(() => {
    if (label && func.status_liberacao !== label) {
      (async () => {
        const patch = { status_liberacao: label };
        if (result.status === 'liberado') {
          patch.data_liberacao = new Date().toISOString().slice(0, 10);
          try { const me = await base44.auth.me(); patch.usuario_liberacao = me.nome_exibicao || me.full_name || me.email; } catch {}
        }
        try { await base44.entities.Funcionarios.update(func.id, patch); onUpdated?.(); } catch {}
      })();
    }
  }, [label]);

  const Icon = result.status === 'liberado' ? ShieldCheck : result.status === 'bloqueado' ? Ban : result.status === 'pendente' ? Clock : AlertTriangle;
  const iconColor = result.status === 'liberado' ? 'text-emerald-600' : result.status === 'bloqueado' ? 'text-red-600' : 'text-amber-600';

  const pendencias = (demandas || []).filter((d) => d.status !== 'Concluído' && d.status !== 'Cancelado');

  const criar = async () => {
    if (!form.titulo.trim()) return;
    setSaving(true);
    try {
      const hist = [{ evento: 'Pendência criada na ficha do colaborador', data: new Date().toISOString(), usuario: func.nome }];
      await base44.entities.Demandas.create({
        titulo: form.titulo.trim(),
        descricao: form.descricao,
        responsavel: form.responsavel,
        funcionario_id: func.id,
        origem: 'RH',
        tipo: 'Tarefa',
        status: 'Novo',
        prioridade: form.prioridade,
        categoria: form.categoria,
        prazo: form.prazo,
        obra: func.obra,
        empresa: func.empresa,
        solicitante: func.nome,
        historico: JSON.stringify(hist),
      });
      setOpen(false);
      setForm({ titulo: '', responsavel: func.supervisor || '', prazo: '', prioridade: 'Média', categoria: 'Cadastro', descricao: '' });
      onUpdated?.();
    } catch {}
    setSaving(false);
  };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <Icon className={`w-5 h-5 ${iconColor}`} />
        <h3 className="font-semibold text-[#0b2545]">Liberação do Colaborador</h3>
        <span className={`ml-auto text-xs px-3 py-1 rounded-full border font-medium ${BADGE[label]}`}>{label}</span>
      </div>

      {result.status === 'liberado' && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 mb-4 text-sm text-emerald-800">
          Colaborador apto para iniciar suas atividades.
          {func.data_liberacao && <span className="block text-xs text-emerald-700 mt-1">Liberado em {fmt(func.data_liberacao)}{func.usuario_liberacao ? ` por ${func.usuario_liberacao}` : ''}</span>}
        </div>
      )}
      {result.status === 'bloqueado' && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4 text-sm text-red-800">
          <p className="font-semibold mb-1">COLABORADOR BLOQUEADO</p>
          <p>{result.motivo}</p>
          {result.pendentes.length > 0 && <p className="text-xs mt-1">{result.pendentes.length} pendência(s) de liberação.</p>}
        </div>
      )}
      {(result.status === 'pendente' || result.status === 'cadastro_incompleto') && result.pendentes.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-4">
          <p className="text-sm font-medium text-amber-800 mb-1">Pendências de liberação ({result.pendentes.length}):</p>
          <ul className="text-sm text-amber-700 space-y-0.5">{result.pendentes.map((p) => <li key={p.key}>⚠ {p.label}</li>)}</ul>
        </div>
      )}

      <div className="grid sm:grid-cols-2 gap-2 mb-4">
        {items.map((it) => (
          <div key={it.key} className="flex items-center gap-2 text-sm border border-slate-100 rounded-lg px-3 py-2">
            {it.ok ? <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" /> : <XCircle className="w-4 h-4 text-red-500 shrink-0" />}
            <span className={it.ok ? 'text-slate-700' : 'text-slate-500'}>{it.label}</span>
          </div>
        ))}
      </div>

      {pendencias.length > 0 && (
        <div className="mb-4">
          <p className="text-xs font-medium text-slate-500 mb-1">Pendências (tarefas) do colaborador:</p>
          <div className="space-y-1">{pendencias.map((p) => (
            <div key={p.id} className="text-xs text-slate-600 flex items-center gap-2 border border-slate-100 rounded-lg px-2 py-1.5">
              <span className={`px-1.5 py-0.5 rounded ${p.prioridade === 'Crítica' ? 'bg-red-100 text-red-700' : p.prioridade === 'Alta' ? 'bg-orange-100 text-orange-700' : 'bg-slate-100 text-slate-600'}`}>{p.prioridade || '—'}</span>
              <span className="font-medium text-slate-700">{p.titulo}</span>
              {p.responsavel && <span className="text-slate-400">· {p.responsavel}</span>}
              {p.prazo && <span className="text-slate-400 ml-auto">venc. {fmt(p.prazo)}</span>}
            </div>
          ))}</div>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild><Button variant="outline" className="border-[#0b2545] text-[#0b2545]"><UserPlus className="w-4 h-4 mr-1" />Criar Pendência</Button></DialogTrigger>
        <DialogContent>
          <DialogHeader><DialogTitle>Criar Pendência para o colaborador</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Título / descrição curta *</Label><Input value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })} placeholder="Ex.: Regularizar ASO vencido" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Responsável</Label><Input value={form.responsavel} onChange={(e) => setForm({ ...form, responsavel: e.target.value })} placeholder="Nome do responsável" /></div>
              <div><Label>Prazo</Label><Input type="date" value={form.prazo} onChange={(e) => setForm({ ...form, prazo: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Prioridade</Label>
                <Select value={form.prioridade} onValueChange={(v) => setForm({ ...form, prioridade: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{PRIORIDADES.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent></Select>
              </div>
              <div><Label>Categoria</Label>
                <Select value={form.categoria} onValueChange={(v) => setForm({ ...form, categoria: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{CATEGORIAS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select>
              </div>
            </div>
            <div><Label>Descrição</Label><Textarea value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} rows={2} /></div>
            <p className="text-[11px] text-slate-400">A pendência é criada na mesma estrutura de tarefas do sistema e aparece automaticamente na Central de Operações, em Minhas Tarefas (quando atribuída) e no cadastro do colaborador.</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button onClick={criar} disabled={saving || !form.titulo.trim()} className="bg-[#0b2545] hover:bg-[#16365f]">{saving ? 'Criando...' : 'Criar pendência'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}