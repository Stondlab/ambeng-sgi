import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2 } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import StatusBadge from '@/components/StatusBadge';
import ValidityForm from '@/components/ValidityForm';
import { getStatus, fmt } from '@/lib/sst';

export default function ValidityPage({ title, subtitle, entityName, fields }) {
  const [records, setRecords] = useState([]);
  const [funcionarios, setFuncionarios] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [fFunc, setFFunc] = useState('all');
  const [fStatus, setFStatus] = useState('all');

  const load = async () => {
    const [recs, funcs] = await Promise.all([
      base44.entities[entityName].list('-data_validade', 500),
      base44.entities.Funcionarios.list('nome', 500),
    ]);
    setRecords(recs);
    setFuncionarios(funcs);
    setLoading(false);
  };

  useEffect(() => { load(); }, [entityName]);

  const nome = (id) => funcionarios.find((f) => f.id === id)?.nome || '—';

  const filtered = records.filter((r) =>
    (fFunc === 'all' || r.funcionario_id === fFunc) &&
    (fStatus === 'all' || getStatus(r.data_validade) === fStatus)
  );

  const save = async (values) => {
    await base44.entities[entityName].create(values);
    setShowForm(false);
    await load();
  };

  const remove = async (id) => {
    await base44.entities[entityName].delete(id);
    await load();
  };

  return (
    <div>
      <PageHeader title={title} subtitle={subtitle} action={
        <Button onClick={() => setShowForm((s) => !s)} className="bg-amber-400 text-[#0b2545] hover:bg-amber-300 font-semibold">
          <Plus className="w-4 h-4 mr-1" /> Novo
        </Button>
      } />

      {showForm && <ValidityForm fields={fields} funcionarios={funcionarios} onSubmit={save} onCancel={() => setShowForm(false)} />}

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <Select value={fFunc} onValueChange={setFFunc}>
          <SelectTrigger className="bg-white sm:w-64"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os funcionários</SelectItem>
            {funcionarios.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fStatus} onValueChange={setFStatus}>
          <SelectTrigger className="bg-white sm:w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os status</SelectItem>
            <SelectItem value="Vencido">Vencido</SelectItem>
            <SelectItem value="A vencer">A vencer</SelectItem>
            <SelectItem value="Em dia">Em dia</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
              <tr>
                <th className="text-left px-4 py-3">Funcionário</th>
                {fields.map((f) => <th key={f.name} className="text-left px-4 py-3">{f.label}</th>)}
                <th className="text-left px-4 py-3">Status</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading && <tr><td colSpan={fields.length + 3} className="px-4 py-10 text-center text-slate-400">Carregando...</td></tr>}
              {!loading && filtered.length === 0 && (
                <tr><td colSpan={fields.length + 3} className="px-4 py-10 text-center text-slate-400">Nenhum registro encontrado.</td></tr>
              )}
              {filtered.map((r) => (
                <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 font-medium text-[#0b2545] whitespace-nowrap">{nome(r.funcionario_id)}</td>
                  {fields.map((f) => (
                    <td key={f.name} className="px-4 py-3 text-slate-600 whitespace-nowrap">
                      {f.type === 'date' ? fmt(r[f.name]) : (r[f.name] || '—')}
                    </td>
                  ))}
                  <td className="px-4 py-3"><StatusBadge data_validade={r.data_validade} /></td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => remove(r.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}