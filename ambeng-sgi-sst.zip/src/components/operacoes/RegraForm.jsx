import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { GATILHOS, ACOES } from '@/lib/quadro';
import { TIPOS, PRIORIDADES } from '@/lib/acoes';
import { nomeUsuario } from '@/lib/usuarioNome';

export default function RegraForm({ regra, colunas, etiquetas, usuarios, onClose, onSaved }) {
  const [form, setForm] = useState(regra
    ? { nome: regra.nome, gatilho: regra.gatilho, gatilho_valor: regra.gatilho_valor || '', acao: regra.acao, acao_valor: regra.acao_valor || '', ativa: regra.ativa !== false }
    : { nome: '', gatilho: 'mover_para_coluna', gatilho_valor: '', acao: 'mover_para_coluna', acao_valor: '', ativa: true });

  const setG = (v) => setForm((f) => ({ ...f, gatilho: v, gatilho_valor: '' }));
  const setA = (v) => setForm((f) => ({ ...f, acao: v, acao_valor: '' }));

  const salvar = async () => {
    if (!form.nome.trim()) return;
    if (regra) await base44.entities.RegrasAutomacao.update(regra.id, form);
    else await base44.entities.RegrasAutomacao.create(form);
    onSaved?.();
    onClose?.();
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>{regra ? 'Editar regra' : 'Nova regra'}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Nome</Label><Input className="mt-1" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} placeholder="Ex.: Concluir → arquivar" /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Gatilho</Label><Select value={form.gatilho} onValueChange={setG}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{GATILHOS.map((g) => <SelectItem key={g.v} value={g.v}>{g.label}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Valor do gatilho</Label>
              {form.gatilho === 'mover_para_coluna' ? (
                <Select value={form.gatilho_valor} onValueChange={(v) => setForm({ ...form, gatilho_valor: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Coluna" /></SelectTrigger><SelectContent>{colunas.map((c) => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent></Select>
              ) : form.gatilho === 'criado_com_tipo' ? (
                <Select value={form.gatilho_valor} onValueChange={(v) => setForm({ ...form, gatilho_valor: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Tipo" /></SelectTrigger><SelectContent>{TIPOS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select>
              ) : form.gatilho === 'criado_com_categoria' ? (
                <Input className="mt-1" value={form.gatilho_valor} onChange={(e) => setForm({ ...form, gatilho_valor: e.target.value })} placeholder="Categoria" />
              ) : (
                <Input className="mt-1" disabled placeholder="(automático)" />
              )}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Ação</Label><Select value={form.acao} onValueChange={setA}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{ACOES.map((a) => <SelectItem key={a.v} value={a.v}>{a.label}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Valor da ação</Label>
              {form.acao === 'mover_para_coluna' ? (
                <Select value={form.acao_valor} onValueChange={(v) => setForm({ ...form, acao_valor: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Coluna" /></SelectTrigger><SelectContent>{colunas.map((c) => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent></Select>
              ) : form.acao === 'atribuir_responsavel' ? (
                <Select value={form.acao_valor} onValueChange={(v) => setForm({ ...form, acao_valor: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Responsável" /></SelectTrigger><SelectContent>{usuarios.map((u) => <SelectItem key={u.id} value={nomeUsuario(u)}>{nomeUsuario(u)}</SelectItem>)}</SelectContent></Select>
              ) : form.acao === 'adicionar_etiqueta' ? (
                <Select value={form.acao_valor} onValueChange={(v) => setForm({ ...form, acao_valor: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Etiqueta" /></SelectTrigger><SelectContent>{etiquetas.map((e) => <SelectItem key={e.id} value={e.nome}>{e.nome}</SelectItem>)}</SelectContent></Select>
              ) : form.acao === 'alterar_prioridade' ? (
                <Select value={form.acao_valor} onValueChange={(v) => setForm({ ...form, acao_valor: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Prioridade" /></SelectTrigger><SelectContent>{PRIORIDADES.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent></Select>
              ) : form.acao === 'arquivar' ? (
                <Input className="mt-1" disabled placeholder="(automático)" />
              ) : (
                <Input className="mt-1" value={form.acao_valor} onChange={(e) => setForm({ ...form, acao_valor: e.target.value })} placeholder="Texto da notificação" />
              )}
            </div>
          </div>
          {form.gatilho === 'marcado_concluido' && (
            <label className="flex items-center gap-2 text-sm text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 cursor-pointer">
              <Switch checked={form.acao === 'arquivar'} onCheckedChange={(v) => setForm((f) => ({ ...f, acao: v ? 'arquivar' : 'mover_para_coluna', acao_valor: v ? '' : f.acao_valor }))} />
              <span>Arquivar automaticamente após concluir</span>
            </label>
          )}
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Cancelar</Button>
          <Button onClick={salvar} className="bg-[#0b2545] hover:bg-[#16365f]">{regra ? 'Atualizar' : 'Criar regra'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}