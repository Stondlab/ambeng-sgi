import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { STATUS, PRIORIDADES, ORIGENS, parseList, appendHistorico, appendComentario, checklistProgress, PRIO_COR, isAtrasada, venceHoje } from '@/lib/acoes';
import { GATILHOS, ACOES, parseEtiquetas, addEtiquetaArr, removeEtiquetaArr, parseSeguidores, toggleSeguidorArr, notificar, extrairMencoes, rodarAutomacoes } from '@/lib/quadro';
import { Plus, Check, MessageSquare, History, Star, Paperclip, Bookmark, Bell, ChevronDown, Zap, X, ListChecks, Users, Paperclip as AnexoIcon, Pencil, Plug, CalendarClock, Tag, Flag, Archive, ArchiveRestore, Trash2, Building2, UserRound, CalendarDays, CircleDot, Download, ExternalLink } from 'lucide-react';
import EtiquetasPopoverContent from '@/components/operacoes/EtiquetasPopoverContent';
import CategoriaSelector from '@/components/operacoes/CategoriaSelector';
import MentionInput from '@/components/operacoes/MentionInput';
import ChecklistItem from '@/components/operacoes/ChecklistItem';
import RegraForm from '@/components/operacoes/RegraForm';
import { usePerm } from '@/hooks/usePerm';
import { nomeUsuario, resolverNomeUsuario } from '@/lib/usuarioNome';
import { LABEL_ETAPA } from '@/lib/orcamento';
import { formatarMoeda } from '@/lib/moeda';
import ProcessosArea from '@/components/operacoes/orcamento/ProcessosArea';
import AcaoDetalhesSidebar from '@/components/operacoes/AcaoDetalhesSidebar';
import ResponsavelPicker from '@/components/operacoes/ResponsavelPicker';
import useUsuarios from '@/hooks/useUsuarios';
import { useToast } from '@/components/ui/use-toast';
import { registrarErroInterno } from '@/lib/validacao';
import useJobSubtasks from '@/hooks/useJobSubtasks';
import JobChecklistPanel from '@/components/operacoes/JobChecklistPanel';

const POWERUPS = [
  { v: 'notificacoes', label: 'Notificações', desc: 'Alertas do cartão por e-mail e no app.', icon: Bell },
  { v: 'calendario', label: 'Calendário', desc: 'Sincroniza os prazos do cartão no calendário.', icon: CalendarClock },
  { v: 'campos', label: 'Campos personalizados', desc: 'Adiciona campos extras ao cartão.', icon: ListChecks },
  { v: 'integracoes', label: 'Integrações externas', desc: 'Conecta sistemas externos ao cartão.', icon: Plug },
];

const AVATAR_PALETTE = ['bg-amber-400', 'bg-sky-500', 'bg-emerald-500', 'bg-violet-500', 'bg-pink-500', 'bg-orange-500', 'bg-slate-500'];
const avatarInitials = (n) => (n || '').split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();
const avatarColor = (n) => AVATAR_PALETTE[(n || '').split('').reduce((a, c) => a + c.charCodeAt(0), 0) % AVATAR_PALETTE.length];

function matchesRegra(r, acao, colunas) {
  if (r.gatilho === 'criado_com_categoria') return (acao.categoria || '') === r.gatilho_valor;
  if (r.gatilho === 'criado_com_tipo') return (acao.tipo || '') === r.gatilho_valor;
  if (r.gatilho === 'mover_para_coluna') return !!colunas.find((c) => c.id === r.gatilho_valor);
  if (r.gatilho === 'marcado_concluido') return acao.status === 'Concluído';
  if (r.gatilho === 'prazo_vencendo') return venceHoje(acao);
  if (r.gatilho === 'prazo_vencido') return isAtrasada(acao);
  return false;
}

export default function AcaoDetalhe({ acao, orcamento, onClose, onUpdated, user, etiquetas: etiquetasProp }) {
  const eu = nomeUsuario(user);
  const { toast } = useToast();
  const [titulo, setTitulo] = useState(acao?.titulo || '');
  const [novoItem, setNovoItem] = useState('');
  const [comentario, setComentario] = useState('');
  const [descricao, setDescricao] = useState(acao?.descricao || '');
  const [obra, setObra] = useState(acao?.obra || '');
  const [categoria, setCategoria] = useState(acao?.categoria || '');
  const [prazo, setPrazo] = useState(acao?.prazo || '');
  const [registro, setRegistro] = useState(acao?.registro_relacionado || '');
  const [etiquetas, setEtiquetas] = useState(etiquetasProp || []);
  const usuarios = useUsuarios();
  const [categorias, setCategorias] = useState([]);
  const [obras, setObras] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [showModelo, setShowModelo] = useState(false);
  const [nomeModelo, setNomeModelo] = useState('');
  const [aba, setAba] = useState('detalhes');
  const [showDetalhes, setShowDetalhes] = useState(false);
  const [editando, setEditando] = useState(false);
  const [regras, setRegras] = useState([]);
  const [colunasAuto, setColunasAuto] = useState([]);
  const [regraEditando, setRegraEditando] = useState(null);
  const [configPowerup, setConfigPowerup] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [showExcluir, setShowExcluir] = useState(false);
  const { podeEditar: podeEditTask, podeExcluir: podeDelTask } = usePerm('painel');
  const readOnly = !podeEditTask;
  const canDel = podeDelTask;
  const subtaskControl = useJobSubtasks(acao, user, onUpdated);

  const excluir = async () => {
    try {
      await base44.entities.Demandas.delete(acao.id);
      toast({ title: 'Tarefa excluída.' });
      setShowExcluir(false); onUpdated?.(); onClose?.();
    } catch (erro) {
      registrarErroInterno('Excluir tarefa', erro);
      toast({ title: 'Não foi possível excluir a tarefa.', description: 'Atualize os dados e tente novamente.', variant: 'destructive' });
    }
  };
  const arquivar = () => upd({ arquivada: true }, 'Cartão arquivado', true);
  const restaurar = () => upd({ arquivada: false }, 'Cartão restaurado', true);

  const prazoRef = useRef(null);
  const newItemRef = useRef(null);
  const fileRef = useRef(null);
  const etiquetaRef = useRef(null);
  const membrosRef = useRef(null);

  useEffect(() => {
    setTitulo(acao?.titulo || ''); setDescricao(acao?.descricao || '');
    setObra(acao?.obra || ''); setCategoria(acao?.categoria || '');
    setPrazo(acao?.prazo || ''); setRegistro(acao?.registro_relacionado || '');
  }, [acao?.id]);

  const loadRegras = async () => { try { setRegras(await base44.entities.RegrasAutomacao.list('-created_date', 500)); } catch {} };
  const loadEtiquetas = async () => { try { setEtiquetas(await base44.entities.Etiquetas.list('-created_date', 500)); } catch {} };
  const loadCategorias = async () => { try { setCategorias(await base44.entities.Categorias.list('nome', 500)); } catch {} };

  useEffect(() => {
    if (etiquetasProp) setEtiquetas(etiquetasProp);
    (async () => {
      try { setObras(await base44.entities.Obras.list('nome', 500)); } catch {}
      try { setJobs(await base44.entities.Jobs.list('-created_date', 500)); } catch {}
      loadCategorias();
      loadRegras();
      try { setColunasAuto(await base44.entities.ColunasQuadro.list('ordem', 500)); } catch {}
    })();
  }, [etiquetasProp]);

  useEffect(() => {
    if (!acao) return;
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [acao, onClose]);

  if (!acao) return null;

  const membrosArr = parseList(acao.membros);
  const powerupsArr = parseList(acao.powerups);

  const upd = async (changes, evento, notificarSeguidores = false) => {
    const hist = appendHistorico(acao.historico, evento, eu);
    try {
      await base44.entities.Demandas.update(acao.id, { ...changes, historico: JSON.stringify(hist) });
      let falhasNotificacao = 0;
      if (notificarSeguidores) {
        const segs = parseSeguidores(acao.seguidores).filter((s) => s !== eu);
        for (const s of segs) if (!await notificar(s, `Ação atualizada: ${acao.titulo}`, evento, acao.id)) falhasNotificacao += 1;
      }
      toast({ title: evento.endsWith('.') ? evento : `${evento}.`, description: falhasNotificacao ? 'A alteração foi salva, mas alguns seguidores não receberam o alerta.' : undefined, variant: falhasNotificacao ? 'destructive' : undefined });
      onUpdated();
      return true;
    } catch (erro) {
      registrarErroInterno(`Atualizar tarefa: ${evento}`, erro);
      toast({ title: 'Não foi possível atualizar a tarefa.', description: 'Tente novamente. Se o problema continuar, atualize a página.', variant: 'destructive' });
      return false;
    }
  };

  const saveTitulo = () => { if (titulo !== (acao.titulo || '')) upd({ titulo }, 'Título alterado'); };
  const concluido = acao.status === 'Concluído';
  const toggleDone = () => {
    const novoStatus = concluido ? 'A Fazer' : 'Concluído';
    const ch = { status: novoStatus };
    if (novoStatus === 'Concluído') ch.data_conclusao = new Date().toISOString();
    upd(ch, `Status → ${novoStatus}`, true);
    if (novoStatus === 'Concluído') rodarAutomacoes({ tipo: 'concluir' }, { ...acao, status: 'Concluído' });
  };
  const setStatus = (status) => { const ch = { status }; if (status === 'Concluído') ch.data_conclusao = new Date().toISOString(); upd(ch, `Status → ${status}`, true); if (status === 'Concluído') rodarAutomacoes({ tipo: 'concluir' }, { ...acao, status }); };
  const setPrio = (prioridade) => upd({ prioridade }, `Prioridade → ${prioridade}`);
  const toggleFav = () => upd({ favorita: !acao.favorita }, acao.favorita ? 'Removida dos favoritos' : 'Marcada como favorita');
  const savePrazo = () => {
    if (prazo !== (acao?.prazo || '')) {
      upd({ prazo }, 'Prazo atualizado', true);
      if (prazo) {
        if (venceHoje({ ...acao, prazo, status: 'Em Andamento' })) rodarAutomacoes({ tipo: 'prazo_vencendo' }, { ...acao, prazo });
        if (isAtrasada({ ...acao, prazo, status: 'Em Andamento' })) rodarAutomacoes({ tipo: 'prazo_vencido' }, { ...acao, prazo });
      }
    }
  };
  const saveDesc = () => { if (descricao !== (acao?.descricao || '')) upd({ descricao }, 'Descrição atualizada'); };
  const saveObra = () => { if (obra !== (acao?.obra || '')) upd({ obra }, `Obra → ${obra}`); };
  const saveCat = (v) => { if (v !== (acao?.categoria || '')) upd({ categoria: v }, `Categoria → ${v}`); };
  const saveReg = () => { if (registro !== (acao?.registro_relacionado || '')) upd({ registro_relacionado: registro }, 'Relacionamento atualizado'); };

  const setMembros = (arr) => upd({ membros: JSON.stringify(arr), responsavel: arr[0] || '' }, 'Membros atualizados', true);
  const togglePowerup = (v) => { const arr = powerupsArr.includes(v) ? powerupsArr.filter((x) => x !== v) : [...powerupsArr, v]; upd({ powerups: JSON.stringify(arr) }, `Power-up ${v} ${powerupsArr.includes(v) ? 'desativado' : 'ativado'}`); };

  const toggleEtiqueta = (nome) => { const arr = parseEtiquetas(acao.etiquetas); const novo = arr.includes(nome) ? removeEtiquetaArr(arr, nome) : addEtiquetaArr(arr, nome); upd({ etiquetas: JSON.stringify(novo) }, 'Etiquetas atualizadas'); };
  const toggleSeguir = async () => {
    const arr = parseSeguidores(acao.seguidores); const novo = toggleSeguidorArr(arr, eu);
    try { await base44.entities.Demandas.update(acao.id, { seguidores: JSON.stringify(novo) }); toast({ title: novo.includes(eu) ? 'Você está seguindo esta tarefa.' : 'Você deixou de seguir esta tarefa.' }); onUpdated(); }
    catch (erro) { registrarErroInterno('Alterar acompanhamento da tarefa', erro); toast({ title: 'Não foi possível alterar o acompanhamento.', description: 'Tente novamente.', variant: 'destructive' }); }
  };
  const seguindo = parseSeguidores(acao.seguidores).includes(eu);

  const checklist = subtaskControl.checklist;
  const updateItem = subtaskControl.update;
  const deleteItem = subtaskControl.remove;
  const moveItem = subtaskControl.move;
  const addItem = async () => { if (!novoItem.trim()) return; await subtaskControl.add(novoItem.trim()); setNovoItem(''); newItemRef.current?.focus(); };

  const comentarios = parseList(acao.comentarios);
  const cobrarAcao = async () => {
    if (!responsavelAtual || responsavelAtual === 'Não atribuído') return toast({ title: 'Defina um responsável antes de cobrar a ação.', variant: 'destructive' });
    const ok = await notificar(responsavelAtual, `Ação pendente: ${acao.titulo}`, `${proximaAcao}${prazoAtual ? ` · Prazo ${prazoAtual.split('-').reverse().join('/')}` : ''}`, acao.id);
    toast({ title: ok ? 'Cobrança enviada.' : 'Não foi possível enviar a cobrança.', variant: ok ? undefined : 'destructive' });
  };

  const addComent = async (texto) => {
    if (!texto || !texto.trim()) return;
    const cs = appendComentario(acao.comentarios, texto.trim(), eu);
    try {
      await base44.entities.Demandas.update(acao.id, { comentarios: JSON.stringify(cs) });
      const menc = extrairMencoes(texto, usuarios);
      let falhasNotificacao = 0;
      for (const m of menc) if (m !== eu && !await notificar(m, 'Você foi mencionado', `Em "${acao.titulo}": ${texto.trim().slice(0, 80)}`, acao.id)) falhasNotificacao += 1;
      setComentario('');
      toast({ title: 'Comentário publicado.', description: falhasNotificacao ? 'O comentário foi salvo, mas algumas menções não receberam o alerta.' : undefined });
      onUpdated();
    } catch (erro) {
      registrarErroInterno('Publicar comentário na tarefa', erro);
      toast({ title: 'Não foi possível publicar o comentário.', description: 'Tente novamente.', variant: 'destructive' });
    }
  };
  const historico = parseList(acao.historico);
  const fotos = parseList(acao.fotos);
  const arquivos = parseList(acao.arquivos);

  const onFile = async (e) => {
    const f = e.target.files?.[0]; if (!f) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: f });
      const isImg = f.type.startsWith('image/');
      const key = isImg ? 'fotos' : 'arquivos';
      const arr = parseList(acao[key]);
      arr.push(file_url);
      await upd({ [key]: JSON.stringify(arr) }, `Anexo adicionado: ${f.name}`);
    } catch (erro) {
      registrarErroInterno('Anexar arquivo à tarefa', erro);
      toast({ title: 'Não foi possível anexar o arquivo.', description: 'Verifique o arquivo e tente novamente.', variant: 'destructive' });
    } finally { setUploading(false); e.target.value = ''; }
  };
  const rmAnexo = (key, i) => { const arr = parseList(acao[key]).filter((_, j) => j !== i); upd({ [key]: JSON.stringify(arr) }, 'Anexo removido'); };

  const toggleRegra = async (r) => {
    try { await base44.entities.RegrasAutomacao.update(r.id, { ativa: r.ativa === false }); toast({ title: r.ativa === false ? 'Automação ativada.' : 'Automação desativada.' }); loadRegras(); }
    catch (erro) { registrarErroInterno('Alterar automação', erro); toast({ title: 'Não foi possível alterar a automação.', description: 'Tente novamente.', variant: 'destructive' }); }
  };

  const salvarModelo = async () => {
    if (!nomeModelo.trim()) return;
    try {
      await base44.entities.ModelosAcao.create({ nome: nomeModelo.trim(), tipo: acao.tipo_execucao === 'Outro processo' ? 'Processo' : 'Tarefa', categoria: acao.categoria || '', descricao: acao.descricao || '', checklist: JSON.stringify(checklist.map(({ id, ...item }) => item)), etiquetas: acao.etiquetas || '', prioridade: acao.prioridade || 'Média', origem: acao.origem || 'Manual', responsavel: acao.responsavel || '', membros: acao.membros || '[]', ...(orcamento ? { processo_tipo: 'Orcamento', processo_responsaveis: orcamento.etapas_resp || '{}' } : {}), criado_por: eu });
      setShowModelo(false); setNomeModelo(''); toast({ title: 'Modelo salvo.' });
    } catch (erro) { registrarErroInterno('Salvar modelo de tarefa', erro); toast({ title: 'Não foi possível salvar o modelo.', description: 'Confira o nome e tente novamente.', variant: 'destructive' }); }
  };

  const descRegra = (r) => {
    const g = GATILHOS.find((x) => x.v === r.gatilho)?.label || r.gatilho;
    const a = ACOES.find((x) => x.v === r.acao)?.label || r.acao;
    const gv = r.gatilho === 'mover_para_coluna' ? colunasAuto.find((c) => c.id === r.gatilho_valor)?.nome : r.gatilho_valor;
    const av = r.acao === 'mover_para_coluna' ? colunasAuto.find((c) => c.id === r.acao_valor)?.nome : r.acao_valor;
    return `${g}${gv ? `: ${gv}` : ''} → ${a}${av ? `: ${av}` : ''}`;
  };

  const prazoBadge = () => {
    if (!acao.prazo) return 'bg-slate-100 text-slate-400';
    if (concluido) return 'bg-emerald-100 text-emerald-700';
    if (isAtrasada(acao)) return 'bg-red-100 text-red-700';
    if (venceHoje(acao)) return 'bg-amber-100 text-amber-700';
    return 'bg-sky-100 text-sky-700';
  };
  const nomeAnexo = (u) => decodeURIComponent((u.split('/').pop() || 'arquivo').split('?')[0]).slice(0, 38);
  const tipoAnexo = (u) => (nomeAnexo(u).split('.').pop() || 'arquivo').toUpperCase();

  const modalTabs = [
    ['detalhes', 'Visão geral'], ['processo', 'Processo'], ['anexos', `Anexos (${fotos.length + arquivos.length})`],
    ['comentarios', 'Comentários'], ['historico', 'Histórico'], ['relacionamentos', 'Relacionamentos'],
  ];
  const etapasResponsaveis = (() => { try { return JSON.parse(orcamento?.etapas_resp || '{}'); } catch { return {}; } })();
  const etapaAtual = orcamento ? LABEL_ETAPA[orcamento.etapa] || orcamento.etapa : null;
  const proximoChecklist = checklist.find((item) => !item.done)?.text;
  const proximaAcao = etapaAtual ? `${etapaAtual} do processo de compra` : proximoChecklist || (concluido ? 'Tarefa concluída' : acao.status === 'Aguardando' ? 'Resolver a pendência atual' : 'Avançar a execução da tarefa');
  const responsavelAtual = etapasResponsaveis[orcamento?.etapa]?.responsavel || acao.responsavel || 'Não atribuído';
  const prazoAtual = etapasResponsaveis[orcamento?.etapa]?.prazo || acao.prazo;
  const regrasAplicaveis = regras.filter((regra) => regra.ativa !== false && matchesRegra(regra, acao, colunasAuto));
  const obraRelacionada = obras.find((item) => item.nome === acao.obra);
  const jobRelacionado = jobs.find((item) => item.id === acao.job_id);
  const financeiroRelacionado = (() => { try { return JSON.parse(orcamento?.financeiro || 'null'); } catch { return null; } })();

  return createPortal(
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-2 backdrop-blur-[2px] sm:p-4" onClick={() => { if (!editando && !comentario.trim()) onClose(); }}>
        <div className="flex h-[96dvh] w-full max-w-[1200px] flex-col overflow-hidden rounded-xl bg-card shadow-2xl sm:h-[88vh] sm:rounded-2xl" onClick={(event) => event.stopPropagation()}>
          <header className="border-b border-border px-4 py-4 sm:px-6">
            <div className="flex items-start gap-4">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-full bg-primary/10 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-primary">TAREFA</span>
                  <span className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${acao.prioridade === 'Crítica' ? 'bg-red-100 text-red-700' : acao.prioridade === 'Alta' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'}`}>{acao.prioridade || 'Média'}</span>
                  {acao.arquivada && <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-medium text-slate-600">Arquivada</span>}
                </div>
                <input value={titulo} onChange={(event) => setTitulo(event.target.value)} onBlur={saveTitulo} disabled={readOnly || !editando} className="mt-2 w-full rounded-md bg-transparent text-xl font-semibold text-foreground outline-none focus:bg-muted/50 sm:text-2xl" />
                <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1"><Building2 className="h-3.5 w-3.5" />{acao.obra || 'Sem obra'}</span><span className="inline-flex items-center gap-1"><UserRound className="h-3.5 w-3.5" />{resolverNomeUsuario(acao.responsavel, usuarios) || 'Não atribuído'}</span><span className="inline-flex items-center gap-1"><CalendarDays className="h-3.5 w-3.5" />{acao.prazo ? acao.prazo.split('-').reverse().join('/') : 'Sem prazo'}</span><span className={`inline-flex items-center gap-1 font-medium ${isAtrasada(acao) ? 'text-destructive' : 'text-foreground'}`}><CircleDot className="h-3.5 w-3.5" />{acao.status}</span>
                </div>
                {[acao.categoria, ...parseEtiquetas(acao.etiquetas)].filter(Boolean).length > 0 && <div className="mt-2 flex flex-wrap items-center gap-1.5"><span className="mr-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Etiquetas</span>{[acao.categoria, ...parseEtiquetas(acao.etiquetas)].filter(Boolean).map((item) => <span key={item} className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary">{item}</span>)}</div>}
              </div>
              <div className="flex shrink-0 items-center gap-1">
                <button onClick={toggleSeguir} className="flex min-h-10 min-w-10 items-center justify-center rounded-md hover:bg-muted" title={seguindo ? 'Deixar de seguir' : 'Seguir'}><Bell className={`h-4 w-4 ${seguindo ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground'}`} /></button>
                <button onClick={toggleFav} className="flex min-h-10 min-w-10 items-center justify-center rounded-md hover:bg-muted" title="Favoritar"><Star className={`h-4 w-4 ${acao.favorita ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground'}`} /></button>
                <Popover><PopoverTrigger asChild><button className="flex min-h-10 min-w-10 items-center justify-center rounded-md text-lg text-muted-foreground hover:bg-muted" title="Mais ações">•••</button></PopoverTrigger><PopoverContent align="end" className="w-52 p-1">
                  <button onClick={() => setShowModelo(true)} className="w-full rounded px-3 py-2 text-left text-sm hover:bg-muted">Salvar como modelo</button>
                  {!readOnly && <button onClick={acao.arquivada ? restaurar : arquivar} className="w-full rounded px-3 py-2 text-left text-sm hover:bg-muted">{acao.arquivada ? 'Restaurar tarefa' : 'Arquivar tarefa'}</button>}
                  {canDel && <button onClick={() => setShowExcluir(true)} className="w-full rounded px-3 py-2 text-left text-sm text-destructive hover:bg-destructive/10">Excluir tarefa</button>}
                </PopoverContent></Popover>
                <button onClick={onClose} className="flex min-h-10 min-w-10 items-center justify-center rounded-md hover:bg-muted" title="Fechar"><X className="h-5 w-5 text-muted-foreground" /></button>
              </div>
            </div>
          </header>

          <nav className="flex shrink-0 gap-1 overflow-x-auto border-b border-border px-4 sm:px-6">
            {modalTabs.map(([value, label]) => <button key={value} onClick={() => setAba(value)} className={`min-h-11 whitespace-nowrap border-b-2 px-3 text-sm font-medium ${aba === value ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>{label}</button>)}
          </nav>

          <main className="flex-1 overflow-y-auto bg-muted/20 p-4 sm:p-6">
            {aba === 'detalhes' && <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,3fr)_minmax(340px,2fr)]">
              <div className="space-y-4">
                {editando ? <section className="rounded-xl border border-border bg-card p-4"><h3 className="mb-4 text-sm font-semibold">Editar informações</h3><div className="grid gap-4 sm:grid-cols-2"><div><Label>Status</Label><Select value={acao.status} onValueChange={setStatus} disabled={readOnly}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{STATUS.map((item) => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select></div><div><Label>Prioridade</Label><Select value={acao.prioridade || 'Média'} onValueChange={setPrio} disabled={readOnly}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{PRIORIDADES.map((item) => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select></div><div><Label>Obra</Label><Select value={acao.obra || ''} disabled={readOnly} onValueChange={(value) => { setObra(value); upd({ obra: value }, `Obra → ${value}`); }}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{obras.map((item) => <SelectItem key={item.id} value={item.nome}>{item.nome}</SelectItem>)}</SelectContent></Select></div><div><Label>Prazo</Label><Input type="date" className="mt-1" value={prazo} onChange={(event) => setPrazo(event.target.value)} onBlur={savePrazo} disabled={readOnly} /></div><div className="sm:col-span-2"><Label>Responsável</Label><div className="mt-1"><ResponsavelPicker usuarios={usuarios} value={acao.responsavel || ''} disabled={readOnly} onChange={(value) => upd({ responsavel: value }, `Responsável: ${acao.responsavel || '—'} → ${value}`)} /></div></div><div className="sm:col-span-2"><Label>Categoria</Label><div className="mt-1"><CategoriaSelector value={acao.categoria || ''} onChange={saveCat} categorias={categorias} onRefresh={loadCategorias} disabled={readOnly} /></div></div><div className="sm:col-span-2"><Label>Descrição</Label><Textarea className="mt-1" rows={5} value={descricao} onChange={(event) => setDescricao(event.target.value)} onBlur={saveDesc} readOnly={readOnly} /></div></div></section> : <section className="rounded-xl border border-border bg-card p-4"><h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Descrição</h3><p className={`mt-3 whitespace-pre-wrap text-sm leading-6 text-foreground ${showDetalhes ? '' : 'line-clamp-5'}`}>{acao.descricao || 'Sem descrição.'}</p>{acao.descricao?.length > 280 && <button onClick={() => setShowDetalhes((value) => !value)} className="mt-2 text-sm font-medium text-primary">{showDetalhes ? 'Ver menos' : 'Ver mais'}</button>}</section>}
                <JobChecklistPanel title={acao.tipo_execucao === 'Outro processo' ? 'Etapas do processo' : 'Checklist'} checklist={checklist} usuarios={usuarios} readOnly={readOnly} onUpdate={updateItem} onDelete={deleteItem} onMove={moveItem} onAdd={subtaskControl.add} user={eu} />
              </div>
              <AcaoDetalhesSidebar executionType={acao.tipo_execucao} orcamento={orcamento} checklist={checklist} onToggleChecklist={(index) => updateItem(index, { ...checklist[index], done: !checklist[index].done })} onCreateChecklist={subtaskControl.add} onOpenProcess={() => setAba('processo')} proximaAcao={proximaAcao} responsavel={responsavelAtual} prazo={prazoAtual} regras={regrasAplicaveis} descRegra={descRegra} comentarios={comentarios} historico={historico} usuarios={usuarios} comentario={comentario} setComentario={setComentario} addComent={addComent} fotos={fotos} arquivos={arquivos} onOpenAnexos={() => setAba('anexos')} cobrarAcao={cobrarAcao} readOnly={readOnly} onAutomacoes={() => setAba('relacionamentos')} />
            </div>}

            {aba === 'processo' && <div className="mx-auto max-w-5xl">{acao.tipo_execucao === 'Outro processo' && !orcamento ? <JobChecklistPanel title="Etapas do processo" checklist={checklist} usuarios={usuarios} readOnly={readOnly} onUpdate={updateItem} onDelete={deleteItem} onMove={moveItem} onAdd={subtaskControl.add} user={eu} /> : <ProcessosArea acao={acao} user={user} usuarios={usuarios} obras={obras} onUpdated={onUpdated} orcamentoInicial={orcamento} />}</div>}

            {aba === 'anexos' && <section className="mx-auto max-w-5xl overflow-hidden rounded-xl border border-border bg-card"><div className="flex items-center justify-between border-b border-border px-4 py-3"><div><h3 className="font-semibold">Anexos ({fotos.length + arquivos.length})</h3><p className="text-xs text-muted-foreground">Arquivos vinculados a esta tarefa.</p></div>{!readOnly && <Button variant="outline" onClick={() => fileRef.current?.click()} disabled={uploading}><Plus />{uploading ? 'Enviando' : 'Adicionar'}</Button>}</div><input ref={fileRef} type="file" className="hidden" onChange={onFile} /><div className="divide-y divide-border">{[...fotos.map((url, index) => ({ url, index, key: 'fotos' })), ...arquivos.map((url, index) => ({ url, index, key: 'arquivos' }))].map((item) => <div key={item.url} className="grid items-center gap-3 px-4 py-3 text-sm sm:grid-cols-[minmax(0,2fr)_80px_90px_120px_auto]"><div className="flex min-w-0 items-center gap-2"><Paperclip className="h-4 w-4 shrink-0 text-muted-foreground" /><div className="min-w-0"><p className="truncate font-medium">{nomeAnexo(item.url)}</p><p className="text-[10px] text-muted-foreground">Usuário não registrado no arquivo legado</p></div></div><span className="text-xs text-muted-foreground">{tipoAnexo(item.url)}</span><span className="text-xs text-muted-foreground">Tamanho —</span><span className="text-xs text-muted-foreground">Data não registrada</span><div className="flex justify-end gap-1"><a href={item.url} target="_blank" rel="noreferrer" className="flex min-h-9 min-w-9 items-center justify-center rounded-md hover:bg-muted" title="Abrir"><ExternalLink className="h-4 w-4" /></a><a href={item.url} download className="flex min-h-9 min-w-9 items-center justify-center rounded-md hover:bg-muted" title="Baixar"><Download className="h-4 w-4" /></a>{canDel && <button onClick={() => rmAnexo(item.key, item.index)} className="flex min-h-9 min-w-9 items-center justify-center rounded-md text-destructive hover:bg-destructive/10" title="Excluir"><Trash2 className="h-4 w-4" /></button>}</div></div>)}{fotos.length + arquivos.length === 0 && <p className="py-12 text-center text-sm text-muted-foreground">Nenhum anexo.</p>}</div></section>}

            {aba === 'comentarios' && <section className="mx-auto max-w-3xl rounded-xl bg-card p-5 shadow-sm"><h3 className="font-semibold">Comentários</h3><div className="mt-4 space-y-3">{comentarios.map((item, index) => <div key={index} className="rounded-lg bg-muted/50 p-3"><div className="flex justify-between gap-3 text-xs"><b>{resolverNomeUsuario(item.usuario, usuarios)}</b><span className="text-muted-foreground">{format(new Date(item.data), 'dd/MM HH:mm')}</span></div><p className="mt-1 text-sm">{item.texto}</p></div>)}{comentarios.length === 0 && <p className="py-8 text-center text-sm text-muted-foreground">Nenhum comentário.</p>}</div>{!readOnly && <div className="mt-4 flex gap-2"><MentionInput value={comentario} onChange={setComentario} onSend={addComent} placeholder="Escreva um comentário..." /><Button onClick={() => addComent(comentario)}>Enviar</Button></div>}</section>}

            {aba === 'historico' && <section className="mx-auto max-w-3xl rounded-xl border border-border bg-card p-5"><h3 className="font-semibold">Histórico da tarefa</h3><div className="mt-5 space-y-0">{historico.map((item, index) => <div key={index} className="relative flex gap-3 pb-5 text-sm last:pb-0"><span className="z-10 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-success/10 text-success"><Check className="h-3.5 w-3.5" /></span>{index < historico.length - 1 && <span className="absolute left-[11px] top-6 h-full w-px bg-border" />}<div className="min-w-0 flex-1"><p className="font-medium">{item.evento}</p><p className="mt-0.5 text-xs text-muted-foreground">{resolverNomeUsuario(item.usuario, usuarios)} · {format(new Date(item.data), 'dd/MM/yyyy HH:mm')}</p></div></div>)}{historico.length === 0 && <p className="py-8 text-center text-sm text-muted-foreground">Sem atividade registrada.</p>}</div></section>}

            {aba === 'relacionamentos' && <div className="mx-auto grid max-w-4xl gap-5 lg:grid-cols-2">
              <section className="rounded-xl border border-border bg-card p-5 lg:col-span-2"><h3 className="font-semibold">Registros vinculados</h3><div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{[
                { label: 'Obra relacionada', value: acao.obra, open: obraRelacionada ? () => window.open(`/obras/${obraRelacionada.id}`, '_blank', 'noopener,noreferrer') : null },
                { label: 'Orçamento relacionado', value: orcamento?.demanda_titulo || orcamento?.descricao, open: orcamento ? () => setAba('processo') : null },
                { label: 'Despesa relacionada', value: financeiroRelacionado?.despesa_id || financeiroRelacionado?.status, open: financeiroRelacionado ? () => window.open('/financeiro/despesas', '_blank', 'noopener,noreferrer') : null },
                { label: 'Ações relacionadas', value: jobRelacionado?.titulo || jobRelacionado?.nome, open: jobRelacionado ? () => window.open('/operacoes', '_blank', 'noopener,noreferrer') : null },
                { label: 'Relatórios relacionados', value: '', open: null },
                { label: 'Outros registros', value: acao.registro_relacionado, open: acao.registro_relacionado ? () => setRegistro(acao.registro_relacionado) : null },
              ].map((item) => <button key={item.label} disabled={!item.open} onClick={item.open || undefined} className="rounded-lg border border-border p-3 text-left enabled:hover:bg-muted/50 disabled:cursor-default"><p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{item.label}</p><p className={`mt-1 truncate text-sm font-medium ${item.open ? 'text-primary' : 'text-muted-foreground'}`}>{item.value || 'Nenhum vínculo'}</p></button>)}</div></section>
              <section className="rounded-xl bg-card p-5 shadow-sm"><h3 className="font-semibold">Membros e classificação</h3><div className="mt-4 flex flex-wrap gap-2"><Popover><PopoverTrigger asChild><Button variant="outline"><Tag className="h-4 w-4" />Etiquetas ({parseEtiquetas(acao.etiquetas).length})</Button></PopoverTrigger><PopoverContent className="w-72 p-2"><EtiquetasPopoverContent acao={acao} etiquetas={etiquetas} onToggle={toggleEtiqueta} onAtualizou={loadEtiquetas} /></PopoverContent></Popover><Popover><PopoverTrigger asChild><Button variant="outline"><Users className="h-4 w-4" />Membros ({membrosArr.length})</Button></PopoverTrigger><PopoverContent className="w-64 p-2">{usuarios.map((item) => { const nome = nomeUsuario(item); const ativo = membrosArr.includes(nome); return <button key={item.id} disabled={readOnly} onClick={() => setMembros(ativo ? membrosArr.filter((value) => value !== nome) : [...membrosArr, nome])} className="flex w-full items-center justify-between rounded px-2 py-2 text-sm hover:bg-muted"><span>{nome}</span>{ativo && <Check className="h-4 w-4 text-success" />}</button>; })}</PopoverContent></Popover></div><div className="mt-5 grid gap-4"><div><Label>Origem</Label><Select value={acao.origem || 'Manual'} disabled={readOnly} onValueChange={(value) => upd({ origem: value }, `Origem → ${value}`)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{ORIGENS.map((item) => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select></div><div><Label>Registro relacionado</Label><Input className="mt-1" value={registro} onChange={(event) => setRegistro(event.target.value)} onBlur={saveReg} disabled={readOnly} /></div></div></section>
              <section className="rounded-xl bg-card p-5 shadow-sm"><div className="flex items-center justify-between"><h3 className="font-semibold">Automações e extensões</h3><button onClick={() => setRegraEditando('nova')} className="text-sm font-medium text-primary">Nova regra</button></div><div className="mt-4 space-y-2">{regras.map((regra) => <div key={regra.id} className="flex items-center gap-3 rounded-lg bg-muted/50 p-3"><Zap className={`h-4 w-4 ${regra.ativa !== false ? 'text-amber-500' : 'text-muted-foreground'}`} /><button onClick={() => setRegraEditando(regra)} className="min-w-0 flex-1 text-left"><p className="truncate text-sm font-medium">{regra.nome}</p><p className="truncate text-xs text-muted-foreground">{descRegra(regra)}</p></button><Switch checked={regra.ativa !== false} onCheckedChange={() => toggleRegra(regra)} /></div>)}{regras.length === 0 && <p className="text-sm text-muted-foreground">Nenhuma automação configurada.</p>}</div><div className="mt-5 space-y-2">{POWERUPS.map((item) => { const Icon = item.icon; return <div key={item.v} className="flex items-center gap-3 rounded-lg border border-border p-3"><Icon className="h-4 w-4 text-muted-foreground" /><span className="flex-1 text-sm">{item.label}</span><button onClick={() => setConfigPowerup(item.v)} className="text-xs text-primary">Configurar</button><Switch checked={powerupsArr.includes(item.v)} onCheckedChange={() => togglePowerup(item.v)} /></div>; })}</div></section>
            </div>}
          </main>

          <footer className="flex shrink-0 flex-wrap items-center justify-between gap-3 border-t border-border bg-card px-4 py-3 sm:px-6">
            <Popover><PopoverTrigger asChild><Button variant="outline">•••</Button></PopoverTrigger><PopoverContent align="start" className="w-48 p-1"><button onClick={() => setShowModelo(true)} className="w-full rounded px-3 py-2 text-left text-sm hover:bg-muted">Salvar como modelo</button>{!readOnly && <button onClick={acao.arquivada ? restaurar : arquivar} className="w-full rounded px-3 py-2 text-left text-sm hover:bg-muted">{acao.arquivada ? 'Restaurar' : 'Arquivar'}</button>}</PopoverContent></Popover>
            <div className="ml-auto flex flex-wrap gap-2"><Popover><PopoverTrigger asChild><Button variant="outline">Mover tarefa</Button></PopoverTrigger><PopoverContent align="end" className="w-52 p-1">{STATUS.map((item) => <button key={item} onClick={() => setStatus(item)} disabled={readOnly || item === acao.status} className="w-full rounded px-3 py-2 text-left text-sm hover:bg-muted disabled:opacity-50">{item}</button>)}</PopoverContent></Popover>{!readOnly && <Button variant="outline" onClick={() => { setAba('detalhes'); setEditando((value) => !value); }}>{editando ? 'Concluir edição' : 'Editar tarefa'}</Button>}{!readOnly && orcamento?.etapa === 'Aprovacao' && <><Button variant="destructive" onClick={() => setAba('processo')}>Rejeitar</Button><Button onClick={() => setAba('processo')}>Aprovar</Button></>}{!readOnly && !orcamento && !concluido && <Button onClick={toggleDone}>Concluir</Button>}</div>
          </footer>
        </div>
      </div>

      {regraEditando && (
        <RegraForm regra={regraEditando === 'nova' ? null : regraEditando} colunas={colunasAuto} etiquetas={etiquetas} usuarios={usuarios} onClose={() => setRegraEditando(null)} onSaved={loadRegras} />
      )}

      <Dialog open={!!configPowerup} onOpenChange={(o) => !o && setConfigPowerup(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>{POWERUPS.find((p) => p.v === configPowerup)?.label}</DialogTitle></DialogHeader>
          <p className="text-sm text-slate-500">{POWERUPS.find((p) => p.v === configPowerup)?.desc}</p>
          <p className="text-xs text-slate-400">As configurações específicas deste power-up estarão disponíveis em breve no painel de Configurações do sistema.</p>
          <DialogFooter><Button variant="ghost" onClick={() => setConfigPowerup(null)}>Fechar</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showModelo} onOpenChange={(o) => !o && setShowModelo(false)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Bookmark className="w-4 h-4 text-amber-500" />Salvar como modelo</DialogTitle></DialogHeader>
          <div><Label>Nome do modelo</Label><Input className="mt-1" value={nomeModelo} onChange={(e) => setNomeModelo(e.target.value)} placeholder="Ex.: Inspeção de rotina" /></div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowModelo(false)}>Cancelar</Button>
            <Button onClick={salvarModelo} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar modelo</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showExcluir} onOpenChange={(o) => !o && setShowExcluir(false)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Trash2 className="w-4 h-4 text-red-500" />Excluir cartão</DialogTitle></DialogHeader>
          <p className="text-sm text-slate-600">Tem certeza que deseja excluir definitivamente o cartão <strong className="text-[#0b2545]">{acao.titulo}</strong>? Esta ação não pode ser desfeita.</p>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShowExcluir(false)}>Cancelar</Button>
            <Button onClick={excluir} className="bg-red-500 hover:bg-red-600 text-white">Excluir definitivamente</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>,
    document.body
  );
}