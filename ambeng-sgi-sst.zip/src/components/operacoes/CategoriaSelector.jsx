import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { CORES_ETIQUETA, corEtiqueta } from '@/lib/quadro';
import { usePermissoes } from '@/lib/PermissoesContext';
import { podeCriarEstrutural, podeEditarEstrutural, podeExcluirEstrutural } from '@/lib/estruturalPerm';
import { Plus, Pencil, Trash2 } from 'lucide-react';

// Seletor de Categoria com criação/edição/exclusão inline (registro compartilhado).
// size: 'sm' (h-9, modal de detalhes) | 'md' (h-11, modal de nova tarefa)
export default function CategoriaSelector({ value, onChange, categorias, onRefresh, disabled, size = 'sm' }) {
  const { perfilEfetivo: perfil } = usePermissoes();
  const podeCriar = podeCriarEstrutural(perfil);
  const podeEditar = podeEditarEstrutural(perfil);
  const podeExcluir = podeExcluirEstrutural(perfil);
  const [showForm, setShowForm] = useState(false);
  const [nome, setNome] = useState('');
  const [cor, setCor] = useState('cinza');
  const [editId, setEditId] = useState(null);
  const [delId, setDelId] = useState(null);

  const h = size === 'md' ? 'h-11' : 'h-9';
  const lista = categorias || [];

  const reset = () => { setNome(''); setCor('cinza'); setEditId(null); setShowForm(false); };

  const salvar = async () => {
    if (!nome.trim()) return;
    if (editId) await base44.entities.Categorias.update(editId, { nome: nome.trim(), cor });
    else await base44.entities.Categorias.create({ nome: nome.trim(), cor });
    reset(); onRefresh?.();
  };
  const editar = (c) => { setEditId(c.id); setNome(c.nome); setCor(c.cor || 'cinza'); setShowForm(true); };
  const confirmarExcluir = async () => {
    try { if (delId) await base44.entities.Categorias.delete(delId); } catch {}
    setDelId(null); onRefresh?.();
  };

  return (
    <div className="mt-1 flex items-center gap-1.5">
      <Select value={value || ''} disabled={disabled} onValueChange={onChange}>
        <SelectTrigger className={`${h} text-sm flex-1`}>
          <SelectValue placeholder="Selecione..." />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={null}>—</SelectItem>
          {lista.map((c) => { const cc = corEtiqueta(c.cor); return <SelectItem key={c.id} value={c.nome}><span className="flex items-center gap-2"><span className={`w-2.5 h-2.5 rounded-full ${cc.dot}`} />{c.nome}</span></SelectItem>; })}
          {value && !lista.find((c) => c.nome === value) && <SelectItem value={value}>{value}</SelectItem>}
        </SelectContent>
      </Select>

      {podeCriar && !disabled && (
        <Popover>
          <PopoverTrigger asChild>
            <button type="button" className={`${h} px-2.5 rounded-lg border border-slate-200 text-[#0b2545] text-xs font-medium flex items-center gap-1 hover:bg-slate-50 shrink-0`} title="Criar / gerenciar categorias">
              <Plus className="w-3.5 h-3.5" />Criar
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-72 p-2" align="end">
            <div className="space-y-2">
              <div className="text-xs font-semibold text-[#0b2545]">Gerenciar categorias</div>
              {!showForm ? (
                <button onClick={() => setShowForm(true)} className="w-full flex items-center gap-1.5 px-2 py-1.5 rounded-md text-xs text-slate-500 hover:bg-slate-100"><Plus className="w-3.5 h-3.5" />Criar nova categoria</button>
              ) : (
                <div className="space-y-2 p-1">
                  <Input className="h-8 text-xs" placeholder="Nome da categoria" value={nome} onChange={(e) => setNome(e.target.value)} autoFocus />
                  <div className="flex flex-wrap gap-1.5">
                    {CORES_ETIQUETA.map((c) => (
                      <button key={c.key} type="button" onClick={() => setCor(c.key)} className={`w-6 h-6 rounded-full ${c.dot} ring-2 ring-offset-1 ${cor === c.key ? 'ring-[#0b2545]' : 'ring-transparent'}`} title={c.label} />
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <button onClick={salvar} className="px-3 py-1.5 rounded-md bg-[#0b2545] text-white text-xs font-medium">{editId ? 'Atualizar' : 'Salvar'}</button>
                    <button onClick={reset} className="px-3 py-1.5 rounded-md text-slate-500 text-xs hover:bg-slate-100">Cancelar</button>
                  </div>
                </div>
              )}
              <div className="border-t border-slate-100 pt-2 max-h-44 overflow-y-auto space-y-0.5">
                {lista.map((c) => {
                  const cc = corEtiqueta(c.cor);
                  return (
                    <div key={c.id} className="flex items-center gap-0.5">
                      <div className="flex-1 flex items-center gap-2 rounded-md px-2 py-1.5 text-sm">
                        <span className={`w-4 h-4 rounded ${cc.dot}`} />
                        <span className="flex-1 text-slate-700 truncate">{c.nome}</span>
                      </div>
                      {podeEditar && <button onClick={() => editar(c)} className="p-1 text-slate-300 hover:text-[#0b2545]"><Pencil className="w-3 h-3" /></button>}
                      {podeExcluir && <button onClick={() => setDelId(c.id)} className="p-1 text-slate-300 hover:text-red-500"><Trash2 className="w-3 h-3" /></button>}
                    </div>
                  );
                })}
                {lista.length === 0 && <p className="text-xs text-slate-400 text-center py-2">Nenhuma categoria.</p>}
              </div>
            </div>
          </PopoverContent>
        </Popover>
      )}

      <AlertDialog open={!!delId} onOpenChange={(o) => !o && setDelId(null)}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir categoria</AlertDialogTitle>
            <AlertDialogDescription>Tem certeza? A categoria será removida do cadastro. Esta ação não pode ser desfeita.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmarExcluir} className="bg-red-500 hover:bg-red-600 text-white">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}