import React, { useEffect, useRef, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { AtSign } from 'lucide-react';
import { extrairMencoes } from '@/lib/quadro';
import { nomeUsuario } from '@/lib/usuarioNome';

export default function MentionInput({ onSend, placeholder, value, onChange }) {
  const [usuarios, setUsuarios] = useState([]);
  const [show, setShow] = useState(false);
  const [sugest, setSugest] = useState([]);
  const ref = useRef(null);

  useEffect(() => {
    (async () => { try { setUsuarios(await base44.entities.User.list('-created_date', 500)); } catch {} })();
  }, []);

  const handleChange = (e) => {
    const v = e.target.value;
    onChange?.(v);
    const at = v.lastIndexOf('@');
    if (at >= 0) {
      const trecho = v.slice(at + 1).toLowerCase();
      if (trecho === '' || /\s/.test(trecho) === false) {
        const matches = usuarios.filter((u) => nomeUsuario(u).toLowerCase().includes(trecho)).slice(0, 5);
        setSugest(matches); setShow(matches.length > 0); return;
      }
    }
    setShow(false);
  };

  const pick = (nome) => {
    const v = value || '';
    const at = v.lastIndexOf('@');
    const novo = v.slice(0, at + 1) + nome + ' ';
    onChange?.(novo); setShow(false);
    ref.current?.focus();
  };

  return (
    <div className="relative flex-1">
      <AtSign className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400 pointer-events-none" />
      <Input ref={ref} className="h-9 pl-8 text-sm" placeholder={placeholder} value={value} onChange={handleChange} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); onSend(value); } }} />
      {show && (
        <div className="absolute bottom-full mb-1 left-0 right-0 bg-white border border-slate-200 rounded-lg shadow-lg max-h-48 overflow-y-auto z-20">
          {sugest.map((u) => { const n = nomeUsuario(u); return (
            <button key={u.id} type="button" onClick={() => pick(n)} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#0b2545] text-white text-[10px] flex items-center justify-center font-semibold">{n.slice(0, 2)}</span>
              {n}
            </button>
          );})}
        </div>
      )}
    </div>
  );
}

export { extrairMencoes };