import React, { useState } from 'react';
import { ChevronRight } from 'lucide-react';

// Toggle compacto "Ver detalhes" — oculta informações secundárias até serem necessárias.
// Não altera dados; apenas controla apresentação visual.
export default function DetalhesToggle({ label = 'Ver detalhes', openLabel = 'Ocultar detalhes', children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="mt-2">
      <button type="button" onClick={() => setOpen((o) => !o)} className="text-[11px] text-[#0b2545] hover:underline inline-flex items-center gap-1 font-medium">
        <ChevronRight className={`w-3 h-3 transition-transform ${open ? 'rotate-90' : ''}`} />
        {open ? openLabel : label}
      </button>
      {open && <div className="mt-2">{children}</div>}
    </div>
  );
}