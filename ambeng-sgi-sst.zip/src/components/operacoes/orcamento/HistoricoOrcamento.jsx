import React from 'react';
import { format } from 'date-fns';
import { History, ChevronDown } from 'lucide-react';
import { parseHistoricoOrc } from '@/lib/orcamento';
import { resolverNomeUsuario } from '@/lib/usuarioNome';

// Histórico do processo — sempre exibe o NOME DE USUÁRIO (BIA, HELOIZA, LUCIANO), nunca e-mail.
export default function HistoricoOrcamento({ orc, usuarios, open, onToggle }) {
  const hist = parseHistoricoOrc(orc.historico);
  return (
    <div className="border border-slate-200 rounded-lg bg-white">
      <button type="button" onClick={onToggle} className="w-full flex items-center gap-2.5 px-3.5 py-2.5 hover:bg-slate-50">
        <History className="w-4 h-4 text-slate-400" />
        <span className="text-sm font-medium text-[#0b2545] flex-1 text-left">Histórico do processo</span>
        <span className="text-xs text-slate-400">{hist.length}</span>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="px-3.5 pb-3.5 border-t border-slate-100 space-y-1.5 pt-2">
          {hist.length === 0 && <p className="text-xs text-slate-400">Sem atividade registrada.</p>}
          {hist.map((h, i) => (
            <div key={i} className="flex items-start gap-2 text-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
              <span className="text-slate-700 flex-1">{h.acao}</span>
              <span className="text-slate-400 shrink-0">{resolverNomeUsuario(h.usuario, usuarios)} · {format(new Date(h.data), 'dd/MM HH:mm')}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}