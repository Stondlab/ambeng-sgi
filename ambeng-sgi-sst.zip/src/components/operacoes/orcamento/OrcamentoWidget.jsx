import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { formatarMoeda, resumoWidget } from '@/lib/orcamento';

const TOM = {
  orcando: 'border-amber-200 bg-amber-50 text-amber-700',
  aprovacao: 'border-sky-200 bg-sky-50 text-sky-700',
  oc: 'border-violet-200 bg-violet-50 text-violet-700',
  recebido: 'border-indigo-200 bg-indigo-50 text-indigo-700',
  financeiro: 'border-cyan-200 bg-cyan-50 text-cyan-700',
  concluido: 'border-emerald-200 bg-emerald-50 text-emerald-700',
  cancelado: 'border-slate-200 bg-slate-100 text-slate-500',
};

// Widget compacto exibido no card da tarefa quando ela possui um processo de orçamento/compra.
export default function OrcamentoWidget({ orcamento, onClick }) {
  const r = resumoWidget(orcamento);
  if (!r) return null;
  return (
    <button
      type="button"
      onClick={(e) => { e.stopPropagation(); onClick?.(); }}
      className={`mt-1.5 w-full text-left rounded-lg border px-2.5 py-1.5 flex items-center gap-2 ${TOM[r.tom] || TOM.orcando} hover:shadow-sm transition-shadow`}
    >
      <ShoppingCart className="w-3.5 h-3.5 shrink-0" />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <span className="text-[11px] font-semibold truncate">🛒 {r.tag}</span>
          {r.oc && <span className="text-[10px] opacity-70 truncate">· {r.oc}</span>}
        </div>
        <div className="flex items-center gap-1.5 text-[10px] opacity-80 truncate">
          {r.valor > 0 && <span className="font-medium">{formatarMoeda(r.valor)}</span>}
          {r.linha2 && <span className="truncate">· {r.linha2}</span>}
        </div>
      </div>
    </button>
  );
}