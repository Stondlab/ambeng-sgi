import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Plus, ClipboardList } from 'lucide-react';
import StageCard from './StageCard';
import CotacaoCard from './CotacaoCard';
import EtapaResp from './EtapaResp';
import { parseCotacoes, novoId, calcCotacaoTotal, formatarMoeda, compactResp } from '@/lib/orcamento';

// Etapa 2 — Cotações. Resumo compacto primeiro (nº de cotações, melhor proposta,
// proposta escolhida). Fornecedores/valores/condições só aparecem ao clicar em
// "Ver cotações". Permite adicionar quantos fornecedores forem necessários e
// seleciona a proposta escolhida (sem obrigar o menor preço).
export default function CotacaoStage({ orc, salvar, fornecedores, usuarios, user, readOnly }) {
  const [justif, setJustif] = useState(orc.justificativa_escolha || '');
  const [verCot, setVerCot] = useState(false);
  const cots = parseCotacoes(orc.cotacoes);

  const setCots = (arr) => salvar({ cotacoes: JSON.stringify(arr) }, null, null, { silent: true });
  const addCot = () => setCots([...cots, { id: novoId(), fornecedor: '', fornecedor_id: '', cnpj: '', contato: '', data: new Date().toISOString().slice(0, 10), validade: '', prazo_entrega: '', condicao_pagamento: '', frete: 0, itens: '[]', observacoes: '' }]);
  const updCot = (c) => setCots(cots.map((x) => (x.id === c.id ? c : x)));
  const delCot = (id) => {
    if (!confirm('Remover esta cotação?')) return;
    setCots(cots.filter((x) => x.id !== id));
    if (orc.cotacao_escolhida === id) salvar({ cotacao_escolhida: '', fornecedor_nome: '', fornecedor_id: '', valor_total: 0 }, 'Cotação escolhida removida');
  };

  const escolher = (c) => {
    const total = calcCotacaoTotal(c);
    salvar(
      { cotacao_escolhida: c.id, fornecedor_nome: c.fornecedor, fornecedor_id: c.fornecedor_id, valor_total: total, etapa: 'Aprovacao', status: 'AGUARDANDO APROVAÇÃO', justificativa_escolha: justif },
      `Proposta escolhida: ${c.fornecedor || 'fornecedor'} (${formatarMoeda(total)})`,
      { titulo: 'Orçamento aguardando aprovação', descricao: `${orc.descricao} — ${c.fornecedor || 'fornecedor'} · ${formatarMoeda(total)}` },
    );
  };

  const salvarJustif = () => salvar({ justificativa_escolha: justif }, 'Justificativa da escolha atualizada');

  const totais = cots.map((c) => calcCotacaoTotal(c));
  const melhor = cots.length ? Math.min(...totais) : 0;
  const idxEsc = cots.findIndex((c) => c.id === orc.cotacao_escolhida);

  return (
    <StageCard orc={orc} etapa="Cotacao" label="Cotações" icon={ClipboardList} defaultOpen={orc.etapa === 'Cotacao'} respCompact={compactResp(orc, 'Cotacao')} right={<span className="text-xs text-slate-400">{cots.length} cotação(ões)</span>}>
      <EtapaResp orc={orc} etapaKey="Cotacao" usuarios={usuarios} salvar={salvar} readOnly={readOnly} />

      {/* Resumo compacto — detalhes só ao clicar em "Ver cotações" */}
      <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50/60 px-3 py-2.5 text-xs">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="font-semibold text-[#0b2545]">{cots.length} {cots.length === 1 ? 'cotação' : 'cotações'}</div>
            <div className="text-slate-500 truncate">
              {cots.length ? (<>Melhor proposta: <span className="font-medium text-[#0b2545]">{formatarMoeda(melhor)}</span>{idxEsc >= 0 ? ` · Escolhida: ${cots[idxEsc].fornecedor || '—'}` : ''}</>) : 'Sem cotações registradas'}
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => setVerCot((v) => !v)}><ClipboardList className="w-3.5 h-3.5" />{verCot ? 'Ocultar' : 'Ver cotações'}</Button>
        </div>
      </div>

      {verCot && (
        <>
          <div className="mt-2 space-y-2">
            {cots.map((c, i) => (
              <CotacaoCard key={c.id} cot={c} idx={i} fornecedores={fornecedores} escolhidaId={orc.cotacao_escolhida} onChoose={escolher} onChange={updCot} onDelete={() => delCot(c.id)} readOnly={readOnly} />
            ))}
            {cots.length === 0 && <p className="text-xs text-slate-400 text-center py-3">Nenhuma cotação. Adicione quantos fornecedores forem necessários.</p>}
            {!readOnly && <Button variant="outline" size="sm" onClick={addCot}><Plus className="w-3.5 h-3.5" />Adicionar cotação</Button>}
          </div>

          {cots.length >= 2 && (
            <div className="mt-3 border border-slate-200 rounded-lg p-3 bg-slate-50/60">
              <div className="text-xs font-semibold text-[#0b2545] mb-2">Comparativo de propostas</div>
              <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${Math.min(cots.length, 4)}, minmax(0,1fr))` }}>
                {cots.map((c) => {
                  const esc = orc.cotacao_escolhida === c.id;
                  return (
                    <div key={c.id} className={`rounded-lg border p-2 text-xs ${esc ? 'border-emerald-300 bg-emerald-50' : 'border-slate-200 bg-white'}`}>
                      <div className="font-semibold text-[#0b2545] truncate">{c.fornecedor || '—'}</div>
                      <div className="text-slate-700 font-medium">{formatarMoeda(calcCotacaoTotal(c))}</div>
                      <div className="text-slate-400">Entrega: {c.prazo_entrega || '—'}</div>
                      <div className="text-slate-400">Pagto: {c.condicao_pagamento || '—'}</div>
                      {esc && <div className="text-emerald-600 font-medium mt-1">✓ Escolhida</div>}
                    </div>
                  );
                })}
              </div>
              <div className="mt-2">
                <Label className="text-xs">Justificativa da escolha</Label>
                <Textarea className="mt-1 text-sm" rows={2} value={justif} onChange={(e) => setJustif(e.target.value)} onBlur={salvarJustif} placeholder="ex: Menor prazo de entrega e condição de pagamento adequada" disabled={readOnly} />
              </div>
            </div>
          )}
        </>
      )}
    </StageCard>
  );
}