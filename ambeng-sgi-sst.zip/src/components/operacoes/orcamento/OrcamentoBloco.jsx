import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { ShoppingCart, Ban } from 'lucide-react';
import { ETAPAS, etapaState, appendHistoricoOrc, notificarPartes, LABEL_ETAPA } from '@/lib/orcamento';
import { nomeUsuario, usuariosAtivos } from '@/lib/usuarioNome';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { formatarMoeda } from '@/lib/moeda';
import SolicitacaoStage from './SolicitacaoStage';
import CotacaoStage from './CotacaoStage';
import AprovacaoStage from './AprovacaoStage';
import OrdemCompraStage from './OrdemCompraStage';
import RecebimentoStage from './RecebimentoStage';
import FinanceiroStage from './FinanceiroStage';
import HistoricoOrcamento from './HistoricoOrcamento';

const MARK = { done: '✓', current: '●', pending: '○' };
const MARK_TONE = { done: 'text-emerald-500', current: 'text-amber-500', pending: 'text-slate-300' };
const PROCESS_STEPS = ETAPAS.filter((item) => item.key !== 'Concluido');

// Processo de orçamento exibido somente na aba Processo da ficha operacional.
// A tarefa permanece o registro principal e cada etapa reutiliza suas ações existentes.
export default function OrcamentoBloco({ orcamento, acao, user, usuarios, obras, onUpdated }) {
  const [orc, setOrc] = useState(orcamento);
  const [fornecedores, setFornecedores] = useState([]);
  const [allOrcs, setAllOrcs] = useState([]);
  const [showHist, setShowHist] = useState(false);

  useEffect(() => {
    (async () => {
      try { setFornecedores(await base44.entities.Fornecedores.list('nome', 500)); } catch {}
      try { setAllOrcs(await base44.entities.Orcamentos.list('-created_date', 500)); } catch {}
    })();
  }, []);

  if (!orc) return null;
  const eu = nomeUsuario(user);

  const salvar = async (patch, evento, notificar, opts = {}) => {
    const dados = { ...patch };
    if (!opts.silent && evento) {
      const hist = appendHistoricoOrc(orc.historico, evento, eu);
      dados.historico = JSON.stringify(hist);
    }
    try { await base44.entities.Orcamentos.update(orc.id, dados); } catch {}
    const novo = { ...orc, ...dados };
    setOrc(novo);
    onUpdated?.(novo);
    if (!opts.silent && notificar?.titulo) {
      notificarPartes(usuarios, acao, notificar.titulo, notificar.descricao, eu, acao.id);
    }
  };

  const cancelar = async () => {
    if (!confirm('Cancelar este processo de orçamento/compra? A tarefa original não será alterada.')) return;
    salvar({ status: 'CANCELADO' }, 'Processo cancelado', { titulo: 'Processo de compra cancelado', descricao: orc.descricao });
  };

  const setRespGeral = (v) => {
    const prev = orc.responsavel_geral || '';
    const ev = prev ? `Responsável geral alterado: ${prev} → ${v}` : `Responsável geral definido: ${v}`;
    salvar({ responsavel_geral: v }, ev);
  };

  const solicitante = orc.solicitante || acao?.responsavel || '—';
  const obra = orc.obra || acao?.obra || '—';
  const processIndex = orc.etapa === 'Concluido' ? PROCESS_STEPS.length : Math.max(1, PROCESS_STEPS.findIndex((item) => item.key === orc.etapa) + 1);

  return (
    <div className="rounded-xl border border-slate-200 bg-white overflow-hidden animate-fade-in">
      {/* Cabeçalho */}
      <div className="px-4 py-3 border-b border-slate-100 flex items-center gap-2.5">
        <span className="w-8 h-8 rounded-md bg-amber-50 text-amber-600 flex items-center justify-center shrink-0"><ShoppingCart className="w-5 h-5" /></span>
        <div><h3 className="text-sm font-semibold text-[#0b2545] tracking-wide">PROCESSO DE COMPRA — {processIndex}/{PROCESS_STEPS.length}</h3><p className="text-[11px] text-slate-500">Orçamento / Compra</p></div>
        <span className="ml-auto text-[11px] px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 font-medium shrink-0">{orc.status}</span>
        {orc.status !== 'CONCLUÍDO' && orc.status !== 'CANCELADO' && (
          <Button variant="outline" size="sm" onClick={cancelar}><Ban className="w-3.5 h-3.5" />Cancelar</Button>
        )}
      </div>

      {/* Resumo do processo — informação essencial em segundos */}
      <div className="px-4 py-3 border-b border-slate-100 bg-slate-50/60">
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-x-4 gap-y-2.5 text-xs">
          <div><div className="text-slate-500">Solicitante</div><div className="font-semibold text-[#0b2545] truncate">{solicitante}</div></div>
          <div><div className="text-slate-500">Obra</div><div className="font-semibold text-[#0b2545] truncate">{obra}</div></div>
          <div><div className="text-slate-500">Valor</div><div className="font-semibold text-[#0b2545]">{formatarMoeda(orc.valor_total)}</div></div>
          <div><div className="text-slate-500">Etapa atual</div><div className="font-semibold text-[#0b2545]">{LABEL_ETAPA[orc.etapa] || orc.etapa}</div></div>
          <div><div className="text-slate-500">Status</div><div className="font-semibold text-[#0b2545] truncate">{orc.status}</div></div>
        </div>

        {/* Responsável geral do processo (editável, independente dos responsáveis de cada etapa) */}
        <div className="mt-3 flex items-center gap-2 text-xs">
          <span className="text-slate-500 font-medium shrink-0">Responsável geral:</span>
          <Select value={orc.responsavel_geral || '__none__'} onValueChange={(v) => v !== '__none__' && setRespGeral(v)}>
            <SelectTrigger className="h-8 w-48 text-xs"><SelectValue placeholder="Atribuir responsável..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="__none__">—</SelectItem>
              {usuariosAtivos(usuarios).map((u) => <SelectItem key={u.id} value={nomeUsuario(u)}>{nomeUsuario(u)}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* Fluxo visual */}
        <div className="mt-3 flex items-center gap-1 overflow-x-auto">
          <div className="flex items-center gap-1 min-w-max">
            {PROCESS_STEPS.map((e, i) => {
              const st = etapaState(orc, e.key);
              return (
                <React.Fragment key={e.key}>
                  <div className="flex flex-col items-center gap-0.5">
                    <span className={`text-base font-bold leading-none ${MARK_TONE[st]}`}>{MARK[st]}</span>
                    <span className={`text-[10px] ${st === 'current' ? 'font-semibold text-[#0b2545]' : st === 'done' ? 'text-emerald-600' : 'text-slate-400'}`}>{e.label}</span>
                  </div>
                  {i < PROCESS_STEPS.length - 1 && <div className={`h-px w-5 ${etapaState(orc, PROCESS_STEPS[i].key) === 'done' ? 'bg-emerald-400' : 'bg-slate-200'}`} />}
                </React.Fragment>
              );
            })}
          </div>
        </div>
      </div>

      {/* Etapas em sequência vertical — rolam junto com a tarefa */}
      <div className="p-3 sm:p-4 space-y-2.5">
        <SolicitacaoStage orc={orc} acao={acao} salvar={salvar} obras={obras} usuarios={usuarios} user={user} readOnly={false} />
        <CotacaoStage orc={orc} salvar={salvar} fornecedores={fornecedores} usuarios={usuarios} user={user} readOnly={false} />
        <AprovacaoStage orc={orc} salvar={salvar} user={user} usuarios={usuarios} readOnly={false} />
        <OrdemCompraStage orc={orc} salvar={salvar} allOrcs={allOrcs} acao={acao} usuarios={usuarios} user={user} readOnly={false} />
        <RecebimentoStage orc={orc} salvar={salvar} user={user} usuarios={usuarios} readOnly={false} />
        <FinanceiroStage orc={orc} salvar={salvar} usuarios={usuarios} user={user} readOnly={false} />
        <HistoricoOrcamento orc={orc} usuarios={usuarios} open={showHist} onToggle={() => setShowHist((s) => !s)} />
      </div>
    </div>
  );
}