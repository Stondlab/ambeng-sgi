import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { FileText, Printer, Send, Eye, FileCheck } from 'lucide-react';
import { format } from 'date-fns';
import { jsPDF } from 'jspdf';
import StageCard from './StageCard';
import EtapaResp from './EtapaResp';
import { parseCotacoes, calcCotacaoTotal, calcItemTotal, parseJson, formatarMoeda, compactResp } from '@/lib/orcamento';
import { useToast } from '@/components/ui/use-toast';

// Etapa 4 — Ordem de Compra. Gera a OC a partir dos dados já cadastrados (sem redigitar).
export default function OrdemCompraStage({ orc, salvar, allOrcs, acao, usuarios, user, readOnly }) {
  const { toast } = useToast();
  const [showDetalhe, setShowDetalhe] = useState(false);
  const cots = parseCotacoes(orc.cotacoes);
  const escolhida = cots.find((c) => c.id === orc.cotacao_escolhida);
  const oc = parseJson(orc.ordem_compra, null);
  const aprov = parseJson(orc.aprovacao, null);

  const gerar = () => {
    if (!escolhida) { toast({ title: 'Escolha uma proposta primeiro.' }); return; }
    const numero = orc.oc_numero || gerarNumeroLocal(allOrcs);
    const itens = parseJson(escolhida.itens, []);
    const dados = {
      numero,
      data: new Date().toISOString().slice(0, 10),
      fornecedor: escolhida.fornecedor,
      cnpj: escolhida.cnpj,
      obra: orc.obra,
      solicitante: orc.solicitante,
      itens,
      frete: Number(escolhida.frete) || 0,
      valor_final: calcCotacaoTotal(escolhida),
      condicao_pagamento: escolhida.condicao_pagamento,
      prazo_entrega: escolhida.prazo_entrega,
      observacoes: orc.observacoes || '',
      aprovado_por: aprov?.nome || '',
      aprovado_em: aprov?.data_hora || '',
    };
    salvar(
      { oc_numero: numero, ordem_compra: JSON.stringify(dados), etapa: 'Recebimento', status: 'OC EMITIDA' },
      `Ordem de compra gerada: ${numero}`,
      { titulo: 'Ordem de compra gerada', descricao: `${numero} — ${orc.descricao}` },
    );
  };

  const gerarPdf = (autoPrint = false) => {
    if (!oc) return;
    const doc = new jsPDF();
    let y = 18;
    doc.setFontSize(16); doc.setFont(undefined, 'bold');
    doc.text(`ORDEM DE COMPRA ${oc.numero}`, 105, y, { align: 'center' }); y += 8;
    doc.setFontSize(9); doc.setFont(undefined, 'normal');
    doc.text(`Data: ${format(new Date(oc.data), 'dd/MM/yyyy')}`, 14, y); y += 6;
    doc.text(`Obra: ${oc.obra || '—'}`, 14, y); y += 6;
    doc.text(`Solicitante: ${oc.solicitante || '—'}`, 14, y); y += 6;
    doc.text(`Fornecedor: ${oc.fornecedor || '—'}`, 14, y); y += 6;
    doc.text(`CNPJ: ${oc.cnpj || '—'}`, 14, y); y += 6;
    doc.text(`Cond. pagamento: ${oc.condicao_pagamento || '—'}   Prazo de entrega: ${oc.prazo_entrega || '—'}`, 14, y); y += 8;
    if (oc.aprovado_por) { doc.text(`Aprovado por: ${oc.aprovado_por}${oc.aprovado_em ? ' em ' + format(new Date(oc.aprovado_em), 'dd/MM/yyyy') : ''}`, 14, y); y += 8; }
    doc.setFont(undefined, 'bold'); doc.text('Itens', 14, y); y += 6;
    doc.setFont(undefined, 'normal');
    (oc.itens || []).forEach((it, i) => {
      doc.text(`${i + 1}. ${it.produto || '—'} — ${it.quantidade || 0} ${it.unidade || ''} x ${formatarMoeda(it.valor_unitario || 0)}${it.desconto ? ' (-' + formatarMoeda(it.desconto) + ')' : ''}`, 14, y);
      doc.text(formatarMoeda(calcItemTotal(it)), 196, y, { align: 'right' }); y += 6;
      if (y > 270) { doc.addPage(); y = 18; }
    });
    y += 2;
    doc.text(`Subtotal: ${formatarMoeda((oc.valor_final || 0) - (Number(oc.frete) || 0))}`, 196, y, { align: 'right' }); y += 6;
    if (Number(oc.frete)) { doc.text(`Frete: ${formatarMoeda(oc.frete)}`, 196, y, { align: 'right' }); y += 6; }
    doc.setFont(undefined, 'bold'); doc.text(`Valor final: ${formatarMoeda(oc.valor_final || 0)}`, 196, y, { align: 'right' });
    if (autoPrint) doc.autoPrint();
    doc.save(`${oc.numero}.pdf`);
  };

  if (orc.status !== 'APROVADO' && !oc) {
    return (
      <StageCard orc={orc} etapa="OrdemCompra" label="Ordem de Compra" icon={FileCheck} respCompact={compactResp(orc, 'OrdemCompra')}>
        <p className="text-xs text-slate-400 mt-3">{orc.status === 'AGUARDANDO APROVAÇÃO' ? 'Aguardando aprovação da proposta.' : 'Aprove a proposta para gerar a ordem de compra.'}</p>
      </StageCard>
    );
  }

  return (
    <StageCard orc={orc} etapa="OrdemCompra" label="Ordem de Compra" icon={FileCheck} defaultOpen={orc.etapa === 'OrdemCompra'} respCompact={compactResp(orc, 'OrdemCompra')} right={oc && <span className="text-xs font-medium text-violet-600">{oc.numero}</span>}>
      <EtapaResp orc={orc} etapaKey="OrdemCompra" usuarios={usuarios} salvar={salvar} readOnly={readOnly} />
      <div className="mt-3 space-y-2.5">
        {!oc ? (
          !readOnly && <Button size="sm" onClick={gerar} className="bg-violet-600 hover:bg-violet-500"><FileText className="w-4 h-4" />Gerar Ordem de Compra</Button>
        ) : (
          <>
            <div className="border border-slate-200 rounded-lg p-3 bg-slate-50/60 text-xs space-y-1">
              <div className="font-semibold text-[#0b2545] text-sm">{oc.numero}</div>
              <div className="flex justify-between"><span className="text-slate-500">Fornecedor:</span><span>{oc.fornecedor || '—'}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Valor final:</span><span className="font-medium text-[#0b2545]">{formatarMoeda(oc.valor_final)}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Entrega:</span><span>{oc.prazo_entrega || '—'}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Pagamento:</span><span>{oc.condicao_pagamento || '—'}</span></div>
            </div>
            {showDetalhe && (
              <div className="border border-slate-200 rounded-lg p-2 text-xs">
                {(oc.itens || []).map((it, i) => (
                  <div key={i} className="flex justify-between border-b border-slate-100 py-1">
                    <span>{it.quantidade} {it.unidade} {it.produto}</span>
                    <span className="font-medium">{formatarMoeda(calcItemTotal(it))}</span>
                  </div>
                ))}
              </div>
            )}
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" onClick={() => setShowDetalhe((s) => !s)}><Eye className="w-3.5 h-3.5" />{showDetalhe ? 'Ocultar' : 'Visualizar'}</Button>
              <Button size="sm" variant="outline" onClick={() => gerarPdf(false)}><FileText className="w-3.5 h-3.5" />Gerar PDF</Button>
              <Button size="sm" variant="outline" onClick={() => gerarPdf(true)}><Printer className="w-3.5 h-3.5" />Imprimir</Button>
              <Button size="sm" variant="outline" onClick={() => { navigator.clipboard?.writeText(`${oc.numero} — ${oc.fornecedor} — ${formatarMoeda(oc.valor_final)}`); toast({ title: 'OC copiada para enviar' }); }}><Send className="w-3.5 h-3.5" />Enviar</Button>
            </div>
          </>
        )}
      </div>
    </StageCard>
  );
}

function gerarNumeroLocal(allOrcs = []) {
  const ano = new Date().getFullYear();
  const nums = allOrcs.map((o) => parseJson(o.ordem_compra, null)?.numero || o.oc_numero).filter(Boolean)
    .map((n) => { const m = String(n).match(/OC-(\d{4})-(\d+)/); return m ? parseInt(m[2], 10) : 0; });
  const max = nums.length ? Math.max(...nums) : 0;
  return `OC-${ano}-${String(max + 1).padStart(4, '0')}`;
}