import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { AlertTriangle, PackageCheck } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import StageCard from './StageCard';
import EtapaResp from './EtapaResp';
import { parseJson, parseCotacoes, compactResp } from '@/lib/orcamento';
import { nomeUsuario } from '@/lib/usuarioNome';

// Etapa 5 — Recebimento. Conferência de quantidade/valor e registro da NF.
export default function RecebimentoStage({ orc, salvar, user, usuarios, readOnly }) {
  const cots = parseCotacoes(orc.cotacoes);
  const escolhida = cots.find((c) => c.id === orc.cotacao_escolhida);
  const oc = parseJson(orc.ordem_compra, null);
  const rec = parseJson(orc.recebimento, null);
  const qtdSolicitada = (parseJson(escolhida?.itens, [])).reduce((a, it) => a + (Number(it.quantidade) || 0), 0);
  const [form, setForm] = useState(rec || {
    data: '', qtd_solicitada: qtdSolicitada, qtd_recebida: qtdSolicitada,
    responsavel: nomeUsuario(user), nf_numero: '', nf_data: '', nf_valor: orc.valor_total || 0, nf_anexo: '',
    conferencia_qtd: 'Completa', conferencia_valor: 'Conforme', observacoes: '',
  });
  const [uploading, setUploading] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const divergenteQtd = form.conferencia_qtd === 'Divergente' || form.conferencia_qtd === 'Parcial';
  const divergenteVal = form.conferencia_valor === 'Divergente';

  const anexarNF = async (e) => {
    const f = e.target.files?.[0]; if (!f) return;
    setUploading(true);
    try { const { file_url } = await base44.integrations.Core.UploadFile({ file: f }); set('nf_anexo', file_url); }
    finally { setUploading(false); e.target.value = ''; }
  };

  const confirmar = () => salvar(
    { recebimento: JSON.stringify(form), etapa: 'Financeiro', status: 'RECEBIDO' },
    `Recebimento registrado — NF ${form.nf_numero || 's/n'} (${form.conferencia_qtd}/${form.conferencia_valor})`,
    { titulo: 'Recebimento registrado', descricao: `${orc.descricao} — NF ${form.nf_numero || 's/n'}` },
  );

  if (!oc) {
    return (
      <StageCard orc={orc} etapa="Recebimento" label="Recebimento" icon={PackageCheck} respCompact={compactResp(orc, 'Recebimento')}>
        <p className="text-xs text-slate-400 mt-3">Gere a ordem de compra antes de registrar o recebimento.</p>
      </StageCard>
    );
  }

  return (
    <StageCard orc={orc} etapa="Recebimento" label="Recebimento" icon={PackageCheck} defaultOpen={orc.etapa === 'Recebimento'} respCompact={compactResp(orc, 'Recebimento')}>
      <EtapaResp orc={orc} etapaKey="Recebimento" usuarios={usuarios} salvar={salvar} readOnly={readOnly} />
      <div className="mt-3 space-y-2.5">
        {rec ? (
          <div className="rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-xs text-indigo-700 flex items-center justify-between">
            <span>Recebimento conferido · NF {rec.nf_numero || 's/n'} · {form.conferencia_qtd}</span>
            <button type="button" onClick={() => setFormOpen((o) => !o)} className="text-[11px] text-[#0b2545] hover:underline">{formOpen ? 'Ocultar' : 'Ver detalhes'}</button>
          </div>
        ) : (
          !readOnly && <Button size="sm" onClick={() => setFormOpen((o) => !o)} className="bg-indigo-600 hover:bg-indigo-500"><PackageCheck className="w-4 h-4" />{formOpen ? 'Fechar' : 'Registrar recebimento'}</Button>
        )}
        {formOpen && (
        <>
        <div className="grid grid-cols-2 gap-2.5">
          <div><Label className="text-xs">Data de recebimento</Label><Input type="date" className="mt-1 h-9 text-sm" value={form.data || ''} onChange={(e) => set('data', e.target.value)} disabled={readOnly} /></div>
          <div><Label className="text-xs">Responsável pelo recebimento</Label><Input className="mt-1 h-9 text-sm" value={form.responsavel || ''} onChange={(e) => set('responsavel', e.target.value)} disabled={readOnly} /></div>
          <div><Label className="text-xs">Qtd. solicitada</Label><Input type="number" className="mt-1 h-9 text-sm" value={form.qtd_solicitada || 0} onChange={(e) => set('qtd_solicitada', Number(e.target.value))} disabled={readOnly} /></div>
          <div><Label className="text-xs">Qtd. recebida</Label><Input type="number" className="mt-1 h-9 text-sm" value={form.qtd_recebida || 0} onChange={(e) => set('qtd_recebida', Number(e.target.value))} disabled={readOnly} /></div>
          <div><Label className="text-xs">Conferência de quantidade</Label>
            <div className="mt-1 flex gap-1">
              {['Completa', 'Parcial', 'Divergente'].map((o) => (
                <button key={o} type="button" onClick={() => set('conferencia_qtd', o)} disabled={readOnly} className={`text-xs px-2.5 py-1.5 rounded-md border ${form.conferencia_qtd === o ? 'bg-[#0b2545] text-white border-[#0b2545]' : 'bg-white text-slate-600 border-slate-200'}`}>{o === 'Completa' ? '✓' : o === 'Parcial' ? '⚠' : '✕'} {o}</button>
              ))}
            </div>
          </div>
          <div><Label className="text-xs">Conferência de valor</Label>
            <div className="mt-1 flex gap-1">
              {['Conforme', 'Divergente'].map((o) => (
                <button key={o} type="button" onClick={() => set('conferencia_valor', o)} disabled={readOnly} className={`text-xs px-2.5 py-1.5 rounded-md border ${form.conferencia_valor === o ? 'bg-[#0b2545] text-white border-[#0b2545]' : 'bg-white text-slate-600 border-slate-200'}`}>{o === 'Conforme' ? '✓' : '⚠'} {o}</button>
              ))}
            </div>
          </div>
          <div><Label className="text-xs">Número da NF</Label><Input className="mt-1 h-9 text-sm" value={form.nf_numero || ''} onChange={(e) => set('nf_numero', e.target.value)} disabled={readOnly} /></div>
          <div><Label className="text-xs">Data da NF</Label><Input type="date" className="mt-1 h-9 text-sm" value={form.nf_data || ''} onChange={(e) => set('nf_data', e.target.value)} disabled={readOnly} /></div>
          <div><Label className="text-xs">Valor da NF (R$)</Label><Input type="number" className="mt-1 h-9 text-sm" value={form.nf_valor || 0} onChange={(e) => set('nf_valor', Number(e.target.value))} disabled={readOnly} /></div>
          <div className="flex items-end">
            <div>
              <Label className="text-xs">Anexo da NF</Label>
              <div className="mt-1 flex items-center gap-2">
                <Button size="sm" variant="outline" onClick={() => document.getElementById('nf-anexo-' + orc.id)?.click()} disabled={readOnly || uploading}>{uploading ? 'Enviando...' : 'Anexar NF'}</Button>
                {form.nf_anexo && <a href={form.nf_anexo} target="_blank" rel="noreferrer" className="text-xs text-[#0b2545] hover:underline">Ver NF</a>}
                <input id={`nf-anexo-${orc.id}`} type="file" className="hidden" onChange={anexarNF} />
              </div>
            </div>
          </div>
        </div>
        <div><Label className="text-xs">Observações</Label><Textarea className="mt-1 text-sm" rows={2} value={form.observacoes || ''} onChange={(e) => set('observacoes', e.target.value)} disabled={readOnly} /></div>

        {(divergenteQtd || divergenteVal) && (
          <div className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-700">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>Divergência no recebimento. Verifique a conferência antes de prosseguir.</span>
          </div>
        )}

        {orc.status !== 'RECEBIDO' && orc.status !== 'NO FINANCEIRO' && orc.status !== 'PAGO' && orc.status !== 'CONCLUÍDO' && !readOnly && (
          <div className="flex justify-end"><Button size="sm" onClick={confirmar} className="bg-indigo-600 hover:bg-indigo-500"><PackageCheck className="w-4 h-4" />Confirmar recebimento</Button></div>
        )}
        {orc.status === 'RECEBIDO' && <p className="text-xs text-indigo-600 font-medium">Recebimento conferido e registrado.</p>}
        </>
        )}
      </div>
    </StageCard>
  );
}