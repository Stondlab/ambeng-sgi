import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Plus, Trash2, Check, ChevronDown } from 'lucide-react';
import { calcItemTotal, calcCotacaoTotal, parseJson, formatarMoeda } from '@/lib/orcamento';

// Editor de uma cotação individual (fornecedor, itens, totais calculados).
export default function CotacaoCard({ cot, idx, fornecedores, escolhidaId, onChoose, onChange, onDelete, readOnly }) {
  const [open, setOpen] = useState(true);
  const set = (k, v) => onChange({ ...cot, [k]: v });
  const itens = parseJson(cot.itens, []);
  const setItens = (arr) => onChange({ ...cot, itens: JSON.stringify(arr) });
  const addItem = () => setItens([...itens, { produto: '', quantidade: 1, unidade: 'un', valor_unitario: 0, desconto: 0 }]);
  const updItem = (i, it) => setItens(itens.map((x, j) => (j === i ? it : x)));
  const delItem = (i) => setItens(itens.filter((_, j) => j !== i));
  const total = calcCotacaoTotal(cot);
  const escolhida = escolhidaId === cot.id;

  return (
    <div className={`border rounded-lg ${escolhida ? 'border-emerald-300 bg-emerald-50/40' : 'border-slate-200 bg-white'}`}>
      <div className="flex items-center gap-2 px-3 py-2">
        <button type="button" onClick={() => setOpen((o) => !o)} className="flex items-center gap-2 flex-1 min-w-0">
          <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${open ? '' : '-rotate-90'}`} />
          <span className="text-sm font-medium text-[#0b2545] truncate">{cot.fornecedor || `Cotação ${idx + 1}`}</span>
          {escolhida && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 font-medium">Escolhida</span>}
        </button>
        <span className="text-sm font-semibold text-[#0b2545]">{formatarMoeda(total)}</span>
        {!readOnly && !escolhida && <Button size="sm" variant="outline" onClick={() => onChoose(cot)} title="Escolher esta proposta"><Check className="w-3.5 h-3.5" />Escolher</Button>}
        {!readOnly && <button type="button" onClick={onDelete} className="p-1.5 text-slate-300 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>}
      </div>
      {open && (
        <div className="px-3 pb-3 border-t border-slate-100 pt-3 space-y-2.5">
          <div className="grid grid-cols-2 gap-2.5">
            <div className="col-span-2">
              <Label className="text-xs">Fornecedor</Label>
              <Select value={cot.fornecedor_id || ''} onValueChange={(v) => { const f = fornecedores.find((x) => x.id === v); onChange({ ...cot, fornecedor_id: v, fornecedor: f?.nome || cot.fornecedor, cnpj: f?.cnpj || cot.cnpj, contato: f?.contato || cot.contato }); }} disabled={readOnly}>
                <SelectTrigger className="mt-1 h-9 text-sm"><SelectValue placeholder="Selecionar fornecedor cadastrado..." /></SelectTrigger>
                <SelectContent>{fornecedores.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}</SelectContent>
              </Select>
              <Input className="mt-1.5 h-9 text-sm" placeholder="Ou digite o nome (continuar sem fornecedor cadastrado)" value={cot.fornecedor || ''} onChange={(e) => set('fornecedor', e.target.value)} disabled={readOnly} />
            </div>
            <div><Label className="text-xs">CNPJ</Label><Input className="mt-1 h-9 text-sm" value={cot.cnpj || ''} onChange={(e) => set('cnpj', e.target.value)} disabled={readOnly} /></div>
            <div><Label className="text-xs">Contato</Label><Input className="mt-1 h-9 text-sm" value={cot.contato || ''} onChange={(e) => set('contato', e.target.value)} disabled={readOnly} /></div>
            <div><Label className="text-xs">Data da cotação</Label><Input type="date" className="mt-1 h-9 text-sm" value={cot.data || ''} onChange={(e) => set('data', e.target.value)} disabled={readOnly} /></div>
            <div><Label className="text-xs">Validade da proposta</Label><Input type="date" className="mt-1 h-9 text-sm" value={cot.validade || ''} onChange={(e) => set('validade', e.target.value)} disabled={readOnly} /></div>
            <div><Label className="text-xs">Prazo de entrega</Label><Input className="mt-1 h-9 text-sm" placeholder="ex: 5 dias" value={cot.prazo_entrega || ''} onChange={(e) => set('prazo_entrega', e.target.value)} disabled={readOnly} /></div>
            <div><Label className="text-xs">Condição de pagamento</Label><Input className="mt-1 h-9 text-sm" placeholder="ex: 28 dias" value={cot.condicao_pagamento || ''} onChange={(e) => set('condicao_pagamento', e.target.value)} disabled={readOnly} /></div>
            <div><Label className="text-xs">Frete (R$)</Label><Input type="number" className="mt-1 h-9 text-sm" value={cot.frete || 0} onChange={(e) => set('frete', Number(e.target.value))} disabled={readOnly} /></div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <Label className="text-xs">Itens</Label>
              {!readOnly && <Button size="sm" variant="ghost" onClick={addItem}><Plus className="w-3.5 h-3.5" />Item</Button>}
            </div>
            <div className="space-y-1.5">
              {itens.map((it, i) => (
                <div key={i} className="grid grid-cols-12 gap-1 items-center">
                  <Input className="col-span-3 h-8 text-xs" placeholder="Produto/Serviço" value={it.produto} onChange={(e) => updItem(i, { ...it, produto: e.target.value })} disabled={readOnly} />
                  <Input type="number" className="col-span-1 h-8 text-xs" placeholder="Qtd" value={it.quantidade} onChange={(e) => updItem(i, { ...it, quantidade: Number(e.target.value) })} disabled={readOnly} />
                  <Input className="col-span-1 h-8 text-xs" placeholder="Un" value={it.unidade} onChange={(e) => updItem(i, { ...it, unidade: e.target.value })} disabled={readOnly} />
                  <Input type="number" className="col-span-2 h-8 text-xs" placeholder="Vl. unit." value={it.valor_unitario} onChange={(e) => updItem(i, { ...it, valor_unitario: Number(e.target.value) })} disabled={readOnly} />
                  <Input type="number" className="col-span-2 h-8 text-xs" placeholder="Desc." value={it.desconto} onChange={(e) => updItem(i, { ...it, desconto: Number(e.target.value) })} disabled={readOnly} />
                  <span className="col-span-2 text-[11px] text-slate-600 font-medium text-right truncate">{formatarMoeda(calcItemTotal(it))}</span>
                  {!readOnly && <button type="button" onClick={() => delItem(i)} className="col-span-1 text-slate-300 hover:text-red-500 flex justify-center"><Trash2 className="w-3.5 h-3.5" /></button>}
                </div>
              ))}
              {itens.length === 0 && <p className="text-xs text-slate-400">Nenhum item. Adicione para calcular o total.</p>}
            </div>
            <div className="flex items-center justify-between mt-2 text-sm">
              <span className="text-slate-500">Subtotal: {formatarMoeda(total - (Number(cot.frete) || 0))}</span>
              <span className="font-semibold text-[#0b2545]">Total: {formatarMoeda(total)}</span>
            </div>
          </div>

          <div><Label className="text-xs">Observações</Label><Textarea className="mt-1 text-sm" rows={2} value={cot.observacoes || ''} onChange={(e) => set('observacoes', e.target.value)} disabled={readOnly} /></div>
        </div>
      )}
    </div>
  );
}