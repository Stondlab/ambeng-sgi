import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, ShoppingCart, Layers } from 'lucide-react';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import OrcamentoBloco from './OrcamentoBloco';

// Responsáveis iniciais são sugestões editáveis; não há pessoas fixas no código.
function etapasRespPadrao(responsavelGeral = '') {
  const base = (resp) => ({ responsavel: resp, prazo: '', status: 'Aguardando', data_conclusao: '', observacao: '' });
  return JSON.stringify({
    Solicitacao: base(responsavelGeral),
    Cotacao: base(''),
    Aprovacao: base(''),
    OrdemCompra: base(''),
    Recebimento: base(''),
    Financeiro: base(''),
  });
}

// Área de processos da ficha operacional. Reutiliza o orçamento já carregado pelo
// Kanban quando disponível e consulta somente ao abrir uma tarefa sem esse dado.
export default function ProcessosArea({ acao, user, usuarios, obras, onUpdated, orcamentoInicial }) {
  const [orc, setOrc] = useState(orcamentoInicial || null);
  const [loading, setLoading] = useState(!orcamentoInicial);
  const [showAdd, setShowAdd] = useState(false);

  const load = async () => {
    try {
      const list = await base44.entities.Orcamentos.filter({ demanda_id: acao.id });
      setOrc(list[0] || null);
    } catch { setOrc(null); }
    setLoading(false);
  };
  useEffect(() => {
    if (orcamentoInicial) { setOrc(orcamentoInicial); setLoading(false); return; }
    load();
  }, [acao.id, orcamentoInicial]);

  const criar = async () => {
    setShowAdd(false);
    const hoje = new Date().toISOString().slice(0, 10);
    try {
      const novo = await base44.entities.Orcamentos.create({
        demanda_id: acao.id,
        demanda_titulo: acao.titulo,
        descricao: acao.titulo,
        obra: acao.obra || '',
        solicitante: acao.responsavel || '',
        responsavel_geral: acao.responsavel || '',
        data_solicitacao: hoje,
        prioridade: acao.prioridade || 'Média',
        etapa: 'Solicitacao',
        status: 'RASCUNHO',
        etapas_resp: etapasRespPadrao(acao.responsavel || ''),
        cotacoes: '[]', historico: '[]',
        aprovacao: 'null', ordem_compra: 'null', recebimento: 'null', financeiro: 'null',
        valor_total: 0,
      });
      setOrc(novo);
      onUpdated?.();
    } catch (e) { alert('Erro ao criar processo: ' + (e?.message || e)); }
  };

  if (loading) return null;

  if (!orc) {
    return (
      <div>
        <div className="flex items-center gap-1.5 mb-1.5 text-sm font-semibold text-[#0b2545]"><Layers className="w-4 h-4" />Processos</div>
        <Popover open={showAdd} onOpenChange={setShowAdd}>
          <PopoverTrigger asChild>
            <button className="h-9 px-3 rounded-md border border-dashed border-slate-300 text-slate-500 text-xs font-medium flex items-center gap-1.5 hover:bg-slate-50"><Plus className="w-3.5 h-3.5" />Adicionar processo</button>
          </PopoverTrigger>
          <PopoverContent className="w-56 p-1" align="start">
            <button onClick={criar} className="w-full flex items-center gap-2 px-2 py-2 rounded-md hover:bg-slate-100 text-sm"><ShoppingCart className="w-4 h-4 text-amber-500" />Processo de Compra</button>
            <div className="px-2 py-1.5 text-[11px] text-slate-400 border-t border-slate-100 mt-1">Processos configurados são escolhidos ao criar a tarefa</div>
          </PopoverContent>
        </Popover>
      </div>
    );
  }

  return (
    <OrcamentoBloco orcamento={orc} acao={acao} user={user} usuarios={usuarios} obras={obras} onUpdated={(o) => { setOrc(o); onUpdated?.(); }} />
  );
}