import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Wallet, Send, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import StageCard from './StageCard';
import EtapaResp from './EtapaResp';
import DetalhesToggle from './DetalhesToggle';
import { parseJson, formatarMoeda, FIN_STATUS, compactResp } from '@/lib/orcamento';
import { useToast } from '@/components/ui/use-toast';

// Etapa 6 — Financeiro. Envia a compra ao Financeiro (cria Despesa, sem duplicar)
// e acompanha o fluxo COMPROMETIDO → NF RECEBIDA → A PAGAR → PAGO.
export default function FinanceiroStage({ orc, salvar, usuarios, user, readOnly }) {
  const { toast } = useToast();
  const fin = parseJson(orc.financeiro, null) || { status: 'COMPROMETIDO', despesa_id: '', vencimento: '', categoria: 'Material' };
  const [venc, setVenc] = useState(fin.vencimento || '');
  const [categoria, setCategoria] = useState(fin.categoria || 'Material');
  const rec = parseJson(orc.recebimento, null);

  const enviar = async () => {
    if (fin.despesa_id) { toast({ title: 'Já enviado ao Financeiro.' }); return; }
    try {
      const despesa = await base44.entities.Despesas.create({
        descricao: `OC ${orc.oc_numero} — ${orc.descricao}`,
        valor: Number(orc.valor_total) || 0,
        data_vencimento: venc || '',
        fornecedor_id: orc.fornecedor_id || '',
        fornecedor: orc.fornecedor_nome || '',
        obra: orc.obra || '',
        categoria: categoria || 'Material',
        numero_nota_fiscal: rec?.nf_numero || '',
        observacoes: `[ORC:${orc.id}] Ordem de compra ${orc.oc_numero}. Tarefa: ${orc.demanda_titulo || ''}`,
        status: 'Pendente',
      });
      salvar(
        { financeiro: JSON.stringify({ despesa_id: despesa.id, status: 'A PAGAR', vencimento: venc, categoria }), status: 'NO FINANCEIRO' },
        'Enviado para o Financeiro',
        { titulo: 'Compra aguardando conferência no Financeiro', descricao: `${orc.descricao} · ${formatarMoeda(orc.valor_total)}` },
      );
    } catch (e) { toast({ title: 'Erro ao criar despesa', description: String(e?.message || e) }); }
  };

  const setStatus = async (novoStatus) => {
    const novoFin = { ...fin, status: novoStatus };
    salvar({ financeiro: JSON.stringify(novoFin), status: novoStatus === 'PAGO' ? 'PAGO' : 'NO FINANCEIRO' }, `Financeiro: ${novoStatus}`);
    if (novoStatus === 'PAGO' && fin.despesa_id) {
      try { await base44.entities.Despesas.update(fin.despesa_id, { status: 'Pago', data_pagamento: new Date().toISOString().slice(0, 10) }); } catch {}
    }
  };

  const concluir = () => salvar({ etapa: 'Concluido', status: 'CONCLUÍDO' }, 'Processo de compra concluído', { titulo: 'Compra concluída', descricao: orc.descricao });

  if (!rec) {
    return (
      <StageCard orc={orc} etapa="Financeiro" label="Financeiro" icon={Wallet} respCompact={compactResp(orc, 'Financeiro')}>
        <p className="text-xs text-slate-400 mt-3">Registre o recebimento antes de enviar ao Financeiro.</p>
      </StageCard>
    );
  }

  return (
    <StageCard orc={orc} etapa="Financeiro" label="Financeiro" icon={Wallet} defaultOpen={orc.etapa === 'Financeiro'} respCompact={compactResp(orc, 'Financeiro')}>
      <EtapaResp orc={orc} etapaKey="Financeiro" usuarios={usuarios} salvar={salvar} readOnly={readOnly} />
      <div className="mt-3 space-y-2.5">
        <div className="flex items-center justify-between rounded-lg border border-slate-200 bg-slate-50/60 px-3 py-2 text-xs">
          <span><span className="text-slate-500">Status:</span> <span className="font-medium text-[#0b2545]">{fin.despesa_id ? fin.status : 'Aguardando lançamento'}</span></span>
          <Link to="/financeiro" className="text-[11px] text-cyan-700 hover:underline font-medium">Ver no Financeiro</Link>
        </div>
        <DetalhesToggle label="Ver detalhes">
          <div className="border border-slate-200 rounded-lg p-3 bg-white text-xs space-y-1">
            <div className="flex justify-between"><span className="text-slate-500">Fornecedor:</span><span>{orc.fornecedor_nome || '—'}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Valor:</span><span className="font-medium text-[#0b2545]">{formatarMoeda(orc.valor_total)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Obra:</span><span>{orc.obra || '—'}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">OC:</span><span>{orc.oc_numero || '—'}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">NF:</span><span>{rec.nf_numero || '—'}</span></div>
          </div>
        </DetalhesToggle>

        {!fin.despesa_id ? (
          <div className="grid grid-cols-2 gap-2.5">
            <div><Label className="text-xs">Vencimento</Label><Input type="date" className="mt-1 h-9 text-sm" value={venc} onChange={(e) => setVenc(e.target.value)} disabled={readOnly} /></div>
            <div><Label className="text-xs">Categoria</Label>
              <Select value={categoria} onValueChange={setCategoria} disabled={readOnly}>
                <SelectTrigger className="mt-1 h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>{['Material', 'Mão de Obra', 'Serviço', 'ADM', 'Outros'].map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {!readOnly && <div className="col-span-2 flex justify-end"><Button size="sm" onClick={enviar} className="bg-cyan-600 hover:bg-cyan-500"><Send className="w-4 h-4" />Enviar para o Financeiro</Button></div>}
          </div>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500">Status financeiro:</span>
              <Select value={fin.status} onValueChange={setStatus} disabled={readOnly}>
                <SelectTrigger className="h-8 text-xs w-44"><SelectValue /></SelectTrigger>
                <SelectContent>{FIN_STATUS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <p className="text-[11px] text-slate-400">Despesa criada no Financeiro (sem duplicidade). O Financeiro permanece responsável pelo tratamento.</p>
            {(orc.status === 'NO FINANCEIRO' || orc.status === 'PAGO') && !readOnly && orc.status !== 'CONCLUÍDO' && (
              <div className="flex justify-end"><Button size="sm" onClick={concluir} className="bg-emerald-600 hover:bg-emerald-500"><CheckCircle2 className="w-4 h-4" />Concluir processo</Button></div>
            )}
            {orc.status === 'CONCLUÍDO' && <p className="text-xs text-emerald-600 font-medium">Processo concluído. ✓</p>}
          </div>
        )}
      </div>
    </StageCard>
  );
}