import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';
import StageCard from './StageCard';
import EtapaResp from './EtapaResp';
import { PRIORIDADES_ORC, compactResp } from '@/lib/orcamento';

// Etapa 1 — Solicitação. Reutiliza os dados da tarefa principal (descrição, obra,
// solicitante) — exibidos como resumo somente-leitura para evitar duplicação.
// Apenas os campos próprios da solicitação (data da solicitação, data necessária,
// prioridade, justificativa, observações) são editáveis aqui.
export default function SolicitacaoStage({ orc, acao, salvar, obras, usuarios, user, readOnly }) {
  const [form, setForm] = useState({
    data_solicitacao: orc.data_solicitacao || '',
    data_necessaria: orc.data_necessaria || '',
    prioridade: orc.prioridade || 'Média',
    justificativa: orc.justificativa || '',
    observacoes: orc.observacoes || '',
  });
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const salvarForm = () => salvar(form, 'Solicitação atualizada');

  // Dados que vêm da tarefa principal (não duplicados como campos editáveis).
  const descricao = orc.descricao || acao?.titulo || '—';
  const obra = orc.obra || acao?.obra || '—';
  const solicitante = orc.solicitante || acao?.responsavel || '—';

  return (
    <StageCard orc={orc} etapa="Solicitacao" label="Solicitação" icon={FileText} defaultOpen={orc.etapa === 'Solicitacao'} respCompact={compactResp(orc, 'Solicitacao')}>
      <EtapaResp orc={orc} etapaKey="Solicitacao" usuarios={usuarios} salvar={salvar} readOnly={readOnly} />

      {/* Dados herdados da tarefa — somente leitura */}
      <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50/60 px-3 py-2.5 text-xs space-y-1.5">
        <div className="flex gap-2"><span className="text-slate-500 w-20 shrink-0">Descrição:</span><span className="font-medium text-[#0b2545]">{descricao}</span></div>
        <div className="flex gap-2"><span className="text-slate-500 w-20 shrink-0">Obra:</span><span className="font-medium text-[#0b2545]">{obra}</span></div>
        <div className="flex gap-2"><span className="text-slate-500 w-20 shrink-0">Solicitante:</span><span className="font-medium text-[#0b2545]">{solicitante}</span></div>
      </div>

      {/* Campos próprios da solicitação */}
      <div className="grid grid-cols-2 gap-3 mt-3">
        <div>
          <Label className="text-xs">Data da solicitação</Label>
          <Input type="date" className="mt-1 h-9 text-sm" value={form.data_solicitacao} onChange={(e) => set('data_solicitacao', e.target.value)} disabled={readOnly} />
        </div>
        <div>
          <Label className="text-xs">Data necessária</Label>
          <Input type="date" className="mt-1 h-9 text-sm" value={form.data_necessaria} onChange={(e) => set('data_necessaria', e.target.value)} disabled={readOnly} />
        </div>
        <div>
          <Label className="text-xs">Prioridade</Label>
          <Select value={form.prioridade} onValueChange={(v) => set('prioridade', v)} disabled={readOnly}>
            <SelectTrigger className="mt-1 h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>{PRIORIDADES_ORC.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="col-span-2">
          <Label className="text-xs">Justificativa</Label>
          <Textarea className="mt-1 text-sm" rows={2} value={form.justificativa} onChange={(e) => set('justificativa', e.target.value)} disabled={readOnly} />
        </div>
        <div className="col-span-2">
          <Label className="text-xs">Observações</Label>
          <Textarea className="mt-1 text-sm" rows={2} value={form.observacoes} onChange={(e) => set('observacoes', e.target.value)} disabled={readOnly} />
        </div>
      </div>
      {!readOnly && <div className="flex justify-end mt-3"><Button size="sm" onClick={salvarForm}>Salvar solicitação</Button></div>}
    </StageCard>
  );
}