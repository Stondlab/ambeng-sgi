import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Check, X, ShieldCheck } from 'lucide-react';
import { format } from 'date-fns';
import StageCard from './StageCard';
import EtapaResp from './EtapaResp';
import DetalhesToggle from './DetalhesToggle';
import { parseCotacoes, calcCotacaoTotal, parseJson, formatarMoeda, compactResp } from '@/lib/orcamento';
import { nomeUsuario, resolverNomeUsuario } from '@/lib/usuarioNome';

// Etapa 3 — Aprovação. Exibe o resumo da proposta escolhida e ações Aprovar/Reprovar.
export default function AprovacaoStage({ orc, salvar, user, usuarios, readOnly }) {
  const [obs, setObs] = useState('');
  const [reprovJust, setReprovJust] = useState('');
  const [showReprov, setShowReprov] = useState(false);
  const cots = parseCotacoes(orc.cotacoes);
  const escolhida = cots.find((c) => c.id === orc.cotacao_escolhida);
  const aprov = parseJson(orc.aprovacao, null);

  const aprovar = () => salvar(
    { aprovacao: JSON.stringify({ usuario: user?.id || '', nome: nomeUsuario(user), data_hora: new Date().toISOString(), decisao: 'Aprovado', observacao: obs }), etapa: 'OrdemCompra', status: 'APROVADO' },
    'Orçamento aprovado',
    { titulo: 'Orçamento aprovado', descricao: `${orc.descricao} — ${formatarMoeda(orc.valor_total)}` },
  );

  const reprovar = () => {
    if (!reprovJust.trim()) { alert('Informe a justificativa da reprovação.'); return; }
    salvar(
      { aprovacao: JSON.stringify({ usuario: user?.id || '', nome: nomeUsuario(user), data_hora: new Date().toISOString(), decisao: 'Reprovado', observacao: reprovJust }), etapa: 'Cotacao', status: 'ORÇANDO', cotacao_escolhida: '', fornecedor_nome: '', fornecedor_id: '', valor_total: 0 },
      `Orçamento reprovado: ${reprovJust.trim()}`,
      { titulo: 'Orçamento reprovado', descricao: orc.descricao },
    );
    setShowReprov(false); setReprovJust('');
  };

  const reabrir = () => salvar({ cotacao_escolhida: '', fornecedor_nome: '', fornecedor_id: '', valor_total: 0, etapa: 'Cotacao', status: 'ORÇANDO', aprovacao: 'null' }, 'Aprovação reaberta — voltou para cotações');

  return (
    <StageCard orc={orc} etapa="Aprovacao" label="Aprovação" icon={ShieldCheck} defaultOpen={orc.etapa === 'Aprovacao'} respCompact={compactResp(orc, 'Aprovacao')}>
      <EtapaResp orc={orc} etapaKey="Aprovacao" usuarios={usuarios} salvar={salvar} readOnly={readOnly} />
      <div className="mt-3 space-y-2.5">
        {!escolhida && orc.status !== 'APROVADO' && <p className="text-xs text-slate-400">Nenhuma proposta escolhida. Selecione uma cotação na etapa anterior.</p>}

        {escolhida && (
          <div className="rounded-lg border border-slate-200 bg-slate-50/60 px-3 py-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-[#0b2545] text-sm">{escolhida.fornecedor || 'Fornecedor'}</span>
              <span className="font-medium text-[#0b2545]">{formatarMoeda(calcCotacaoTotal(escolhida))}</span>
            </div>
            <DetalhesToggle label="Ver detalhes da proposta" openLabel="Ocultar detalhes">
              <div className="border border-slate-200 rounded-lg p-3 bg-white space-y-1">
                <div className="flex justify-between"><span className="text-slate-500">Obra:</span><span>{orc.obra || '—'}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Prazo de entrega:</span><span>{escolhida.prazo_entrega || '—'}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Pagamento:</span><span>{escolhida.condicao_pagamento || '—'}</span></div>
                {orc.justificativa_escolha && <div className="pt-1 border-t border-slate-200"><span className="text-slate-500">Justificativa:</span> {orc.justificativa_escolha}</div>}
              </div>
            </DetalhesToggle>
          </div>
        )}

        {aprov && (
          <div className={`rounded-lg border p-3 text-xs ${aprov.decisao === 'Aprovado' ? 'border-emerald-200 bg-emerald-50' : 'border-red-200 bg-red-50'}`}>
            <div className="font-semibold text-[#0b2545]">{aprov.decisao} por {resolverNomeUsuario(aprov.nome, usuarios)}</div>
            <div className="text-slate-500">{format(new Date(aprov.data_hora), 'dd/MM/yyyy HH:mm')}</div>
            {aprov.observacao && <div className="text-slate-600 mt-1">"{aprov.observacao}"</div>}
            {!readOnly && <button onClick={reabrir} className="text-[11px] text-[#0b2545] hover:underline mt-1">Reabrir aprovação</button>}
          </div>
        )}

        {!aprov && escolhida && !readOnly && (
          <div className="space-y-2">
            <div><Label className="text-xs">Observação da aprovação (opcional)</Label><Textarea className="mt-1 text-sm" rows={2} value={obs} onChange={(e) => setObs(e.target.value)} /></div>
            <div className="flex gap-2">
              <Button size="sm" onClick={aprovar} className="bg-emerald-600 hover:bg-emerald-500"><Check className="w-4 h-4" />Aprovar</Button>
              <Button size="sm" variant="outline" onClick={() => setShowReprov((s) => !s)} className="border-red-200 text-red-600 hover:bg-red-50"><X className="w-4 h-4" />Reprovar</Button>
            </div>
            {showReprov && (
              <div>
                <Label className="text-xs">Justificativa da reprovação *</Label>
                <Textarea className="mt-1 text-sm" rows={2} value={reprovJust} onChange={(e) => setReprovJust(e.target.value)} />
                <Button size="sm" variant="destructive" className="mt-2" onClick={reprovar}>Confirmar reprovação</Button>
              </div>
            )}
          </div>
        )}
      </div>
    </StageCard>
  );
}