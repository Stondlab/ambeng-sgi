import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { parseEtapasResp, LABEL_ETAPA, RESP_STATUS } from '@/lib/orcamento';
import { nomeUsuario, usuariosAtivos } from '@/lib/usuarioNome';
import DetalhesToggle from './DetalhesToggle';

// Gestão de responsável por etapa (checklist): responsável, prazo, status,
// data de conclusão e observação. Compacto — mostra só o essencial (Responsável,
// Prazo, Status); "Concluído em" e "Observação" ficam em "Ver detalhes".
// Independente do responsável geral e do fluxo (etapa/status do processo).
export default function EtapaResp({ orc, etapaKey, usuarios, salvar, readOnly }) {
  const etapas = parseEtapasResp(orc);
  const cur = etapas[etapaKey] || {};
  const [form, setForm] = useState({
    responsavel: cur.responsavel || '',
    prazo: cur.prazo || '',
    status: cur.status || 'Aguardando',
    data_conclusao: cur.data_conclusao || '',
    observacao: cur.observacao || '',
  });
  const label = LABEL_ETAPA[etapaKey] || 'Etapa';

  const set = (k, v) => {
    const next = { ...form, [k]: v };
    if (k === 'status' && v === 'Concluído' && !form.data_conclusao) {
      next.data_conclusao = new Date().toISOString().slice(0, 10);
    }
    setForm(next);
  };

  const salvarResp = () => {
    const novas = { ...etapas, [etapaKey]: form };
    const prev = cur.responsavel || '';
    let evento;
    if (form.responsavel && form.responsavel !== prev) {
      evento = `Responsável da etapa ${label} definido: ${form.responsavel}${prev ? ` (anterior: ${prev})` : ''}`;
    } else if (prev && !form.responsavel) {
      evento = `Responsável da etapa ${label} removido`;
    } else if (form.status === 'Concluído' && cur.status !== 'Concluído') {
      evento = `Etapa ${label} concluída`;
    } else {
      evento = `Etapa ${label} atualizada (responsável/prazo/status)`;
    }
    salvar({ etapas_resp: JSON.stringify(novas) }, evento);
  };

  return (
    <div className="mb-3 rounded-lg border border-slate-200 bg-slate-50/40 p-2.5">
      <div className="grid grid-cols-3 gap-2">
        <div>
          <Label className="text-[11px] text-slate-500">Responsável</Label>
          <Select value={form.responsavel || '__none__'} onValueChange={(v) => set('responsavel', v === '__none__' ? '' : v)} disabled={readOnly}>
            <SelectTrigger className="mt-0.5 h-8 text-xs"><SelectValue placeholder="Atribuir..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="__none__">—</SelectItem>
              {usuariosAtivos(usuarios).map((u) => <SelectItem key={u.id} value={nomeUsuario(u)}>{nomeUsuario(u)}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-[11px] text-slate-500">Prazo</Label>
          <Input type="date" className="mt-0.5 h-8 text-xs" value={form.prazo} onChange={(e) => set('prazo', e.target.value)} disabled={readOnly} />
        </div>
        <div>
          <Label className="text-[11px] text-slate-500">Status</Label>
          <Select value={form.status} onValueChange={(v) => set('status', v)} disabled={readOnly}>
            <SelectTrigger className="mt-0.5 h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>{RESP_STATUS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </div>
      <DetalhesToggle>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label className="text-[11px] text-slate-500">Concluído em</Label>
            <Input type="date" className="mt-0.5 h-8 text-xs" value={form.data_conclusao} onChange={(e) => set('data_conclusao', e.target.value)} disabled={readOnly} />
          </div>
          <div className="col-span-2">
            <Label className="text-[11px] text-slate-500">Observação</Label>
            <Input className="mt-0.5 h-8 text-xs" value={form.observacao} onChange={(e) => set('observacao', e.target.value)} disabled={readOnly} />
          </div>
        </div>
      </DetalhesToggle>
      {!readOnly && <div className="flex justify-end mt-2"><Button size="sm" variant="outline" className="h-8 text-xs" onClick={salvarResp}>Salvar responsável da etapa</Button></div>}
    </div>
  );
}