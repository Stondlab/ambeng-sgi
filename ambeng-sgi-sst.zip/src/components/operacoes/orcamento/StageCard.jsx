import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { etapaState } from '@/lib/orcamento';

const MARK = { done: '✓', current: '●', pending: '○' };
const TONE = { done: 'bg-emerald-500 text-white', current: 'bg-amber-500 text-white', pending: 'bg-slate-200 text-slate-400' };
const STATE_LABEL = { done: 'Concluída', current: 'Em andamento', pending: 'Aguardando' };

// Card de uma etapa do processo (acordeão). state = done/current/pending.
export default function StageCard({ orc, etapa, label, icon: Icon, defaultOpen, children, right, respCompact }) {
  const [open, setOpen] = useState(!!defaultOpen);
  const st = etapaState(orc, etapa);
  return (
    <div className="border border-slate-200 rounded-lg bg-white overflow-hidden">
      <button type="button" onClick={() => setOpen((o) => !o)} className="w-full flex items-center gap-2.5 px-3.5 py-2.5 hover:bg-slate-50">
        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-bold shrink-0 ${TONE[st]}`}>{MARK[st]}</span>
        {Icon && <Icon className="w-4 h-4 text-slate-400 shrink-0" />}
        <span className="text-sm font-medium text-[#0b2545] flex-1 text-left truncate">{label}</span>
        {!open && respCompact && <span className="hidden max-w-[45%] truncate text-xs font-medium text-slate-400 sm:block">{respCompact}</span>}
        <span className={`text-xs font-medium ${st === 'done' ? 'text-emerald-600' : st === 'current' ? 'text-amber-600' : 'text-slate-400'}`}>{STATE_LABEL[st]}</span>
        {right}
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform shrink-0 ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && <div className="px-3.5 pb-3.5 border-t border-slate-100">{children}</div>}
    </div>
  );
}