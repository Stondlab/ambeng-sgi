import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Bell, CheckCheck, Trash2, X, AlertOctagon, AlertTriangle, ArrowRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { format } from 'date-fns';
import { nomeUsuario } from '@/lib/usuarioNome';
import { useSstData } from '@/hooks/useSstEntitiesData';
import { alertasSst } from '@/lib/alertas';
import { alertasOrcamento } from '@/lib/orcamento';
import { useToast } from '@/components/ui/use-toast';
import { registrarErroInterno } from '@/lib/validacao';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

const HDR = {
  red: { c: 'text-red-700 bg-red-50', Icon: AlertOctagon, l: 'Crítico' },
  amber: { c: 'text-amber-700 bg-amber-50', Icon: AlertTriangle, l: 'Atenção' },
};

export default function NotificacoesUnificadas({ user }) {
  const meusNomes = [nomeUsuario(user), user?.full_name, user?.email].filter(Boolean);
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [filtro, setFiltro] = useState('todas'); // todas | nao-lidas | lidas
  const [confirmarLimpeza, setConfirmarLimpeza] = useState(false);
  const [orcamentos, setOrcamentos] = useState([]);
  const [usuarios, setUsuarios] = useState([]);

  const sstData = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis', 'inspecoes', 'ocorrencias', 'dds']);

  // Carrega notificações armazenadas
  const load = async () => {
    if (!meusNomes.length) return;
    let n = [];
    try { n = await base44.entities.Notificacoes.list('-data', 200); }
    catch (erro) { registrarErroInterno('Carregar Central de Alertas', erro); }
    setItems(n.filter((x) => meusNomes.includes(x.usuario)));
  };

  // Carrega dados para alertas SST
  useEffect(() => {
    (async () => {
      try { setOrcamentos(await base44.entities.Orcamentos.list('-created_date', 200)); } catch {}
      try { setUsuarios(await base44.entities.User.list()); } catch {}
    })();
  }, []);

  useEffect(() => { load(); const t = setInterval(load, 20000); const unsubscribe = base44.entities.Notificacoes.subscribe(() => load()); return () => { clearInterval(t); unsubscribe(); }; }, [meusNomes.join('|'), open]);

  // Alertas SST computados (não armazenados — somem quando resolvidos)
  const alertasSstList = useMemo(() => [...alertasSst(sstData), ...alertasOrcamento(orcamentos, usuarios)], [sstData, orcamentos, usuarios]);
  const criticosCount = alertasSstList.filter((p) => p.tone === 'red').length;

  const naoLidas = items.filter((n) => !n.lida).length;
  const totalNaoLidas = naoLidas;

  // Ações em lote
  const marcarTodas = async () => {
    const nl = items.filter((n) => !n.lida);
    if (!nl.length) return;
    try {
      setItems((current) => current.map((item) => ({ ...item, lida: true })));
      await base44.entities.Notificacoes.bulkUpdate(nl.map((n) => ({ id: n.id, lida: true })));
      await load(); toast({ title: 'Todas as notificações foram marcadas como lidas.' });
    } catch (erro) {
      registrarErroInterno('Marcar notificações como lidas', erro);
      toast({ title: 'Não foi possível atualizar as notificações.', description: 'Tente novamente em instantes.', variant: 'destructive' });
    }
  };
  const limparTudo = async () => {
    if (!items.length) return;
    try {
      setConfirmarLimpeza(false);
      await base44.entities.Notificacoes.deleteMany({ usuario: { $in: meusNomes } });
      setItems([]); toast({ title: 'Notificações excluídas.' });
    } catch (erro) {
      registrarErroInterno('Excluir todas as notificações', erro);
      toast({ title: 'Não foi possível excluir as notificações.', description: 'Tente novamente em instantes.', variant: 'destructive' });
    }
  };

  // Ações individuais
  const marcarLida = async (id, lida) => {
    try { setItems((current) => current.map((item) => item.id === id ? { ...item, lida } : item)); await base44.entities.Notificacoes.update(id, { lida }); await load(); }
    catch (erro) { registrarErroInterno('Atualizar notificação', erro); toast({ title: 'Não foi possível atualizar a notificação.', description: 'Tente novamente.', variant: 'destructive' }); }
  };
  const deletar = async (id) => {
    try { await base44.entities.Notificacoes.delete(id); await load(); toast({ title: 'Notificação excluída.' }); }
    catch (erro) { registrarErroInterno('Excluir notificação', erro); toast({ title: 'Não foi possível excluir a notificação.', description: 'Tente novamente.', variant: 'destructive' }); }
  };

  // Filtro
  const filtered = useMemo(() => {
    if (filtro === 'nao-lidas') return items.filter((n) => !n.lida);
    if (filtro === 'lidas') return items.filter((n) => n.lida);
    return items;
  }, [items, filtro]);

  const alertasGroups = ['red', 'amber'].map((t) => ({ tone: t, items: alertasSstList.filter((p) => p.tone === t) })).filter((g) => g.items.length > 0);

  const FILTROS = [
    { v: 'todas', l: 'Todas' },
    { v: 'nao-lidas', l: 'Não lidas' },
    { v: 'lidas', l: 'Lidas' },
  ];

  return (
    <div className="relative">
      <button onClick={() => setOpen(true)} className="relative flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted" title="Notificações">
        <Bell className="w-5 h-5" />
        {totalNaoLidas > 0 && (
          <span className="absolute right-1.5 top-1.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-bold text-white ring-2 ring-card">
            {totalNaoLidas > 9 ? '9+' : totalNaoLidas}
          </span>
        )}
      </button>

      <Dialog open={open} onOpenChange={(o) => !o && setOpen(false)}>
        <DialogContent className="max-w-lg p-0 max-h-[600px] overflow-hidden flex flex-col">
          {/* Header */}
          <DialogHeader className="shrink-0 flex-row items-center justify-between space-y-0 border-b border-border px-4 py-3">
            <DialogTitle className="flex items-center gap-2 text-base">
              <Bell className="w-4 h-4 text-amber-500" />Notificações
              <span className="rounded-full bg-red-500 px-2 py-0.5 text-xs text-white">{totalNaoLidas}</span>
            </DialogTitle>
          </DialogHeader>

          {/* Filtros */}
          <div className="flex shrink-0 flex-wrap gap-1 border-b border-border px-4 py-2">
            {FILTROS.map((f) => (
              <button
                key={f.v}
                onClick={() => setFiltro(f.v)}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${filtro === f.v ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'}`}
              >
                {f.l}
              </button>
            ))}
            <div className="ml-auto flex items-center gap-2">
              {naoLidas > 0 && (
                <button onClick={marcarTodas} className="flex items-center gap-1 text-xs text-primary hover:underline" title="Marcar todas como lidas">
                  <CheckCheck className="w-3.5 h-3.5" />Marcar todas como lidas
                </button>
              )}
              {items.length > 0 && (
                <button onClick={() => setConfirmarLimpeza(true)} className="flex items-center gap-1 text-xs text-destructive hover:underline" title="Limpar tudo">
                  <Trash2 className="w-3.5 h-3.5" />Limpar tudo
                </button>
              )}
            </div>
          </div>

          {/* Conteúdo */}
          <div className="flex-1 divide-y divide-border overflow-y-auto">
            {/* Alertas do sistema (SST) — sempre visíveis, não filtráveis */}
            {filtro === 'todas' && alertasGroups.length > 0 && (
              <div className="space-y-3 bg-muted/40 p-3">
                {alertasGroups.map((g) => {
                  const h = HDR[g.tone];
                  return (
                    <div key={g.tone}>
                      <div className={`flex items-center gap-2 rounded-lg px-3 py-2 mb-2 ${h.c}`}>
                        <h.Icon className="w-4 h-4" /><span className="text-sm font-semibold">{h.l}</span>
                        <span className="ml-auto text-xs opacity-70">{g.items.length}</span>
                      </div>
                      <div className="space-y-1.5">
                        {g.items.map((a, i) => {
                          const to = a.funcionario_id ? `/funcionarios/${a.funcionario_id}` : a.link;
                          return (
                            <div key={i} className="flex items-center gap-2 rounded-lg border border-border bg-card p-2">
                              <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${g.tone === 'red' ? 'bg-red-500' : 'bg-amber-500'}`} />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm text-slate-700 truncate">{a.label}</p>
                                <p className="text-xs text-muted-foreground">{a.detalhe}</p>
                                <p className="mt-1 text-[10px] text-muted-foreground">{a.data ? format(new Date(a.data), 'dd/MM/yyyy HH:mm') : format(new Date(), 'dd/MM/yyyy HH:mm')}</p>
                                </div>
                              <Link to={to} onClick={() => setOpen(false)} className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-md bg-[#0b2545] text-white hover:bg-[#0b2545]/90 shrink-0">Abrir <ArrowRight className="w-3 h-3" /></Link>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Notificações armazenadas */}
            {filtered.length === 0 && (filtro === 'todas' || alertasGroups.length === 0) ? (
              <p className="text-sm text-slate-400 text-center py-10">Sem notificações.</p>
            ) : (
              filtered.map((n) => (
                <div key={n.id} className={`group px-4 py-3 ${n.lida ? 'bg-muted/40' : 'bg-card'}`}>
                  <div className="flex items-start gap-2">
                    {/* Checkbox marcar como lido */}
                    <button
                      onClick={() => marcarLida(n.id, !n.lida)}
                      className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border-2 transition ${n.lida ? 'border-success bg-success' : 'border-border hover:border-primary'}`}
                      title={n.lida ? 'Marcar como não lida' : 'Marcar como lida'}
                    >
                      {n.lida && <CheckCheck className="w-3 h-3 text-white" />}
                    </button>
                    {!n.lida && <span className="w-2 h-2 rounded-full bg-amber-500 mt-2 shrink-0" />}
                    <div className="min-w-0 flex-1">
                      <p className={`text-sm ${n.lida ? 'font-normal text-muted-foreground' : 'font-medium text-foreground'}`}>{n.titulo}</p>
                      {n.descricao && <p className="mt-0.5 text-xs text-muted-foreground">{n.descricao}</p>}
                      <div className="mt-2 flex items-center gap-3"><p className="text-[10px] text-muted-foreground">{n.data ? format(new Date(n.data), 'dd/MM/yyyy HH:mm') : ''}</p>{!n.lida && <button onClick={() => marcarLida(n.id, true)} className="text-xs font-medium text-primary hover:underline">Marcar como lida</button>}{(n.link || n.demanda_id) && <Link to={n.link || `/operacoes?demanda=${n.demanda_id}`} onClick={() => { if (!n.lida) marcarLida(n.id, true); setOpen(false); }} className="ml-auto inline-flex items-center gap-1 text-xs font-semibold text-primary">Abrir <ArrowRight className="h-3 w-3" /></Link>}</div>
                    </div>
                    {/* Botão deletar */}
                    <button onClick={() => deletar(n.id)} className="p-1 text-slate-300 hover:text-red-500 transition shrink-0" title="Excluir">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
      <AlertDialog open={confirmarLimpeza} onOpenChange={setConfirmarLimpeza}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Limpar todas as notificações?</AlertDialogTitle><AlertDialogDescription>Essa ação removerá as notificações da sua central.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={limparTudo} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Limpar notificações</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
    </div>
  );
}