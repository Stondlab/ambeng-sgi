import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { CORES_ETIQUETA, corEtiqueta, parseEtiquetas } from '@/lib/quadro';
import { usePermissoes } from '@/lib/PermissoesContext';
import { podeCriarEstrutural, podeEditarEstrutural, podeExcluirEstrutural } from '@/lib/estruturalPerm';
import { Plus, Check, Pencil, Trash2 } from 'lucide-react';

// Seletor de etiquetas com criação/edição/exclusão inline (registro compartilhado).
export default function EtiquetasPopoverContent({ acao, etiquetas, onToggle, onAtualizou }) {
  const { perfilEfetivo: perfil } = usePermissoes();
  const podeCriar = podeCriarEstrutural(perfil);
  const podeEditar = podeEditarEstrutural(perfil);
  const podeExcluir = podeExcluirEstrutural(perfil);
  const [nome, setNome] = useState('');
  const [cor, setCor] = useState('cinza');
  const [editId, setEditId] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [delId, setDelId] = useState(null);

  const atuais = parseEtiquetas(acao.etiquetas);

  const reset = () => { setNome(''); setCor('cinza'); setEditId(null); setShowForm(false); };

  const salvar = async () => {
    if (!nome.trim()) return;
    if (editId) await base44.entities.Etiquetas.update(editId, { nome: nome.trim(), cor });
    else await base44.entities.Etiquetas.create({ nome: nome.trim(), cor, ativa: true });
    reset(); onAtualizou?.();
  };
  const editar = (e) => { setEditId(e.id); setNome(e.nome); setCor(e.cor || 'cinza'); setShowForm(true); };
  const confirmarExcluir = async () => {
    try { if (delId) await base44.entities.Etiquetas.delete(delId); } catch {}
    setDelId(null); onAtualizou?.();
  };

  return (
    <div className="w-72">
      <div className="space-y-0.5 max-h-52 overflow-y-auto">
        {etiquetas.length === 0 && <p className="text-xs text-slate-400 text-center py-3">Nenhuma etiqueta criada.</p>}
        {etiquetas.map((e) => {
          const c = corEtiqueta(e.cor);
          const on = atuais.includes(e.nome);
          return (
            <div key={e.id} className="flex items-center gap-0.5">
              <button onClick={() => onToggle(e.nome)} className="flex-1 flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-slate-100 text-sm">
                <span className={`w-4 h-4 rounded ${c.dot}`} />
                <span className="flex-1 text-left text-slate-700 truncate">{e.nome}</span>
                {on && <Check className="w-3.5 h-3.5 text-emerald-500" />}
              </button>
              {podeEditar && <button onClick={() => editar(e)} className="p-1 text-slate-300 hover:text-[#0b2545]"><Pencil className="w-3 h-3" /></button>}
              {podeExcluir && <button onClick={() => setDelId(e.id)} className="p-1 text-slate-300 hover:text-red-500"><Trash2 className="w-3 h-3" /></button>}
            </div>
          );
        })}
      </div>

      {podeCriar && (
        <div className="border-t border-slate-100 mt-2 pt-2">
          {!showForm ? (
            <button onClick={() => setShowForm(true)} className="w-full flex items-center gap-1.5 px-2 py-1.5 rounded-md text-xs text-slate-500 hover:bg-slate-100"><Plus className="w-3.5 h-3.5" />Criar nova etiqueta</button>
          ) : (
            <div className="space-y-2 p-1">
              <Input className="h-8 text-xs" placeholder="Nome da etiqueta" value={nome} onChange={(e) => setNome(e.target.value)} autoFocus />
              <div className="flex flex-wrap gap-1.5">
                {CORES_ETIQUETA.map((c) => (
                  <button key={c.key} type="button" onClick={() => setCor(c.key)} className={`w-6 h-6 rounded-full ${c.dot} ring-2 ring-offset-1 ${cor === c.key ? 'ring-[#0b2545]' : 'ring-transparent'}`} title={c.label} />
                ))}
              </div>
              <div className="flex gap-2">
                <button onClick={salvar} className="px-3 py-1.5 rounded-md bg-[#0b2545] text-white text-xs font-medium">{editId ? 'Atualizar' : 'Salvar'}</button>
                <button onClick={reset} className="px-3 py-1.5 rounded-md text-slate-500 text-xs hover:bg-slate-100">Cancelar</button>
              </div>
            </div>
          )}
        </div>
      )}

      <AlertDialog open={!!delId} onOpenChange={(o) => !o && setDelId(null)}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir etiqueta</AlertDialogTitle>
            <AlertDialogDescription>Tem certeza? A etiqueta será removida do cadastro. Esta ação não pode ser desfeita.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmarExcluir} className="bg-red-500 hover:bg-red-600 text-white">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}