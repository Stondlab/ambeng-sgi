import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Pencil, Trash2, Tag } from 'lucide-react';
import { CORES_ETIQUETA, corEtiqueta } from '@/lib/quadro';

export function EtiquetasPanel({ onAtualizou }) {
  const [lista, setLista] = useState([]);
  const [nome, setNome] = useState('');
  const [cor, setCor] = useState('cinza');
  const [editId, setEditId] = useState(null);

  const load = async () => { let l = []; try { l = await base44.entities.Etiquetas.list('-created_date', 500); } catch {} setLista(l); };
  useEffect(() => { load(); }, []);

  const reset = () => { setNome(''); setCor('cinza'); setEditId(null); };

  const salvar = async () => {
    if (!nome.trim()) return;
    if (editId) await base44.entities.Etiquetas.update(editId, { nome: nome.trim(), cor });
    else await base44.entities.Etiquetas.create({ nome: nome.trim(), cor, ativa: true });
    reset(); load(); onAtualizou?.();
  };
  const editar = (e) => { setEditId(e.id); setNome(e.nome); setCor(e.cor || 'cinza'); };
  const excluir = async (id) => { await base44.entities.Etiquetas.delete(id); load(); onAtualizou?.(); };

  return (
    <div className="space-y-3">
      <div>
        <Label>Nome</Label>
        <Input className="mt-1" value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Ex.: Urgente" />
      </div>
      <div>
        <Label>Cor</Label>
        <div className="flex flex-wrap gap-2 mt-1.5">
          {CORES_ETIQUETA.map((c) => (
            <button key={c.key} type="button" onClick={() => setCor(c.key)} className={`w-8 h-8 rounded-full ${c.dot} ring-2 ring-offset-2 ${cor === c.key ? 'ring-[#0b2545]' : 'ring-transparent'}`} title={c.label} />
          ))}
        </div>
      </div>
      <div className="flex gap-2">
        <Button onClick={salvar} className="bg-[#0b2545] hover:bg-[#16365f]">{editId ? 'Atualizar' : 'Adicionar'}</Button>
        {editId && <Button variant="ghost" onClick={reset}>Cancelar edição</Button>}
      </div>

      <div className="border-t border-slate-100 pt-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        {lista.length === 0 && <p className="text-sm text-slate-400 col-span-full text-center py-4">Nenhuma etiqueta criada.</p>}
        {lista.map((e) => {
          const c = corEtiqueta(e.cor);
          return (
            <div key={e.id} className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2">
              <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${c.chip}`}><span className={`w-1.5 h-1.5 rounded-full ${c.dot}`} />{e.nome}</span>
              <div className="ml-auto flex items-center">
                <button onClick={() => editar(e)} className="p-1.5 text-slate-400 hover:text-[#0b2545]"><Pencil className="w-3.5 h-3.5" /></button>
                <button onClick={() => excluir(e.id)} className="p-1.5 text-slate-400 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function EtiquetasManager({ open, onClose, onAtualizou }) {
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle className="flex items-center gap-2"><Tag className="w-4 h-4 text-amber-500" />Etiquetas do quadro</DialogTitle></DialogHeader>
        <EtiquetasPanel onAtualizou={onAtualizou} />
      </DialogContent>
    </Dialog>
  );
}