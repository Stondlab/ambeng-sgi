import React from 'react';
import { Trash2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { nomeUsuario } from '@/lib/usuarioNome';

export default function ChecklistDraftRow({ item, usuarios, onChange, onDelete }) {
  const set = (key, value) => onChange({ ...item, [key]: value });
  return <div className="grid gap-2 rounded-lg border border-border bg-card p-2 sm:grid-cols-[minmax(180px,2fr)_minmax(150px,1fr)_140px_130px_40px]">
    <Input value={item.text || ''} onChange={(event) => set('text', event.target.value)} placeholder="Descrição da tarefa" />
    <Select value={item.responsavel || '__none__'} onValueChange={(value) => set('responsavel', value === '__none__' ? '' : value)}><SelectTrigger><SelectValue placeholder="Responsável" /></SelectTrigger><SelectContent><SelectItem value="__none__">Sem responsável</SelectItem>{usuarios.map((user) => <SelectItem key={user.id} value={nomeUsuario(user)}>{nomeUsuario(user)}</SelectItem>)}</SelectContent></Select>
    <Input type="date" value={item.data || ''} onChange={(event) => set('data', event.target.value)} />
    <Select value={item.status || 'A Fazer'} onValueChange={(value) => set('status', value)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{['A Fazer', 'Em Andamento', 'Aguardando', 'Concluído'].map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent></Select>
    <button type="button" onClick={onDelete} className="flex min-h-10 items-center justify-center rounded-md text-muted-foreground hover:bg-destructive/10 hover:text-destructive" aria-label="Excluir item"><Trash2 className="h-4 w-4" /></button>
  </div>;
}