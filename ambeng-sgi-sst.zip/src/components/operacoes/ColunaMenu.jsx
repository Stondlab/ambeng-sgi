import React from 'react';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { MoreHorizontal, ArrowDownWideNarrow, CalendarClock, EyeOff, Archive } from 'lucide-react';

export default function ColunaMenu({ col, onOrdenar, onOcultar, onArquivarConcluidos }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button onClick={(e) => e.stopPropagation()} className="w-7 h-7 rounded-md hover:bg-slate-200 flex items-center justify-center text-slate-400" title="Ações da coluna"><MoreHorizontal className="w-4 h-4" /></button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" onClick={(e) => e.stopPropagation()}>
        <DropdownMenuItem onClick={() => onOrdenar(col, 'prioridade')}><ArrowDownWideNarrow className="w-3.5 h-3.5 mr-2" />Ordenar por prioridade</DropdownMenuItem>
        <DropdownMenuItem onClick={() => onOrdenar(col, 'prazo')}><CalendarClock className="w-3.5 h-3.5 mr-2" />Ordenar por prazo</DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => onArquivarConcluidos(col)}><Archive className="w-3.5 h-3.5 mr-2" />Arquivar concluídos da coluna</DropdownMenuItem>
        <DropdownMenuItem onClick={() => onOcultar(col)} className="text-amber-700"><EyeOff className="w-3.5 h-3.5 mr-2" />Ocultar coluna</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}