import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Pencil, Trash2, Zap } from 'lucide-react';
import { GATILHOS, ACOES, pertenceAoQuadro } from '@/lib/quadro';
import { TIPOS, PRIORIDADES } from '@/lib/acoes';

export default function RegrasAutomacaoManager({ open, onClose, quadroId, geralId }) {
  const [regras, setRegras] = useState([]);
  const [colunas, setColunas] = useState([]);
  const [etiquetas, setEtiquetas] = useState([]);
  const [form, setForm] = useState({ nome: '', gatilho: 'mover_para_coluna', gatilho_valor: '', acao: 'mover_para_coluna', acao_valor: '', ativa: true, quadro_id: '' });
  const [editId, setEditId] = useState(null);

  const load = async () => {
    let r = [], c = [], e = [];
    try { r = await base44.entities.RegrasAutomacao.list('-created_date', 500); } catch {}
    try { c = await base44.entities.ColunasQuadro.list('ordem', 500); } catch {}
    try { e = await base44.entities.Etiquetas.list('-created_date', 500); } catch {}
    setRegras(r.filter((x) => pertenceAoQuadro(x.quadro_id, quadroId, geralId)));
    setColunas(c.filter((x) => !x.arquivada && pertenceAoQuadro(x.quadro_id, quadroId, geralId)));
    setEtiquetas(e);
  };
  useEffect(() => { if (open) load(); }, [open, quadroId, geralId]);

  const reset = () => { setForm({ nome: '', gatilho: 'mover_para_coluna', gatilho_valor: '', acao: 'mover_para_coluna', acao_valor: '', ativa: true, quadro_id: quadroId || '' }); setEditId(null); };

  const salvar = async () => {
    if (!form.nome.trim()) return;
    const payload = editId ? form : { ...form, quadro_id: quadroId || '' };
    if (editId) await base44.entities.RegrasAutomacao.update(editId, payload);
    else await base44.entities.RegrasAutomacao.create(payload);
    reset(); load();
  };
  const editar = (r) => { setEditId(r.id); setForm({ nome: r.nome, gatilho: r.gatilho, gatilho_valor: r.gatilho_valor || '', acao: r.acao, acao_valor: r.acao_valor || '', ativa: r.ativa !== false, quadro_id: r.quadro_id || '' }); };
  const excluir = async (id) => { await base44.entities.RegrasAutomacao.delete(id); load(); };
  const toggle = async (r) => { await base44.entities.RegrasAutomacao.update(r.id, { ativa: !r.ativa }); load(); };

  const descGatilho = (r) => {
    const g = GATILHOS.find((x) => x.v === r.gatilho)?.label || r.gatilho;
    const c = colunas.find((x) => x.id === r.gatilho_valor);
    const val = r.gatilho === 'mover_para_coluna' ? c?.nome : r.gatilho_valor;
    return `${g}${val ? `: ${val}` : ''}`;
  };
  const descAcao = (r) => {
    const a = ACOES.find((x) => x.v === r.acao)?.label || r.acao;
    const c = colunas.find((x) => x.id === r.acao_valor);
    let val = r.acao_valor;
    if (r.acao === 'mover_para_coluna') val = c?.nome;
    return `${a}${val ? `: ${val}` : ''}`;
  };

  const setGatilho = (v) => setForm((f) => ({ ...f, gatilho: v, gatilho_valor: '' }));
  const setAcao = (v) => setForm((f) => ({ ...f, acao: v, acao_valor: '' }));

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-xl max-h-[88vh] overflow-y-auto">
        <DialogHeader><DialogTitle className="flex items-center gap-2"><Zap className="w-4 h-4 text-amber-500" />Automações do quadro</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-3">
            <div><Label>Nome da regra</Label><Input className="mt-1" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} placeholder="Ex.: Concluir → arquivar" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Gatilho</Label>
                <Select value={form.gatilho} onValueChange={setGatilho}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{GATILHOS.map((g) => <SelectItem key={g.v} value={g.v}>{g.label}</SelectItem>)}</SelectContent></Select>
              </div>
              <div>
                <Label>Valor do gatilho</Label>
                {form.gatilho === 'mover_para_coluna' ? (
                  <Select value={form.gatilho_valor} onValueChange={(v) => setForm({ ...form, gatilho_valor: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Coluna" /></SelectTrigger><SelectContent>{colunas.map((c) => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent></Select>
                ) : form.gatilho === 'criado_com_tipo' ? (
                  <Select value={form.gatilho_valor} onValueChange={(v) => setForm({ ...form, gatilho_valor: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Tipo" /></SelectTrigger><SelectContent>{TIPOS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select>
                ) : form.gatilho === 'criado_com_categoria' ? (
                  <Input className="mt-1" value={form.gatilho_valor} onChange={(e) => setForm({ ...form, gatilho_valor: e.target.value })} placeholder="Categoria" />
                ) : (
                  <Input className="mt-1" value={form.gatilho_valor} onChange={(e) => setForm({ ...form, gatilho_valor: e.target.value })} placeholder="(automático)" disabled />
                )}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Ação</Label>
                <Select value={form.acao} onValueChange={setAcao}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{ACOES.map((a) => <SelectItem key={a.v} value={a.v}>{a.label}</SelectItem>)}</SelectContent></Select>
              </div>
              <div>
                <Label>Valor da ação</Label>
                {form.acao === 'mover_para_coluna' ? (
                  <Select value={form.acao_valor} onValueChange={(v) => setForm({ ...form, acao_valor: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Coluna" /></SelectTrigger><SelectContent>{colunas.map((c) => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent></Select>
                ) : form.acao === 'atribuir_responsavel' ? (
                  <Input className="mt-1" value={form.acao_valor} onChange={(e) => setForm({ ...form, acao_valor: e.target.value })} placeholder="Nome do responsável" />
                ) : form.acao === 'adicionar_etiqueta' ? (
                  <Select value={form.acao_valor} onValueChange={(v) => setForm({ ...form, acao_valor: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Etiqueta" /></SelectTrigger><SelectContent>{etiquetas.map((e) => <SelectItem key={e.id} value={e.nome}>{e.nome}</SelectItem>)}</SelectContent></Select>
                ) : form.acao === 'alterar_prioridade' ? (
                  <Select value={form.acao_valor} onValueChange={(v) => setForm({ ...form, acao_valor: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Prioridade" /></SelectTrigger><SelectContent>{PRIORIDADES.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent></Select>
                ) : (
                  <Input className="mt-1" value={form.acao_valor} onChange={(e) => setForm({ ...form, acao_valor: e.target.value })} placeholder="Texto da notificação" />
                )}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-sm text-slate-600"><Switch checked={form.ativa} onCheckedChange={(v) => setForm({ ...form, ativa: v })} />Regra ativa</label>
              <div className="flex gap-2">
                {editId && <Button variant="ghost" onClick={reset}>Cancelar</Button>}
                <Button onClick={salvar} className="bg-[#0b2545] hover:bg-[#16365f]">{editId ? 'Atualizar' : 'Criar regra'}</Button>
              </div>
            </div>
          </div>

          <div className="space-y-1.5">
            {regras.length === 0 && <p className="text-sm text-slate-400 text-center py-4">Nenhuma automação configurada.</p>}
            {regras.map((r) => (
              <div key={r.id} className="flex items-center gap-2 bg-white border border-slate-200 rounded-lg px-3 py-2">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-[#0b2545] truncate">{r.nome}</p>
                  <p className="text-xs text-slate-500 truncate">Quando {descGatilho(r)} → {descAcao(r)}</p>
                </div>
                <Switch checked={r.ativa !== false} onCheckedChange={() => toggle(r)} />
                <button onClick={() => editar(r)} className="p-1.5 text-slate-400 hover:text-[#0b2545]"><Pencil className="w-3.5 h-3.5" /></button>
                <button onClick={() => excluir(r.id)} className="p-1.5 text-slate-400 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}