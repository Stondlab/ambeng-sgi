import React, { useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ORIGENS, PRIORIDADES } from '@/lib/acoes';
import { tagFromFilter } from '@/lib/tags';
import { corCategoria } from '@/lib/quadro';
import { Search, SlidersHorizontal, ChevronDown } from 'lucide-react';
import { resolverNomeUsuario } from '@/lib/usuarioNome';

const CHIPS = [
  { key: 'todas', label: 'Todas' },
  { key: 'minhas', label: 'Minhas' },
  { key: 'hoje', label: 'Hoje' },
  { key: 'semana', label: 'Esta semana' },
  { key: 'atrasadas', label: 'Atrasadas' },
  { key: 'criticas', label: 'Críticas' },
  { key: 'concluidas', label: 'Concluídas' },
];

export default function FiltrosAcoes({ filtros, setFiltros, demands, search, setSearch, etiquetas = [], jobs = [], categoriasCad = [], usuarios = [] }) {
  const [avancado, setAvancado] = useState(false);
  const responsaveis = [...new Set(demands.map((d) => resolverNomeUsuario(d.responsavel, usuarios)).filter(Boolean))];
  const obras = [...new Set(demands.map((d) => d.obra).filter(Boolean))];
  const empresas = [...new Set(demands.map((d) => d.empresa).filter(Boolean))];
  const categorias = [...new Set(demands.map((d) => d.categoria).filter(Boolean))];
  const ATIVOS = [
    { field: 'job', def: 'todos' }, { field: 'responsavel', def: 'todos' }, { field: 'obra', def: 'todos' },
    { field: 'empresa', def: 'todos' }, { field: 'categoria', def: 'todos' },
    { field: 'prioridade', def: 'todas' }, { field: 'origem', def: 'todas' }, { field: 'etiqueta', def: 'todas' },
  ].map((f) => ({ ...f, value: filtros[f.field] })).filter((f) => f.value && f.value !== f.def);
  const limparFiltros = () => setFiltros({ ...filtros, job: 'todos', responsavel: 'todos', obra: 'todos', empresa: 'todos', categoria: 'todos', prioridade: 'todas', origem: 'todas', etiqueta: 'todas' });

  return (
    <div className="mb-4 space-y-3">
      <div className="flex flex-wrap gap-2">
        {CHIPS.map((c) => (
          <button
            key={c.key}
            onClick={() => setFiltros((f) => ({ ...f, rapido: c.key }))}
            className={`min-h-[36px] px-3 rounded-full text-xs font-medium border transition-colors ${filtros.rapido === c.key ? 'bg-[#0b2545] text-white border-[#0b2545]' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {ATIVOS.length > 0 && (
        <div className="flex flex-wrap gap-1.5 items-center">
          {ATIVOS.map((f) => {
            const tag = f.field === 'categoria'
              ? (() => { const cc = corCategoria(categoriasCad, f.value); return { categoria: 'Categoria', chip: cc.chip, dot: cc.dot, label: f.value }; })()
              : tagFromFilter(f.field, f.value);
            if (!tag) return null;
            return (
              <button key={f.field} onClick={() => setFiltros((s) => ({ ...s, [f.field]: f.def }))} className={`inline-flex items-center gap-1 rounded-full border text-xs px-2 py-1 font-medium ${tag.chip}`} title={`${tag.categoria}: ${tag.label}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${tag.dot}`} />{tag.label}<span className="ml-0.5 opacity-60">✕</span>
              </button>
            );
          })}
          <button onClick={limparFiltros} className="text-xs text-slate-400 hover:text-slate-600 underline">Limpar</button>
        </div>
      )}

      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Pesquisar ações..." className="pl-8 h-9" />
        </div>
        <Button variant="outline" size="sm" onClick={() => setAvancado((a) => !a)} className="h-9">
          <SlidersHorizontal className="w-4 h-4" />Filtros avançados
          <ChevronDown className={`w-3.5 h-3.5 transition-transform ${avancado ? 'rotate-180' : ''}`} />
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs text-slate-400">Status:</span>
        <Select value={filtros.status || 'todos'} onValueChange={(v) => setFiltros((f) => ({ ...f, status: v }))}>
          <SelectTrigger className="h-9 w-44 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="A Fazer">A Fazer</SelectItem>
            <SelectItem value="Em Andamento">Em Andamento</SelectItem>
            <SelectItem value="Aguardando">Aguardando</SelectItem>
            <SelectItem value="Concluído">Concluído</SelectItem>
            <SelectItem value="Arquivado">Arquivado</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-xs text-slate-400">Arquivamento:</span>
        <Select value={filtros.arquivamento || 'ativos'} onValueChange={(v) => setFiltros((f) => ({ ...f, arquivamento: v }))}>
          <SelectTrigger className="h-9 w-44 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="ativos">Ativos</SelectItem>
            <SelectItem value="arquivados">Arquivados</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {avancado && (
        <div className="bg-white border border-slate-200 rounded-xl p-3 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-8 gap-2">
          <Select value={filtros.job} onValueChange={(v) => setFiltros((f) => ({ ...f, job: v }))}>
            <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Agrupamento" /></SelectTrigger>
            <SelectContent><SelectItem value="todos">Agrupamento</SelectItem>{jobs.map((j) => <SelectItem key={j.id} value={j.id}>{j.nome}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={filtros.responsavel} onValueChange={(v) => setFiltros((f) => ({ ...f, responsavel: v }))}>
            <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Responsável" /></SelectTrigger>
            <SelectContent><SelectItem value="todos">Responsável</SelectItem>{responsaveis.map((r) => <SelectItem key={r} value={r}>{resolverNomeUsuario(r, usuarios)}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={filtros.obra} onValueChange={(v) => setFiltros((f) => ({ ...f, obra: v }))}>
            <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Obra" /></SelectTrigger>
            <SelectContent><SelectItem value="todos">Obra</SelectItem>{obras.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={filtros.empresa} onValueChange={(v) => setFiltros((f) => ({ ...f, empresa: v }))}>
            <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Empresa" /></SelectTrigger>
            <SelectContent><SelectItem value="todos">Empresa</SelectItem>{empresas.map((e) => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={filtros.categoria} onValueChange={(v) => setFiltros((f) => ({ ...f, categoria: v }))}>
            <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Categoria" /></SelectTrigger>
            <SelectContent><SelectItem value="todos">Categoria</SelectItem>{categorias.map((c) => { const cc = corCategoria(categoriasCad, c); return <SelectItem key={c} value={c}><span className="flex items-center gap-1.5"><span className={`w-2 h-2 rounded-full ${cc.dot}`} />{c}</span></SelectItem>; })}</SelectContent>
          </Select>
          <Select value={filtros.prioridade} onValueChange={(v) => setFiltros((f) => ({ ...f, prioridade: v }))}>
            <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Prioridade" /></SelectTrigger>
            <SelectContent><SelectItem value="todas">Prioridade</SelectItem>{PRIORIDADES.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={filtros.origem} onValueChange={(v) => setFiltros((f) => ({ ...f, origem: v }))}>
            <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Origem" /></SelectTrigger>
            <SelectContent><SelectItem value="todas">Origem</SelectItem>{ORIGENS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={filtros.etiqueta} onValueChange={(v) => setFiltros((f) => ({ ...f, etiqueta: v }))}>
            <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Etiqueta" /></SelectTrigger>
            <SelectContent><SelectItem value="todas">Etiqueta</SelectItem>{etiquetas.map((e) => <SelectItem key={e.id} value={e.nome}>{e.nome}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={filtros.orcamento || 'todos'} onValueChange={(v) => setFiltros((f) => ({ ...f, orcamento: v }))}>
            <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Orçamento" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Orçamento</SelectItem>
              <SelectItem value="qualquer">Com orçamento</SelectItem>
              <SelectItem value="ORÇANDO">Orçando</SelectItem>
              <SelectItem value="AGUARDANDO APROVAÇÃO">Aguardando aprovação</SelectItem>
              <SelectItem value="APROVADO">Aprovado</SelectItem>
              <SelectItem value="OC EMITIDA">OC emitida</SelectItem>
              <SelectItem value="AGUARDANDO RECEBIMENTO">Aguardando recebimento</SelectItem>
              <SelectItem value="NO FINANCEIRO">No financeiro</SelectItem>
              <SelectItem value="CONCLUÍDO">Concluído</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
}