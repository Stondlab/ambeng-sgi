import React from 'react';
import { corEtiqueta, parseEtiquetas } from '@/lib/quadro';
import { X } from 'lucide-react';

export default function EtiquetaSelector({ acao, etiquetas, onToggle }) {
  const atuais = parseEtiquetas(acao.etiquetas);
  return (
    <div>
      <div className="flex flex-wrap gap-1.5 mb-2">
        {atuais.length === 0 && <span className="text-xs text-slate-400">Nenhuma etiqueta atribuída.</span>}
        {atuais.map((nome) => {
          const e = etiquetas.find((x) => x.nome === nome);
          const c = corEtiqueta(e?.cor);
          return (
            <span key={nome} className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium ${c.chip}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${c.dot}`} />{nome}
              <button type="button" onClick={() => onToggle(nome)} className="ml-0.5 opacity-60 hover:opacity-100"><X className="w-2.5 h-2.5" /></button>
            </span>
          );
        })}
      </div>
      {etiquetas.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {etiquetas.filter((e) => !atuais.includes(e.nome)).map((e) => {
            const c = corEtiqueta(e.cor);
            return (
              <button key={e.id} type="button" onClick={() => onToggle(e.nome)} className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] border border-dashed ${c.chip} hover:opacity-80`}>
                <span className={`w-1.5 h-1.5 rounded-full ${c.dot}`} />+ {e.nome}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}