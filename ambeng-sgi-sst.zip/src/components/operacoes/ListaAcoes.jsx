import React from 'react';
import { format, parseISO } from 'date-fns';
import { STATUS_BADGE } from '@/lib/acoes';
import { corCategoria } from '@/lib/quadro';
import { resolverNomeUsuario } from '@/lib/usuarioNome';

// Lista de tarefas com hierarquia Obra → Job → Tarefa.
export default function ListaAcoes({ demands, onOpen, jobs = [], categorias = [], usuarios = [], orcamentos = [] }) {
  const jobNome = (id) => jobs.find((j) => j.id === id)?.nome || '—';
  const linhas = [...demands].sort((a, b) => (a.obra || '~').localeCompare(b.obra || '~') || (a.job_id || '').localeCompare(b.job_id || ''));

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
            <tr>
              <th className="text-left px-4 py-3">Obra</th>
              <th className="text-left px-4 py-3">Job</th>
              <th className="text-left px-4 py-3">Tarefa</th>
              <th className="text-left px-4 py-3">Responsável</th>
              <th className="text-left px-4 py-3">Status</th>
              <th className="text-left px-4 py-3">Prazo</th>
              <th className="text-left px-4 py-3">Categoria</th>
              <th className="text-left px-4 py-3">Orçamento</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {linhas.map((d) => (
              <tr key={d.id} className="hover:bg-slate-50 cursor-pointer" onClick={() => onOpen(d)}>
                <td className="px-4 py-3 text-slate-600 whitespace-nowrap">{d.obra || '—'}</td>
                <td className="px-4 py-3 text-slate-600 whitespace-nowrap">{d.job_id ? jobNome(d.job_id) : '—'}</td>
                <td className="px-4 py-3 font-medium text-[#0b2545]">{d.titulo}</td>
                <td className="px-4 py-3 text-slate-600">{d.responsavel ? resolverNomeUsuario(d.responsavel, usuarios) : '—'}</td>
                <td className="px-4 py-3"><span className={`text-xs px-2 py-1 rounded-full font-medium ${STATUS_BADGE[d.status] || 'bg-slate-100 text-slate-600'}`}>{d.status}</span></td>
                <td className="px-4 py-3 text-slate-500 whitespace-nowrap">{d.prazo ? format(parseISO(d.prazo), 'dd/MM/yyyy') : '—'}</td>
                <td className="px-4 py-3 text-slate-600">{d.categoria ? (() => { const cc = corCategoria(categorias, d.categoria); return <span className={`inline-flex items-center gap-1.5 text-xs px-2 py-1 rounded-full font-medium ${cc.chip}`}><span className={`w-2 h-2 rounded-full ${cc.dot}`} />{d.categoria}</span>; })() : '—'}</td>
                <td className="px-4 py-3">{(() => { const o = orcamentos.find((x) => x.demanda_id === d.id); if (!o) return <span className="text-xs text-slate-300">—</span>; const tom = { 'CONCLUÍDO': 'bg-emerald-100 text-emerald-700', 'PAGO': 'bg-emerald-100 text-emerald-700', 'NO FINANCEIRO': 'bg-cyan-100 text-cyan-700', 'RECEBIDO': 'bg-indigo-100 text-indigo-700', 'AGUARDANDO RECEBIMENTO': 'bg-indigo-100 text-indigo-700', 'OC EMITIDA': 'bg-violet-100 text-violet-700', 'APROVADO': 'bg-violet-100 text-violet-700', 'AGUARDANDO APROVAÇÃO': 'bg-sky-100 text-sky-700' }; return <span className={`text-xs px-2 py-1 rounded-full font-medium ${tom[o.status] || 'bg-amber-100 text-amber-700'}`}>🛒 {o.status}</span>; })()}</td>
              </tr>
            ))}
            {demands.length === 0 && <tr><td colSpan={8} className="px-4 py-10 text-center text-slate-400">Nenhuma tarefa.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}