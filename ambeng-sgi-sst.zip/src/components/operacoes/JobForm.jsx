import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import ResponsavelPicker from '@/components/operacoes/ResponsavelPicker';
import { Briefcase } from 'lucide-react';
import { nomeUsuario } from '@/lib/usuarioNome';

const PRIOS = ['Baixa', 'Média', 'Alta', 'Crítica'];
const STATUS_JOB = ['Planejamento', 'Em andamento', 'Pausado', 'Concluído', 'Cancelado'];

export default function JobForm({ open, onClose, onSaved, user, usuarios = [], obras = [], jobEdit, prefillObra = '' }) {
  const [form, setForm] = useState({ nome: '', codigo: '', responsavel: '', obra: '', empresa: '', descricao: '', status: 'Planejamento', prioridade: 'Média', data_inicio: '', prazo: '', observacoes: '' });

  useEffect(() => {
    if (open) {
      if (jobEdit) {
        setForm({
          nome: jobEdit.nome || '', codigo: jobEdit.codigo || '', responsavel: jobEdit.responsavel || '',
          obra: jobEdit.obra || '', empresa: jobEdit.empresa || '', descricao: jobEdit.descricao || '',
          status: jobEdit.status || 'Planejamento', prioridade: jobEdit.prioridade || 'Média',
          data_inicio: jobEdit.data_inicio || '', prazo: jobEdit.prazo || '', observacoes: jobEdit.observacoes || '',
        });
      } else {
        const obraInicial = prefillObra || user?.obra || '';
        const o = obras.find((x) => x.nome === obraInicial);
        const euNome = (() => { const n = nomeUsuario(user); return n === '—' ? '' : n; })();
        setForm({ nome: '', codigo: '', responsavel: euNome, obra: obraInicial, empresa: (o?.cliente || user?.empresa || ''), descricao: '', status: 'Planejamento', prioridade: 'Média', data_inicio: '', prazo: '', observacoes: '' });
      }
    }
  }, [open, jobEdit, user, prefillObra, obras]);

  const save = async (e) => {
    e.preventDefault();
    if (!form.nome.trim()) return;
    const payload = { ...form, nome: form.nome.trim(), ativa: true };
    try {
      if (jobEdit) await base44.entities.Jobs.update(jobEdit.id, payload);
      else await base44.entities.Jobs.create(payload);
    } catch { return; }
    onSaved?.();
    onClose?.();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[#0b2545]"><Briefcase className="w-5 h-5" />{jobEdit ? 'Editar Job' : 'Novo Job'}</DialogTitle>
          <DialogDescription>Agrupador de tarefas. O responsável geral do Job não substitui o responsável individual de cada tarefa.</DialogDescription>
        </DialogHeader>
        <form onSubmit={save} className="space-y-3">
          <div>
            <Label>Obra *</Label>
            <Select value={form.obra} onValueChange={(v) => {
              const o = obras.find((x) => x.nome === v);
              setForm((f) => ({ ...f, obra: v, empresa: (o?.cliente && !f.empresa) ? o.cliente : f.empresa }));
            }}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Selecionar obra" /></SelectTrigger>
              <SelectContent>{obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Nome do Job *</Label><Input className="mt-1" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} placeholder="Ex.: Orçar Sistema de Ponto Eletrônico" required autoFocus /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Código</Label><Input className="mt-1" value={form.codigo} onChange={(e) => setForm({ ...form, codigo: e.target.value })} placeholder="JOB-001" /></div>
            <div><Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{STATUS_JOB.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div><Label>Responsável geral</Label><div className="mt-1"><ResponsavelPicker usuarios={usuarios} value={form.responsavel} onChange={(v) => setForm({ ...form, responsavel: v })} /></div></div>
          <div><Label>Empresa</Label><Input className="mt-1" value={form.empresa} onChange={(e) => setForm({ ...form, empresa: e.target.value })} /></div>
          <div className="grid grid-cols-3 gap-3">
            <div><Label>Prioridade</Label>
              <Select value={form.prioridade} onValueChange={(v) => setForm({ ...form, prioridade: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{PRIOS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Início</Label><Input type="date" className="mt-1" value={form.data_inicio} onChange={(e) => setForm({ ...form, data_inicio: e.target.value })} /></div>
            <div><Label>Prazo</Label><Input type="date" className="mt-1" value={form.prazo} onChange={(e) => setForm({ ...form, prazo: e.target.value })} /></div>
          </div>
          <div><Label>Descrição</Label><Textarea className="mt-1" rows={2} value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} /></div>
          <div><Label>Observações</Label><Textarea className="mt-1" rows={2} value={form.observacoes} onChange={(e) => setForm({ ...form, observacoes: e.target.value })} /></div>
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button>
            <Button type="submit" className="bg-[#0b2545] hover:bg-[#16365f]">{jobEdit ? 'Salvar' : 'Criar Job'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}