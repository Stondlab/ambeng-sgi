import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { base44 } from '@/api/base44Client';
import { format, parseISO } from 'date-fns';
import { Plus, Pencil, Briefcase, ChevronDown, ChevronRight, Building2, FolderOpen, AlertTriangle, User } from 'lucide-react';
import { appendHistorico, STATUS_BADGE } from '@/lib/acoes';
import AcaoCard from '@/components/operacoes/AcaoCard';

// Quadro organizado por OBRA → JOB → TAREFAS.
// Cada coluna principal é uma Obra; dentro dela, grupos de Job com suas tarefas.
// "Sem Job associado" é um grupo interno da obra (não é coluna principal).
// "Sem Obra definida" é uma área separada para Jobs/tarefas órfãos.
export default function KanbanObras({ obras, jobs, demands, onOpen, onAddTask, onEditJob, onAddJob, onUpdated, user, etiquetas, densidade, cardsPor }) {
  const [fechados, setFechados] = useState({});
  const [shownMore, setShownMore] = useState({});
  const eu = user?.nome_exibicao || user?.full_name || '—';

  const toggleJob = (id) => setFechados((s) => ({ ...s, [id]: !s[id] }));

  const nomesPresentes = new Set();
  jobs.forEach((j) => j.obra && nomesPresentes.add(j.obra));
  demands.forEach((d) => d.obra && nomesPresentes.add(d.obra));

  const obrasConhecidas = obras.filter((o) => nomesPresentes.has(o.nome));
  const nomesDesconhecidos = [...nomesPresentes].filter((n) => !obras.find((o) => o.nome === n));
  const obraCols = [
    ...obrasConhecidas.map((o) => o.nome),
    ...nomesDesconhecidos,
  ];

  const jobsDaObra = (nome) => jobs.filter((j) => j.obra === nome && j.ativa !== false);
  const tarefasDoJob = (jobId) => demands.filter((d) => d.job_id === jobId);
  const semJobDaObra = (nome) => demands.filter((d) => d.obra === nome && !d.job_id);
  const jobsSemObra = jobs.filter((j) => !j.obra && j.ativa !== false);
  const tarefasSemObraSemJob = demands.filter((d) => !d.obra && !d.job_id);

  const onDragEnd = async (res) => {
    if (!res.destination) return;
    const dest = res.destination.droppableId;
    const d = demands.find((x) => x.id === res.draggableId);
    if (!d) return;
    let patch = {};
    if (dest.startsWith('job::')) {
      const novoJobId = dest.slice(5);
      const job = jobs.find((j) => j.id === novoJobId);
      const novoObra = job?.obra || d.obra || '';
      const hist = appendHistorico(d.historico, `Job → ${job?.nome || '—'}`, eu);
      patch = { job_id: novoJobId, obra: novoObra, historico: JSON.stringify(hist) };
    } else if (dest.startsWith('semjob::')) {
      const novoObra = decodeURIComponent(dest.slice(8));
      const hist = appendHistorico(d.historico, `Obra → ${novoObra} (sem job)`, eu);
      patch = { job_id: '', obra: novoObra, historico: JSON.stringify(hist) };
    } else if (dest === 'semobra') {
      const hist = appendHistorico(d.historico, `Sem obra definida`, eu);
      patch = { job_id: '', obra: '', historico: JSON.stringify(hist) };
    }
    await base44.entities.Demandas.update(d.id, patch);
    onUpdated?.();
  };

  const temOrfaos = jobsSemObra.length > 0 || tarefasSemObraSemJob.length > 0;

  const ctx = {
    onOpen, onAddTask, onEditJob, onUpdated, user, etiquetas, densidade, cardsPor,
    fechados, toggleJob, shownMore, setShownMore, tarefasDoJob,
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="flex gap-3 h-full">
        {obraCols.map((nome) => (
          <ObraColumn key={nome} nome={nome} jobsDaObra={jobsDaObra(nome)} semJob={semJobDaObra(nome)} onAddJob={onAddJob} ctx={ctx} />
        ))}
        {temOrfaos && (
          <div className="w-72 shrink-0 flex flex-col max-h-full rounded-xl border border-dashed border-amber-300 bg-amber-50/50">
            <div className="flex items-center gap-1.5 px-3 py-2.5 border-b border-amber-200">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <h3 className="font-semibold text-amber-700 text-sm">Sem Obra definida</h3>
            </div>
            <div className="p-2 space-y-2 min-h-[80px] flex-1 overflow-y-auto">
              {jobsSemObra.map((j) => <JobGroup key={j.id} job={j} ctx={ctx} />)}
              {tarefasSemObraSemJob.length > 0 && (
                <Droppable droppableId="semobra">
                  {(prov) => (
                    <div ref={prov.innerRef} {...prov.droppableProps} className="rounded-lg border border-dashed border-amber-300 p-1.5 space-y-2 min-h-[40px]">
                      <div className="text-[11px] font-medium text-amber-600 px-1">Tarefas sem obra/job</div>
                      {tarefasSemObraSemJob.map((t, i) => (
                        <Draggable draggableId={t.id} index={i} key={t.id}>
                          {(p) => <AcaoCard acao={t} onOpen={() => onOpen(t)} provided={p} etiquetas={etiquetas} onUpdated={onUpdated} user={user} densidade={densidade} />}
                        </Draggable>
                      ))}
                      {prov.placeholder}
                    </div>
                  )}
                </Droppable>
              )}
            </div>
          </div>
        )}
      </div>
    </DragDropContext>
  );
}

function JobGroup({ job, ctx }) {
  const { onOpen, onAddTask, onEditJob, onUpdated, user, etiquetas, densidade, cardsPor, fechados, toggleJob, shownMore, setShownMore, tarefasDoJob } = ctx;
  const tarefas = tarefasDoJob(job.id);
  const aberto = !fechados[job.id];
  const limite = cardsPor > 0 && !shownMore[job.id] ? cardsPor : tarefas.length;
  const visiveis = tarefas.slice(0, limite);
  const ocultos = tarefas.length - visiveis.length;
  return (
    <div className="rounded-lg border border-slate-200 bg-white shadow-sm">
      <div className="flex items-center gap-1 px-2 py-2 border-b border-slate-100">
        <button onClick={() => toggleJob(job.id)} className="min-w-[28px] min-h-[28px] flex items-center justify-center text-slate-400 hover:text-slate-700">
          {aberto ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </button>
        <Briefcase className="w-3.5 h-3.5 text-[#0b2545] shrink-0" />
        <button onClick={() => onEditJob(job)} className="text-left min-w-0 flex-1" title="Editar Job">
          <span className="font-semibold text-[#0b2545] text-sm truncate block">{job.nome}</span>
        </button>
        <span className="text-xs text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded-full">{tarefas.length}</span>
        <button onClick={() => onAddTask(job)} className="min-w-[28px] min-h-[28px] flex items-center justify-center rounded hover:bg-slate-100 text-slate-500" title="Adicionar tarefa"><Plus className="w-3.5 h-3.5" /></button>
        <button onClick={() => onEditJob(job)} className="min-w-[28px] min-h-[28px] flex items-center justify-center rounded hover:bg-slate-100 text-slate-500" title="Editar Job"><Pencil className="w-3 h-3" /></button>
      </div>
      <div className="px-2.5 py-1.5 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-slate-500 border-b border-slate-50">
        {job.status && <span>Status: <span className={`px-1.5 py-0.5 rounded-full font-medium ${STATUS_BADGE[job.status] || 'bg-slate-100 text-slate-600'}`}>{job.status}</span></span>}
        {job.responsavel && <span className="inline-flex items-center gap-1"><User className="w-3 h-3" />{job.responsavel}</span>}
        {job.prazo && <span>Prazo: {format(parseISO(job.prazo), 'dd/MM/yyyy')}</span>}
        {job.empresa && <span>Emp.: {job.empresa}</span>}
      </div>
      {aberto && (
        <Droppable droppableId={`job::${job.id}`}>
          {(prov) => (
            <div ref={prov.innerRef} {...prov.droppableProps} className="p-1.5 space-y-2 min-h-[40px]">
              {visiveis.map((t, i) => (
                <Draggable draggableId={t.id} index={i} key={t.id}>
                  {(p) => <AcaoCard acao={t} onOpen={() => onOpen(t)} provided={p} etiquetas={etiquetas} onUpdated={onUpdated} user={user} densidade={densidade} />}
                </Draggable>
              ))}
              {tarefas.length === 0 && <p className="text-xs text-slate-300 text-center py-3">Sem tarefas</p>}
              {ocultos > 0 && (
                <button onClick={() => setShownMore((s) => ({ ...s, [job.id]: true }))} className="w-full text-xs text-[#0b2545] hover:underline py-1">Mostrar mais (+{ocultos})</button>
              )}
              {prov.placeholder}
            </div>
          )}
        </Droppable>
      )}
    </div>
  );
}

function ObraColumn({ nome, jobsDaObra, semJob, onAddJob, ctx }) {
  const { onOpen, onUpdated, user, etiquetas, densidade } = ctx;
  return (
    <div className="bg-slate-50/60 border border-slate-200 rounded-xl border-t-4 border-t-[#0b2545] w-72 shrink-0 flex flex-col max-h-full">
      <div className="flex items-center justify-between px-3 py-2.5 border-b border-slate-100">
        <div className="flex items-center gap-1.5 min-w-0">
          <Building2 className="w-4 h-4 text-[#0b2545] shrink-0" />
          <h3 className="font-semibold text-[#0b2545] text-sm truncate">{nome}</h3>
          <span className="text-xs text-slate-400 bg-white px-1.5 py-0.5 rounded-full">{jobsDaObra.length}</span>
        </div>
        <button onClick={() => onAddJob(nome)} className="min-w-[28px] min-h-[28px] flex items-center justify-center rounded hover:bg-slate-200 text-slate-500" title="Novo Job nesta obra"><Plus className="w-4 h-4" /></button>
      </div>
      <div className="p-2 space-y-2 min-h-[80px] flex-1 overflow-y-auto">
        {jobsDaObra.map((j) => <JobGroup key={j.id} job={j} ctx={ctx} />)}
        {semJob.length > 0 && (
          <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50">
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 text-[11px] font-medium text-slate-500">
              <FolderOpen className="w-3.5 h-3.5" />Sem Job associado
            </div>
            <Droppable droppableId={`semjob::${encodeURIComponent(nome)}`}>
              {(prov) => (
                <div ref={prov.innerRef} {...prov.droppableProps} className="p-1.5 space-y-2 min-h-[40px]">
                  {semJob.map((t, i) => (
                    <Draggable draggableId={t.id} index={i} key={t.id}>
                      {(p) => <AcaoCard acao={t} onOpen={() => onOpen(t)} provided={p} etiquetas={etiquetas} onUpdated={onUpdated} user={user} densidade={densidade} />}
                    </Draggable>
                  ))}
                  {prov.placeholder}
                </div>
              )}
            </Droppable>
          </div>
        )}
        {jobsDaObra.length === 0 && semJob.length === 0 && <p className="text-xs text-slate-300 text-center py-6">Vazio</p>}
      </div>
    </div>
  );
}