import React, { useMemo, useState } from 'react';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Check, Trash2, ChevronUp, ChevronDown, ChevronDown as Chevron, User, Search, UserMinus } from 'lucide-react';
import { nomeUsuario } from '@/lib/usuarioNome';

const AV = ['bg-amber-400', 'bg-sky-500', 'bg-emerald-500', 'bg-violet-500', 'bg-pink-500', 'bg-orange-500', 'bg-slate-500'];
const initials = (n) => (n || '').split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();
const cor = (n) => AV[((n || '').split('').reduce((a, c) => a + c.charCodeAt(0), 0)) % AV.length];
const nomeU = (u) => nomeUsuario(u);
const perfilU = (u) => u?.role || u?.perfil || 'Usuário';

export default function ChecklistItem({ item, index, total, usuarios = [], onChange, onDelete, onMove }) {
  const [texto, setTexto] = useState(item.text || '');
  const [q, setQ] = useState('');
  const commitText = () => { if (texto !== (item.text || '')) onChange({ ...item, text: texto }); };

  const selecionado = useMemo(() => (usuarios || []).find((u) => nomeU(u) === item.responsavel) || null, [usuarios, item.responsavel]);
  const filtrados = useMemo(() => {
    const query = q.trim().toLowerCase();
    const list = [...(usuarios || [])].sort((a, b) => nomeU(a).localeCompare(nomeU(b)));
    return query ? list.filter((u) => nomeU(u).toLowerCase().includes(query)) : list;
  }, [usuarios, q]);

  return (
    <div className="py-1.5 border-b border-slate-100 last:border-0 group">
      <div className="flex items-center gap-2">
        <button onClick={() => onChange({ ...item, done: !item.done })} className="min-w-[28px] min-h-[28px] flex items-center justify-center shrink-0">
          {item.done ? <Check className="w-4 h-4 text-emerald-500" /> : <span className="w-4 h-4 border-2 border-slate-300 rounded" />}
        </button>
        <input value={texto} onChange={(e) => setTexto(e.target.value)} onBlur={commitText} className={`flex-1 text-sm bg-transparent border-0 focus:outline-none focus:bg-slate-50 rounded px-1 py-1 ${item.done ? 'line-through text-slate-400' : 'text-slate-700'}`} />
        <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
          <button onClick={() => onMove('up')} disabled={index === 0} className="p-1 text-slate-300 hover:text-slate-600 disabled:opacity-20"><ChevronUp className="w-3.5 h-3.5" /></button>
          <button onClick={() => onMove('down')} disabled={index === total - 1} className="p-1 text-slate-300 hover:text-slate-600 disabled:opacity-20"><ChevronDown className="w-3.5 h-3.5" /></button>
          <button onClick={onDelete} className="p-1 text-slate-300 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
        </div>
      </div>
      <div className="flex items-center gap-3 pl-8 mt-1">
        {/* Responsável (individual por tarefa) */}
        <Popover onOpenChange={(o) => !o && setQ('')}>
          <PopoverTrigger asChild>
            <button className="h-8 w-48 flex items-center gap-1.5 px-2 rounded-md border border-slate-200 bg-white text-[11px] hover:bg-slate-50">
              {selecionado ? (
                <>
                  <span className={`w-5 h-5 rounded-full ${cor(item.responsavel)} text-white text-[9px] font-semibold flex items-center justify-center shrink-0`}>{initials(item.responsavel)}</span>
                  <span className="flex-1 text-left text-[#0b2545] truncate">{item.responsavel}</span>
                </>
              ) : (
                <>
                  <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="flex-1 text-left text-slate-400">Selecionar responsável</span>
                </>
              )}
              <Chevron className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-64 p-2" align="start">
            <div className="relative mb-2">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Pesquisar usuário..." className="w-full h-8 pl-7 pr-2 rounded-md border border-slate-200 text-xs" autoFocus />
            </div>
            <div className="max-h-52 overflow-y-auto space-y-0.5">
              {filtrados.map((u) => {
                const n = nomeU(u);
                const sel = n === item.responsavel;
                return (
                  <button key={u.id} onClick={() => { onChange({ ...item, responsavel: n }); setQ(''); }} className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-slate-100 text-sm">
                    <span className={`w-6 h-6 rounded-full ${cor(n)} text-white text-[10px] font-semibold flex items-center justify-center shrink-0`}>{initials(n)}</span>
                    <span className="flex-1 text-left text-slate-700 truncate">{n}</span>
                    <span className="text-[10px] text-slate-400">{perfilU(u)}</span>
                    {sel && <Check className="w-4 h-4 text-emerald-600 shrink-0" />}
                  </button>
                );
              })}
              {filtrados.length === 0 && <p className="text-xs text-slate-400 text-center py-3">Nenhum usuário.</p>}
            </div>
            {item.responsavel && (
              <button onClick={() => { onChange({ ...item, responsavel: undefined }); setQ(''); }} className="w-full flex items-center gap-2 px-2 py-1.5 mt-1 border-t border-slate-100 rounded-md hover:bg-red-50 text-sm text-red-600">
                <UserMinus className="w-3.5 h-3.5" />Remover responsável
              </button>
            )}
          </PopoverContent>
        </Popover>

        {/* Data da tarefa */}
        <div className="flex items-center gap-1">
          <svg className="w-3 h-3 text-slate-300" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2" /><line x1="16" y1="2" x2="16" y2="6" /><line x1="8" y1="2" x2="8" y2="6" /><line x1="3" y1="10" x2="21" y2="10" /></svg>
          <input type="date" value={item.data || ''} onChange={(e) => onChange({ ...item, data: e.target.value })} className="h-8 text-[11px] border border-slate-200 rounded-md px-1.5 text-slate-600" />
        </div>
        <Select value={item.done ? 'Concluído' : item.status || 'A Fazer'} onValueChange={(status) => onChange({ ...item, status, done: status === 'Concluído' })}><SelectTrigger className="h-8 w-32 text-[11px]"><SelectValue /></SelectTrigger><SelectContent>{['A Fazer', 'Em Andamento', 'Aguardando', 'Concluído'].map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent></Select>
      </div>
    </div>
  );
}