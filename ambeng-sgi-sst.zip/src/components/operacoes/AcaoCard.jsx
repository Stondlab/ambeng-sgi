import React from 'react';
import { format, parseISO } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { Check, CalendarClock, Lock } from 'lucide-react';
import { parseList, checklistProgress, isAtrasada, venceHoje, isBloqueada, appendHistorico } from '@/lib/acoes';
import { parseEtiquetas, corEtiqueta, rodarAutomacoes } from '@/lib/quadro';
import TagChips from '@/components/operacoes/TagChips';
import QuickAdd from '@/components/operacoes/QuickAdd';
import { nomeUsuario, resolverNomeUsuario } from '@/lib/usuarioNome';

const AVATAR_PALETTE = ['bg-amber-400', 'bg-sky-500', 'bg-emerald-500', 'bg-violet-500', 'bg-pink-500', 'bg-orange-500', 'bg-slate-500'];
const initials = (n) => (n || '').split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();
const avatarColor = (n) => AVATAR_PALETTE[(n || '').split('').reduce((a, c) => a + c.charCodeAt(0), 0) % AVATAR_PALETTE.length];

export default function AcaoCard({ acao, onOpen, provided, onTagClick, etiquetas, categorias, onUpdated, user, densidade = 'normal', jobNome, usuarios = [], orcamento, dragging = false }) {
  const checklist = parseList(acao.checklist);
  const responsavel = resolverNomeUsuario(acao.responsavel, usuarios);
  const membros = parseList(acao.membros).filter((m) => m !== acao.responsavel).map((m) => resolverNomeUsuario(m, usuarios));
  const atrasada = isAtrasada(acao);
  const bloqueada = isBloqueada(acao);
  const hoje = venceHoje(acao);
  const concluido = acao.status === 'Concluído';

  const etq = parseEtiquetas(acao.etiquetas);
  const firstEtq = etq.length ? (etiquetas || []).find((e) => e.nome === etq[0]) : null;
  const barColor = firstEtq ? corEtiqueta(firstEtq.cor).dot : (acao.prioridade === 'Crítica' ? 'bg-red-500' : acao.prioridade === 'Alta' ? 'bg-orange-500' : 'bg-slate-300');

  const toggleDone = async (e) => {
    e.stopPropagation();
    const novoStatus = concluido ? 'A Fazer' : 'Concluído';
    const hist = appendHistorico(acao.historico, `Status → ${novoStatus}`, user?.nome_exibicao ? nomeUsuario(user) : (user?.full_name || '—'));
    const ch = { status: novoStatus, historico: JSON.stringify(hist) };
    if (novoStatus === 'Concluído') ch.data_conclusao = new Date().toISOString();
    await base44.entities.Demandas.update(acao.id, ch);
    if (novoStatus === 'Concluído') rodarAutomacoes({ tipo: 'concluir' }, { ...acao, status: 'Concluído' });
    onUpdated?.();
  };

  return (
    <div ref={provided?.innerRef} {...(provided?.draggableProps || {})} {...(provided?.dragHandleProps || {})} onClick={onOpen} className={`border rounded-lg bg-white hover:shadow-md cursor-pointer transition-shadow overflow-hidden group ${hoje ? 'ring-2 ring-amber-300 border-amber-200' : 'border-slate-200'} ${dragging ? 'shadow-xl ring-2 ring-amber-300 rotate-1' : ''}`}>
      <div className={`h-1.5 w-full ${barColor}`} />
      <div className="p-2.5">
        {/* Linha 1: check + título em negrito + badge bloqueado */}
        <div className="flex items-start gap-2">
          <button onClick={toggleDone} onMouseDown={(e) => e.stopPropagation()} className={`shrink-0 w-5 h-5 rounded-full border-2 flex items-center justify-center mt-0.5 ${concluido ? 'bg-emerald-500 border-emerald-500' : 'border-slate-300 hover:border-emerald-500'}`} title={concluido ? 'Reabrir' : 'Concluir'}>
            {concluido && <Check className="w-3 h-3 text-white" />}
          </button>
          <p className="text-sm font-bold text-[#0b2545] flex-1 leading-snug">{acao.titulo}</p>
          {bloqueada && (
            <span className="shrink-0 inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-red-600 text-white animate-blink" title="Aguardando há mais de 7 dias">
              <Lock className="w-2.5 h-2.5" />BLOQUEADO
            </span>
          )}
        </div>

        {/* Linha 2: data abaixo (vermelho só se vencida) */}
        {acao.prazo && (
          <div className="mt-1.5 flex items-center gap-1.5">
            <CalendarClock className={`w-3 h-3 ${atrasada ? 'text-red-500' : 'text-slate-400'}`} />
            <span className={`text-xs font-medium ${atrasada ? 'text-red-600' : 'text-slate-500'}`}>{format(parseISO(acao.prazo), 'dd/MM')}</span>
            {hoje && !atrasada && <span className="text-[9px] font-bold px-1 py-0.5 rounded-full bg-amber-100 text-amber-700">HOJE</span>}
          </div>
        )}

        {/* Tags — máximo 2 */}
        <div className="mt-1.5"><TagChips acao={acao} onTagClick={onTagClick} etiquetas={etiquetas} categorias={categorias} max={2} /></div>

        {checklist.length > 0 && (
          <div className="mt-1.5">
            <div className="w-full h-1 bg-slate-100 rounded-full"><div className="h-1 bg-emerald-500 rounded-full" style={{ width: `${checklistProgress(acao.checklist)}%` }} /></div>
          </div>
        )}

        {/* Linha inferior: avatar grande do responsável + membros */}
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-1.5 min-w-0">
            {responsavel && responsavel !== '—' && (
              <div className="flex items-center gap-1.5 min-w-0" title={`Responsável: ${responsavel}`}>
                <span className={`w-7 h-7 rounded-full ${avatarColor(responsavel)} text-[10px] text-white font-semibold flex items-center justify-center shrink-0`}>{initials(responsavel)}</span>
                <span className="text-[11px] font-medium text-slate-600 truncate max-w-[100px]">{responsavel.split(' ')[0]}</span>
              </div>
            )}
            {membros.length > 0 && (
              <div className="flex items-center -space-x-2">
                {membros.slice(0, 2).map((m, i) => <span key={i} className={`w-6 h-6 rounded-full ${avatarColor(m)} text-[9px] text-white font-semibold flex items-center justify-center ring-2 ring-white`} title={m}>{initials(m)}</span>)}
                {membros.length > 2 && <span className="w-6 h-6 rounded-full bg-slate-200 text-slate-500 text-[9px] font-semibold flex items-center justify-center ring-2 ring-white">+{membros.length - 2}</span>}
              </div>
            )}
          </div>
          <div className="opacity-0 group-hover:opacity-100 transition-opacity shrink-0" onClick={(e) => e.stopPropagation()}>
            <QuickAdd acao={acao} etiquetas={etiquetas} onUpdated={onUpdated} user={user} />
          </div>
        </div>
      </div>
    </div>
  );
}