import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { format } from 'date-fns';
import { Bell, CheckCheck, Trash2, X } from 'lucide-react';
import { nomeUsuario } from '@/lib/usuarioNome';

export default function NotificacoesBell({ user }) {
  const meusNomes = [nomeUsuario(user), user?.full_name, user?.email].filter(Boolean);
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [filtro, setFiltro] = useState('todas');

  const load = async () => {
    if (!meusNomes.length) return;
    let n = [];
    try { n = await base44.entities.Notificacoes.list('-data', 200); } catch {}
    setItems(n.filter((x) => meusNomes.includes(x.usuario)));
  };
  useEffect(() => { load(); const t = setInterval(load, 20000); return () => clearInterval(t); }, [meusNomes.join('|'), open]);

  const naoLidas = items.filter((n) => !n.lida).length;

  const marcarTodas = async () => {
    const nl = items.filter((n) => !n.lida);
    if (!nl.length) return;
    await base44.entities.Notificacoes.bulkUpdate(nl.map((n) => ({ id: n.id, lida: true })));
    load();
  };
  const limparTudo = async () => {
    if (!items.length) return;
    if (!confirm('Excluir todas as notificações?')) return;
    await base44.entities.Notificacoes.deleteMany({ usuario: { $in: meusNomes } });
    load();
  };
  const marcarLida = async (id, lida) => {
    await base44.entities.Notificacoes.update(id, { lida });
    load();
  };
  const deletar = async (id) => {
    await base44.entities.Notificacoes.delete(id);
    load();
  };

  const filtered = useMemo(() => {
    if (filtro === 'nao-lidas') return items.filter((n) => !n.lida);
    if (filtro === 'lidas') return items.filter((n) => n.lida);
    return items;
  }, [items, filtro]);

  const FILTROS = [
    { v: 'todas', l: 'Todas' },
    { v: 'nao-lidas', l: 'Não lidas' },
    { v: 'lidas', l: 'Lidas' },
  ];

  return (
    <div className="relative">
      <button onClick={() => setOpen(true)} className="relative w-10 h-10 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-500 transition-colors" title="Notificações">
        <Bell className="w-5 h-5" />
        {naoLidas > 0 && <span className="absolute top-1.5 right-1.5 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-white">{naoLidas > 9 ? '9+' : naoLidas}</span>}
      </button>
      <Dialog open={open} onOpenChange={(o) => !o && setOpen(false)}>
        <DialogContent className="max-w-sm p-0 max-h-[80vh] overflow-hidden flex flex-col">
          <DialogHeader className="px-4 py-3 border-b border-slate-100 flex-row items-center justify-between space-y-0 shrink-0">
            <DialogTitle className="flex items-center gap-2 text-base">
              <Bell className="w-4 h-4 text-amber-500" />Notificações
              {naoLidas > 0 && <span className="text-xs bg-red-500 text-white px-2 py-0.5 rounded-full">{naoLidas}</span>}
            </DialogTitle>
          </DialogHeader>

          <div className="flex gap-1 px-4 py-2 border-b border-slate-100 shrink-0">
            {FILTROS.map((f) => (
              <button
                key={f.v}
                onClick={() => setFiltro(f.v)}
                className={`text-xs px-3 py-1.5 rounded-lg font-medium transition ${filtro === f.v ? 'bg-[#0b2545] text-white' : 'text-slate-500 hover:bg-slate-100'}`}
              >
                {f.l}
              </button>
            ))}
            <div className="ml-auto flex items-center gap-2">
              {naoLidas > 0 && (
                <button onClick={marcarTodas} className="text-xs text-[#0b2545] hover:underline flex items-center gap-1" title="Marcar tudo como lido">
                  <CheckCheck className="w-3.5 h-3.5" />Marcar tudo
                </button>
              )}
              {items.length > 0 && (
                <button onClick={limparTudo} className="text-xs text-red-500 hover:underline flex items-center gap-1" title="Limpar tudo">
                  <Trash2 className="w-3.5 h-3.5" />Limpar tudo
                </button>
              )}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
            {filtered.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-10">Sem notificações.</p>
            ) : (
              filtered.map((n) => (
                <div key={n.id} className={`px-4 py-3 group ${n.lida ? 'bg-slate-50 opacity-50' : 'bg-amber-50/60'}`}>
                  <div className="flex items-start gap-2">
                    <button
                      onClick={() => marcarLida(n.id, !n.lida)}
                      className={`mt-0.5 w-5 h-5 rounded border-2 shrink-0 flex items-center justify-center transition ${n.lida ? 'bg-emerald-500 border-emerald-500' : 'border-slate-300 hover:border-[#0b2545]'}`}
                      title={n.lida ? 'Marcar como não lida' : 'Marcar como lida'}
                    >
                      {n.lida && <CheckCheck className="w-3 h-3 text-white" />}
                    </button>
                    <div className="min-w-0 flex-1">
                      <p className={`text-sm ${n.lida ? 'font-normal text-slate-400 line-through' : 'font-medium text-[#0b2545]'}`}>{n.titulo}</p>
                      {n.descricao && <p className={`text-xs mt-0.5 ${n.lida ? 'text-slate-400 line-through' : 'text-slate-500'}`}>{n.descricao}</p>}
                      <p className="text-[10px] text-slate-400 mt-1">{n.data ? format(new Date(n.data), 'dd/MM/yyyy HH:mm') : ''}</p>
                    </div>
                    <button onClick={() => deletar(n.id)} className="p-1 text-slate-300 hover:text-red-500 transition shrink-0" title="Excluir">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}