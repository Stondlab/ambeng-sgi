import React from 'react';
import { format, parseISO } from 'date-fns';
import { Clock, CheckCircle2, Flame, ArrowRight, AlertOctagon, Hourglass } from 'lucide-react';
import { PRIO_COR, PRIO_RANK, isAtrasada, venceHoje, parseList } from '@/lib/acoes';
import { nomeUsuario } from '@/lib/usuarioNome';

export default function MeuDia({ demands, user }) {
  // Matching canônico (mesmo do ChecklistDoDia e da Central de Operações):
  // considera a tarefa "minha" se o responsável OU algum membro for o usuário,
  // comparando contra nome_exibicao e full_name. O responsavel é armazenado como
  // nome_exibicao, então comparar apenas com full_name deixava a lista vazia.
  const meusNomes = [nomeUsuario(user), user?.nome_exibicao, user?.full_name].filter(Boolean);
  const souMinha = (d) =>
    meusNomes.includes(d.responsavel) || parseList(d.membros).some((m) => meusNomes.includes(m));
  const minhas = demands.filter(souMinha);
  const abertas = minhas.filter((d) => d.status !== 'Concluído' && d.status !== 'Cancelado');
  const hoje = abertas.filter(venceHoje);
  const atrasadas = abertas.filter(isAtrasada);
  const pendencias = abertas.filter((d) => isAtrasada(d) || venceHoje(d));
  const criticas = abertas.filter((d) => d.prioridade === 'Crítica');
  const concluidas = minhas.filter((d) => d.status === 'Concluído');
  const minutos = abertas.reduce((s, d) => s + (Number(d.tempo_estimado_min) > 0 ? Number(d.tempo_estimado_min) : 30), 0);
  const tempo = `${Math.floor(minutos / 60)}h${minutos % 60 ? ' ' + (minutos % 60) + 'm' : ''}`;
  const proxima = abertas.slice().sort((a, b) => PRIO_RANK(a.prioridade) - PRIO_RANK(b.prioridade))[0];

  const cards = [
    { label: 'Para hoje', value: hoje.length, icon: Clock, tone: 'amber' },
    { label: 'Pendências', value: pendencias.length, icon: AlertOctagon, tone: 'red' },
    { label: 'Críticas', value: criticas.length, icon: Flame, tone: 'red' },
    { label: 'Tempo estimado', value: tempo, icon: Hourglass, tone: 'navy' },
    { label: 'Concluídas', value: concluidas.length, icon: CheckCircle2, tone: 'green' },
  ];
  const tones = { navy: 'text-[#0b2545] bg-[#0b2545]/10', red: 'text-red-600 bg-red-50', amber: 'text-amber-600 bg-amber-100', green: 'text-emerald-600 bg-emerald-50' };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-4 mb-4">
      <div className="flex items-center gap-2 mb-3">
        <Flame className="w-5 h-5 text-amber-500" />
        <h2 className="text-base font-semibold text-[#0b2545]">Meu Dia</h2>
        <span className="text-xs text-slate-400">— ações de {nomeUsuario(user)}</span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {cards.map((c) => { const Icon = c.icon; return (
          <div key={c.label} className="border border-slate-100 rounded-lg p-3">
            <div className={`w-8 h-8 rounded-md flex items-center justify-center mb-2 ${tones[c.tone]}`}><Icon className="w-4 h-4" /></div>
            <p className="text-xl font-bold text-[#0b2545] leading-none">{c.value}</p>
            <p className="text-[11px] text-slate-500 mt-1">{c.label}</p>
          </div>
        ); })}
      </div>
      {proxima && (
        <div className="mt-3 flex items-center gap-2 text-sm bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
          <ArrowRight className="w-4 h-4 text-amber-500" />
          <span className="text-xs text-slate-500">Próxima prioridade:</span>
          <span className="font-medium text-[#0b2545] flex-1 truncate">{proxima.titulo}</span>
          <span className={`text-xs font-semibold ${PRIO_COR[proxima.prioridade]}`}>{proxima.prioridade}</span>
          {proxima.prazo && <span className="text-xs text-slate-400">{format(parseISO(proxima.prazo), 'dd/MM')}</span>}
        </div>
      )}
    </section>
  );
}