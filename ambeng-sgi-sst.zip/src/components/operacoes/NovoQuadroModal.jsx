import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { criarQuadro } from '@/lib/quadro';
import { useToast } from '@/components/ui/use-toast';

// Modal simples para criar um novo quadro. Após criar, abre o quadro automaticamente.
export default function NovoQuadroModal({ open, onClose, onCriado }) {
  const [nome, setNome] = useState('');
  const [descricao, setDescricao] = useState('');
  const [salvando, setSalvando] = useState(false);
  const { toast } = useToast();

  useEffect(() => { if (open) { setNome(''); setDescricao(''); setSalvando(false); } }, [open]);

  const criar = async () => {
    if (!nome.trim()) return;
    setSalvando(true);
    try {
      const q = await criarQuadro(nome.trim(), descricao.trim());
      toast({ title: 'Quadro criado', description: q.nome });
      onCriado?.(q);
      onClose?.();
    } catch (e) {
      toast({ variant: 'destructive', title: 'Erro ao criar quadro', description: String(e?.message || e) });
    } finally {
      setSalvando(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>Novo Quadro</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Nome do quadro</Label><Input className="mt-1" value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Ex.: Compras" autoFocus onKeyDown={(e) => e.key === 'Enter' && criar()} /></div>
          <div><Label>Descrição (opcional)</Label><Textarea className="mt-1" rows={2} value={descricao} onChange={(e) => setDescricao(e.target.value)} placeholder="Para que serve este quadro?" /></div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose} disabled={salvando}>Cancelar</Button>
          <Button onClick={criar} disabled={salvando || !nome.trim()} className="bg-[#0b2545] hover:bg-[#16365f]">{salvando ? 'Criando...' : 'Criar Quadro'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}