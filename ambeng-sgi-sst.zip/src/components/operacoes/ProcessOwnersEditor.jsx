import React from 'react';
import ResponsavelPicker from '@/components/operacoes/ResponsavelPicker';
import { Label } from '@/components/ui/label';

export const PROCESS_STAGES = [['Solicitacao', 'Solicitação'], ['Cotacao', 'Cotação'], ['Aprovacao', 'Aprovação'], ['OrdemCompra', 'Ordem de Compra'], ['Recebimento', 'Recebimento'], ['Financeiro', 'Financeiro']];
export default function ProcessOwnersEditor({ value, onChange, usuarios }) {
  return <div className="grid gap-2 sm:grid-cols-2">{PROCESS_STAGES.map(([key, label]) => <div key={key} className="rounded-lg border border-border p-2"><Label className="text-xs">{label}</Label><div className="mt-1"><ResponsavelPicker usuarios={usuarios} value={value[key] || ''} onChange={(responsavel) => onChange({ ...value, [key]: responsavel })} /></div></div>)}</div>;
}