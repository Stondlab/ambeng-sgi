import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { parseList, appendHistorico } from '@/lib/acoes';
import { parseEtiquetas, addEtiquetaArr } from '@/lib/quadro';
import { Plus, Tag, CalendarClock, ListChecks, User } from 'lucide-react';
import { nomeUsuario } from '@/lib/usuarioNome';

export default function QuickAdd({ acao, etiquetas, onUpdated, user, trigger }) {
  const [modo, setModo] = useState(null);
  const [val, setVal] = useState('');
  const eu = nomeUsuario(user);

  const upd = async (changes, evento) => {
    const hist = appendHistorico(acao.historico, evento, eu);
    await base44.entities.Demandas.update(acao.id, { ...changes, historico: JSON.stringify(hist) });
    onUpdated?.();
  };

  const aplicar = async () => {
    if (modo === 'prazo' && val) { await upd({ prazo: val }, 'Prazo definido'); }
    else if (modo === 'responsavel' && val.trim()) { await upd({ responsavel: val.trim() }, `Responsável → ${val.trim()}`); }
    else if (modo === 'checklist' && val.trim()) { const cl = [...parseList(acao.checklist), { text: val.trim(), done: false }]; await upd({ checklist: JSON.stringify(cl) }, 'Item adicionado'); }
    else if (modo === 'etiqueta' && val) { const arr = addEtiquetaArr(parseEtiquetas(acao.etiquetas), val); await upd({ etiquetas: JSON.stringify(arr) }, 'Etiqueta adicionada'); }
    setModo(null); setVal('');
  };

  const opts = [
    { k: 'etiqueta', icon: Tag, label: 'Etiqueta' },
    { k: 'prazo', icon: CalendarClock, label: 'Prazo' },
    { k: 'checklist', icon: ListChecks, label: 'Checklist' },
    { k: 'responsavel', icon: User, label: 'Responsável' },
  ];

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button onClick={(e) => e.stopPropagation()} className={`min-h-9 min-w-9 rounded-md flex items-center justify-center ${trigger ? 'border border-border bg-card text-muted-foreground hover:bg-muted' : 'bg-[#0b2545] text-white hover:bg-[#16365f]'}`} title="Mais ações">{trigger || <Plus className="w-3.5 h-3.5" />}</button>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-2" align="end" onClick={(e) => e.stopPropagation()}>
        {!modo ? (
          <div className="space-y-0.5">
            {opts.map((o) => { const Icon = o.icon; return (
              <button key={o.k} onClick={() => { setModo(o.k); setVal(''); }} className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-xs text-slate-700 hover:bg-slate-100"><Icon className="w-3.5 h-3.5 text-amber-500" />{o.label}</button>
            ); })}
          </div>
        ) : (
          <div className="space-y-2">
            {modo === 'etiqueta' ? (
              <Select value={val} onValueChange={setVal}><SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Etiqueta" /></SelectTrigger><SelectContent>{etiquetas.filter((e) => !parseEtiquetas(acao.etiquetas).includes(e.nome)).map((e) => <SelectItem key={e.id} value={e.nome}>{e.nome}</SelectItem>)}</SelectContent></Select>
            ) : modo === 'prazo' ? (
              <Input type="date" className="h-8 text-xs" value={val} onChange={(e) => setVal(e.target.value)} />
            ) : (
              <Input className="h-8 text-xs" placeholder={modo === 'checklist' ? 'Novo item...' : 'Responsável...'} value={val} onChange={(e) => setVal(e.target.value)} />
            )}
            <div className="flex gap-1.5 justify-end">
              <button onClick={() => { setModo(null); setVal(''); }} className="text-xs px-2 py-1 text-slate-500 hover:bg-slate-100 rounded">Voltar</button>
              <button onClick={aplicar} className="text-xs px-2 py-1 bg-[#0b2545] text-white rounded">Aplicar</button>
            </div>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}