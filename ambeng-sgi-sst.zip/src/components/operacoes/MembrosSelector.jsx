import React, { useState } from 'react';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import { Check, Plus, Search } from 'lucide-react';
import { nomeUsuario } from '@/lib/usuarioNome';

const PALETTE = ['bg-amber-400', 'bg-sky-500', 'bg-emerald-500', 'bg-violet-500', 'bg-pink-500', 'bg-orange-500', 'bg-slate-500'];
const initials = (n) => (n || '').split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();
const colorFor = (n) => PALETTE[(n || '').split('').reduce((a, c) => a + c.charCodeAt(0), 0) % PALETTE.length];

export default function MembrosSelector({ membros, usuarios, onChange }) {
  const [q, setQ] = useState('');
  const nomeU = (u) => nomeUsuario(u);
  const disp = usuarios.filter((u) => nomeU(u).toLowerCase().includes(q.toLowerCase()));
  const toggle = (nome) => { const arr = membros.includes(nome) ? membros.filter((x) => x !== nome) : [...membros, nome]; onChange(arr); };

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {membros.map((m) => (
        <button key={m} onClick={() => toggle(m)} title={`Remover ${m}`} className={`w-8 h-8 rounded-full ${colorFor(m)} text-white text-xs font-semibold flex items-center justify-center ring-2 ring-white hover:opacity-80`}>{initials(m)}</button>
      ))}
      <Popover>
        <PopoverTrigger asChild>
          <button className="w-8 h-8 rounded-full border-2 border-dashed border-slate-300 text-slate-400 hover:border-[#0b2545] hover:text-[#0b2545] flex items-center justify-center" title="Adicionar membros"><Plus className="w-4 h-4" /></button>
        </PopoverTrigger>
        <PopoverContent className="w-64 p-2" align="start">
          <div className="relative mb-2">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-2.5" />
            <Input className="h-8 pl-7 text-xs" placeholder="Buscar pessoa..." value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <div className="max-h-56 overflow-y-auto space-y-0.5">
            {disp.map((u) => { const n = nomeU(u); const on = membros.includes(n); return (
              <button key={u.id} onClick={() => toggle(n)} className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-slate-100 text-sm">
                <span className={`w-6 h-6 rounded-full ${colorFor(n)} text-white text-[10px] font-semibold flex items-center justify-center`}>{initials(n)}</span>
                <span className="flex-1 text-left text-slate-700 truncate">{n}</span>
                {on && <Check className="w-3.5 h-3.5 text-emerald-500" />}
              </button>
            );})}
            {disp.length === 0 && <p className="text-xs text-slate-400 text-center py-3">Nenhuma pessoa.</p>}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}