import React from 'react';
import { ZoomIn, ZoomOut, ChevronLeft, ChevronRight, Rows3 } from 'lucide-react';

// Toolbar de visualização do Kanban: densidade, zoom, cards por coluna e setas laterais.
export default function ControlesKanban({ densidade, setDensidade, zoom, setZoom, cardsPor, setCardsPor, onArrow }) {
  const ZOOMS = [80, 90, 100, 110];
  const LIMITES = [
    { v: 5, label: '5' }, { v: 10, label: '10' }, { v: 15, label: '15' }, { v: 25, label: '25' }, { v: 0, label: 'Todos' },
  ];
  return (
    <div className="flex items-center gap-2 flex-wrap">
      <div className="inline-flex items-center rounded-lg border border-slate-200 bg-white px-1 h-[34px]">
        <button onClick={() => setZoom(Math.max(80, zoom - 10))} className="px-1.5 text-slate-500 hover:text-[#0b2545]" title="Diminuir zoom"><ZoomOut className="w-4 h-4" /></button>
        <select value={zoom} onChange={(e) => setZoom(Number(e.target.value))} className="h-7 text-xs bg-transparent border-0 focus:outline-none">
          {ZOOMS.map((z) => <option key={z} value={z}>{z}%</option>)}
        </select>
        <button onClick={() => setZoom(Math.min(110, zoom + 10))} className="px-1.5 text-slate-500 hover:text-[#0b2545]" title="Aumentar zoom"><ZoomIn className="w-4 h-4" /></button>
      </div>

      <div className="inline-flex items-center rounded-lg border border-slate-200 bg-white px-2 h-[34px] gap-1.5">
        <Rows3 className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-xs text-slate-500">Cards/coluna:</span>
        <select value={cardsPor} onChange={(e) => setCardsPor(Number(e.target.value))} className="h-7 text-xs bg-transparent border-0 focus:outline-none">
          {LIMITES.map((l) => <option key={l.v} value={l.v}>{l.label}</option>)}
        </select>
      </div>

      <div className="inline-flex rounded-lg border border-slate-200 bg-white p-0.5">
        <button onClick={() => onArrow(-1)} className="min-w-[32px] min-h-[32px] flex items-center justify-center rounded-md text-slate-600 hover:bg-slate-50" title="Anterior"><ChevronLeft className="w-4 h-4" /></button>
        <button onClick={() => onArrow(1)} className="min-w-[32px] min-h-[32px] flex items-center justify-center rounded-md text-slate-600 hover:bg-slate-50" title="Próximo"><ChevronRight className="w-4 h-4" /></button>
      </div>
    </div>
  );
}