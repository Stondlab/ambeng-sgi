import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Plus, Pencil, Trash2, GripVertical, Archive, Columns3, RotateCcw, Check } from 'lucide-react';
import { CORES_ETIQUETA, pertenceAoQuadro } from '@/lib/quadro';
import { useToast } from '@/components/ui/use-toast';

const CORES = CORES_ETIQUETA;

// Colunas pertencem ao quadro selecionado (quadroId). Excluir coluna NUNCA exclui
// tarefas — elas são realocadas para outra coluna (com confirmação) ou ficam sem coluna.
export default function ColunasManager({ open, onClose, onAtualizou, quadroId, geralId }) {
  const [ativas, setAtivas] = useState([]);
  const [arquivadas, setArquivadas] = useState([]);
  const [nome, setNome] = useState('');
  const [cor, setCor] = useState('cinza');
  const [editId, setEditId] = useState(null);
  const [editNome, setEditNome] = useState('');
  const { toast } = useToast();

  const load = async () => {
    let l = [];
    try { l = await base44.entities.ColunasQuadro.list('ordem', 500); } catch {}
    const doQuadro = l.filter((c) => pertenceAoQuadro(c.quadro_id, quadroId, geralId));
    setAtivas(doQuadro.filter((c) => !c.arquivada));
    setArquivadas(doQuadro.filter((c) => c.arquivada));
  };
  useEffect(() => { if (open) load(); }, [open, quadroId, geralId]);

  const add = async () => {
    if (!nome.trim()) return;
    const ordem = ativas.length;
    await base44.entities.ColunasQuadro.create({ nome: nome.trim(), ordem, cor, arquivada: false, quadro_id: quadroId || '' });
    setNome(''); setCor('cinza'); load(); onAtualizou?.();
  };
  const renomear = async (id) => { if (!editNome.trim()) return; await base44.entities.ColunasQuadro.update(id, { nome: editNome.trim() }); setEditId(null); load(); onAtualizou?.(); };
  const arquivar = async (id) => { await base44.entities.ColunasQuadro.update(id, { arquivada: true }); load(); onAtualizou?.(); };
  const restaurar = async (id) => { await base44.entities.ColunasQuadro.update(id, { arquivada: false }); load(); onAtualizou?.(); };

  const excluir = async (id) => { await base44.entities.ColunasQuadro.delete(id); load(); onAtualizou?.(); };

  // Exclui coluna ativa preservando tarefas (realoca com confirmação).
  const excluirComConfirmacao = async (col) => {
    let tasks = [];
    try { tasks = await base44.entities.Demandas.filter({ coluna_id: col.id }); } catch { tasks = []; }
    const restantes = ativas.filter((c) => c.id !== col.id);
    if (tasks.length) {
      const destino = restantes[0];
      const msg = destino
        ? `A coluna "${col.nome}" possui ${tasks.length} tarefa(s). Elas serão movidas para "${destino.nome}". Excluir a coluna?`
        : `A coluna "${col.nome}" possui ${tasks.length} tarefa(s) e não há outra coluna. As tarefas ficarão sem coluna. Excluir a coluna?`;
      if (!window.confirm(msg)) return;
      if (destino) {
        const patch = { coluna_id: destino.id };
        if (destino.status_ref) patch.status = destino.status_ref;
        try { await base44.entities.Demandas.bulkUpdate(tasks.map((t) => ({ id: t.id, ...patch }))); } catch {}
      } else {
        try { await base44.entities.Demandas.bulkUpdate(tasks.map((t) => ({ id: t.id, coluna_id: '' }))); } catch {}
      }
      toast({ title: 'Coluna excluída', description: `${tasks.length} tarefa(s) realocada(s).` });
    } else {
      if (!window.confirm(`Excluir a coluna "${col.nome}"?`)) return;
    }
    await base44.entities.ColunasQuadro.delete(col.id);
    load(); onAtualizou?.();
  };

  const onDragEnd = async (res) => {
    if (!res.destination) return;
    const arr = [...ativas];
    const [moved] = arr.splice(res.source.index, 1);
    arr.splice(res.destination.index, 0, moved);
    setAtivas(arr);
    await base44.entities.ColunasQuadro.bulkUpdate(arr.map((c, i) => ({ id: c.id, ordem: i })));
    onAtualizou?.();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle className="flex items-center gap-2"><Columns3 className="w-4 h-4 text-amber-500" />Colunas do quadro</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <div className="flex gap-2 items-end">
            <div className="flex-1"><Label>Nova coluna</Label><Input className="mt-1" value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Ex.: Em Revisão" onKeyDown={(e) => e.key === 'Enter' && add()} /></div>
            <div className="flex gap-1">
              {CORES.slice(0, 6).map((c) => (
                <button key={c.key} type="button" onClick={() => setCor(c.key)} className={`w-7 h-7 rounded-full ${c.dot} ring-2 ring-offset-1 ${cor === c.key ? 'ring-[#0b2545]' : 'ring-transparent'}`} title={c.label} />
              ))}
            </div>
            <Button onClick={add} className="bg-[#0b2545] hover:bg-[#16365f]"><Plus className="w-4 h-4" /></Button>
          </div>

          <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="cols">
              {(prov) => (
                <div ref={prov.innerRef} {...prov.droppableProps} className="space-y-1.5">
                  {ativas.map((c, i) => (
                    <Draggable draggableId={c.id} index={i} key={c.id}>
                      {(p) => (
                        <div ref={p.innerRef} {...p.draggableProps} className="flex items-center gap-2 bg-white border border-slate-200 rounded-lg pl-2 pr-3 py-2">
                          <span {...p.dragHandleProps} className="text-slate-300 cursor-grab"><GripVertical className="w-4 h-4" /></span>
                          <span className={`w-3 h-3 rounded-full ${CORES.find((x) => x.key === c.cor)?.dot || 'bg-slate-400'}`} />
                          {editId === c.id ? (
                            <div className="flex items-center gap-1 flex-1">
                              <Input className="h-8 text-sm" value={editNome} onChange={(e) => setEditNome(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && renomear(c.id)} />
                              <button onClick={() => renomear(c.id)} className="p-1.5 text-emerald-600"><Check className="w-4 h-4" /></button>
                            </div>
                          ) : (
                            <span className="flex-1 text-sm font-medium text-[#0b2545]">{c.nome}</span>
                          )}
                          <button onClick={() => { setEditId(c.id); setEditNome(c.nome); }} className="p-1.5 text-slate-400 hover:text-[#0b2545]"><Pencil className="w-3.5 h-3.5" /></button>
                          <button onClick={() => excluirComConfirmacao(c)} className="p-1.5 text-slate-400 hover:text-red-500" title="Excluir coluna"><Trash2 className="w-3.5 h-3.5" /></button>
                          <button onClick={() => arquivar(c.id)} className="p-1.5 text-slate-400 hover:text-amber-600" title="Arquivar coluna (mantém os cartões)"><Archive className="w-3.5 h-3.5" /></button>
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {prov.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>

          {arquivadas.length > 0 && (
            <div className="border-t border-slate-100 pt-3">
              <p className="text-xs font-semibold text-slate-400 uppercase mb-2">Arquivadas</p>
              <div className="space-y-1.5">
                {arquivadas.map((c) => (
                  <div key={c.id} className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2">
                    <span className="flex-1 text-sm text-slate-500">{c.nome}</span>
                    <button onClick={() => restaurar(c.id)} className="p-1.5 text-slate-400 hover:text-emerald-600" title="Restaurar"><RotateCcw className="w-3.5 h-3.5" /></button>
                    <button onClick={() => excluir(c.id)} className="p-1.5 text-slate-400 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}