import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { novoHistorico, PRIORIDADES, STATUS } from '@/lib/acoes';
import { notificar } from '@/lib/quadro';
import { ChevronRight, LayoutTemplate, Briefcase, Check } from 'lucide-react';
import ResponsavelPicker from '@/components/operacoes/ResponsavelPicker';
import CategoriaSelector from '@/components/operacoes/CategoriaSelector';
import { nomeUsuario } from '@/lib/usuarioNome';
import { applyTitleCase } from '@/lib/titleCase';
import { useToast } from '@/components/ui/use-toast';
import { mensagemAmigavelErro, registrarErroInterno } from '@/lib/validacao';
import { criarProcessoPadrao } from '@/lib/modelosAcao';
import { criarSubtarefasDoJob } from '@/lib/subtarefas';
import JobExecutionSetup from '@/components/operacoes/JobExecutionSetup';

export default function NovaAcaoModal({ open, onClose, onSaved, user, prefill, usuarios = [], obras = [], jobs = [] }) {
  const tipo = prefill?.tipo || 'Tarefa';
  const { toast } = useToast();
  const [modelos, setModelos] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [showModelos, setShowModelos] = useState(false);
  const [modeloSelecionado, setModeloSelecionado] = useState(null);
  const [membros, setMembros] = useState([]);
  const [form, setForm] = useState({
    titulo: '', descricao: '', obra: '', categoria: '', job_id: '',
    responsavel: '', prazo: '', data_inicio: '', prioridade: 'Média', origem: 'Manual', status: 'Novo',
  });
  const [extra, setExtra] = useState({ etiquetas: '' });
  const [executionType, setExecutionType] = useState('Sem processo');
  const [includeChecklist, setIncludeChecklist] = useState(false);
  const [checklistItems, setChecklistItems] = useState([]);
  const [processOwners, setProcessOwners] = useState({ Solicitacao: '', Cotacao: '', Aprovacao: '', OrdemCompra: '', Recebimento: '', Financeiro: '' });
  const [showAdvanced, setShowAdvanced] = useState(false);

  const parseModeloMembros = (value) => { try { const parsed = JSON.parse(value || '[]'); return Array.isArray(parsed) ? parsed : []; } catch { return []; } };
  const nomeU = (u) => nomeUsuario(u);
  const euNome = () => { const n = nomeUsuario(user); return n === '—' ? '' : n; };
  const loadCategorias = async () => { try { setCategorias(await base44.entities.Categorias.list('nome', 500)); } catch {} };

  useEffect(() => {
    if (open) {
      (async () => {
        try { setModelos(await base44.entities.ModelosAcao.list('-created_date', 500)); } catch {}
        loadCategorias();
      })();
      setForm({
        titulo: prefill?.titulo || '',
        descricao: '',
        obra: prefill?.obra || user?.obra || '',
        categoria: prefill?.categoria || '',
        job_id: prefill?.job_id || '',
        responsavel: prefill?.responsavel || euNome(),
        prazo: prefill?.prazo || '',
        data_inicio: '',
        prioridade: prefill?.prioridade || 'Média',
        origem: prefill?.origem || 'Manual',
        status: prefill?.status || 'Novo',
      });
      setMembros([]);
      setModeloSelecionado(null);
      setExtra({ etiquetas: '' });
      setExecutionType('Sem processo'); setIncludeChecklist(false); setChecklistItems([]); setShowAdvanced(false);
      setProcessOwners({ Solicitacao: '', Cotacao: '', Aprovacao: '', OrdemCompra: '', Recebimento: '', Financeiro: '' });
    }
  }, [open, prefill, user]);

  const reset = () => {
    setForm({ titulo: '', descricao: '', obra: user?.obra || '', categoria: '', job_id: '', responsavel: user?.nome_exibicao || user?.full_name || '', prazo: '', data_inicio: '', prioridade: 'Média', origem: 'Manual', status: 'Novo' });
    setExtra({ etiquetas: '' });
      setExecutionType('Sem processo'); setIncludeChecklist(false); setChecklistItems([]); setShowAdvanced(false);
      setProcessOwners({ Solicitacao: '', Cotacao: '', Aprovacao: '', OrdemCompra: '', Recebimento: '', Financeiro: '' });
    setMembros([]);
    setModeloSelecionado(null);
    setShowModelos(false);
  };

  const fromModelo = (m) => {
    setModeloSelecionado(m);
    setForm((f) => ({ ...f, titulo: '', descricao: m.descricao || '', categoria: m.categoria || '', prioridade: m.prioridade || 'Média', origem: m.origem || 'Manual', responsavel: m.responsavel || f.responsavel }));
    setMembros(parseModeloMembros(m.membros));
    setExtra({ etiquetas: m.etiquetas || '' });
    let itens = []; try { itens = JSON.parse(m.checklist || '[]'); } catch {} setChecklistItems(Array.isArray(itens) ? itens : []);
    setExecutionType(m.processo_tipo === 'Orcamento' ? 'Processo de Orçamento/Compra' : m.tipo === 'Processo' ? 'Outro processo' : itens.length ? 'Checklist' : 'Sem processo'); setIncludeChecklist(m.processo_tipo === 'Orcamento' && itens.length > 0);
    if (m.processo_responsaveis) { try { const raw = JSON.parse(m.processo_responsaveis); setProcessOwners(Object.fromEntries(Object.entries(raw).map(([key, value]) => [key, typeof value === 'string' ? value : value?.responsavel || '']))); } catch {} }
    setShowModelos(false);
  };

  const toggleMembro = (nome) => setMembros((arr) => arr.includes(nome) ? arr.filter((x) => x !== nome) : [...arr, nome]);

  const save = async (e) => {
    e.preventDefault();
    if (!form.titulo.trim()) return;
    const membrosArr = form.responsavel ? [form.responsavel, ...membros.filter((m) => m !== form.responsavel)] : membros;
    const eu = nomeUsuario(user);
    const hist = novoHistorico('Criação da tarefa', eu);
    hist.push({ evento: `Responsável: ${form.responsavel || '—'}`, data: new Date().toISOString(), usuario: eu });
    const hasExecutionItems = executionType === 'Checklist' || executionType === 'Outro processo' || includeChecklist;
    const payload = applyTitleCase({
      titulo: form.titulo.trim(),
      descricao: form.descricao,
      obra: form.obra,
      categoria: form.categoria,
      job_id: form.job_id,
      tipo,
      status: form.status,
      prioridade: form.prioridade,
      origem: form.origem,
      etiquetas: extra.etiquetas,
      checklist: hasExecutionItems ? JSON.stringify(checklistItems) : '[]',
      checklist_ativo: hasExecutionItems,
      tipo_execucao: executionType,
      processo_tipo: executionType === 'Processo de Orçamento/Compra' ? 'Orcamento' : executionType === 'Outro processo' ? 'Outro' : undefined,
      responsavel: form.responsavel,
      membros: JSON.stringify(membrosArr),
      prazo: form.prazo,
      data_inicio: form.data_inicio,
      solicitante: euNome(),
      empresa: user?.empresa || (jobs.find((j) => j.id === form.job_id)?.empresa) || '',
      usuario_origem: euNome(),
      quadro_id: prefill?.quadro_id || '',
      coluna_id: prefill?.coluna_id || '',
      historico: JSON.stringify(hist),
    }, ['titulo', 'descricao']);
    let criado;
    try { criado = await base44.entities.Demandas.create(payload); }
    catch (erro) {
      registrarErroInterno('Criar tarefa', erro);
      toast({ title: 'Não foi possível criar a tarefa.', description: mensagemAmigavelErro(erro, 'Verifique os dados preenchidos e tente novamente.'), variant: 'destructive' });
      return;
    }
    if (hasExecutionItems) {
      try { await criarSubtarefasDoJob(criado, checklistItems, euNome()); }
      catch (erro) { registrarErroInterno('Criar subtarefas', erro); toast({ title: 'Tarefa criada, mas alguns itens não foram salvos.', variant: 'destructive' }); }
    }
    if (executionType === 'Processo de Orçamento/Compra') {
      try { await criarProcessoPadrao(criado, euNome(), processOwners); }
      catch (erro) { registrarErroInterno('Aplicar processo padrão', erro); toast({ title: 'Tarefa criada, mas o processo padrão não foi aplicado.', variant: 'destructive' }); }
    }
    const alvos = [...new Set([form.responsavel, ...membros].filter(Boolean))];
    let falhasNotificacao = 0;
    for (const a of alvos) {
      if (a !== euNome() && a !== '—') {
        const jobNome = jobs.find((j) => j.id === form.job_id)?.nome || '';
        if (!await notificar(a, 'Você recebeu uma nova tarefa', `${form.titulo}${jobNome ? ` · Agrupamento: ${jobNome}` : ''}${form.prazo ? ` · Prazo: ${form.prazo}` : ''}`, criado.id)) falhasNotificacao += 1;
      }
    }
    toast({
      title: 'Tarefa criada com sucesso.',
      description: falhasNotificacao ? 'A tarefa foi salva, mas alguns destinatários não receberam o alerta. Tente notificá-los novamente.' : undefined,
      variant: falhasNotificacao ? 'destructive' : undefined,
    });
    reset();
    onSaved?.(criado);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) { reset(); onClose(); } }}>
      <DialogContent className="max-w-5xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-foreground"><Briefcase className="w-5 h-5" />Nova tarefa</DialogTitle>
          <DialogDescription>Preencha o essencial e adicione checklist ou processo somente quando precisar.</DialogDescription>
        </DialogHeader>
        <form onSubmit={save} className="space-y-3">
          <div><Label>Título *</Label><Input className="mt-1" value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })} placeholder="Ex.: Orçamento do sistema de ponto" required autoFocus /></div>
          {showAdvanced && <div><Label>Descrição</Label><Textarea className="mt-1" rows={2} value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} placeholder="O que precisa ser feito?" /></div>}

          <div className="grid grid-cols-1 gap-3">
            {showAdvanced && <div><Label>Agrupamento (opcional)</Label>
              <Select value={form.job_id || '__none__'} onValueChange={(v) => { const id = v === '__none__' ? '' : v; const j = jobs.find((x) => x.id === id); setForm((f) => ({ ...f, job_id: id, obra: f.obra || j?.obra || '', })); }}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Sem agrupamento" /></SelectTrigger>
                <SelectContent><SelectItem value="__none__">Sem agrupamento</SelectItem>{jobs.map((j) => <SelectItem key={j.id} value={j.id}>{j.nome}</SelectItem>)}</SelectContent>
              </Select>
            </div>}
            <div><Label>Obra / Projeto</Label>
              <Select value={form.obra || '__none__'} onValueChange={(v) => setForm({ ...form, obra: v === '__none__' ? '' : v })}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="—" /></SelectTrigger>
                <SelectContent><SelectItem value="__none__">—</SelectItem>{obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>

          <div><Label>Responsável</Label><div className="mt-1"><ResponsavelPicker usuarios={usuarios} value={form.responsavel} onChange={(v) => setForm({ ...form, responsavel: v })} /></div></div>

          {showAdvanced && <div>
            <Label>Membros</Label>
            <div className="mt-1 flex flex-wrap gap-1.5 max-h-24 overflow-y-auto border border-slate-200 rounded-lg p-2">
              {usuarios.length === 0 && <p className="text-xs text-slate-400">Nenhum usuário cadastrado.</p>}
              {usuarios.map((u) => {
                const n = nomeU(u); const sel = membros.includes(n);
                return (
                  <button key={u.id} type="button" onClick={() => toggleMembro(n)} className={`inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full border ${sel ? 'bg-[#0b2545] text-white border-[#0b2545]' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}>
                    {sel && <Check className="w-3 h-3" />}{n}
                  </button>
                );
              })}
            </div>
          </div>}

          <div className="grid grid-cols-2 gap-3">
            {showAdvanced && <div><Label>Início</Label><Input type="date" className="mt-1" value={form.data_inicio} onChange={(e) => setForm({ ...form, data_inicio: e.target.value })} /></div>}
            <div><Label>Prazo</Label><Input type="date" className="mt-1" value={form.prazo} onChange={(e) => setForm({ ...form, prazo: e.target.value })} /></div>
            <div><Label>Prioridade</Label>
              <Select value={form.prioridade} onValueChange={(v) => setForm({ ...form, prioridade: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{PRIORIDADES.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3">
            {showAdvanced && <div><Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{STATUS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>}
            <div><Label>Etiqueta / categoria</Label>
              <CategoriaSelector value={form.categoria || ''} onChange={(v) => setForm({ ...form, categoria: v })} categorias={categorias} onRefresh={loadCategorias} size="md" />
            </div>
          </div>

          <button type="button" onClick={() => setShowAdvanced((value) => !value)} className="text-sm font-medium text-primary">{showAdvanced ? 'Ocultar opções adicionais' : 'Mais opções'}</button>

          <JobExecutionSetup executionType={executionType} setExecutionType={setExecutionType} includeChecklist={includeChecklist} setIncludeChecklist={setIncludeChecklist} items={checklistItems} setItems={setChecklistItems} templates={modelos} usuarios={usuarios} processOwners={processOwners} setProcessOwners={setProcessOwners} onSaveTemplate={async (nome, itens, tipoModelo = 'Checklist') => { await base44.entities.ModelosAcao.create({ nome, tipo: tipoModelo, checklist: JSON.stringify(itens), criado_por: euNome() }); setModelos(await base44.entities.ModelosAcao.list('-created_date', 500)); toast({ title: 'Modelo de checklist salvo.' }); }} />

          {modelos.length > 0 && (
            <div className="border-t border-slate-100 pt-2">
              {!showModelos ? (
                <button type="button" onClick={() => setShowModelos(true)} className="text-xs text-[#0b2545] hover:underline flex items-center gap-1"><LayoutTemplate className="w-3.5 h-3.5" />Partir de um modelo</button>
              ) : (
                <div className="space-y-1.5">
                  <p className="text-xs font-semibold text-slate-400 uppercase mb-1 flex items-center gap-1.5"><LayoutTemplate className="w-3.5 h-3.5" />Checklists e processos padrão</p>
                  {modelos.map((m) => (
                    <button key={m.id} type="button" onClick={() => fromModelo(m)} className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-lg border border-slate-200 hover:border-amber-400 hover:bg-amber-50">
                      <LayoutTemplate className="w-4 h-4 text-slate-400" />
                      <div className="min-w-0"><p className="text-sm font-medium text-[#0b2545] truncate">{m.nome}</p><p className="text-[11px] text-slate-400">{m.processo_tipo || m.tipo === 'Processo' ? 'Processo padrão' : m.checklist ? 'Checklist padrão' : m.tipo === 'JOB' ? 'Tarefa' : m.tipo}{m.categoria ? ` · ${m.categoria}` : ''}</p></div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => { reset(); onClose(); }}>Cancelar</Button>
            <Button type="submit">Criar tarefa <ChevronRight className="w-4 h-4" /></Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}