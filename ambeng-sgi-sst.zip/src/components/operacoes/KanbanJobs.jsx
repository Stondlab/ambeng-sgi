import React from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { base44 } from '@/api/base44Client';
import { Plus, Briefcase, Pencil } from 'lucide-react';
import { appendHistorico } from '@/lib/acoes';
import AcaoCard from '@/components/operacoes/AcaoCard';

// Visão Kanban por Job: cada Job é uma coluna vertical; arrastar um card entre
// colunas altera o job_id da tarefa. Coluna "Sem Job" para tarefas sem vínculo.
export default function KanbanJobs({ jobs, demands, onOpen, onAddTask, onEditJob, onUpdated, user, etiquetas, densidade, podeEditar }) {
  const semJob = demands.filter((d) => !d.job_id);
  const tarefasDoJob = (jobId) => demands.filter((d) => d.job_id === jobId);
  const jobCols = [
    ...jobs.map((j) => ({ id: j.id, nome: j.nome, job: j, items: tarefasDoJob(j.id) })),
    { id: '__semjob', nome: 'Sem Job', job: null, items: semJob },
  ];

  const onDragEnd = async (res) => {
    if (!res.destination) return;
    const destId = res.destination.droppableId;
    const d = demands.find((x) => x.id === res.draggableId);
    if (!d) return;
    const novoJobId = destId === '__semjob' ? '' : destId;
    const jobNome = jobCols.find((c) => c.id === destId)?.nome || 'Sem Job';
    const hist = appendHistorico(d.historico, `Job → ${jobNome}`, user?.nome_exibicao || user?.full_name || '—');
    const patch = { job_id: novoJobId, historico: JSON.stringify(hist) };
    await base44.entities.Demandas.update(d.id, patch);
    onUpdated?.();
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="flex gap-3 h-full">
        {jobCols.map((col) => (
          <Droppable droppableId={col.id} key={col.id}>
            {(provided) => (
              <div ref={provided.innerRef} {...provided.droppableProps} className="bg-slate-50/60 border border-slate-200 rounded-xl border-t-4 border-t-[#0b2545] w-72 shrink-0 flex flex-col max-h-full">
                <div className="flex items-center justify-between px-3 py-2.5 border-b border-slate-100">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <Briefcase className="w-3.5 h-3.5 text-[#0b2545] shrink-0" />
                    <h3 className="font-semibold text-[#0b2545] text-sm truncate">{col.nome}</h3>
                    <span className="text-xs text-slate-400 bg-white px-2 py-0.5 rounded-full">{col.items.length}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {col.job && podeEditar && (
                      <>
                        <button onClick={() => onAddTask(col.job)} className="min-w-[28px] min-h-[28px] flex items-center justify-center rounded hover:bg-slate-200 text-slate-500" title="Adicionar tarefa"><Plus className="w-4 h-4" /></button>
                        <button onClick={() => onEditJob(col.job)} className="min-w-[28px] min-h-[28px] flex items-center justify-center rounded hover:bg-slate-200 text-slate-500" title="Editar Job"><Pencil className="w-3.5 h-3.5" /></button>
                      </>
                    )}
                    {!col.job && podeEditar && (
                      <button onClick={() => onAddTask(null)} className="min-w-[28px] min-h-[28px] flex items-center justify-center rounded hover:bg-slate-200 text-slate-500" title="Adicionar tarefa"><Plus className="w-4 h-4" /></button>
                    )}
                  </div>
                </div>
                <div className="p-2 space-y-2 min-h-[80px] flex-1 overflow-y-auto">
                  {col.items.map((d, i) => (
                    <Draggable draggableId={d.id} index={i} key={d.id}>
                      {(prov) => <AcaoCard acao={d} onOpen={() => onOpen(d)} provided={prov} etiquetas={etiquetas} onUpdated={onUpdated} user={user} densidade={densidade} />}
                    </Draggable>
                  ))}
                  {col.items.length === 0 && <p className="text-xs text-slate-300 text-center py-6">Vazio</p>}
                  {provided.placeholder}
                </div>
                {col.job && (col.job.responsavel || col.job.prazo) && (
                  <div className="px-3 py-2 border-t border-slate-100 text-[11px] text-slate-500 truncate">
                    {col.job.responsavel && <span>👤 {col.job.responsavel}</span>}
                    {col.job.responsavel && col.job.prazo && ' · '}
                    {col.job.prazo && <span>📅 {col.job.prazo}</span>}
                  </div>
                )}
              </div>
            )}
          </Droppable>
        ))}
      </div>
    </DragDropContext>
  );
}