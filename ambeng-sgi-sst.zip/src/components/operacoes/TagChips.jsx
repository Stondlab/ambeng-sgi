import React from 'react';
import { derivarTags } from '@/lib/tags';
import { parseEtiquetas, corEtiqueta, corCategoria } from '@/lib/quadro';

export default function TagChips({ acao, onTagClick, etiquetas: catalogo = [], categorias = [], size = 'sm', max }) {
  const tags = derivarTags(acao).filter((t) => t.field !== 'obra');
  if (acao.categoria) {
    const cc = corCategoria(categorias, acao.categoria);
    tags.push({ label: acao.categoria, categoria: 'Categoria', chip: cc.chip, dot: cc.dot, field: 'categoria', value: acao.categoria });
  }
  parseEtiquetas(acao.etiquetas).forEach((nome) => {
    const found = (catalogo || []).find((e) => e.nome === nome);
    const c = found ? corEtiqueta(found.cor) : corEtiqueta('cinza');
    tags.push({ label: nome, categoria: 'Etiqueta', chip: c.chip, dot: c.dot, field: 'etiqueta', value: nome });
  });
  if (!tags.length) return null;
  const visible = max ? tags.slice(0, max) : tags;
  const pad = size === 'xs' ? 'px-1.5 py-0 text-[10px]' : 'px-2 py-0.5 text-[11px]';
  return (
    <div className="flex flex-wrap gap-1">
      {visible.map((t, i) => (
        <button
          key={`${t.field}-${t.value}-${i}`}
          type="button"
          onClick={(e) => { e.stopPropagation(); onTagClick && onTagClick(t); }}
          className={`inline-flex items-center gap-1 rounded-full font-medium ${t.chip} ${pad} ${onTagClick ? 'hover:opacity-80 cursor-pointer' : 'cursor-default'}`}
          title={`${t.categoria}: ${t.label}`}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${t.dot}`} />
          {t.label}
        </button>
      ))}
      {max && tags.length > max && <span className="text-[10px] text-slate-400 self-center">+{tags.length - max}</span>}
    </div>
  );
}