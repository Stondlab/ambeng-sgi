import React, { useMemo, useState } from 'react';
import { Search, Check, UserCog } from 'lucide-react';
import { nomeUsuario } from '@/lib/usuarioNome';

// Seletor de responsável/membro: lista usuários cadastrados com avatar, nome e perfil.
// value: nome de exibição (nome_exibicao || full_name) — compatível com o restante do sistema.
export default function ResponsavelPicker({ usuarios = [], value, onChange, placeholder = 'Atribuir responsável...', disabled }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');

  const nomeU = (u) => nomeUsuario(u);
  const perfilU = (u) => u?.role || u?.perfil || 'Usuário';
  const selecionado = useMemo(() => usuarios.find((u) => nomeU(u).toLowerCase() === String(value || '').toLowerCase()) || null, [usuarios, value]);

  const filtrados = useMemo(() => {
    const query = q.trim().toLowerCase();
    const list = [...usuarios].sort((a, b) => nomeU(a).localeCompare(nomeU(b)));
    return query ? list.filter((u) => nomeU(u).toLowerCase().includes(query)) : list;
  }, [usuarios, q]);

  const AV = ['bg-amber-400', 'bg-sky-500', 'bg-emerald-500', 'bg-violet-500', 'bg-pink-500', 'bg-orange-500', 'bg-slate-500'];
  const initials = (n) => (n || '').split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();
  const cor = (n) => AV[((n || '').split('').reduce((a, c) => a + c.charCodeAt(0), 0)) % AV.length];

  return (
    <div className="relative">
      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center gap-2 h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm hover:bg-slate-50 disabled:opacity-50"
      >
        {selecionado ? (
          <>
            <span className={`w-6 h-6 rounded-full ${cor(value)} text-white text-[10px] font-semibold flex items-center justify-center`}>{initials(value)}</span>
            <span className="flex-1 text-left text-[#0b2545] truncate">{selecionado ? nomeU(selecionado) : value}</span>
            <span className="text-[10px] text-slate-400">{perfilU(selecionado)}</span>
          </>
        ) : (
          <>
            <UserCog className="w-4 h-4 text-slate-400" />
            <span className="flex-1 text-left text-slate-400">{placeholder}</span>
          </>
        )}
      </button>

      {open && !disabled && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="absolute z-40 mt-1 w-full max-h-64 overflow-y-auto bg-white border border-slate-200 rounded-lg shadow-lg p-2">
            <div className="relative mb-2">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Pesquisar usuário..."
                className="w-full h-8 pl-7 pr-2 rounded-md border border-slate-200 text-xs"
                autoFocus
              />
            </div>
            <div className="space-y-0.5">
              {filtrados.map((u) => {
                const n = nomeU(u);
                const sel = n === value;
                return (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => { onChange?.(n); setOpen(false); setQ(''); }}
                    className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-slate-100 text-sm"
                  >
                    <span className={`w-6 h-6 rounded-full ${cor(n)} text-white text-[10px] font-semibold flex items-center justify-center`}>{initials(n)}</span>
                    <span className="flex-1 text-left text-slate-700 truncate">{n}</span>
                    <span className="text-[10px] text-slate-400">{perfilU(u)}</span>
                    {sel && <Check className="w-4 h-4 text-emerald-600" />}
                  </button>
                );
              })}
              {filtrados.length === 0 && <p className="text-xs text-slate-400 text-center py-3">Nenhum usuário.</p>}
            </div>
          </div>
        </>
      )}
    </div>
  );
}