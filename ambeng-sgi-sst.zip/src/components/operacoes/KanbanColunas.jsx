import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { base44 } from '@/api/base44Client';
import { Plus } from 'lucide-react';
import { appendHistorico } from '@/lib/acoes';
import { corColuna, rodarAutomacoes } from '@/lib/quadro';
import OperacoesCard from '@/components/CentralOperacoes/OperacoesCard';
import { nomeUsuario } from '@/lib/usuarioNome';
import ColunaMenu from '@/components/operacoes/ColunaMenu';
import { useToast } from '@/components/ui/use-toast';

// Kanban por colunas de status (Novo, A Fazer, Em Andamento...).
// Cada coluna vem da entidade ColunasQuadro (com status_ref). Arrastar um card
// entre colunas atualiza status + coluna_id + ordem; reordenar dentro da coluna
// persiste a ordem (campo `ordem`). Histórico registra quem moveu e de onde para onde.
export default function KanbanColunas({ colunas, demands, onOpen, onAddTask, onUpdated, user, etiquetas, categorias, densidade, podeEditar, usuarios = [], orcamentos = [], subtarefas = [], geralId }) {
  const [ordenacao, setOrdenacao] = useState({});
  const { toast } = useToast();

  // Ordenação padrão: pelo campo `ordem` (asc) preservando a ordem de criação como desempate.
  const itemsDaColuna = (col) => {
    let items = col.status_ref ? demands.filter((d) => d.status === col.status_ref) : demands.filter((d) => d.coluna_id === col.id);
    const ord = ordenacao[col.id];
    if (ord === 'prioridade') {
      const rank = { Crítica: 0, Alta: 1, Média: 2, Baixa: 3 };
      items = [...items].sort((a, b) => (rank[a.prioridade] ?? 9) - (rank[b.prioridade] ?? 9));
    } else if (ord === 'prazo') {
      items = [...items].sort((a, b) => (a.prazo || '9999').localeCompare(b.prazo || '9999'));
    } else {
      // Ordem manual persistida (campo `ordem`); desempate pela posição atual (já vem -created_date).
      items = [...items].sort((a, b) => (a.ordem ?? 0) - (b.ordem ?? 0));
    }
    return items;
  };

  const onDragEnd = async (res) => {
    if (!res.destination) return;
    if (res.destination.droppableId === res.source.droppableId && res.destination.index === res.source.index) return;

    const destCol = colunas.find((c) => c.id === res.destination.droppableId);
    const srcCol = colunas.find((c) => c.id === res.source.droppableId);
    if (!destCol) return;
    const d = demands.find((x) => x.id === res.draggableId);
    if (!d) return;

    const mudouColuna = res.destination.droppableId !== res.source.droppableId;
    const prevNome = srcCol?.nome || d.status || '—';
    const novoNome = destCol.nome;
    const prevStatus = d.status;
    const novoStatus = destCol.status_ref || destCol.nome;

    // Nova ordem dos itens visíveis na coluna de destino (e da origem, se cruzou coluna).
    const destItems = itemsDaColuna(destCol);
    let novaDest;
    if (mudouColuna) {
      novaDest = destItems.filter((x) => x.id !== d.id);
      novaDest.splice(res.destination.index, 0, d);
    } else {
      novaDest = [...destItems];
      const [movido] = novaDest.splice(res.source.index, 1);
      novaDest.splice(res.destination.index, 0, movido);
    }

    // Patch do card movido.
    const patch = { coluna_id: destCol.id };
    if (destCol.status_ref) patch.status = destCol.status_ref;
    if (destCol.status_ref === 'Concluído' && prevStatus !== 'Concluído') {
      patch.data_conclusao = new Date().toISOString();
    } else if (destCol.status_ref !== 'Concluído' && prevStatus === 'Concluído') {
      patch.data_conclusao = null; // reabrir
    }

    const quem = nomeUsuario(user);
    const msg = mudouColuna ? `${quem} moveu a tarefa de ${prevNome} para ${novoNome}.` : `${quem} reordenou a tarefa em ${novoNome}.`;
    patch.historico = JSON.stringify(appendHistorico(d.historico, msg, quem));

    try {
      await base44.entities.Demandas.update(d.id, patch);
      // Persistir a nova ordem dos itens visíveis (0..n-1).
      const updates = novaDest.map((x, i) => ({ id: x.id, ordem: i }));
      if (updates.length) await base44.entities.Demandas.bulkUpdate(updates);

      // Automação de "movido para coluna".
      if (mudouColuna && destCol.status_ref === 'Concluído') {
        rodarAutomacoes({ tipo: 'concluir' }, { ...d, status: 'Concluído' }, geralId);
      }
      rodarAutomacoes({ tipo: 'mover', colunaId: destCol.id }, { ...d, ...patch }, geralId);

      toast({ title: mudouColuna ? `Tarefa movida para ${novoNome}` : 'Ordem atualizada', description: msg });
      onUpdated?.();
    } catch (e) {
      toast({ variant: 'destructive', title: 'Erro ao mover tarefa', description: 'A tarefa voltará para a posição anterior.' });
      onUpdated?.(); // recarrega do banco para reverter visualmente
    }
  };

  const ordenar = (col, criterio) => setOrdenacao((s) => ({ ...s, [col.id]: criterio }));
  const ocultar = async (col) => { await base44.entities.ColunasQuadro.update(col.id, { arquivada: true }); onUpdated?.(); };
  const arquivarConcluidos = async (col) => {
    const items = itemsDaColuna(col).filter((d) => d.status === 'Concluído');
    if (!items.length) return;
    await base44.entities.Demandas.bulkUpdate(items.map((d) => ({ id: d.id, arquivada: true })));
    onUpdated?.();
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="flex gap-3 h-full min-w-max">
        {colunas.map((col) => {
          const items = itemsDaColuna(col);
          return (
            <Droppable droppableId={col.id} key={col.id}>
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className={`w-[300px] shrink-0 flex flex-col h-full rounded-xl border border-t-2 bg-muted/50 ${corColuna(col.cor)} transition-colors ${snapshot.isDraggingOver ? 'border-primary bg-primary/5 ring-2 ring-primary/15' : 'border-border'}`}
                >
                  <div className="flex items-center justify-between px-3 py-2.5 shrink-0">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <h3 className="truncate text-sm font-semibold text-foreground">{col.nome}</h3>
                      <span className="rounded-full bg-card px-2 py-0.5 text-xs font-medium text-muted-foreground">{items.length}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      {podeEditar && <button onClick={() => onAddTask(col)} className="min-w-[28px] min-h-[28px] flex items-center justify-center rounded hover:bg-slate-200 text-slate-500" title="Adicionar tarefa"><Plus className="w-4 h-4" /></button>}
                      <ColunaMenu col={col} onOrdenar={ordenar} onOcultar={ocultar} onArquivarConcluidos={arquivarConcluidos} />
                    </div>
                  </div>
                  <div className="p-2 space-y-2 min-h-[80px] flex-1 overflow-y-auto">
                    {items.map((d, i) => (
                      <Draggable draggableId={d.id} index={i} key={d.id}>
                        {(prov, snap) => (
                          <div
                            ref={prov.innerRef}
                            {...prov.draggableProps}
                            {...prov.dragHandleProps}
                            style={prov.draggableProps.style}
                            className={snap.isDragging ? 'shadow-lg ring-2 ring-amber-300 rounded-lg' : ''}
                          >
                            <OperacoesCard
                              acao={d}
                              onOpen={() => onOpen(d)}
                              etiquetas={etiquetas}
                              categorias={categorias}
                              onUpdated={onUpdated}
                              user={user}
                              densidade={densidade}
                              usuarios={usuarios}
                              orcamento={orcamentos.find((o) => o.demanda_id === d.id)}
                              subtarefas={subtarefas}
                              dragging={snap.isDragging}
                            />
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {items.length === 0 && <p className="text-xs text-slate-300 text-center py-6">Vazio</p>}
                    {provided.placeholder}
                  </div>
                </div>
              )}
            </Droppable>
          );
        })}
      </div>
    </DragDropContext>
  );
}