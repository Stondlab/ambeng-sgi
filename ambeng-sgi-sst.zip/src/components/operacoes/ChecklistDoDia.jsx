import React from 'react';
import { format, parseISO } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { parseList, isAtrasada, venceHoje, appendHistorico } from '@/lib/acoes';
import { CheckCircle2, Circle, CalendarClock } from 'lucide-react';
import { nomeUsuario } from '@/lib/usuarioNome';
import { useToast } from '@/components/ui/use-toast';
import { registrarErroInterno } from '@/lib/validacao';

// Checklist do Dia — REAL: mostra somente tarefas existentes e pendentes para o
// usuário (vencendo hoje ou atrasadas). Concluir aqui atualiza a tarefa real
// (Demandas), mantendo a Central de Operações sincronizada via recarga compartilhada.
export default function ChecklistDoDia({ demands = [], user, onUpdated }) {
  const { toast } = useToast();
  const meusNomes = [nomeUsuario(user), user?.nome_exibicao, user?.full_name].filter(Boolean);
  const eu = nomeUsuario(user);
  const souMinha = (d) =>
    meusNomes.includes(d.responsavel) || parseList(d.membros).some((m) => meusNomes.includes(m));

  const pendentesHoje = demands
    .filter((d) => !d.arquivada && d.status !== 'Concluído' && d.status !== 'Cancelado')
    .filter(souMinha)
    .filter((d) => venceHoje(d) || isAtrasada(d))
    .sort((a, b) => {
      const aAtr = isAtrasada(a) ? 0 : 1;
      const bAtr = isAtrasada(b) ? 0 : 1;
      if (aAtr !== bAtr) return aAtr - bAtr;
      return (a.prazo || '9999').localeCompare(b.prazo || '9999');
    });

  const toggle = async (d) => {
    const concluido = d.status === 'Concluído';
    const novoStatus = concluido ? 'A Fazer' : 'Concluído';
    const hist = appendHistorico(d.historico, `Status → ${novoStatus} (checklist)`, eu);
    const patch = { status: novoStatus, historico: JSON.stringify(hist) };
    if (novoStatus === 'Concluído') patch.data_conclusao = new Date().toISOString();
    try {
      await base44.entities.Demandas.update(d.id, patch);
      toast({ title: novoStatus === 'Concluído' ? 'Tarefa concluída.' : 'Tarefa reaberta.' });
      onUpdated?.();
    } catch (erro) {
      registrarErroInterno('Atualizar tarefa pelo checklist', erro);
      toast({ title: 'Não foi possível atualizar a tarefa.', description: 'Tente novamente em instantes.', variant: 'destructive' });
    }
  };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-4 mb-4">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-base font-semibold text-[#0b2545]">Checklist do Dia</h2>
        <span className="text-xs text-slate-400">{pendentesHoje.length} pendente(s)</span>
      </div>
      {pendentesHoje.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-6 text-center">
          <CheckCircle2 className="w-8 h-8 text-emerald-400 mb-2" />
          <p className="text-sm text-slate-500">Nada pendente para hoje. Tudo em dia!</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-2">
          {pendentesHoje.map((d) => (
            <button
              key={d.id}
              onClick={() => toggle(d)}
              className="flex items-center gap-2 min-h-[44px] px-3 rounded-lg border text-sm text-left transition-colors bg-white border-slate-200 hover:bg-slate-50 text-slate-700"
            >
              <Circle className="w-4 h-4 text-slate-300 shrink-0" />
              <span className="flex-1 truncate font-medium text-[#0b2545]">{d.titulo}</span>
              {d.prazo && (
                <span className={`inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full font-medium ${isAtrasada(d) ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}`}>
                  <CalendarClock className="w-3 h-3" />{format(parseISO(d.prazo), 'dd/MM')}
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </section>
  );
}