import React, { useEffect, useState } from 'react';
import { Sparkles } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import AssistenteSGI from '@/components/relatorios/AssistenteSGI';

export default function SstAssistantLauncher({ data }) {
  const [open,setOpen]=useState(false);
  useEffect(()=>{ const openAssistant=()=>setOpen(true); window.addEventListener('open-sgi-assistant',openAssistant); return ()=>window.removeEventListener('open-sgi-assistant',openAssistant); },[]);
  return <><button onClick={()=>setOpen(true)} title="Assistente SGI - Clique para abrir" className="fixed bottom-20 right-4 z-30 flex min-h-14 items-center gap-2 rounded-full bg-warning px-5 font-semibold text-warning-foreground shadow-xl ring-4 ring-warning/20 hover:bg-warning/90 lg:bottom-6 lg:right-6" aria-label="Assistente SGI - Clique para abrir"><Sparkles className="h-6 w-6" /><span>Assistente SGI</span></button><Dialog open={open} onOpenChange={setOpen}><DialogContent className="max-h-[88vh] max-w-2xl overflow-y-auto"><DialogHeader><DialogTitle>Assistente SGI</DialogTitle></DialogHeader><AssistenteSGI data={data} /></DialogContent></Dialog></>;
}