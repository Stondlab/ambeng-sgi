import React from 'react';
import { FileCheck2, Image, Paperclip } from 'lucide-react';

const parseUrls=(value)=>{ try { const list=JSON.parse(value||'[]'); return Array.isArray(list)?list.filter(Boolean):[]; } catch { return value?[value]:[]; } };
export default function SstEvidencePanel({ data }) {
  const ocorrenciaFotos=(data.ocorrencias||[]).flatMap((r)=>parseUrls(r.fotos).map((url)=>({ url, tipo:'Foto de ocorrência', detalhe:`${r.obra||'Sem obra'} · ${r.data||'Sem data'}` })));
  const inspecaoFotos=(data.inspecoes||[]).flatMap((r)=>parseUrls(r.fotos).map((url)=>({ url, tipo:'Foto de inspeção', detalhe:`${r.obra||'Sem obra'} · ${r.data||'Sem data'}` })));
  const arquivos=[...(data.treinamentos||[]).filter((r)=>r.certificado_url).map((r)=>({url:r.certificado_url,tipo:'Certificado de treinamento',detalhe:r.norma_curso||r.nome_curso||'Treinamento'})),...(data.asos||[]).filter((r)=>r.arquivo_url).map((r)=>({url:r.arquivo_url,tipo:'Comprovante de ASO',detalhe:r.tipo||'ASO'})),...ocorrenciaFotos,...inspecaoFotos];
  const cards=[
    { label:'Documentos cadastrados', value:(data.documentos||[]).length, Icon:FileCheck2 },
    { label:'Fotos de ocorrências', value:ocorrenciaFotos.length, Icon:Image },
    { label:'Fotos de inspeções', value:inspecaoFotos.length, Icon:Image },
    { label:'Certificados e ASOs', value:arquivos.length-ocorrenciaFotos.length-inspecaoFotos.length, Icon:Paperclip },
  ];
  return <div className="space-y-4"><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{cards.map(({label,value,Icon})=><div key={label} className="rounded-xl border border-border bg-card p-4"><Icon className="h-5 w-5 text-primary" /><p className="mt-3 text-2xl font-bold">{value}</p><p className="mt-1 text-xs text-muted-foreground">{label}</p></div>)}</div><section className="rounded-xl border border-border bg-card p-4"><h2 className="mb-3 font-semibold">Arquivos e comprovantes</h2><div className="grid gap-2 md:grid-cols-2">{arquivos.slice(0,24).map((item,index)=><a key={`${item.url}-${index}`} href={item.url} target="_blank" rel="noreferrer" className="flex min-h-12 items-center gap-3 rounded-lg border border-border px-3 hover:bg-muted"><Paperclip className="h-4 w-4 text-primary" /><span className="min-w-0"><strong className="block truncate text-sm">{item.tipo}</strong><span className="block truncate text-xs text-muted-foreground">{item.detalhe}</span></span></a>)}{!arquivos.length&&<p className="py-6 text-sm text-muted-foreground">Nenhuma evidência anexada.</p>}</div></section></div>;
}