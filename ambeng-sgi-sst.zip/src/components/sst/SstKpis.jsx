import React from 'react';
import { AlertOctagon, CalendarClock, ShieldCheck, TimerReset } from 'lucide-react';

const ITEMS = [{ key: 'diasSemAcidente', label: 'Dias sem acidente', icon: TimerReset, tone: 'success' }, { key: 'conformidade', label: 'Conformidade SST', icon: ShieldCheck, tone: 'success', suffix: '%' }, { key: 'acidentesMes', label: 'Acidentes no mês', icon: AlertOctagon, tone: 'destructive' }, { key: 'proximos30', label: 'Vencimentos em 30 dias', icon: CalendarClock, tone: 'warning' }];
const TONES = { success: 'border-success/40 bg-success/10 text-success', destructive: 'border-destructive/40 bg-destructive/10 text-destructive', warning: 'border-warning/40 bg-warning/10 text-warning' };
export default function SstKpis({ dashboard }) {
  const values = { ...dashboard, diasSemAcidente: dashboard.diasSemAcidente ?? '—' };
  return <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{ITEMS.map(({ key, label, icon: Icon, tone, suffix }) => <div key={key} className={`rounded-lg border-2 p-4 ${TONES[tone]}`}><Icon className="mb-3 h-6 w-6" /><p className="text-xs font-medium text-muted-foreground">{label}</p><p className="mt-1 text-2xl font-bold">{values[key]}{suffix}</p></div>)}</div>;
}