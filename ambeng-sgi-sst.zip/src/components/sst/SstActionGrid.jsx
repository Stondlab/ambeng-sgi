import React from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, BarChart3, ClipboardCheck, ClipboardList, GraduationCap, HardHat, Sparkles, Stethoscope } from 'lucide-react';

const ACTIONS=[
  { to:'/inspecoes', label:'Inspecionar obra', description:'Checklist, fotos e conformidade', Icon:ClipboardCheck },
  { to:'/ocorrencias', label:'Registrar ocorrência', description:'Acidente, risco ou não conformidade', Icon:AlertTriangle },
  { to:'/epis', label:'Controlar EPIs', description:'Estoque, entregas e vencimentos', Icon:HardHat },
  { to:'/treinamentos', label:'Treinamentos', description:'Agenda, certificados e pendências', Icon:GraduationCap },
  { to:'/asos', label:'Controlar ASOs', description:'Validades e histórico por pessoa', Icon:Stethoscope },
  { to:'/formularios', label:'DDS & Documentação', description:'Formulários e pacote de auditoria', Icon:ClipboardList },
  { to:'/relatorios', label:'Emitir relatório', description:'Executivo, auditoria e investigação', Icon:BarChart3 },
  { action:'assistant', label:'Assistente SGI', description:'Riscos, ações e resumo executivo', Icon:Sparkles },
];
export default function SstActionGrid() { const cardClass="group min-h-28 rounded-xl border border-border bg-card p-4 text-left hover:border-primary/40 hover:shadow-sm"; return <section><h2 className="mb-3 text-lg font-semibold">Ações do técnico</h2><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{ACTIONS.map(({to,action,label,description,Icon})=>action==='assistant'?<button key={action} type="button" onClick={()=>window.dispatchEvent(new CustomEvent('open-sgi-assistant'))} className={cardClass}><Icon className="h-6 w-6 text-primary" /><p className="mt-3 font-semibold group-hover:text-primary">{label}</p><p className="mt-1 text-xs text-muted-foreground">{description}</p></button>:<Link key={to} to={to} className={cardClass}><Icon className="h-6 w-6 text-primary" /><p className="mt-3 font-semibold group-hover:text-primary">{label}</p><p className="mt-1 text-xs text-muted-foreground">{description}</p></Link>)}</div></section>; }