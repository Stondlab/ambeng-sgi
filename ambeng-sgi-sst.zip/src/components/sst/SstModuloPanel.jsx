import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { MODULOS_SST } from '@/lib/sstDashboard';

const GROUPS = [{ key: 'critico', label: 'Crítico', tone: 'text-destructive bg-destructive/10 border-destructive/20' }, { key: 'atencao', label: 'Atenção', tone: 'text-warning bg-warning/10 border-warning/20' }, { key: 'conforme', label: 'Conforme', tone: 'text-success bg-success/10 border-success/20' }];
export default function SstModuloPanel({ modulo, rows }) {
  const config = MODULOS_SST.find((m) => m.id === modulo);
  return <div className="space-y-4">{GROUPS.map((group) => { const items = rows.filter((r) => r.nivel === group.key); return <section key={group.key} className={`rounded-lg border p-4 ${group.tone}`}><div className="mb-3 flex items-center justify-between"><h3 className="font-semibold uppercase tracking-wide">{group.label}</h3><span className="text-lg font-bold">{items.length}</span></div><div className="space-y-2">{items.slice(0, 8).map((item) => <div key={item.id} className="flex items-center gap-3 rounded-md bg-card p-3 text-foreground"><span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{item.titulo}</span><span className="block truncate text-xs text-muted-foreground">{item.detalhe}</span></span><Button size="sm" variant="outline" asChild><Link to={config.path}>Ver</Link></Button></div>)}{!items.length && <p className="text-sm opacity-75">Nenhum item nesta classificação.</p>}</div></section>; })}</div>;
}