import React from 'react';
import { Building2 } from 'lucide-react';

export default function SstCriticalWorks({ works }) {
  return <section className="rounded-xl border border-border bg-card p-4"><h2 className="mb-3 flex items-center gap-2 text-lg font-semibold"><Building2 className="h-5 w-5 text-destructive" />Obras críticas do dia</h2><div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">{works.slice(0,6).map((work)=><div key={work.obra} className="rounded-lg border-l-4 border-l-destructive bg-destructive/5 p-3"><p className="font-semibold">{work.obra}</p><p className="mt-1 text-xs text-muted-foreground">{work.criticos} crítico(s) · {work.pendentes} pendência(s) · {work.total ? Math.round((work.conformes / work.total) * 100) : 0}% conforme</p></div>)}{!works.length && <p className="text-sm text-success">Nenhuma obra em situação crítica hoje.</p>}</div></section>;
}