import React from 'react';
import { Link } from 'react-router-dom';
import { BarChart3, CalendarRange, FileSearch } from 'lucide-react';

export default function SstReportsPanel() {
  return <div className="grid gap-4 md:grid-cols-2"><section className="rounded-xl border border-border p-4"><CalendarRange className="h-5 w-5 text-primary" /><h3 className="mt-3 font-semibold">Períodos</h3><p className="mt-1 text-sm text-muted-foreground">Mensal, trimestral e anual, com seleção por obra.</p></section><section className="rounded-xl border border-border p-4"><FileSearch className="h-5 w-5 text-primary" /><h3 className="mt-3 font-semibold">Tipos de relatório</h3><p className="mt-1 text-sm text-muted-foreground">Executivo, auditoria e investigação de ocorrências.</p></section><Link to="/relatorios" className="flex min-h-12 items-center justify-center gap-2 rounded-lg bg-primary px-4 font-medium text-primary-foreground md:col-span-2"><BarChart3 className="h-5 w-5" />Abrir central de relatórios</Link></div>;
}