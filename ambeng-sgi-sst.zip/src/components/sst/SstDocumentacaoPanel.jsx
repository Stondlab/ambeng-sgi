import React from 'react';
import { Link } from 'react-router-dom';
import { ClipboardList, FileCheck2 } from 'lucide-react';
import { usePermissoes } from '@/lib/PermissoesContext';
import { podeAcessar } from '@/lib/permissoes';
import PacoteAuditoria from '@/components/relatorios/PacoteAuditoria';

const FORMS = [
  { name:'Colaborador', description:'Cadastro e documentação do colaborador', to:'/funcionarios' },
  { name:'ASO', description:'Atestado de Saúde Ocupacional', to:'/asos' },
  { name:'EPI', description:'Entrega de Equipamento de Proteção Individual', to:'/epis' },
  { name:'DDS', description:'Diálogo Diário de Segurança', to:'/funcionarios' },
  { name:'Integração', description:'Integração de novo colaborador', to:'/funcionarios' },
  { name:'Inspeção', description:'Inspeções de segurança e máquinas', to:'/inspecoes' },
];
export default function SstDocumentacaoPanel({ data }) {
  const { perfilEfetivo } = usePermissoes(); const forms = FORMS.filter((form) => podeAcessar(perfilEfetivo, form.to));
  return <div className="space-y-6"><div><div className="mb-4 flex items-center gap-3"><span className="rounded-lg bg-primary/10 p-2 text-primary"><ClipboardList className="h-5 w-5" /></span><div><h3 className="font-semibold">Formulários SGI</h3><p className="text-sm text-muted-foreground">DDS e documentação operacional do SST.</p></div></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{forms.map((form) => <Link key={form.name} to={form.to} className="group min-h-28 rounded-xl border border-border bg-card p-4 hover:border-primary/40 hover:bg-muted/30"><FileCheck2 className="h-5 w-5 text-primary" /><h4 className="mt-3 font-semibold group-hover:text-primary">{form.name}</h4><p className="mt-1 text-sm text-muted-foreground">{form.description}</p></Link>)}</div></div><PacoteAuditoria data={data} /></div>;
}