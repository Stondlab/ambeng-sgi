import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { differenceInCalendarDays, parseISO, format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useSstData } from '@/hooks/useSstEntitiesData';
import { fmt } from '@/lib/sst';
import { Stethoscope, GraduationCap, HardHat, FileWarning, ArrowRight } from 'lucide-react';

const TABS = [
  { key: 'hoje', label: 'Hoje', min: 0, max: 0 },
  { key: '7', label: '7 dias', min: 0, max: 7 },
  { key: '15', label: '15 dias', min: 0, max: 15 },
  { key: '30', label: '30 dias', min: 0, max: 30 },
];

export default function AgendaSST() {
  const data = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis', 'inspecoes']);
  const [tab, setTab] = useState('hoje');
  const cfg = TABS.find((t) => t.key === tab);

  const items = useMemo(() => {
    if (!data) return [];
    const nome = (id) => data.funcionarios.find((f) => f.id === id)?.nome || '—';
    const ev = [];
    const within = (d) => {
      if (!d) return false;
      const days = differenceInCalendarDays(parseISO(d), new Date());
      return days >= cfg.min && days <= cfg.max;
    };
    data.asos.filter((a) => within(a.data_validade)).forEach((a) => ev.push({ tipo: 'ASO', icon: Stethoscope, label: `ASO ${a.tipo || ''}`, func: nome(a.funcionario_id), data: a.data_validade, fid: a.funcionario_id }));
    data.treinamentos.filter((t) => within(t.data_validade)).forEach((t) => ev.push({ tipo: 'Treinamento', icon: GraduationCap, label: t.norma_curso || t.nome_curso || 'Treinamento', func: nome(t.funcionario_id), data: t.data_validade, fid: t.funcionario_id }));
    data.epis.filter((e) => within(e.data_validade)).forEach((e) => ev.push({ tipo: 'EPI', icon: HardHat, label: `EPI ${e.item || ''}`, func: nome(e.funcionario_id), data: e.data_validade, fid: e.funcionario_id }));
    data.inspecoes.filter((i) => within(i.data_proxima)).forEach((i) => ev.push({ tipo: 'Inspeção', icon: FileWarning, label: `Inspeção ${i.tipo || ''}`, func: i.obra || '—', data: i.data_proxima }));
    return ev.sort((a, b) => (a.data < b.data ? -1 : 1));
  }, [data, cfg]);

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <h3 className="font-semibold text-[#0b2545]">Agenda SST</h3>
        <div className="flex gap-1">
          {TABS.map((t) => (
            <button key={t.key} onClick={() => setTab(t.key)} className={`text-xs px-3 py-1.5 rounded-full border transition ${tab === t.key ? 'bg-[#0b2545] text-white border-[#0b2545]' : 'bg-white text-slate-600 border-slate-200 hover:border-amber-400'}`}>{t.label}</button>
          ))}
        </div>
      </div>
      {!data ? <p className="text-sm text-slate-400">Carregando...</p> : items.length === 0 ? (
        <p className="text-sm text-slate-400 py-6 text-center">Nenhum vencimento ou inspeção {cfg.min === 0 && cfg.max === 0 ? 'para hoje' : `nos próximos ${cfg.max} dias`}.</p>
      ) : (
        <div className="space-y-1.5">
          {items.map((e, i) => {
            const Icon = e.icon;
            const to = e.fid ? `/funcionarios/${e.fid}` : '/formularios';
            const dias = differenceInCalendarDays(parseISO(e.data), new Date());
            return (
              <div key={i} className="flex items-center gap-2 border border-slate-100 rounded-lg p-2">
                <Icon className="w-4 h-4 text-slate-400 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-700 truncate">{e.label}</p>
                  <p className="text-xs text-slate-400">{e.func} · {fmt(e.data)}{e.data && ` · ${format(parseISO(e.data), 'EEE', { locale: ptBR })}`}</p>
                </div>
                <span className="text-[11px] text-slate-400 shrink-0">{dias === 0 ? 'hoje' : `${dias}d`}</span>
                <Link to={to} className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-md text-[#0b2545] hover:bg-slate-100 shrink-0">Abrir <ArrowRight className="w-3 h-3" /></Link>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}