import React from 'react';
import { Check, MonitorCog, Moon, Palette, Sun } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useTheme } from '@/lib/ThemeContext';

const OPTIONS = [
  { value:'claro', label:'Claro', description:'Usar sempre o tema claro', Icon:Sun },
  { value:'escuro', label:'Escuro', description:'Usar sempre o tema escuro', Icon:Moon },
  { value:'automatico', label:'Automático', description:'Seguir o sistema operacional', Icon:MonitorCog },
];
export default function ThemeWidget() {
  const { preference, setPreference } = useTheme();
  return <Popover><PopoverTrigger asChild><button className="flex h-10 w-10 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground" title="Aparência" aria-label="Abrir opções de aparência"><Palette className="h-5 w-5" /></button></PopoverTrigger><PopoverContent align="end" className="w-80 border-border bg-popover p-2 text-popover-foreground"><div className="px-2 py-2"><h2 className="font-semibold text-foreground">Aparência</h2><p className="text-xs text-muted-foreground">Escolha o tema do sistema.</p></div><div className="space-y-1">{OPTIONS.map(({ value, label, description, Icon }) => { const selected=preference===value; return <button key={value} onClick={() => setPreference(value)} className={`flex min-h-14 w-full items-center gap-3 rounded-lg px-3 text-left transition-colors ${selected ? 'bg-primary/15 text-primary' : 'text-foreground hover:bg-muted'}`}><Icon className="h-5 w-5 shrink-0" /><span className="min-w-0 flex-1"><span className="block text-sm font-medium">{label}</span><span className="block text-xs text-muted-foreground">{description}</span></span>{selected && <Check className="h-4 w-4 shrink-0" />}</button>; })}</div></PopoverContent></Popover>;
}