import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import { ThemeProvider } from '@/lib/ThemeContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
// Add page imports here
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Layout from '@/components/Layout';
import { PermissoesProvider } from '@/lib/PermissoesContext';
import Dashboard from '@/pages/Dashboard';
import DashboardSST from '@/pages/SST/DashboardSST';
import FuncionariosPage from '@/pages/Pessoas/FuncionariosPage';
import ProntuarioPage from '@/pages/Pessoas/ProntuarioPage';
import FuncionarioDetail from '@/pages/FuncionarioDetail';
import Relatorios from '@/pages/Relatorios';
import Inteligencia from '@/pages/Inteligencia';
import Formularios from '@/pages/Formularios';
import Configuracoes from '@/pages/Configuracoes';
import Treinamentos from '@/pages/Treinamentos';
import EPIs from '@/pages/EPIs';
import Ocorrencias from '@/pages/Ocorrencias';
import Inspecoes from '@/pages/Inspecoes';
import PainelQuadro from '@/pages/PainelQuadro';
import PainelCalendario from '@/pages/PainelCalendario';
import AsosConsolidado from '@/pages/AsosConsolidado';
import Almoxarifado from '@/pages/Almoxarifado';
import AdminUsuarios from '@/pages/admin/AdminUsuarios';
import AdminPerfis from '@/pages/admin/AdminPerfis';
import AdminPermissoes from '@/pages/admin/AdminPermissoes';
import Obras from '@/pages/Obras';
import ObraDetail from '@/pages/ObraDetail';
import Ponto from '@/pages/Ponto';
import Financeiro from '@/pages/Financeiro';
import VisaoFiscal from '@/pages/VisaoFiscal';
import Encargos from '@/pages/rh/Encargos';
import ParametrosCusto from '@/pages/rh/ParametrosCusto';
import FechamentoMensal from '@/pages/rh/FechamentoMensal';
import CustosMaoObra from '@/pages/rh/CustosMaoObra';
import DashboardFinanceiroUnificado from '@/pages/DashboardFinanceiroUnificado';
import DashboardFinanceiroConsolidado from '@/pages/Financeiro/DashboardFinanceiro';
import AuditoriaIntegracaoFinanceira from '@/pages/AuditoriaIntegracaoFinanceira';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <PermissoesProvider>
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/painel/quadro" element={<PainelQuadro />} />
          <Route path="/operacoes" element={<PainelQuadro />} />
          <Route path="/painel/calendario" element={<PainelCalendario />} />
          <Route path="/painel/inteligencia" element={<Navigate to="/sst" replace />} />
          <Route path="/pessoas" element={<FuncionariosPage />} />
          <Route path="/funcionarios" element={<FuncionariosPage />} />
          <Route path="/funcionarios/:id" element={<FuncionarioDetail />} />
          <Route path="/prontuario/:id" element={<ProntuarioPage />} />
          <Route path="/colaboradores/ponto" element={<Ponto />} />
          <Route path="/colaboradores/ponto/importacao" element={<Navigate to="/colaboradores/ponto" replace />} />
          <Route path="/colaboradores/horas-extras" element={<Navigate to="/colaboradores/ponto" replace />} />
          <Route path="/rh/encargos" element={<Encargos />} />
          <Route path="/rh/parametros-custo" element={<ParametrosCusto />} />
          <Route path="/rh/apontamento" element={<Navigate to="/colaboradores/ponto" replace />} />
          <Route path="/rh/banco-horas" element={<Navigate to="/colaboradores/ponto" replace />} />
          <Route path="/rh/fechamento" element={<FechamentoMensal />} />
          <Route path="/financeiro/mao-de-obra" element={<CustosMaoObra />} />
          <Route path="/treinamentos" element={<Treinamentos />} />
          <Route path="/epis" element={<EPIs />} />
          <Route path="/epis/almoxarifado" element={<Navigate to="/obras/almoxarifado" replace />} />
          <Route path="/obras/almoxarifado" element={<Almoxarifado />} />
          <Route path="/ocorrencias" element={<Ocorrencias />} />
          <Route path="/inspecoes" element={<Inspecoes />} />
          <Route path="/asos" element={<AsosConsolidado />} />
          <Route path="/relatorios" element={<Relatorios />} />
          <Route path="/auditoria" element={<Navigate to="/sst#eventos" replace />} />
          <Route path="/relatorios/auditoria" element={<Navigate to="/sst#eventos" replace />} />
          <Route path="/obras" element={<Obras />} />
          <Route path="/obras/:id" element={<ObraDetail />} />
          <Route path="/financeiro" element={<DashboardFinanceiroConsolidado />} />
          <Route path="/financeiro-dashboard" element={<DashboardFinanceiroConsolidado />} />
          <Route path="/financeiro/despesas" element={<Financeiro />} />
          <Route path="/financeiro/receitas" element={<Financeiro />} />
          <Route path="/financeiro/obras" element={<Navigate to="/saude-obras" replace />} />
          <Route path="/financeiro/cartoes" element={<Financeiro />} />
          <Route path="/financeiro/fornecedores" element={<Financeiro />} />
          <Route path="/financeiro/fiscal" element={<VisaoFiscal />} />
          <Route path="/financeiro/auditoria-integracao" element={<AuditoriaIntegracaoFinanceira />} />

          <Route path="/sst" element={<DashboardSST />} />
          <Route path="/dashboard-sst" element={<DashboardSST />} />
          <Route path="/dashboards/executivo" element={<Navigate to="/sst" replace />} />
          <Route path="/dashboards/custo-obra" element={<Navigate to="/saude-obras" replace />} />
          <Route path="/dashboards/financeiro" element={<DashboardFinanceiroConsolidado />} />
          <Route path="/saude-obras" element={<DashboardFinanceiroUnificado />} />
          <Route path="/saude-obras/:id" element={<DashboardFinanceiroUnificado />} />
          <Route path="/inteligencia" element={<Navigate to="/sst" replace />} />
          <Route path="/inteligencia/indicadores" element={<Navigate to="/sst" replace />} />
          <Route path="/inteligencia/resumo" element={<Navigate to="/sst" replace />} />
          <Route path="/inteligencia/rankings" element={<Navigate to="/sst" replace />} />
          <Route path="/inteligencia/graficos" element={<Navigate to="/sst" replace />} />
          <Route path="/inteligencia/motor" element={<Inteligencia />} />
          <Route path="/inteligencia/auditoria" element={<Inteligencia />} />
          <Route path="/inteligencia/assistente" element={<Inteligencia />} />
          <Route path="/inteligencia/recomendacoes" element={<Inteligencia />} />
          <Route path="/inteligencia/alertas" element={<Inteligencia />} />
          <Route path="/formularios" element={<Formularios />} />
          <Route path="/configuracoes" element={<Configuracoes />} />
          <Route path="/admin/usuarios" element={<AdminUsuarios />} />
          <Route path="/admin/perfis" element={<AdminPerfis />} />
          <Route path="/admin/permissoes" element={<AdminPermissoes />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
      </Routes>
    </PermissoesProvider>
  );
};


function App() {

  return (
    <AuthProvider>
      <ThemeProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
      </ThemeProvider>
    </AuthProvider>
  )
}

export default App