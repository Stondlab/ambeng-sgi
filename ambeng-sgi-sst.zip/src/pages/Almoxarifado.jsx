import React, { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Boxes, ClipboardList, Package, Plus, Wrench } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import PageHeader from '@/components/PageHeader';
import { usePerm } from '@/hooks/usePerm';
import EstoqueTable from '@/components/almoxarifado/EstoqueTable';
import EstoqueForm from '@/components/almoxarifado/EstoqueForm';
import RequisicaoForm from '@/components/almoxarifado/RequisicaoForm';
import RequisicoesTable from '@/components/almoxarifado/RequisicoesTable';

const ABAS = [{ id: 'EPI', label: 'Estoque EPIs', Icon: Package }, { id: 'Ferramenta', label: 'Estoque Ferramentas', Icon: Wrench }, { id: 'Material', label: 'Estoque Materiais', Icon: Boxes }, { id: 'Requisicoes', label: 'Requisições', Icon: ClipboardList }];
export default function Almoxarifado() {
  const [dados, setDados] = useState({ epis: [], estoque: [], requisicoes: [], obras: [] });
  const [aba, setAba] = useState('EPI');
  const [formTipo, setFormTipo] = useState(null);
  const [requisicaoOpen, setRequisicaoOpen] = useState(false);
  const perm = usePerm('almoxarifado');
  const load = async () => { const [epis, estoque, requisicoes, obras] = await Promise.all([base44.entities.EstoqueEPI.list('nome', 500), base44.entities.EstoqueAlmoxarifado.list('nome', 500), base44.entities.RequisicoesAlmoxarifado.list('-created_date', 500), base44.entities.Obras.list('nome', 500)]); setDados({ epis, estoque, requisicoes, obras }); };
  useEffect(() => { load(); }, []);
  const itens = useMemo(() => aba === 'EPI' ? dados.epis : dados.estoque.filter((item) => item.tipo === aba), [aba, dados]);
  const abaixoMinimo = [...dados.epis.map((i) => ({ atual: i.estoque_atual, minimo: i.estoque_minimo })), ...dados.estoque.map((i) => ({ atual: i.quantidade_atual, minimo: i.quantidade_minima }))].filter((i) => Number(i.atual) <= Number(i.minimo)).length;
  const quantidade = async (item, delta) => { const epi = aba === 'EPI'; const atual = epi ? item.estoque_atual : item.quantidade_atual; const entity = epi ? base44.entities.EstoqueEPI : base44.entities.EstoqueAlmoxarifado; await entity.update(item.id, { [epi ? 'estoque_atual' : 'quantidade_atual']: Math.max(0, Number(atual || 0) + delta) }); load(); };
  const excluir = async (item) => { if (!window.confirm('Excluir este registro do almoxarifado?')) return; await (aba === 'EPI' ? base44.entities.EstoqueEPI : base44.entities.EstoqueAlmoxarifado).delete(item.id); load(); };
  const excluirReq = async (item) => { if (!window.confirm('Excluir esta requisição?')) return; await base44.entities.RequisicoesAlmoxarifado.delete(item.id); load(); };
  return <div className="space-y-5">
    <PageHeader title="Almoxarifado de Obras" subtitle="Controle de EPIs, ferramentas, materiais e requisições por obra." action={perm.podeCriar && <Button onClick={() => aba === 'Requisicoes' ? setRequisicaoOpen(true) : setFormTipo(aba)}><Plus className="h-4 w-4" />{aba === 'Requisicoes' ? 'Nova requisição' : 'Novo item'}</Button>} />
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-3"><Resumo Icon={Package} valor={dados.epis.length + dados.estoque.length} label="Itens cadastrados" /><Resumo Icon={AlertTriangle} valor={abaixoMinimo} label="Abaixo do mínimo" alerta /><Resumo Icon={ClipboardList} valor={dados.requisicoes.filter((r) => r.status === 'Pendente').length} label="Requisições pendentes" /></div>
    <div className="flex gap-2 overflow-x-auto pb-1">{ABAS.map(({ id, label, Icon }) => <button key={id} onClick={() => setAba(id)} className={`flex min-h-11 shrink-0 items-center gap-2 rounded-lg border px-4 text-sm font-medium ${aba === id ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-muted-foreground hover:bg-muted'}`}><Icon className="h-4 w-4" />{label}</button>)}</div>
    {aba === 'Requisicoes' ? <RequisicoesTable itens={dados.requisicoes} podeEditar={perm.podeEditar} podeExcluir={perm.podeExcluir} onStatus={async (item, status) => { await base44.entities.RequisicoesAlmoxarifado.update(item.id, { status }); load(); }} onExcluir={excluirReq} /> : <EstoqueTable itens={itens} tipo={aba} podeEditar={perm.podeEditar} podeExcluir={perm.podeExcluir} onQuantidade={quantidade} onExcluir={excluir} />}
    <EstoqueForm tipo={formTipo || 'EPI'} obras={dados.obras} open={!!formTipo} onClose={() => setFormTipo(null)} onSaved={() => { setFormTipo(null); load(); }} />
    <RequisicaoForm obras={dados.obras} open={requisicaoOpen} onClose={() => setRequisicaoOpen(false)} onSaved={() => { setRequisicaoOpen(false); load(); }} />
  </div>;
}
function Resumo({ Icon, valor, label, alerta }) { return <div className="flex items-center gap-3 rounded-lg border border-border bg-card p-4"><Icon className={`h-7 w-7 ${alerta ? 'text-destructive' : 'text-primary'}`} /><div><p className="text-2xl font-bold text-foreground">{valor}</p><p className="text-xs text-muted-foreground">{label}</p></div></div>; }