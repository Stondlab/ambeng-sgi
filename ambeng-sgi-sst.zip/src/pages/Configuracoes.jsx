import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import PageHeader from '@/components/PageHeader';
import AdminUsuarios from '@/pages/admin/AdminUsuarios';
import AdminPerfis from '@/pages/admin/AdminPerfis';
import AdminPermissoes from '@/pages/admin/AdminPermissoes';
import {
  Users, ShieldCheck, Lock, Building2, HardHat,
  UserCog, Settings, Database, Bell, UploadCloud, SearchCheck,
} from 'lucide-react';
import ObrasConfig from '@/components/config/ObrasConfig';
import EmpresasPage from '@/components/config/EmpresasPage';
import CargosPage from '@/components/config/CargosPage';
import TiposASOPage from '@/components/config/TiposASOPage';
import TiposEPIPage from '@/components/config/TiposEPIPage';
import TiposOcorrenciaPage from '@/components/config/TiposOcorrenciaPage';
import ImportacaoDados from '@/pages/ImportacaoDados';
import Encargos from '@/pages/rh/Encargos';
import ConfigAdmNav from '@/components/config/ConfigAdmNav';

const SECOES = [
  { id: 'usuarios', label: 'Usuários', icon: Users, pronto: true },
  { id: 'perfis', label: 'Perfis', icon: ShieldCheck, pronto: true },
  { id: 'permissoes', label: 'Permissões', icon: Lock, pronto: true },
  { id: 'empresas', label: 'Empresas', icon: Building2, pronto: true },
  { id: 'funcoes', label: 'Funções', icon: UserCog, pronto: true },
  { id: 'encargos', label: 'Encargos', icon: HardHat, pronto: true },
  { id: 'importacao', label: 'Importação', icon: UploadCloud, pronto: true },
  { id: 'auditoria', label: 'Auditoria & Evidências', icon: SearchCheck, pronto: true, to: '/auditoria' },
  { id: 'parametros', label: 'Parâmetros', icon: Settings },
  { id: 'backup', label: 'Backup', icon: Database },
  { id: 'notificacoes', label: 'Notificações', icon: Bell, description: 'Configuração de email, SMS e alertas.' },
];

const GRUPOS_CONFIG = [
  { label: 'Usuários & Acesso', items: SECOES.filter((s) => ['usuarios','perfis','permissoes'].includes(s.id)) },
  { label: 'Empresa & Cadastros', items: SECOES.filter((s) => ['empresas','funcoes','encargos','importacao'].includes(s.id)) },
  { label: 'Sistema & Segurança', items: SECOES.filter((s) => ['auditoria','parametros','backup'].includes(s.id)) },
  { label: 'Notificações', items: SECOES.filter((s) => s.id === 'notificacoes') },
];

export default function Configuracoes() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const tabParam = searchParams.get('tab');
  const [secao, setSecao] = useState(tabParam && SECOES.some((s) => s.id === tabParam) ? tabParam : 'usuarios');
  const ativa = SECOES.find((s) => s.id === secao);

  useEffect(() => {
    if (tabParam && SECOES.some((s) => s.id === tabParam) && tabParam !== secao) {
      setSecao(tabParam);
    }
  }, [tabParam, secao]);

  return (
    <div className="flex flex-col lg:flex-row gap-4">
      <aside className="lg:w-60 shrink-0">
        <div className="rounded-xl border border-border bg-card p-2 lg:sticky lg:top-20">
          <div className="px-2 py-2 mb-1 border-b border-slate-100">
            <h1 className="text-base font-semibold text-foreground">Configurações · ADM</h1>
            <p className="text-[11px] text-muted-foreground">11 itens administrativos</p>
          </div>
          <ConfigAdmNav groups={GRUPOS_CONFIG} active={secao} onSelect={(item) => item.to ? navigate(item.to) : setSecao(item.id)} />
        </div>
      </aside>

      <div className="flex-1 min-w-0">
        {secao === 'usuarios' && <AdminUsuarios />}
        {secao === 'perfis' && <AdminPerfis />}
        {secao === 'permissoes' && <AdminPermissoes />}
        {secao === 'empresas' && <EmpresasPage />}
        {secao === 'importacao' && <ImportacaoDados />}
        {secao === 'obras' && <ObrasConfig />}
        {secao === 'funcoes' && <CargosPage />}
        {secao === 'encargos' && <Encargos />}
        {secao === 'cargos' && <CargosPage />}
        {secao === 'tipos-aso' && <TiposASOPage />}
        {secao === 'tipos-epi' && <TiposEPIPage />}
        {secao === 'tipos-ocorrencia' && <TiposOcorrenciaPage />}
        {!ativa?.pronto && (
          <div>
            <PageHeader title={`Configurações · ${ativa?.label}`} subtitle={ativa?.description || 'Módulo em preparação.'} />
            <div className="bg-slate-50 border border-dashed border-slate-200 rounded-xl p-10 text-center text-slate-400">
              Este módulo ainda não está disponível. Estrutura reservada para integração futura.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}