import React, { useMemo, useState } from 'react';
import { startOfMonth, endOfMonth, eachDayOfInterval, format, parseISO, isSameDay, addMonths, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useSstData } from '@/hooks/useSstEntitiesData';
import { getStatus, fmt } from '@/lib/sst';
import { ChevronLeft, ChevronRight, CalendarDays } from 'lucide-react';

const WEEK = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

function colorFor(item, cat) {
  const s = getStatus(item.data_validade);
  if (s === 'Vencido') return '#dc2626';
  if (s === 'A vencer' && dias15(item.data_validade)) return '#ea580c';
  if (cat === 'treinamento') return '#2563eb';
  if (cat === 'aso') return '#16a34a';
  if (cat === 'epi') return '#64748b';
  return '#0b2545';
}
function dias15(d) {
  if (!d) return false;
  const days = (parseISO(d) - new Date()) / 86400000;
  return days <= 15;
}

export default function PainelCalendario() {
  const data = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis']);
  const [cursor, setCursor] = useState(new Date());
  const [selDay, setSelDay] = useState(null);

  const events = useMemo(() => {
    if (!data) return [];
    const nome = (id) => data.funcionarios.find((f) => f.id === id)?.nome || '—';
    const ev = [];
    data.asos.filter((a) => a.data_validade).forEach((a) => ev.push({ date: a.data_validade, cat: 'aso', label: `ASO ${a.tipo || ''}`, func: nome(a.funcionario_id) }));
    data.treinamentos.filter((t) => t.data_validade).forEach((t) => ev.push({ date: t.data_validade, cat: 'treinamento', label: t.norma_curso || 'Treinamento', func: nome(t.funcionario_id) }));
    data.epis.filter((e) => e.data_validade).forEach((e) => ev.push({ date: e.data_validade, cat: 'epi', label: `EPI ${e.item || ''}`, func: nome(e.funcionario_id) }));
    return ev;
  }, [data]);

  if (!data) return <p className="text-slate-400">Carregando calendário...</p>;

  const monthStart = startOfMonth(cursor);
  const monthEnd = endOfMonth(cursor);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const offset = monthStart.getDay();
  const cells = [...Array(offset).fill(null), ...days];
  const evByDay = (d) => events.filter((e) => isSameDay(parseISO(e.date), d));

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-semibold text-[#0b2545]">Calendário SST</h1>
          <p className="text-sm text-slate-500">Vencimentos por dia — toque para ver os detalhes.</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setCursor(subMonths(cursor, 1))} className="min-w-[44px] min-h-[44px] rounded-lg border border-slate-200 bg-white flex items-center justify-center hover:bg-slate-50"><ChevronLeft className="w-5 h-5" /></button>
          <span className="text-sm font-semibold text-[#0b2545] w-40 text-center capitalize">{format(cursor, 'MMMM yyyy', { locale: ptBR })}</span>
          <button onClick={() => setCursor(addMonths(cursor, 1))} className="min-w-[44px] min-h-[44px] rounded-lg border border-slate-200 bg-white flex items-center justify-center hover:bg-slate-50"><ChevronRight className="w-5 h-5" /></button>
        </div>
      </div>

      {/* Legend */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 mb-4 flex flex-wrap gap-4 text-xs">
        <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full" style={{ background: '#dc2626' }} />Vencido</span>
        <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full" style={{ background: '#ea580c' }} />Vencendo em até 15 dias</span>
        <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full" style={{ background: '#2563eb' }} />Treinamento NR</span>
        <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full" style={{ background: '#16a34a' }} />ASO</span>
        <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full" style={{ background: '#64748b' }} />EPI</span>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="grid grid-cols-7 bg-slate-50 border-b border-slate-200">
          {WEEK.map((w) => <div key={w} className="text-center text-xs font-semibold text-slate-500 py-2">{w}</div>)}
        </div>
        <div className="grid grid-cols-7">
          {cells.map((d, i) => {
            if (!d) return <div key={i} className="min-h-[64px] sm:min-h-[96px] bg-slate-50/50 border-b border-r border-slate-100" />;
            const evs = evByDay(d);
            const isToday = isSameDay(d, new Date());
            const isSel = selDay && isSameDay(d, selDay);
            return (
              <button
                key={i}
                onClick={() => setSelDay(d)}
                className={`min-h-[64px] sm:min-h-[96px] border-b border-r border-slate-100 p-1.5 text-left align-top flex flex-col gap-1 hover:bg-slate-50 ${isSel ? 'ring-2 ring-amber-400 ring-inset' : ''}`}
              >
                <span className={`text-xs font-medium ${isToday ? 'bg-[#0b2545] text-white rounded-full w-6 h-6 flex items-center justify-center' : 'text-slate-600'}`}>{format(d, 'd')}</span>
                <div className="flex flex-wrap gap-1">
                  {evs.slice(0, 4).map((e, j) => (
                    <span key={j} className="w-2 h-2 rounded-full" style={{ background: colorFor(e, e.cat) }} title={e.label} />
                  ))}
                  {evs.length > 4 && <span className="text-[10px] text-slate-400">+{evs.length - 4}</span>}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {selDay && (
        <div className="mt-4 bg-white border border-slate-200 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <CalendarDays className="w-5 h-5 text-[#0b2545]" />
            <h3 className="font-semibold text-[#0b2545] capitalize">{format(selDay, "dd 'de' MMMM", { locale: ptBR })}</h3>
          </div>
          {evByDay(selDay).length === 0 ? (
            <p className="text-sm text-slate-400">Nenhum vencimento neste dia.</p>
          ) : (
            <div className="space-y-2">
              {evByDay(selDay).map((e, i) => (
                <div key={i} className="flex items-center gap-3 border border-slate-100 rounded-lg p-2.5">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: colorFor(e, e.cat) }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-slate-700 truncate">{e.label}</p>
                    <p className="text-xs text-slate-400">{e.func} · vence {fmt(e.date)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}