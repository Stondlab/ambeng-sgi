import React, { useEffect, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useSstData } from '@/hooks/useSstEntitiesData';
import { useAuth } from '@/lib/AuthContext';
import { usePermissoes } from '@/lib/PermissoesContext';
import { isAdministrador, isTecnico, pode } from '@/lib/permissoes';
import { statsObra, STATUS_OBRA } from '@/lib/obras';
import { obrasDisponiveisNoPeriodo } from '@/lib/obraDisponibilidade';
import { registrarAcao } from '@/lib/historico';
import { Building2, Users, KanbanSquare, AlertOctagon, Plus, Pencil, Trash2, Eye, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import ObraForm from '@/components/obras/ObraForm';

export default function Obras() {
  const navigate = useNavigate();
  const data = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis', 'inspecoes', 'dds', 'ocorrencias', 'pendencias', 'documentos']);
  const { user } = useAuth();
  const { perfilEfetivo } = usePermissoes();
  const [obras, setObras] = useState([]);
  const [demandas, setDemandas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editObra, setEditObra] = useState(null);
  const [filtros, setFiltros] = useState({ busca: '', status: '', responsavel: '', inicio: '', fim: '' });

  const perfil = perfilEfetivo;
  const podeCriar = isAdministrador(perfil) || pode(perfil, 'obras', 'criar');
  const podeEditar = isAdministrador(perfil) || pode(perfil, 'obras', 'editar');
  const podeExcluir = isAdministrador(perfil);
  const eu = user?.full_name || '';

  const load = async () => {
    setLoading(true);
    try {
      const [obs, dem] = await Promise.all([
        base44.entities.Obras.list('-created_date', 500),
        base44.entities.Demandas.list('-created_date', 500),
      ]);
      setDemandas(dem);
      let lista = obs || [];
      // Técnico: somente obras que responde ou com tarefas suas
      if (isTecnico(perfil)) {
        lista = lista.filter((o) => eu && ((o.responsavel || '') === eu || dem.some((d) => (d.responsavel || '') === eu && (d.obra || '') === o.nome)));
      }
      setObras(lista);
    } catch { /* ignore */ }
    setLoading(false);
  };
  useEffect(() => { load(); }, [perfil]);

  const responsaveis = useMemo(() => [...new Set(obras.map((o) => o.responsavel).filter(Boolean))], [obras]);

  const filtradas = useMemo(() => {
    const hoje = new Date().toISOString().slice(0, 10);
    const disponiveis = obrasDisponiveisNoPeriodo(obras, filtros.inicio || hoje, filtros.fim || hoje);
    return disponiveis.filter((o) => {
      if (filtros.busca) {
        const q = filtros.busca.toLowerCase();
        const hit = (o.nome || '').toLowerCase().includes(q) || (o.codigo || '').toLowerCase().includes(q) || (o.cliente || '').toLowerCase().includes(q);
        if (!hit) return false;
      }
      if (filtros.status && o.status !== filtros.status) return false;
      if (filtros.responsavel && o.responsavel !== filtros.responsavel) return false;
      return true;
    });
  }, [obras, filtros]);

  const abrirNova = () => { setEditObra(null); setFormOpen(true); };
  const abrirEdit = (o) => { setEditObra(o); setFormOpen(true); };
  const onSaved = async () => {
    await registrarAcao(editObra ? 'Editou obra' : 'Cadastrou obra', editObra?.nome || '', user, 'Obra', editObra?.nome || '');
    setFormOpen(false); await load();
  };

  const excluir = async (o) => {
    if (!confirm(`Tem certeza que deseja excluir a obra "${o.nome}"?\n\nA exclusão poderá afetar os registros vinculados à obra. A obra será inativada (histórico e auditoria mantidos).`)) return;
    await base44.entities.Obras.update(o.id, { ativa: false, status: 'Cancelada' });
    await registrarAcao('Excluiu/Inativou obra', o.nome, user, 'Obra', o.nome);
    load();
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <div>
          <h1 className="text-2xl font-semibold text-[#0b2545]">Obras</h1>
          <p className="text-sm text-slate-500">Centro de gestão de obras — colaboradores, tarefas e pendências em cada canteiro.</p>
        </div>
        {podeCriar && <Button onClick={abrirNova} className="bg-[#0b2545]"><Plus className="w-4 h-4" /> Nova Obra</Button>}
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-3 mb-4 flex flex-wrap items-center gap-2">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <Input value={filtros.busca} onChange={(e) => setFiltros({ ...filtros, busca: e.target.value })} placeholder="Buscar por nome, código ou empresa..." className="max-w-xs pl-8" />
        </div>
        <select value={filtros.status} onChange={(e) => setFiltros({ ...filtros, status: e.target.value })} className="h-11 rounded-lg border border-slate-200 bg-white px-3 text-sm">
          <option value="">Todos os status</option>
          {STATUS_OBRA.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <select value={filtros.responsavel} onChange={(e) => setFiltros({ ...filtros, responsavel: e.target.value })} className="h-11 rounded-lg border border-slate-200 bg-white px-3 text-sm">
          <option value="">Todos os responsáveis</option>
          {responsaveis.map((r) => <option key={r} value={r}>{r}</option>)}
        </select>
        <label className="flex items-center gap-1.5 text-xs text-slate-500">De <input type="date" value={filtros.inicio} onChange={(e) => setFiltros({ ...filtros, inicio: e.target.value })} className="h-11 rounded-lg border border-slate-200 px-2 text-sm" /></label>
        <label className="flex items-center gap-1.5 text-xs text-slate-500">até <input type="date" value={filtros.fim} onChange={(e) => setFiltros({ ...filtros, fim: e.target.value })} className="h-11 rounded-lg border border-slate-200 px-2 text-sm" /></label>
      </div>

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-40 rounded-xl bg-slate-100 animate-pulse" />)}</div>
      ) : filtradas.length === 0 ? (
        <p className="text-sm text-slate-400 py-8 text-center">Nenhuma obra encontrada. {podeCriar && 'Clique em “Nova Obra” para começar.'}</p>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtradas.map((o) => {
            const s = data ? statsObra(o.nome, data, demandas) : { ativos: 0, tarefas: 0, atrasadas: 0, total: 0 };
            return (
              <div key={o.id} className="bg-white border border-slate-200 rounded-xl p-4 hover:shadow-card-hover transition-shadow">
                <button onClick={() => navigate(`/obras/${o.id}`)} className="w-full text-left">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-9 h-9 rounded-lg bg-[#0b2545]/10 flex items-center justify-center"><Building2 className="w-5 h-5 text-[#0b2545]" /></div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-[#0b2545] truncate">{o.nome}</h3>
                      <p className="text-xs text-slate-500 truncate">{o.cliente || '—'} · <span className="text-[11px] px-1.5 py-0.5 rounded bg-slate-100">{o.status}</span></p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-y-2 text-sm text-slate-600">
                    <div className="flex items-center gap-1.5"><Users className="w-4 h-4 text-slate-400" />{s.ativos} ativos</div>
                    <div className="flex items-center gap-1.5"><KanbanSquare className="w-4 h-4 text-slate-400" />{s.tarefas} ações</div>
                    <div className="flex items-center gap-1.5"><AlertOctagon className="w-4 h-4 text-slate-400" />{s.atrasadas} atrasadas</div>
                    <div className="flex items-center gap-1.5"><Building2 className="w-4 h-4 text-slate-400" />{s.total} total</div>
                  </div>
                </button>
                <div className="flex items-center gap-1.5 mt-3 pt-3 border-t border-slate-100">
                  <Button variant="outline" size="sm" onClick={() => navigate(`/obras/${o.id}`)}><Eye className="w-3.5 h-3.5" /> Visualizar</Button>
                  {podeEditar && <Button variant="ghost" size="sm" onClick={() => abrirEdit(o)}><Pencil className="w-3.5 h-3.5" /> Editar</Button>}
                  {podeExcluir && <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700" onClick={() => excluir(o)}><Trash2 className="w-3.5 h-3.5" /> Excluir</Button>}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <ObraForm open={formOpen} onOpenChange={setFormOpen} obra={editObra} onSaved={onSaved} />
    </div>
  );
}