import JornadaCentral from '@/pages/JornadaCentral';

export default function Ponto() {
  return <JornadaCentral />;
}