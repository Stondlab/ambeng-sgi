import React, { useState } from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { useSstData } from '@/hooks/useSstEntitiesData';
import SemoforoConformidade from '@/components/relatorios/SemoforoConformidade';
import ResumoInteligente from '@/components/relatorios/ResumoInteligente';
import RecomendacoesInteligentes from '@/components/relatorios/RecomendacoesInteligentes';
import AlertasSistema from '@/components/relatorios/AlertasSistema';
import IndicadoresGerais from '@/components/relatorios/IndicadoresGerais';
import GraficosPainel from '@/components/relatorios/GraficosPainel';
import RankingObras from '@/components/relatorios/RankingObras';
import RankingEmpresas from '@/components/relatorios/RankingEmpresas';
import AssistenteSGI from '@/components/relatorios/AssistenteSGI';
import { Sparkles, X } from 'lucide-react';

const noop = () => {};

export default function PainelInteligencia() {
  const data = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis', 'integracoes', 'documentos', 'dds', 'ocorrencias', 'obras']);
  const [chat, setChat] = useState(false);
  if (!data) return <p className="text-slate-400">Carregando inteligência...</p>;

  return (
    <div>
      <div className="mb-4">
        <h1 className="text-2xl font-semibold text-[#0b2545]">SGI Inteligência</h1>
        <p className="text-sm text-slate-500">Análise, indicadores e rankings do sistema de gestão.</p>
      </div>

      <Tabs defaultValue="visao">
        <TabsList className="flex flex-wrap h-auto bg-slate-100 p-1 mb-4">
          <TabsTrigger value="visao" className="min-h-[40px]">Visão Geral</TabsTrigger>
          <TabsTrigger value="indicadores" className="min-h-[40px]">Indicadores</TabsTrigger>
          <TabsTrigger value="rankings" className="min-h-[40px]">Rankings</TabsTrigger>
        </TabsList>

        <TabsContent value="visao" className="space-y-4">
          <div className="grid lg:grid-cols-2 gap-4">
            <ResumoInteligente data={data} />
            <SemoforoConformidade data={data} onNav={noop} />
          </div>
          <AlertasSistema data={data} onNav={noop} />
          <RecomendacoesInteligentes data={data} onNav={noop} />
        </TabsContent>

        <TabsContent value="indicadores" className="space-y-4">
          <IndicadoresGerais data={data} />
          <GraficosPainel data={data} />
        </TabsContent>

        <TabsContent value="rankings" className="space-y-4">
          <div className="grid lg:grid-cols-2 gap-4">
            <RankingObras data={data} />
            <RankingEmpresas data={data} />
          </div>
        </TabsContent>
      </Tabs>

      {/* Floating chat button */}
      <button
        onClick={() => setChat(true)}
        className="fixed bottom-24 lg:bottom-6 right-4 z-40 w-14 h-14 rounded-full bg-amber-400 text-[#0b2545] shadow-lg flex items-center justify-center hover:bg-amber-300"
        title="Assistente SGI"
      >
        <Sparkles className="w-6 h-6" />
      </button>

      {chat && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
          <div className="absolute inset-0 bg-black/40" onClick={() => setChat(false)} />
          <div className="relative w-full sm:max-w-lg max-h-[85vh] overflow-y-auto bg-white rounded-t-2xl sm:rounded-2xl shadow-xl">
            <div className="sticky top-0 bg-[#0b2545] text-white flex items-center justify-between px-4 py-3">
              <div className="flex items-center gap-2"><Sparkles className="w-5 h-5 text-amber-400" /><span className="font-semibold">Assistente SGI</span></div>
              <button onClick={() => setChat(false)} className="p-2 min-w-[40px] min-h-[40px] flex items-center justify-center hover:bg-white/10 rounded-md"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-4"><AssistenteSGI data={data} /></div>
          </div>
        </div>
      )}
    </div>
  );
}