import React, { useState, useMemo, useEffect } from 'react';
import useSaudeObrasData from '@/hooks/useSaudeObrasData';
import { analisarSaudeObras } from '@/lib/saudeObras';
import PageHeader from '@/components/PageHeader';
import { fmtMoney } from '@/lib/financeiro';
import {
  PERIODOS, periodRange, filtrarPorPeriodo, calcCaixa, calcBurnRunway,
  gerarAlertas, calcKpis, saldoMesAnterior,
} from '@/lib/dashboardFinanceiro';
import { obrasAtivasParaLancamento, obrasDisponiveisNoPeriodo } from '@/lib/obraDisponibilidade';
import {
  TrendingUp, TrendingDown, AlertTriangle, AlertOctagon,
  CheckCircle, Clock, ArrowUpRight, ArrowDownRight, Info, Calendar, X,
} from 'lucide-react';

export default function DashboardFinanceiro({ embedded = false }) {
  const [periodo, setPeriodo] = useState('mes');
  const [obraSel, setObraSel] = useState(null);
  const [customRange, setCustomRange] = useState(null);
  const [modalCustom, setModalCustom] = useState(false);
  const { data, loading } = useSaudeObrasData();
  const allDespesas = data.despesas;
  const allReceitas = data.receitas;
  const allObras = data.obras;

  // Filtro global: período + obra (afeta TODO o dashboard)
  const { desp, rec } = useMemo(() => {
    const f = filtrarPorPeriodo(allDespesas, allReceitas, periodo, customRange);
    if (!obraSel) return f;
    const obra = allObras.find((o) => o.id === obraSel);
    const nome = obra?.nome;
    return {
      ...f,
      desp: f.desp.filter((d) => d.obra_id === obraSel || d.obra === nome),
      rec: f.rec.filter((r) => r.obra_id === obraSel || r.obra === nome),
    };
  }, [allDespesas, allReceitas, periodo, customRange, obraSel, allObras]);

  const rangePeriodo = useMemo(() => periodRange(periodo, customRange), [periodo, customRange]);
  const obrasPeriodo = useMemo(() => periodo === 'mes' ? obrasAtivasParaLancamento(allObras) : obrasDisponiveisNoPeriodo(allObras, rangePeriodo.inicio, rangePeriodo.fim), [allObras, periodo, rangePeriodo]);
  useEffect(() => {
    if (obraSel && !obrasPeriodo.some((obra) => obra.id === obraSel)) setObraSel(null);
  }, [obraSel, obrasPeriodo]);
  const caixa = useMemo(() => calcCaixa(rec, desp), [rec, desp]);
  const analiseObras = useMemo(() => analisarSaudeObras(data, rangePeriodo.inicio, rangePeriodo.fim, false), [data, rangePeriodo]);
  const obrasSaude = useMemo(() => analiseObras.stats.filter((obra) => !obraSel || obra.id === obraSel).map((obra) => ({ id: obra.id, nome: obra.nome, orcamento: obra.fin.custoPrevisto, gasto: obra.fin.custoRealizado, receita: obra.fin.receitaPrevista, margem: obra.fin.margemResultado, status: obra.status })), [analiseObras, obraSel]);
  const burnRunway = useMemo(() => calcBurnRunway(desp, rec, periodo, caixa.saldo, customRange), [desp, rec, periodo, caixa.saldo, customRange]);
  const mesAnt = useMemo(() => saldoMesAnterior(rec, desp), [rec, desp]);
  const kpis = useMemo(() => calcKpis(caixa, obrasSaude, burnRunway, mesAnt), [caixa, obrasSaude, burnRunway, mesAnt]);
  const alertas = useMemo(() => gerarAlertas(caixa, obrasSaude, burnRunway, desp, rec), [caixa, obrasSaude, burnRunway, desp, rec]);

  const comparado = useMemo(() => {
    const recebido = rec.filter((r) => r.status === 'Recebida').reduce((s, r) => s + (Number(r.valor) || 0), 0);
    const pago = desp.filter((d) => d.status === 'Pago').reduce((s, d) => s + (Number(d.valor) || 0), 0);
    const saldoAtual = recebido - pago;
    return { saldoAtual, mesAnterior: mesAnt, mudou: mesAnt != null ? saldoAtual - mesAnt : null };
  }, [rec, desp, mesAnt]);

  const sobra = burnRunway.receitaMes - burnRunway.despesaMes;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-[#0b2545] rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div>
      {!embedded && <PageHeader title="Dashboard Financeiro" subtitle="Situação financeira da empresa em tempo real." />}

      {/* FILTROS GLOBAIS — topo */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 mb-5">
        {/* Período */}
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide mr-1">Período:</span>
          {PERIODOS.map((p) => {
            const isCustom = p.id === 'custom';
            const isActive = periodo === p.id;
            const label = isCustom && customRange
              ? `Customizado (${customRange.inicio.split('-').reverse().join('/')} a ${customRange.fim.split('-').reverse().join('/')})`
              : p.label;
            return (
              <button
                key={p.id}
                onClick={() => {
                  if (isCustom && !customRange) {
                    setModalCustom(true);
                  } else if (isCustom) {
                    setModalCustom(true);
                  } else {
                    setPeriodo(p.id);
                  }
                }}
                className={`text-xs px-3.5 py-1.5 rounded-full border transition ${isActive ? 'bg-blue-500 text-white border-blue-500' : 'bg-white text-slate-600 border-slate-200 hover:border-blue-400'}`}
              >
                {label}
              </button>
            );
          })}
        </div>
        {/* Obra */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide mr-1">Obra:</span>
          <button
            onClick={() => setObraSel(null)}
            className={`text-xs px-3 py-1.5 rounded-full border transition ${!obraSel ? 'bg-blue-500 text-white border-blue-500' : 'bg-white text-slate-600 border-slate-200 hover:border-blue-400'}`}
          >
            Geral
          </button>
          {obrasPeriodo.map((o) => (
            <button
              key={o.id}
              onClick={() => setObraSel((prev) => (prev === o.id ? null : o.id))}
              className={`text-xs px-3 py-1.5 rounded-full border transition ${obraSel === o.id ? 'bg-blue-500 text-white border-blue-500' : 'bg-white text-slate-600 border-slate-200 hover:border-blue-400'}`}
            >
              {o.nome}
            </button>
          ))}
        </div>
      </div>

      {/* 1. Sua Situação Agora */}
      <SituacaoAtualCard caixa={caixa} runway={burnRunway.runway} />

      {/* 2. Dinheiro que Entra e Sai */}
      <EntradasSaidasCard receitaMes={burnRunway.receitaMes} despesaMes={burnRunway.despesaMes} sobra={sobra} />

      {/* 3. Como Tá Cada Obra? */}
      <ComoTaoObrasCard obras={obrasSaude} />

      {/* 4. Comparado com Mês Passado? */}
      <ComparadoMesCard comparado={comparado} />

      {/* 5. Alertas Importantes */}
      <AlertasCard alertas={alertas} />

      {/* Modal Customizado */}
      {modalCustom && (
        <CustomPeriodModal
          onClose={() => setModalCustom(false)}
          onApply={(range) => {
            setCustomRange(range);
            setPeriodo('custom');
            setModalCustom(false);
          }}
        />
      )}
    </div>
  );
}

// ─── Modal Período Customizado ─────────────────────────────────────────

function CustomPeriodModal({ onClose, onApply }) {
  const [inicio, setInicio] = useState('');
  const [fim, setFim] = useState('');
  const [erro, setErro] = useState('');

  const handleApply = () => {
    if (!inicio || !fim) {
      setErro('Preencha as duas datas.');
      return;
    }
    if (fim < inicio) {
      setErro('A data final deve ser maior ou igual à data inicial.');
      return;
    }
    onApply({ inicio, fim });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-lg p-5 w-80 max-w-[90vw]" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-blue-500" />
            <h3 className="font-semibold text-[#0b2545]">Período Customizado</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X className="w-4 h-4" /></button>
        </div>
        <div className="space-y-3">
          <div>
            <label className="text-xs font-medium text-slate-500 uppercase">Data Inicial</label>
            <input
              type="date"
              value={inicio}
              onChange={(e) => { setInicio(e.target.value); setErro(''); }}
              className="flex h-11 w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-sm shadow-sm focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 uppercase">Data Final</label>
            <input
              type="date"
              value={fim}
              onChange={(e) => { setFim(e.target.value); setErro(''); }}
              className="flex h-11 w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-sm shadow-sm focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100"
            />
          </div>
          {erro && <p className="text-xs text-red-600">{erro}</p>}
        </div>
        <button
          onClick={handleApply}
          className="w-full mt-4 h-11 rounded-lg bg-blue-500 text-white text-sm font-medium hover:bg-blue-600 transition"
        >
          Aplicar
        </button>
      </div>
    </div>
  );
}

// ─── Subcomponentes ───────────────────────────────────────────────────

function SituacaoAtualCard({ caixa, runway }) {
  const saldoTone = caixa.saldo > 0 ? 'green' : 'red';
  const saldoBg = { green: 'from-emerald-500 to-emerald-600', red: 'from-red-500 to-red-600' };
  const runwayTone = runway == null ? 'green' : runway > 3 ? 'green' : runway >= 1 ? 'amber' : 'red';
  const runwayBg = { green: 'bg-emerald-50 border-emerald-100', amber: 'bg-amber-50 border-amber-100', red: 'bg-red-50 border-red-100' };
  const runwayText = { green: 'text-emerald-700', amber: 'text-amber-700', red: 'text-red-700' };
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 shadow-card mb-5">
      <h3 className="font-semibold text-[#0b2545] mb-4">Sua Situação Agora</h3>
      <div className="grid md:grid-cols-2 gap-4">
        <div className={`rounded-xl bg-gradient-to-br ${saldoBg[saldoTone]} text-white p-5`}>
          <p className="text-xs opacity-80 uppercase tracking-wide">Seu dinheiro agora</p>
          <p className="text-3xl font-bold mt-1">{fmtMoney(caixa.saldo)}</p>
          <p className="text-xs opacity-80 mt-2">{caixa.saldo > 0 ? 'Tá no positivo' : 'Atenção — negativo!'}</p>
        </div>
        <div className={`rounded-xl border p-5 ${runwayBg[runwayTone]}`}>
          <div className="flex items-center gap-1.5 mb-1">
            <Clock className={`w-4 h-4 ${runwayText[runwayTone]}`} />
            <p className="text-xs text-slate-500 uppercase tracking-wide">Quanto tempo dura</p>
            {runway != null && runway < 1 && <AlertTriangle className="w-4 h-4 text-red-600" />}
          </div>
          <p className={`text-3xl font-bold ${runwayText[runwayTone]}`}>{runway != null ? `${runway.toFixed(1)} meses` : '∞'}</p>
          <p className="text-xs text-slate-400 mt-2">Quanto tempo seu dinheiro cobre as despesas</p>
        </div>
      </div>
    </section>
  );
}

function EntradasSaidasCard({ receitaMes, despesaMes, sobra }) {
  const sobraTone = sobra >= 0 ? 'green' : 'red';
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 shadow-card mb-5">
      <h3 className="font-semibold text-[#0b2545] mb-3">Dinheiro que Entra e Sai</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-lg bg-emerald-50 border border-emerald-100 p-4">
          <div className="flex items-center gap-1.5 mb-1"><TrendingUp className="w-4 h-4 text-emerald-500" /><span className="text-xs text-slate-500 uppercase">Recebe/mês</span></div>
          <p className="text-2xl font-bold text-emerald-700">{fmtMoney(receitaMes)}</p>
        </div>
        <div className="rounded-lg bg-red-50 border border-red-100 p-4">
          <div className="flex items-center gap-1.5 mb-1"><TrendingDown className="w-4 h-4 text-red-500" /><span className="text-xs text-slate-500 uppercase">Gasta/mês</span></div>
          <p className="text-2xl font-bold text-red-700">{fmtMoney(despesaMes)}</p>
        </div>
        <div className={`rounded-lg border p-4 ${sobraTone === 'green' ? 'bg-emerald-50 border-emerald-100' : 'bg-red-50 border-red-100'}`}>
          <div className="flex items-center gap-1.5 mb-1">
            {sobra >= 0 ? <ArrowUpRight className="w-4 h-4 text-emerald-500" /> : <ArrowDownRight className="w-4 h-4 text-red-500" />}
            <span className="text-xs text-slate-500 uppercase">Sobra</span>
          </div>
          <p className={`text-2xl font-bold ${sobraTone === 'green' ? 'text-emerald-700' : 'text-red-700'}`}>{fmtMoney(sobra)}</p>
        </div>
      </div>
    </section>
  );
}

function ComoTaoObrasCard({ obras }) {
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 shadow-card mb-5">
      <h3 className="font-semibold text-[#0b2545] mb-3">Como Tá Cada Obra?</h3>
      {obras.length === 0 ? (
        <p className="text-sm text-slate-400 text-center py-6">Nenhuma obra encontrada.</p>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {obras.map((o) => {
            const tone = o.margem != null && o.margem >= 10 ? 'green' : o.margem != null && o.margem >= 0 ? 'amber' : 'red';
            const toneClass = {
              green: 'border-emerald-200 bg-emerald-50/50',
              amber: 'border-amber-200 bg-amber-50/50',
              red: 'border-red-200 bg-red-50/50',
            };
            const margColor = { green: 'text-emerald-700', amber: 'text-amber-700', red: 'text-red-700' };
            const labelColor = { green: 'Verde', amber: 'Amarelo', red: 'Vermelho' };
            const dotColor = { green: 'bg-emerald-500', amber: 'bg-amber-500', red: 'bg-red-500' };
            const pctOrc = o.orcamento > 0 ? (o.gasto / o.orcamento) * 100 : 0;
            return (
              <div key={o.id} className={`rounded-lg border p-3 ${toneClass[tone]}`}>
                <div className="flex items-center justify-between mb-2">
                  <p className="font-semibold text-sm text-[#0b2545] truncate">{o.nome}</p>
                  <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full text-white ${dotColor[tone]}`}>{labelColor[tone]}</span>
                </div>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between"><span className="text-slate-500">Orçamento</span><span className="font-medium text-slate-700">{fmtMoney(o.orcamento)}</span></div>
                  <div className="flex justify-between"><span className="text-slate-500">Gasto</span><span className="font-medium text-slate-700">{fmtMoney(o.gasto)}</span></div>
                  <div className="flex justify-between"><span className="text-slate-500">Receita</span><span className="font-medium text-slate-700">{fmtMoney(o.receita)}</span></div>
                  <div className="flex justify-between pt-1 border-t border-slate-200/50 mt-1"><span className="text-slate-500">Lucro</span><span className={`font-bold ${margColor[tone]}`}>{o.margem != null ? `${o.margem.toFixed(1)}%` : '—'}</span></div>
                </div>
                {o.orcamento > 0 && (
                  <div className="mt-2 h-1.5 rounded-full bg-slate-200 overflow-hidden">
                    <div className={`h-full ${pctOrc > 100 ? 'bg-red-500' : pctOrc > 80 ? 'bg-amber-500' : 'bg-emerald-500'}`} style={{ width: `${Math.min(pctOrc, 100)}%` }} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}

function ComparadoMesCard({ comparado }) {
  const { saldoAtual, mesAnterior, mudou } = comparado;
  const mudouTone = mudou == null ? 'amber' : mudou >= 0 ? 'green' : 'red';
  const mudouColor = { green: 'text-emerald-700', amber: 'text-amber-700', red: 'text-red-700' };
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 shadow-card mb-5">
      <h3 className="font-semibold text-[#0b2545] mb-3">Comparado com Mês Passado?</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-lg bg-slate-50 border border-slate-200 p-4">
          <p className="text-xs text-slate-500 uppercase tracking-wide mb-1">Mês passado</p>
          <p className="text-2xl font-bold text-[#0b2545]">{mesAnterior != null ? fmtMoney(mesAnterior) : '—'}</p>
        </div>
        <div className="rounded-lg bg-slate-50 border border-slate-200 p-4">
          <p className="text-xs text-slate-500 uppercase tracking-wide mb-1">Hoje</p>
          <p className="text-2xl font-bold text-[#0b2545]">{fmtMoney(saldoAtual)}</p>
        </div>
        <div className={`rounded-lg border p-4 ${mudouTone === 'green' ? 'bg-emerald-50 border-emerald-100' : mudouTone === 'red' ? 'bg-red-50 border-red-100' : 'bg-amber-50 border-amber-100'}`}>
          <div className="flex items-center gap-1.5 mb-1">
            {mudou != null && mudou >= 0 ? <ArrowUpRight className="w-4 h-4 text-emerald-500" /> : mudou != null ? <ArrowDownRight className="w-4 h-4 text-red-500" /> : null}
            <span className="text-xs text-slate-500 uppercase tracking-wide">Mudou quanto</span>
          </div>
          <p className={`text-2xl font-bold ${mudouColor[mudouTone]}`}>{mudou != null ? `${mudou >= 0 ? '+' : ''}${fmtMoney(mudou)}` : '—'}</p>
        </div>
      </div>
    </section>
  );
}

function AlertasCard({ alertas }) {
  const iconMap = {
    risco: { Icon: AlertOctagon, c: 'text-red-600 bg-red-50' },
    atencao: { Icon: AlertTriangle, c: 'text-amber-600 bg-amber-50' },
    info: { Icon: Info, c: 'text-blue-600 bg-blue-50' },
    ok: { Icon: CheckCircle, c: 'text-emerald-600 bg-emerald-50' },
  };
  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 shadow-card">
      <div className="flex items-center gap-2 mb-4">
        <AlertTriangle className="w-5 h-5 text-amber-500" />
        <h3 className="font-semibold text-[#0b2545]">Alertas Importantes</h3>
        <span className="ml-auto text-xs text-slate-400">{alertas.length} alerta(s)</span>
      </div>
      <div className="space-y-2">
        {alertas.map((a, i) => {
          const h = iconMap[a.tipo];
          return (
            <div key={i} className="flex items-center gap-2.5 rounded-lg border border-slate-100 p-2.5">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${h.c}`}>
                <h.Icon className="w-3.5 h-3.5" />
              </div>
              <p className="text-sm text-slate-700">{a.titulo}</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}