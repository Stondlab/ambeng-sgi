import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSstData } from '@/hooks/useSstEntitiesData';
import { calcularDashboardSST } from '@/lib/sstDashboard';
import SstKpis from '@/components/sst/SstKpis';
import SstAlerts from '@/components/sst/SstAlerts';
import SstActionGrid from '@/components/sst/SstActionGrid';
import SstCriticalWorks from '@/components/sst/SstCriticalWorks';
import SstAssistantLauncher from '@/components/sst/SstAssistantLauncher';
import AuditoriaEventos from '@/components/auditoria/AuditoriaEventos';
import TimelineMovimentacoes from '@/components/relatorios/TimelineMovimentacoes';
import SstEvidencePanel from '@/components/sst/SstEvidencePanel';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const MAIN_TABS = ['operacional', 'eventos', 'movimentacoes', 'evidencias'];
const MODULE_ROUTES = { inspecoes: '/inspecoes', ocorrencias: '/ocorrencias', epis: '/epis', treinamentos: '/treinamentos', asos: '/asos' };
const hashValue = () => window.location.hash.replace('#', '');
const hashMain = () => MAIN_TABS.includes(hashValue()) ? hashValue() : 'operacional';
export default function DashboardSST() {
  const navigate = useNavigate();
  const data = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis', 'ocorrencias', 'inspecoes', 'obras', 'integracoes', 'documentos', 'dds']);
  const [principal, setPrincipal] = useState(hashMain);
  useEffect(() => { const sync = () => setPrincipal(hashMain()); window.addEventListener('hashchange', sync); return () => window.removeEventListener('hashchange', sync); }, []);
  const dashboard = useMemo(() => data ? calcularDashboardSST(data) : null, [data]);
  const abrir = (id) => { if (MODULE_ROUTES[id]) navigate(MODULE_ROUTES[id]); };
  const abrirPrincipal = (id) => { setPrincipal(id); window.history.replaceState(null, '', `${window.location.pathname}#${id}`); };
  if (!dashboard) return <p className="text-muted-foreground">Carregando dashboard SST...</p>;
  return <div className="space-y-6"><header><h1 className="text-2xl font-semibold tracking-tight md:text-3xl">Saúde e Segurança no Trabalho</h1><p className="mt-1 text-sm text-muted-foreground">Centro operacional consolidado do SST</p></header><Tabs value={principal} onValueChange={abrirPrincipal}><TabsList className="grid h-auto w-full grid-cols-2 md:grid-cols-4"><TabsTrigger value="operacional" className="min-h-11">Operacional</TabsTrigger><TabsTrigger value="eventos" className="min-h-11">Eventos</TabsTrigger><TabsTrigger value="movimentacoes" className="min-h-11">Movimentações</TabsTrigger><TabsTrigger value="evidencias" className="min-h-11">Evidências</TabsTrigger></TabsList><TabsContent value="operacional" className="mt-6 space-y-6"><SstKpis dashboard={dashboard} /><SstActionGrid /><SstAlerts alertas={dashboard.alertas} proximas={dashboard.proximas} onOpen={abrir} /><SstCriticalWorks works={dashboard.obrasCriticas} /></TabsContent><TabsContent value="eventos" className="mt-6"><AuditoriaEventos /></TabsContent><TabsContent value="movimentacoes" className="mt-6"><TimelineMovimentacoes data={data} /></TabsContent><TabsContent value="evidencias" className="mt-6"><SstEvidencePanel data={data} /></TabsContent></Tabs><SstAssistantLauncher data={data} /></div>;
}