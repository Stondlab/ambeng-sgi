import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import { useSstData } from '@/hooks/useSstEntitiesData';
import { timelineCompleta } from '@/lib/relatorios';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Clock, History } from 'lucide-react';

const MODULOS = ['Geral', 'Login', 'Usuário', 'ASO', 'Treinamento', 'EPI', 'Documento', 'Inspeção', 'Máquina', 'Integração', 'DDS', 'Ocorrência', 'Equipamento', 'RH'];

export default function Movimentacoes({ embedded = false }) {
  const data = useSstData(['funcionarios', 'dds', 'integracoes', 'epis', 'ocorrencias', 'treinamentos', 'asos', 'documentos', 'inspecoes', 'maquinas']);
  const [hist, setHist] = useState([]);
  const [fPeriodo, setFPeriodo] = useState({ de: '', ate: '' });
  const [fUsuario, setFUsuario] = useState('');
  const [fModulo, setFModulo] = useState('');
  const [fTipo, setFTipo] = useState('');
  const [selecionada, setSelecionada] = useState(null);

  useEffect(() => {
    (async () => {
      try { setHist(await base44.entities.HistoricoAcoes.list('-data_hora', 500)); } catch { setHist([]); }
    })();
  }, []);

  const linhas = useMemo(() => {
    if (!data) return [];
    const tl = timelineCompleta(data).map((e) => ({
      data_hora: e.data ? new Date(e.data).toISOString() : null,
      usuario: e.responsavel || '—',
      modulo: e.tipo,
      registro: `${e.titulo}${e.func && e.func !== '—' ? ' · ' + e.func : ''}`,
      acao: e.tipo,
      anterior: '',
      novo: '',
    }));
    const hl = hist.map((h) => ({
      data_hora: h.data_hora,
      usuario: h.usuario_nome || '—',
      modulo: h.modulo || 'Geral',
      registro: h.registro || h.detalhe || '',
      detalhe: h.detalhe || '',
      acao: h.acao,
      anterior: h.anterior || h.antes || '',
      novo: h.novo || h.depois || '',
    }));
    const all = [...hl, ...tl].filter((e) => e.data_hora);
    const de = fPeriodo.de ? new Date(fPeriodo.de) : null;
    const ate = fPeriodo.ate ? new Date(fPeriodo.ate + 'T23:59:59') : null;
    return all
      .filter((e) => (!de || new Date(e.data_hora) >= de) && (!ate || new Date(e.data_hora) <= ate))
      .filter((e) => !fUsuario || (e.usuario || '').toLowerCase().includes(fUsuario.toLowerCase()))
      .filter((e) => !fModulo || e.modulo === fModulo)
      .filter((e) => !fTipo || (e.acao || '').toLowerCase().includes(fTipo.toLowerCase()))
      .sort((a, b) => new Date(b.data_hora) - new Date(a.data_hora));
  }, [data, hist, fPeriodo, fUsuario, fModulo, fTipo]);

  const fmtDT = (d) => d ? new Date(d).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—';

  return (
    <div>
      {!embedded && <PageHeader title="Últimas Movimentações" subtitle="Trilha cronológica de ações e registros do sistema." />}

      <section className="bg-white border border-slate-200 rounded-xl p-4 mb-4">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div><span className="text-xs text-slate-400">De</span><Input type="date" value={fPeriodo.de} onChange={(e) => setFPeriodo({ ...fPeriodo, de: e.target.value })} className="mt-1" /></div>
          <div><span className="text-xs text-slate-400">Até</span><Input type="date" value={fPeriodo.ate} onChange={(e) => setFPeriodo({ ...fPeriodo, ate: e.target.value })} className="mt-1" /></div>
          <div><span className="text-xs text-slate-400">Usuário</span><Input value={fUsuario} onChange={(e) => setFUsuario(e.target.value)} placeholder="Nome..." className="mt-1" /></div>
          <div><span className="text-xs text-slate-400">Módulo</span>
            <Select value={fModulo || 'todos'} onValueChange={(value) => setFModulo(value === 'todos' ? '' : value)}><SelectTrigger className="mt-1"><SelectValue placeholder="Todos" /></SelectTrigger><SelectContent><SelectItem value="todos">Todos</SelectItem>{MODULOS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent></Select>
          </div>
          <div className="lg:col-span-4"><span className="text-xs text-slate-400">Tipo / Ação</span><Input value={fTipo} onChange={(e) => setFTipo(e.target.value)} placeholder="Ex.: Novo colaborador, Entrega de EPI, Login..." className="mt-1" /></div>
        </div>
      </section>

      <section className="bg-white border border-slate-200 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-3"><History className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Movimentações</h3><span className="text-xs text-slate-400">({linhas.length})</span></div>
        {linhas.length === 0 ? <p className="text-sm text-slate-400 py-4">Nenhuma movimentação encontrada.</p> : (
          <div className="space-y-3 max-h-[60vh] overflow-y-auto">
            {linhas.map((e, i) => (
              <button key={i} onClick={() => setSelecionada(e)} className="flex w-full gap-3 rounded-lg p-1 text-left hover:bg-slate-50">
                <div className="flex flex-col items-center"><span className="w-2.5 h-2.5 rounded-full mt-1 bg-[#0b2545]" /><span className="w-px flex-1 bg-slate-100" /></div>
                <div className="pb-1 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm text-slate-700"><b className="text-[#0b2545]">{e.acao}</b> · {e.modulo}</p>
                    <span className="text-[11px] text-slate-400 whitespace-nowrap">{fmtDT(e.data_hora)}</span>
                  </div>
                  <p className="text-xs text-slate-500">{e.registro} · <span className="inline-flex items-center gap-1"><Clock className="w-3 h-3" />{e.usuario}</span></p>
                </div>
              </button>
            ))}
          </div>
        )}
      </section>

      <Dialog open={Boolean(selecionada)} onOpenChange={(open) => !open && setSelecionada(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Detalhe da movimentação</DialogTitle></DialogHeader>
          {selecionada && <div className="space-y-3 text-sm">
            <p><span className="text-slate-500">Ação:</span> <strong>{selecionada.acao}</strong></p>
            <p><span className="text-slate-500">Entidade:</span> {selecionada.modulo || '—'}</p>
            <p><span className="text-slate-500">Usuário:</span> {selecionada.usuario || '—'}</p>
            <p><span className="text-slate-500">Registro:</span> {selecionada.registro || '—'}</p>
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3"><span className="text-xs text-slate-500">Antes</span><p className="mt-1 break-words">{selecionada.anterior || 'Não registrado neste evento'}</p></div>
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3"><span className="text-xs text-slate-500">Depois</span><p className="mt-1 break-words">{selecionada.novo || selecionada.detalhe || 'Não registrado neste evento'}</p></div>
            </div>
          </div>}
        </DialogContent>
      </Dialog>
    </div>
  );
}