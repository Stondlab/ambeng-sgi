import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import PageHeader from '@/components/PageHeader';
import { custoGeral, evolucaoCusto, vigenciaAtiva, recorteCustoObra } from '@/lib/custoMO';
import { fmtMoney } from '@/lib/financeiro';
import { obrasAtivasParaLancamento, obrasDisponiveisNoPeriodo } from '@/lib/obraDisponibilidade';
import CustoPorObraChart from '@/components/rh/custos/CustoPorObraChart';
import RankingObrasCusto from '@/components/rh/custos/RankingObrasCusto';
import EvolucaoCustoChart from '@/components/rh/custos/EvolucaoCustoChart';
import DrillDownCusto from '@/components/rh/custos/DrillDownCusto';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Filter, Settings2, Building2, TrendingUp, PieChart, ChevronRight } from 'lucide-react';
import { usePermissoes } from '@/lib/PermissoesContext';
import { pode } from '@/lib/permissoes';

function ultimosMeses(anoMesAlvo, n = 6) {
  const [y, m] = anoMesAlvo.split('-').map(Number);
  const arr = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(y, m - 1 - i, 1);
    arr.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  }
  return arr;
}

// Dashboard por Custo de Obra — análise financeira focada em obras, reutilizando
// o motor único de Custo de Mão de Obra (custoMO) usado por RH, Obras e Financeiro.
export default function DashboardCustoObra({ embedded = false, embeddedObra = '', embeddedMonth = '' }) {
  const { perfilEfetivo } = usePermissoes();
  const podeVerParametros = pode(perfilEfetivo, 'parametros_custo', 'visualizar');
  const [funcs, setFuncs] = useState([]);
  const [aps, setAps] = useState([]);
  const [ponto, setPonto] = useState([]);
  const [vigencias, setVigencias] = useState([]);
  const [params, setParams] = useState([]);
  const [horasExtras, setHorasExtras] = useState([]);
  const [obras, setObras] = useState([]);
  const [anoMesSel, setAnoMesSel] = useState(embeddedMonth || new Date().toISOString().slice(0, 7));
  const [obraSel, setObraSel] = useState(embeddedObra || 'todas');
  const [drillObra, setDrillObra] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [f, a, p, v, pr, he, o] = await Promise.all([
        base44.entities.Funcionarios.list('-created_date', 1000).catch(() => []),
        base44.entities.Apontamentos.list('-data', 3000).catch(() => []),
        base44.entities.Ponto.list('-data', 3000).catch(() => []),
        base44.entities.EncargosVigencias.list('-data_inicio', 500).catch(() => []),
        base44.entities.ParametrosCustoMO.list('data_inicio', 500).catch(() => []),
        base44.entities.HorasExtras.list('-data', 3000).catch(() => []),
        base44.entities.Obras.list('nome', 500).catch(() => []),
      ]);
      setFuncs(f); setAps(a); setPonto(p); setVigencias(v); setParams(pr); setHorasExtras(he); setObras(o);
      setLoading(false);
    })();
  }, []);

  const encPct = useMemo(() => vigenciaAtiva(vigencias, anoMesSel), [vigencias, anoMesSel]);
  const obrasPeriodo = useMemo(() => {
    const [ano, mes] = anoMesSel.split('-').map(Number);
    const inicio = `${anoMesSel}-01`;
    const fim = `${anoMesSel}-${String(new Date(ano, mes, 0).getDate()).padStart(2, '0')}`;
    const mesAtual = new Date().toISOString().slice(0, 7);
    return anoMesSel === mesAtual ? obrasAtivasParaLancamento(obras) : obrasDisponiveisNoPeriodo(obras, inicio, fim);
  }, [obras, anoMesSel]);

  useEffect(() => {
    if (obraSel !== 'todas' && obraSel !== '__sem__' && !obrasPeriodo.some((obra) => obra.nome === obraSel)) setObraSel('todas');
  }, [obraSel, obrasPeriodo]);

  const geralBase = useMemo(() => custoGeral(funcs, aps, encPct, anoMesSel, ponto, horasExtras, params), [funcs, aps, encPct, anoMesSel, ponto, horasExtras, params]);
  const geral = useMemo(() => recorteCustoObra(geralBase, obraSel === '__sem__' ? 'Sem obra' : obraSel), [geralBase, obraSel]);
  const meses = useMemo(() => ultimosMeses(anoMesSel, 6), [anoMesSel]);
  const evoBase = useMemo(() => evolucaoCusto(funcs, aps, encPct, meses, ponto, horasExtras, params), [funcs, aps, encPct, meses, ponto, horasExtras, params]);
  const evo = useMemo(() => obraSel === 'todas' ? evoBase : evoBase.map((e) => ({ ...e, porObra: { [obraSel]: e.porObra[obraSel] || 0 }, porObraConf: { [obraSel]: e.porObraConf[obraSel] || 0 }, porObraPend: { [obraSel]: e.porObraPend[obraSel] || 0 } })), [evoBase, obraSel]);

  const obrasArr = useMemo(() => Object.entries(geral.porObra).map(([obra, valor]) => ({ obra, valor })).sort((a, b) => b.valor - a.valor), [geral]);
  const totalGeral = obrasArr.reduce((s, o) => s + o.valor, 0);
  const maiorObra = obrasArr[0];
  const mediaObra = obrasArr.length ? totalGeral / obrasArr.length : 0;

  return (
    <div>
      <div className="flex items-start justify-between gap-3">
        <PageHeader title={embedded ? `Mão de Obra — ${embeddedObra}` : 'Dashboard por Custo de Obra'} subtitle={embedded ? 'Funcionários, benefícios, encargos, apropriação e evolução do custo desta obra.' : 'Análise financeira de custos de mão de obra apropriados por obra — conferido vs pendente, ranking e evolução mensal.'} />
        {podeVerParametros && <Button asChild variant="outline" size="sm"><Link to="/rh/parametros-custo"><Settings2 className="w-4 h-4" />Parâmetros de Custo</Link></Button>}
      </div>

      <section className="bg-white border border-slate-200 rounded-xl p-4 mb-4">
        <div className="flex items-center gap-2 mb-3"><Filter className="w-4 h-4 text-[#0b2545]" /><h3 className="text-sm font-semibold text-[#0b2545]">Filtros</h3></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <Label>Mês / Período</Label>
            <input type="month" value={anoMesSel} onChange={(e) => setAnoMesSel(e.target.value)} className="mt-1 h-11 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm" />
          </div>
          <div>
            <Label>Obra</Label>
            <Select value={obraSel} onValueChange={setObraSel}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                {!embedded && <SelectItem value="todas">Todas as obras</SelectItem>}
                {!embedded && <SelectItem value="__sem__">Sem obra vinculada</SelectItem>}
                {obrasPeriodo.filter((o) => !embedded || o.nome === embeddedObra).map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* KPIs focados em obras */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
        <div className="rounded-xl p-4 bg-[#0b2545] text-white">
          <Building2 className="w-5 h-5 opacity-70 mb-2" />
          <p className="text-xl font-bold leading-none">{obrasArr.length}</p>
          <p className="text-xs opacity-80 mt-2">Obras com custo no mês</p>
        </div>
        <div className="rounded-xl p-4 bg-emerald-50 border border-emerald-200 text-emerald-700">
          <TrendingUp className="w-5 h-5 opacity-70 mb-2" />
          <p className="text-xl font-bold leading-none">{fmtMoney(totalGeral)}</p>
          <p className="text-xs opacity-80 mt-2">Custo total apropriado</p>
        </div>
        <div className="rounded-xl p-4 bg-sky-50 border border-sky-200 text-sky-700">
          <PieChart className="w-5 h-5 opacity-70 mb-2" />
          <p className="text-xl font-bold leading-none">{fmtMoney(mediaObra)}</p>
          <p className="text-xs opacity-80 mt-2">Custo médio por obra</p>
        </div>
        {maiorObra && (
          <button onClick={() => setDrillObra(maiorObra.obra)} className="rounded-xl p-4 bg-amber-50 border border-amber-200 text-amber-700 text-left hover:opacity-90 transition">
            <Building2 className="w-5 h-5 opacity-70 mb-2" />
            <p className="text-sm font-bold leading-tight truncate">{maiorObra.obra}</p>
            <p className="text-xs opacity-80 mt-1">{fmtMoney(maiorObra.valor)} · maior custo</p>
          </button>
        )}
      </div>

      {loading ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-400">Carregando custos por obra...</div>
      ) : obrasArr.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-400">Nenhum custo apropriado a obras nesta competência.</div>
      ) : (
        <>
          <div className="grid lg:grid-cols-2 gap-4">
            <CustoPorObraChart porObra={geral.porObra} />
            <EvolucaoCustoChart evo={evo} />
          </div>
          <div className="mt-4"><RankingObrasCusto porObra={geral.porObra} onSelect={(o) => setDrillObra(o)} /></div>

          {/* Tabela detalhada de custos por obra */}
          <section className="bg-white border border-slate-200 rounded-xl p-5 mt-4">
            <div className="flex items-center gap-2 mb-4"><Building2 className="w-5 h-5 text-[#0b2545]" /><h3 className="font-semibold text-[#0b2545]">Detalhamento por Obra</h3></div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs text-slate-500 border-b border-slate-200">
                    <th className="py-2 pr-3">Obra</th>
                    <th className="py-2 px-3 text-right">Custo Conferido</th>
                    <th className="py-2 px-3 text-right">Custo Pendente</th>
                    <th className="py-2 px-3 text-right">Total</th>
                    <th className="py-2 pl-3 text-right">% do total</th>
                    <th className="py-2 pl-3"></th>
                  </tr>
                </thead>
                <tbody>
                  {obrasArr.map((o) => {
                    const conf = geral.porObraConf[o.obra] || 0;
                    const pend = geral.porObraPend[o.obra] || 0;
                    const pct = totalGeral > 0 ? (o.valor / totalGeral) * 100 : 0;
                    return (
                      <tr key={o.obra} className="border-b border-slate-100 hover:bg-slate-50">
                        <td className="py-2.5 pr-3 font-medium text-[#0b2545] truncate max-w-[260px]">{o.obra}</td>
                        <td className="py-2.5 px-3 text-right text-emerald-600">{fmtMoney(conf)}</td>
                        <td className="py-2.5 px-3 text-right text-amber-600">{fmtMoney(pend)}</td>
                        <td className="py-2.5 px-3 text-right font-semibold text-[#0b2545]">{fmtMoney(o.valor)}</td>
                        <td className="py-2.5 pl-3 text-right text-slate-500">{pct.toFixed(1)}%</td>
                        <td className="py-2.5 pl-3 text-right">
                          <button onClick={() => setDrillObra(o.obra)} className="text-[#0b2545] hover:underline inline-flex items-center text-xs font-medium">Detalhar <ChevronRight className="w-3 h-3" /></button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="font-semibold text-[#0b2545] border-t-2 border-slate-200">
                    <td className="py-2.5 pr-3">Total</td>
                    <td className="py-2.5 px-3 text-right text-emerald-600">{fmtMoney(geral.conferido)}</td>
                    <td className="py-2.5 px-3 text-right text-amber-600">{fmtMoney(geral.pendente)}</td>
                    <td className="py-2.5 px-3 text-right">{fmtMoney(totalGeral)}</td>
                    <td className="py-2.5 pl-3 text-right">100%</td>
                    <td className="py-2.5 pl-3"></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </section>
        </>
      )}

      <DrillDownCusto obra={drillObra} anoMes={anoMesSel} geral={geralBase} aps={aps} ponto={ponto} onClose={() => setDrillObra(null)} />
    </div>
  );
}