import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useSstData } from '@/hooks/useSstEntitiesData';
import { useAuth } from '@/lib/AuthContext';
import { usePermissoes } from '@/lib/PermissoesContext';
import { isTecnico, pode } from '@/lib/permissoes';
import { listasObra, statsObra } from '@/lib/obras';
import { registrarAcao } from '@/lib/historico';
import { getStatus, fmt } from '@/lib/sst';
import { Building2, ArrowLeft, Pencil, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ObraForm from '@/components/obras/ObraForm';
import ObraVisaoGeral from '@/components/obras/ObraVisaoGeral';
import ObraColaboradores from '@/components/obras/ObraColaboradores';
import ObraTarefas from '@/components/obras/ObraTarefas';
import ObraPendencias from '@/components/obras/ObraPendencias';
import ObraListaTab from '@/components/obras/ObraListaTab';
import ObraAsos from '@/components/obras/ObraAsos';
import ObraTreinamentos from '@/components/obras/ObraTreinamentos';
import ObraEpis from '@/components/obras/ObraEpis';
import ObraInspecoes from '@/components/obras/ObraInspecoes';
import ObraDds from '@/components/obras/ObraDds';
import ObraOcorrencias from '@/components/obras/ObraOcorrencias';
import ObraCustoMO from '@/components/obras/ObraCustoMO';
import ObraSectionNav from '@/components/obras/ObraSectionNav';

export default function ObraDetail() {
  const { id } = useParams();
  const data = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis', 'inspecoes', 'dds', 'ocorrencias', 'pendencias', 'documentos']);
  const { user } = useAuth();
  const { perfilEfetivo } = usePermissoes();
  const [obra, setObra] = useState(null);
  const [demandas, setDemandas] = useState([]);
  const [section, setSection] = useState('visao');
  const [tab, setTab] = useState('visao');
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [acesso, setAcesso] = useState(true);

  const load = async () => {
    try {
      const o = await base44.entities.Obras.get(id);
      setObra(o);
      const d = await base44.entities.Demandas.list('-created_date', 500);
      setDemandas(d);
      // Escopo Técnico: somente obras que responde ou com tarefas suas
      if (isTecnico(perfilEfetivo)) {
        const eu = user?.full_name || '';
        const tem = eu && ((o.responsavel || '') === eu || d.some((x) => (x.responsavel || '') === eu && (x.obra || '') === o.nome));
        setAcesso(tem);
      }
    } catch { /* ignore */ }
    setLoading(false);
  };
  useEffect(() => { load(); }, [id]);

  if (loading) return <div className="p-6 text-sm text-slate-400">Carregando obra...</div>;
  if (!obra) return <div className="p-6 text-sm text-slate-400">Obra não encontrada.</div>;
  if (!acesso) return <div className="p-6 text-sm text-slate-400">Você não tem acesso a esta obra.</div>;

  const perfil = perfilEfetivo;
  const podeCriar = pode(perfil, 'obras', 'criar');
  const podeEditar = pode(perfil, 'obras', 'editar');
  const podeExcluir = pode(perfil, 'obras', 'excluir');

  const L = listasObra(obra.nome, data || {}, demandas);
  const s = statsObra(obra.nome, data || {}, demandas);
  const funcById = Object.fromEntries((data?.funcionarios || []).map((f) => [f.id, f]));
  const nomeFunc = (fid) => funcById[fid]?.nome || '—';

  const inativar = async () => {
    if (!confirm('Tem certeza que deseja excluir esta obra?\n\nA exclusão poderá afetar os registros vinculados à obra. A obra será inativada (histórico e auditoria mantidos).')) return;
    await base44.entities.Obras.update(obra.id, { ativa: false, status: 'Cancelada' });
    await registrarAcao('Excluiu/Inativou obra', obra.nome, user, 'Obra', obra.nome);
    window.history.back();
  };

  const salvarEdit = async () => { await registrarAcao('Editou obra', obra.nome, user, 'Obra', obra.nome); setFormOpen(false); await load(); };

  const colsAsos = [{ key: 'f', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 't', label: 'Tipo', value: (r) => r.tipo || '—' }, { key: 'v', label: 'Validade', value: (r) => fmt(r.data_validade) }, { key: 's', label: 'Status', render: (r) => <span className="text-xs">{getStatus(r.data_validade)}</span> }];
  const colsTrei = [{ key: 'f', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 'c', label: 'Curso', value: (r) => r.nome_curso || r.norma_curso || '—' }, { key: 'v', label: 'Validade', value: (r) => fmt(r.data_validade) }, { key: 's', label: 'Status', render: (r) => <span className="text-xs">{getStatus(r.data_validade)}</span> }];
  const colsEpi = [{ key: 'f', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 'i', label: 'EPI', value: (r) => r.item || '—' }, { key: 'ca', label: 'CA', value: (r) => r.certificado_aprovacao || '—' }, { key: 'v', label: 'Validade', value: (r) => fmt(r.data_validade) }, { key: 's', label: 'Status', render: (r) => <span className="text-xs">{getStatus(r.data_validade)}</span> }];
  const colsInsp = [{ key: 't', label: 'Tipo', value: (r) => r.tipo || '—' }, { key: 'r', label: 'Responsável', value: (r) => r.responsavel || '—' }, { key: 'p', label: 'Data prevista', value: (r) => fmt(r.data_proxima) }, { key: 's', label: 'Status', render: (r) => <span className="text-xs">{r.status}</span> }];
  const colsDds = [{ key: 'r', label: 'Responsável', value: (r) => r.responsavel || nomeFunc(r.funcionario_id) }, { key: 't', label: 'Tema', value: (r) => r.tema || '—' }, { key: 'd', label: 'Data', value: (r) => fmt(r.data) }];
  const colsOco = [{ key: 't', label: 'Tipo', value: (r) => r.tipo || '—' }, { key: 'f', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 'd', label: 'Data', value: (r) => fmt(r.data) }, { key: 'g', label: 'Gravidade', value: (r) => r.gravidade || '—' }, { key: 's', label: 'Situação', render: (r) => <span className="text-xs">{r.situacao}</span> }];
  const colsDoc = [{ key: 'n', label: 'Documento', value: (r) => r.nome || '—' }, { key: 't', label: 'Tipo', value: (r) => r.tipo || '—' }, { key: 'f', label: 'Colaborador', value: (r) => nomeFunc(r.funcionario_id) }, { key: 'u', label: 'Upload', value: (r) => fmt(r.data_upload) }];
  const colsApr = [{ key: 't', label: 'APR', value: (r) => r.titulo || '—' }, { key: 'r', label: 'Responsável', value: (r) => r.responsavel || '—' }, { key: 'p', label: 'Prazo', value: (r) => fmt(r.prazo) }, { key: 's', label: 'Status', render: (r) => <span className="text-xs">{r.status}</span> }];

  return (
    <div>
      <Link to="/obras" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-primary mb-3"><ArrowLeft className="w-3.5 h-3.5" /> Voltar para Obras</Link>

      <div className="bg-card border border-border rounded-lg p-4 mb-4 shadow-card">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center"><Building2 className="w-6 h-6 text-primary" /></div>
            <div>
              <h1 className="text-xl font-semibold text-foreground">{obra.nome}</h1>
              <p className="text-sm text-muted-foreground">{obra.cliente || '—'} · <span className="text-xs px-2 py-0.5 rounded bg-muted">{obra.status}</span></p>
            </div>
          </div>
          <div className="flex gap-2">
            {podeEditar && <Button variant="outline" onClick={() => setFormOpen(true)}><Pencil className="w-4 h-4" /> Editar</Button>}
            {podeExcluir && <Button variant="destructive" onClick={inativar}><Trash2 className="w-4 h-4" /> Excluir</Button>}
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 text-sm">
          <div><span className="text-xs text-slate-400">Responsável</span><p className="text-[#0b2545] font-medium">{obra.responsavel || '—'}</p></div>
          <div><span className="text-xs text-slate-400">Responsável SST</span><p className="text-[#0b2545] font-medium">{obra.responsavel_sst || '—'}</p></div>
          <div><span className="text-xs text-slate-400">Período</span><p className="text-[#0b2545] font-medium">{fmt(obra.data_inicio)} → {fmt(obra.data_prevista_termino)}</p></div>
          <div><span className="text-xs text-slate-400">Local</span><p className="text-[#0b2545] font-medium">{[obra.cidade, obra.estado].filter(Boolean).join('/') || '—'}</p></div>
        </div>
      </div>

      <ObraSectionNav section={section} tab={tab} onSection={setSection} onTab={setTab} />

      <div className="bg-card border border-border rounded-lg p-4 shadow-card">
        {tab === 'visao' && <ObraVisaoGeral nome={obra.nome} data={data} demandas={demandas} />}
        {tab === 'colaboradores' && <ObraColaboradores nome={obra.nome} L={L} data={data} onRefresh={load} podeEditar={podeEditar} />}
        {tab === 'tarefas' && <ObraTarefas nome={obra.nome} L={L} onRefresh={load} podeEditar={podeEditar} podeExcluir={podeExcluir} />}
        {tab === 'documentos' && <ObraListaTab rows={L.documentos} columns={colsDoc} route={(r) => `/funcionarios/${r.funcionario_id}`} emptyMessage="Nenhum documento vinculado." />}
        {tab === 'asos' && <ObraAsos L={L} data={data} onRefresh={load} podeEditar={podeEditar} podeExcluir={podeExcluir} />}
        {tab === 'treinamentos' && <ObraTreinamentos L={L} data={data} onRefresh={load} podeEditar={podeEditar} podeExcluir={podeExcluir} />}
        {tab === 'epis' && <ObraEpis L={L} data={data} onRefresh={load} podeEditar={podeEditar} podeExcluir={podeExcluir} />}
        {tab === 'inspecoes' && <ObraInspecoes L={L} nome={obra.nome} data={data} onRefresh={load} podeEditar={podeEditar} podeExcluir={podeExcluir} />}
        {tab === 'aprs' && <ObraListaTab rows={L.aprs} columns={colsApr} route="/formularios" />}
        {tab === 'dds' && <ObraDds L={L} data={data} onRefresh={load} podeEditar={podeEditar} podeExcluir={podeExcluir} obra={obra} />}
        {tab === 'ocorrencias' && <ObraOcorrencias L={L} data={data} onRefresh={load} podeEditar={podeEditar} podeExcluir={podeExcluir} />}
        {tab === 'custo' && <ObraCustoMO obraNome={obra.nome} />}
        {tab === 'pendencias' && <ObraPendencias L={L} />}
        {tab === 'relatorios' && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {[
              ['Colaboradores ativos', s.ativos], ['Total colaboradores', s.total], ['Tarefas', s.tarefas],
              ['Tarefas atrasadas', s.atrasadas], ['Pendências', s.pendencias], ['ASOs vencendo', s.asosVenc],
              ['Treinamentos vencendo', s.treiVenc], ['EPIs vencendo', s.episVenc], ['Inspeções pendentes', s.inspPend],
              ['APRs pendentes', s.aprPend], ['Ocorrências abertas', s.ocoAbertas], ['NCs abertas', s.ncs],
            ].map(([l, v]) => (
              <div key={l} className="border border-slate-200 rounded-lg p-3">
                <p className="text-xs text-slate-500">{l}</p>
                <p className="text-xl font-bold text-[#0b2545]">{v}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      <ObraForm open={formOpen} onOpenChange={setFormOpen} obra={obra} onSaved={salvarEdit} />
    </div>
  );
}