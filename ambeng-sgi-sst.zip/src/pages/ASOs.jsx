import React from 'react';
import ValidityPage from '@/components/ValidityPage';

const fields = [
  { name: 'tipo', label: 'Tipo', options: ['Admissional', 'Periódico', 'Mudança de Função', 'Retorno ao Trabalho', 'Demissional'] },
  { name: 'data_exame', label: 'Data do exame', type: 'date' },
  { name: 'data_validade', label: 'Validade', type: 'date' },
];

export default function ASOs() {
  return <ValidityPage title="ASOs" subtitle="Atestados de Saúde Ocupacional" entityName="ASOs" fields={fields} />;
}