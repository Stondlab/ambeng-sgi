import React, { useEffect, useMemo, useState, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Plus, KanbanSquare, Tag, Zap, Columns3 } from 'lucide-react';
import { isAtrasada, venceHoje, isBloqueada, parseList } from '@/lib/acoes';
import { rodarAutomacoes, carregarColunas, carregarQuadros, garantirQuadroGeral, pertenceAoQuadro, verificarPrazos } from '@/lib/quadro';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel } from '@/components/ui/select';
import { nomeUsuario } from '@/lib/usuarioNome';
import NovaAcaoModal from '@/components/operacoes/NovaAcaoModal';
import AcaoDetalhe from '@/components/operacoes/AcaoDetalhe';
import EtiquetasManager from '@/components/operacoes/EtiquetasManager';
import RegrasAutomacaoManager from '@/components/operacoes/RegrasAutomacaoManager';
import KanbanColunas from '@/components/operacoes/KanbanColunas';
import ColunasManager from '@/components/operacoes/ColunasManager';
import NovoQuadroModal from '@/components/operacoes/NovoQuadroModal';
import JobForm from '@/components/operacoes/JobForm';
import useUsuarios from '@/hooks/useUsuarios';
import { obrasAtivasParaLancamento } from '@/lib/obraDisponibilidade';
import MinhasTarefas from '@/components/operacoes/MinhasTarefas';
import SubtarefaDetalhe from '@/components/operacoes/SubtarefaDetalhe';
import OperacoesFilterBar from '@/components/operacoes/OperacoesFilterBar';
import NotificacoesBell from '@/components/operacoes/NotificacoesBell';

// Abas visuais de filtro rápido — substituem dropdowns de Status/Arquivamento.
const TABS = [
  { id: 'todos', label: 'Todos', cls: 'bg-primary text-primary-foreground', badge: 'bg-white/20' },
  { id: 'minhas', label: 'Minhas Tarefas', cls: 'bg-primary text-primary-foreground', badge: 'bg-white/20' },
  { id: 'vencidas', label: 'Vencidas', cls: 'bg-red-500 text-white', badge: 'bg-white/25' },
  { id: 'bloqueadas', label: 'Bloqueadas', cls: 'bg-[#7f1d1d] text-white', badge: 'bg-white/25' },
];

export default function PainelQuadro() {
  const { user } = useAuth();
  const [demands, setDemands] = useState([]);
  const [jobs, setJobs] = useState([]);
  const usuarios = useUsuarios();
  const [obras, setObras] = useState([]);
  const [etiquetas, setEtiquetas] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [colunas, setColunas] = useState([]);
  const [orcamentos, setOrcamentos] = useState([]);
  const [subtarefas, setSubtarefas] = useState([]);
  const [selectedSubtask, setSelectedSubtask] = useState(null);
  const [showNova, setShowNova] = useState(false);
  const [prefill, setPrefill] = useState(null);
  const [selected, setSelected] = useState(null);
  const [filtroRapido, setFiltroRapido] = useState('todos');
  const [search, setSearch] = useState('');
  const [filtros, setFiltros] = useState({ responsavel: 'todos', obra: 'todos', prioridade: 'todos', status: 'todos', categoria: 'todos', etiqueta: 'todos' });
  const [showEtiquetas, setShowEtiquetas] = useState(false);
  const [showRegras, setShowRegras] = useState(false);
  const [showColunas, setShowColunas] = useState(false);
  const [showJobForm, setShowJobForm] = useState(false);
  const [jobEdit, setJobEdit] = useState(null);
  const [jobPrefillObra, setJobPrefillObra] = useState('');
  const [quadros, setQuadros] = useState([]);
  const [quadroId, setQuadroId] = useState(null);
  const [geralId, setGeralId] = useState(null);
  const [showNovoQuadro, setShowNovoQuadro] = useState(false);

  const load = useCallback(async () => {
    let all = [];
    try { all = await base44.entities.Demandas.list('-created_date', 500); } catch { all = []; }
    setDemands(all);
    return all;
  }, []);
  const loadJobs = async () => { let j = []; try { j = await base44.entities.Jobs.list('-created_date', 500); } catch {} setJobs(j); };
  const loadEtiquetas = async () => { let e = []; try { e = await base44.entities.Etiquetas.list('-created_date', 500); } catch {} setEtiquetas(e); };
  const loadCategorias = async () => { let c = []; try { c = await base44.entities.Categorias.list('nome', 500); } catch {} setCategorias(c); };
  const loadOrcamentos = async () => { let o = []; try { o = await base44.entities.Orcamentos.list('-created_date', 500); } catch {} setOrcamentos(o); };
  const loadSubtarefas = async () => { let s = []; try { s = await base44.entities.Subtarefas.list('ordem', 2000); } catch {} setSubtarefas(s); return s; };
  const loadColunas = async () => { setColunas(await carregarColunas(quadroId, geralId)); };

  useEffect(() => {
    (async () => {
      const g = await garantirQuadroGeral();
      setGeralId(g?.id || null);
      setQuadroId(g?.id || null);
      let qs = []; try { qs = await carregarQuadros(); } catch {}
      setQuadros(qs);
      const all = await load();
      const demandaId = new URLSearchParams(window.location.search).get('demanda');
      if (demandaId) setSelected(all.find((item) => item.id === demandaId) || null);
      loadJobs(); loadEtiquetas(); loadCategorias(); loadOrcamentos(); loadSubtarefas();
      try { setObras(obrasAtivasParaLancamento(await base44.entities.Obras.list('nome', 500))); } catch {}
      setTimeout(() => { verificarPrazos(all, g?.id).then(() => load()).catch(() => {}); }, 800);
    })();
  }, []);

  useEffect(() => {
    if (!quadroId) return;
    carregarColunas(quadroId, geralId).then(setColunas).catch(() => setColunas([]));
  }, [quadroId, geralId]);

  const nomeExibicao = user?.nome_exibicao || user?.full_name || user?.email || '—';
  const meusNomes = [nomeUsuario(user), user?.nome_exibicao, user?.full_name].filter(Boolean);
  const hora = new Date().getHours();
  const saudacao = hora < 12 ? 'Bom dia' : hora < 18 ? 'Boa tarde' : 'Boa noite';
  const souMinha = (d) => meusNomes.includes(d.responsavel) || parseList(d.membros).some((m) => meusNomes.includes(m)) || subtarefas.some((item) => item.job_id === d.id && meusNomes.includes(item.responsavel));

  const boardDemands = useMemo(() => demands.filter((d) => pertenceAoQuadro(d.quadro_id, quadroId, geralId)), [demands, quadroId, geralId]);
  const minhasSubtarefas = useMemo(() => subtarefas.filter((item) => meusNomes.includes(item.responsavel) && boardDemands.some((tarefa) => tarefa.id === item.job_id)), [subtarefas, boardDemands, meusNomes.join('|')]);
  const minhasDemandas = useMemo(() => boardDemands.filter((d) => !d.arquivada && (meusNomes.includes(d.responsavel) || parseList(d.membros).some((m) => meusNomes.includes(m)))), [boardDemands, meusNomes.join('|')]);

  const counts = useMemo(() => ({
    todos: boardDemands.filter((d) => !d.arquivada).length,
    minhas: minhasSubtarefas.length + boardDemands.filter((d) => !d.arquivada && (meusNomes.includes(d.responsavel) || parseList(d.membros).some((m) => meusNomes.includes(m)))).length,
    vencidas: boardDemands.filter((d) => !d.arquivada && isAtrasada(d)).length,
    bloqueadas: boardDemands.filter((d) => !d.arquivada && isBloqueada(d)).length,
  }), [boardDemands, subtarefas, minhasSubtarefas.length]);

  const filtradas = useMemo(() => {
    const q = search.trim().toLowerCase();
    return boardDemands.filter((d) => {
      if (d.arquivada) return false;
      if (filtroRapido === 'minhas' && !souMinha(d)) return false;
      if (filtroRapido === 'vencidas' && !isAtrasada(d)) return false;
      if (filtroRapido === 'bloqueadas' && !isBloqueada(d)) return false;
      if (filtros.responsavel !== 'todos' && d.responsavel !== filtros.responsavel) return false;
      if (filtros.obra !== 'todos' && d.obra !== filtros.obra) return false;
      if (filtros.prioridade !== 'todos' && d.prioridade !== filtros.prioridade) return false;
      if (filtros.status !== 'todos' && d.status !== filtros.status) return false;
      if (filtros.categoria !== 'todos' && d.categoria !== filtros.categoria) return false;
      if (filtros.etiqueta !== 'todos' && !parseList(d.etiquetas).includes(filtros.etiqueta)) return false;
      if (q && !(`${d.titulo} ${d.descricao} ${d.responsavel} ${d.obra} ${d.categoria}`.toLowerCase().includes(q))) return false;
      return true;
    });
  }, [boardDemands, filtroRapido, search, filtros]);

  const resumo = useMemo(() => ({
    hoje: boardDemands.filter(venceHoje).length,
    criticas: boardDemands.filter((d) => d.prioridade === 'Crítica' && d.status !== 'Concluído' && d.status !== 'Cancelado').length,
    atrasadas: boardDemands.filter(isAtrasada).length,
    concluidas: boardDemands.filter((d) => d.status === 'Concluído').length,
    minhas: minhasSubtarefas.length + boardDemands.filter((d) => !d.arquivada && (meusNomes.includes(d.responsavel) || parseList(d.membros).some((m) => meusNomes.includes(m)))).length,
  }), [boardDemands, subtarefas, minhasSubtarefas.length]);

  const refreshSel = async () => { const all = await load(); loadEtiquetas(); loadCategorias(); loadOrcamentos(); loadSubtarefas(); if (selected) { const f = all.find((x) => x.id === selected.id); if (f) setSelected(f); } };

  const onSavedNova = async (criado) => {
    setShowNova(false); setPrefill(null);
    await Promise.all([load(), loadSubtarefas(), loadOrcamentos()]);
    if (criado) rodarAutomacoes({ tipo: 'criar', categoria: criado.categoria, cartaoTipo: criado.tipo }, { ...criado }, geralId);
  };

  const abrirNovaNaColuna = (col) => { setPrefill({ quadro_id: quadroId, coluna_id: col?.id || '', status: col?.status_ref || col?.nome || 'Novo' }); setShowNova(true); };
  const abrirNovoJobNaObra = (obraNome) => { setJobEdit(null); setJobPrefillObra(obraNome || ''); setShowJobForm(true); };
  const onSavedJob = async () => { setShowJobForm(false); setJobEdit(null); setJobPrefillObra(''); await loadJobs(); };

  const STAT = [
    { label: 'Para hoje', value: resumo.hoje, tone: 'text-amber-600' },
    { label: 'Críticas', value: resumo.criticas, tone: 'text-red-600' },
    { label: 'Atrasadas', value: resumo.atrasadas, tone: 'text-red-600' },
    { label: 'Minhas', value: resumo.minhas, tone: 'text-[#0b2545]' },
    { label: 'Concluídas', value: resumo.concluidas, tone: 'text-emerald-600' },
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-64px)]">
      {/* Cabeçalho */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 mb-2 shrink-0">
        <div>
          <h1 className="text-2xl font-semibold text-[#0b2545]">Central de Operações</h1>
          <p className="text-sm text-slate-500">{saudacao}, {nomeUsuario(user)} — acompanhe tarefas e processos por status.</p>
          <div className="flex flex-wrap gap-x-5 gap-y-1 mt-1">
            {STAT.map((s) => (
              <div key={s.label} className="flex items-baseline gap-1.5">
                <span className={`text-lg font-bold ${s.tone}`}>{s.value}</span>
                <span className="text-xs text-slate-400">{s.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0 flex-wrap">
          <Select value={quadroId || ''} onValueChange={setQuadroId}><SelectTrigger className="h-11 w-44"><SelectValue placeholder="Selecionar quadro" /></SelectTrigger><SelectContent><SelectGroup><SelectLabel>Quadros</SelectLabel>{quadros.map((q) => <SelectItem key={q.id} value={q.id}>{q.nome}{q.padrao ? ' (padrão)' : ''}</SelectItem>)}</SelectGroup></SelectContent></Select>
          <Button onClick={() => setShowNovoQuadro(true)} variant="outline" className="min-h-[44px]" title="Novo quadro"><Plus className="h-4 w-4" /></Button>
          <Button onClick={() => setShowColunas(true)} variant="outline" className="min-h-[44px] border-slate-200" title="Colunas"><Columns3 className="w-4 h-4 text-amber-500" /></Button>
          <Button onClick={() => setShowEtiquetas(true)} variant="outline" className="min-h-[44px] border-slate-200" title="Etiquetas"><Tag className="w-4 h-4 text-amber-500" /></Button>
          <Button onClick={() => setShowRegras(true)} variant="outline" className="min-h-[44px]" title="Automações"><Zap className="w-4 h-4 text-warning" /></Button>
          <NotificacoesBell user={user} />
          <Button onClick={() => { setPrefill(null); setShowNova(true); }} className="min-h-[44px] px-5 font-semibold"><Plus className="w-5 h-5" />Nova tarefa</Button>
        </div>
      </div>

      <OperacoesFilterBar search={search} setSearch={setSearch} filtros={filtros} setFiltros={setFiltros} rapido={filtroRapido} setRapido={setFiltroRapido} counts={counts} demandas={boardDemands} categorias={categorias} etiquetas={etiquetas} />

      {/* Quadro Kanban — visualização padrão e única */}
      <div className="min-h-[520px] flex-1 overflow-x-auto rounded-xl bg-muted/30 p-2">
        {filtroRapido === 'minhas' ? <MinhasTarefas subtarefas={minhasSubtarefas} minhasDemandas={filtradas} demands={boardDemands} usuarios={usuarios} onOpenSubtask={setSelectedSubtask} onOpenJob={setSelected} /> : colunas.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-slate-400">
            <KanbanSquare className="w-10 h-10 mb-2 opacity-40" />
            <p className="text-sm">Nenhuma coluna para exibir.</p>
          </div>
        ) : (
          <KanbanColunas
            colunas={colunas}
            demands={filtradas}
            onOpen={setSelected}
            onAddTask={abrirNovaNaColuna}
            onUpdated={load}
            user={user}
            etiquetas={etiquetas}
            categorias={categorias}
            densidade="normal"
            podeEditar
            orcamentos={orcamentos}
            subtarefas={subtarefas}
            usuarios={usuarios}
            geralId={geralId}
          />
        )}
      </div>

      {showNova && <NovaAcaoModal open={showNova} onClose={() => { setShowNova(false); setPrefill(null); }} onSaved={onSavedNova} user={user} prefill={prefill} usuarios={usuarios} obras={obras} jobs={jobs} />}
      {selectedSubtask && <SubtarefaDetalhe subtarefa={selectedSubtask} job={demands.find((item) => item.id === selectedSubtask.job_id)} user={user} usuarios={usuarios} onClose={() => setSelectedSubtask(null)} onOpenJob={() => { const job = demands.find((item) => item.id === selectedSubtask.job_id); setSelectedSubtask(null); if (job) setSelected(job); }} onUpdated={async () => { const list = await loadSubtarefas(); setSelectedSubtask(list.find((item) => item.id === selectedSubtask.id) || null); }} />}
      {selected && <AcaoDetalhe acao={selected} orcamento={orcamentos.find((item) => item.demanda_id === selected.id)} onClose={() => setSelected(null)} onUpdated={async () => { await refreshSel(); await loadSubtarefas(); }} user={user} etiquetas={etiquetas} />}
      <EtiquetasManager open={showEtiquetas} onClose={() => setShowEtiquetas(false)} onAtualizou={loadEtiquetas} />
      <ColunasManager open={showColunas} onClose={() => setShowColunas(false)} onAtualizou={() => carregarColunas(quadroId, geralId).then(setColunas)} quadroId={quadroId} geralId={geralId} />
      <RegrasAutomacaoManager open={showRegras} onClose={() => setShowRegras(false)} quadroId={quadroId} geralId={geralId} />
      <NovoQuadroModal open={showNovoQuadro} onClose={() => setShowNovoQuadro(false)} onCriado={async (q) => { const qs = await carregarQuadros(); setQuadros(qs); setQuadroId(q.id); }} />
      <JobForm open={showJobForm} onClose={() => { setShowJobForm(false); setJobEdit(null); setJobPrefillObra(''); }} onSaved={onSavedJob} user={user} usuarios={usuarios} obras={obras} jobEdit={jobEdit} prefillObra={jobPrefillObra} />
    </div>
  );
}