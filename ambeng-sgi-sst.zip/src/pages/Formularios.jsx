import React from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '@/components/PageHeader';
import { Users, AlertTriangle, Calendar, ShieldCheck, Plus, History } from 'lucide-react';
import { usePermissoes } from '@/lib/PermissoesContext';
import { pode, podeAcessar } from '@/lib/permissoes';
import { mapaRotaModulo } from '@/lib/modulosPermissao';

const GRUPOS = [
  { titulo: 'Cadastros', icon: Users, forms: [
    { nome: 'Colaborador', desc: 'Cadastro do colaborador e dados pessoais', link: '/funcionarios' },
    { nome: 'ASO', desc: 'Atestado de Saúde Ocupacional', link: '/asos' },
    { nome: 'Treinamento', desc: 'Registro de treinamentos e certificados', link: '/treinamentos' },
    { nome: 'EPI', desc: 'Entrega de Equipamentos de Proteção Individual', link: '/epis' },
  ]},
  { titulo: 'Operacionais', icon: Calendar, forms: [
    { nome: 'DDS', desc: 'Diálogo Diário de Segurança', link: '/funcionarios' },
    { nome: 'Integração', desc: 'Registro de integração de novo colaborador', link: '/funcionarios' },
    { nome: 'Inspeção', desc: 'Inspeções de segurança e máquinas', link: '/funcionarios' },
  ]},
  { titulo: 'Ocorrências', icon: AlertTriangle, forms: [
    { nome: 'Ocorrência', desc: 'Registro de acidentes e quase-acidentes', link: '/ocorrencias' },
    { nome: 'Não Conformidade', desc: 'Abertura de NC e plano de ação', link: '/ocorrencias' },
  ]},
  { titulo: 'Auditoria e Anexos', icon: ShieldCheck, forms: [
    { nome: 'Documento', desc: 'Anexos e documentos do colaborador', link: '/funcionarios' },
    { nome: 'Pacote de Auditoria', desc: 'Evidências e documentos de auditoria', link: '/auditoria' },
  ]},
];

export default function Formularios() {
  const { perfilEfetivo } = usePermissoes();
  const podeCriarDe = (link) => {
    const m = mapaRotaModulo(link);
    return m ? pode(perfilEfetivo, m.id, 'criar') : false;
  };
  const visiveis = (forms) => forms.filter((f) => podeAcessar(perfilEfetivo, f.link));

  return (
    <div>
      <PageHeader title="Formulários do SGI" subtitle="Todos os formulários centralizados e agrupados por categoria." />
      <div className="space-y-6">
        {GRUPOS.map((g) => {
          const forms = visiveis(g.forms);
          if (!forms.length) return null;
          const GIcon = g.icon;
          return (
          <section key={g.titulo}>
            <div className="flex items-center gap-2 mb-3"><GIcon className="w-5 h-5 text-[#0b2545]" /><h2 className="text-base font-semibold text-[#0b2545]">{g.titulo}</h2></div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {forms.map((f) => {
                const podeCriar = podeCriarDe(f.link);
                return (
                <div key={f.nome} className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col">
                  <h3 className="font-semibold text-[#0b2545]">{f.nome}</h3>
                  <p className="text-sm text-slate-500 mt-1 flex-1">{f.desc}</p>
                  <p className="text-xs text-slate-400 mt-2">Última revisão: —</p>
                  <div className="flex gap-2 mt-3">
                    {podeCriar && <Link to={f.link} className="flex items-center gap-1 text-xs font-medium px-2.5 py-1.5 rounded-md bg-[#0b2545] text-white hover:bg-[#0b2545]/90"><Plus className="w-3.5 h-3.5" />Novo</Link>}
                    <Link to={f.link} className="flex items-center gap-1 text-xs font-medium px-2.5 py-1.5 rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50"><History className="w-3.5 h-3.5" />Histórico</Link>
                  </div>
                </div>
              );})}
            </div>
          </section>
        );})}
      </div>
    </div>
  );
}