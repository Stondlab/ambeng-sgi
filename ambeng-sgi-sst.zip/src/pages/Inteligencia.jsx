import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import { useSstData } from '@/hooks/useSstEntitiesData';
import MotorRegrasPanel from '@/components/relatorios/MotorRegrasPanel';
import PacoteAuditoria from '@/components/relatorios/PacoteAuditoria';
import AuditoriaConformidade from '@/components/relatorios/AuditoriaConformidade';
import AssistenteSGI from '@/components/relatorios/AssistenteSGI';
import RecomendacoesInteligentes from '@/components/relatorios/RecomendacoesInteligentes';
import AlertasSistema from '@/components/relatorios/AlertasSistema';
import ResumoInteligente from '@/components/relatorios/ResumoInteligente';
import { Cog, ScrollText, Bot, Lightbulb, BellRing, Sparkles } from 'lucide-react';

const noop = () => {};

// Inteligência — ferramentas analíticas e IA do SGI.
// Os indicadores executativos (cards, drill-down, semáforo) ficam no
// Dashboard Executivo (/dashboards/executivo). Aqui ficam motor de regras,
// auditoria, assistente IA, recomendações, alertas e resumo inteligente.
const TABS = [
  { to: '/inteligencia', label: 'Resumo Inteligente', icon: Sparkles },
  { to: '/inteligencia/motor', label: 'Motor de Regras', icon: Cog },
  { to: '/inteligencia/auditoria', label: 'Auditoria', icon: ScrollText },
  { to: '/inteligencia/assistente', label: 'Assistente IA', icon: Bot },
  { to: '/inteligencia/recomendacoes', label: 'Recomendações', icon: Lightbulb },
  { to: '/inteligencia/alertas', label: 'Alertas', icon: BellRing },
];

export default function Inteligencia() {
  const data = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis', 'integracoes', 'documentos', 'dds', 'ocorrencias', 'inspecoes', 'maquinas'], true);
  const { pathname } = useLocation();
  if (!data) return <p className="text-slate-400">Carregando inteligência...</p>;

  const active = TABS.find((s) => s.to === pathname) || TABS[0];

  return (
    <div>
      <div className="mb-4">
        <h1 className="text-2xl font-semibold text-[#0b2545]">Inteligência</h1>
        <p className="text-sm text-slate-500">Motor de regras, auditoria, assistente IA, recomendações e alertas do SGI.</p>
      </div>

      <div className="flex gap-1 overflow-x-auto pb-2 mb-4 border-b border-slate-200">
        {TABS.map((s) => { const Icon = s.icon; const on = s.to === active.to; return (
          <Link key={s.to} to={s.to} className={`flex items-center gap-1.5 min-h-[44px] px-3 rounded-t-md text-sm whitespace-nowrap transition-colors ${on ? 'text-[#0b2545] font-semibold border-b-2 border-amber-400 -mb-[2px]' : 'text-slate-500 hover:text-[#0b2545]'}`}>
            <Icon className="w-4 h-4" />{s.label}
          </Link>
        );})}
      </div>

      {active.to === '/inteligencia' && <ResumoInteligente data={data} />}
      {active.to === '/inteligencia/motor' && <MotorRegrasPanel data={data} />}
      {active.to === '/inteligencia/auditoria' && (
        <div className="space-y-4"><PacoteAuditoria data={data} /><AuditoriaConformidade data={data} /></div>
      )}
      {active.to === '/inteligencia/assistente' && <AssistenteSGI data={data} />}
      {active.to === '/inteligencia/recomendacoes' && <RecomendacoesInteligentes data={data} onNav={noop} />}
      {active.to === '/inteligencia/alertas' && <AlertasSistema data={data} onNav={noop} />}
    </div>
  );
}