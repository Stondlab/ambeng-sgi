import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import PageHeader from '@/components/PageHeader';
import MatrizTreinamentos from '@/components/treinamentos/MatrizTreinamentos';
import { refreshSstData, useSstData } from '@/hooks/useSstEntitiesData';
import { getStatus, fmt } from '@/lib/sst';
import { Plus, X, Upload } from 'lucide-react';
import { usePerm } from '@/hooks/usePerm';
import { mensagemAmigavelErro, validarDataOpcional, validarNumeroOpcional } from '@/lib/validacao';

const NRS = ['NR-35 Trabalho em Altura', 'NR-18 Construção Civil', 'NR-10 Eletricidade', 'NR-11 Operação de Equipamentos', 'NR-06 EPI', 'NR-12 Segurança no Trabalho', 'NR-33 Espaços Confinados', 'NR-20 Combustíveis'];

export default function Treinamentos() {
  const data = useSstData(['funcionarios', 'treinamentos']);
  const { podeCriar, podeEditar } = usePerm('treinamentos');
  const [sel, setSel] = useState(null);
  const [showForm, setShowForm] = useState(false);

  if (!data) return <p className="text-slate-400">Carregando treinamentos...</p>;

  return (
    <div>
      <PageHeader title="Treinamentos" subtitle="Matriz de capacitações em Normas Regulamentadoras." action={
        podeCriar ? <Button onClick={() => setShowForm((s) => !s)} className="bg-amber-400 text-[#0b2545] hover:bg-amber-300 font-semibold min-h-[44px]"><Plus className="w-4 h-4 mr-1" />Novo</Button> : null
      } />
      <MatrizTreinamentos funcionarios={data.funcionarios} treinamentos={data.treinamentos} onSelect={setSel} />

      {showForm && <TreinamentoForm funcionarios={data.funcionarios} onClose={() => setShowForm(false)} onSaved={() => { setShowForm(false); refreshSstData(); }} />}

      {sel && <DetalheTreinamento sel={sel} podeEditar={podeEditar} onClose={() => setSel(null)} onSaved={() => { setSel(null); refreshSstData(); }} />}
    </div>
  );
}

function TreinamentoForm({ funcionarios, onClose, onSaved }) {
  const [form, setForm] = useState({ funcionario_id: '', norma_curso: '', data_realizacao: '', data_validade: '', instrutor: '', carga_horaria: '' });
  const [erro, setErro] = useState('');
  const save = async (e) => {
    e.preventDefault();
    if (!form.funcionario_id || !form.norma_curso || !form.data_realizacao || !form.data_validade) return setErro('Preencha funcionário, curso, realização e validade.');
    if (!validarDataOpcional(form.data_realizacao) || !validarDataOpcional(form.data_validade)) return setErro('Informe datas válidas.');
    if (form.data_validade < form.data_realizacao) return setErro('A validade não pode ser anterior à realização.');
    if (!validarNumeroOpcional(form.carga_horaria)) return setErro('Informe uma carga horária numérica válida.');
    setErro('');
    try { await base44.entities.Treinamentos.create({ ...form, carga_horaria: form.carga_horaria === '' ? null : Number(form.carga_horaria) }); onSaved(); }
    catch (error) { setErro(mensagemAmigavelErro(error)); }
  };
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <form onSubmit={save} className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">Novo Treinamento</h3><button type="button" onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div><Label>Funcionário</Label>
          <Select value={form.funcionario_id} onValueChange={(v) => setForm({ ...form, funcionario_id: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{funcionarios.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}</SelectContent></Select>
        </div>
        <div><Label>NR / Curso</Label>
          <Select value={form.norma_curso} onValueChange={(v) => setForm({ ...form, norma_curso: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{NRS.map((n) => <SelectItem key={n} value={n}>{n}</SelectItem>)}</SelectContent></Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Realização</Label><Input className="mt-1" type="date" value={form.data_realizacao} onChange={(e) => setForm({ ...form, data_realizacao: e.target.value })} required /></div>
          <div><Label>Validade</Label><Input className="mt-1" type="date" value={form.data_validade} onChange={(e) => setForm({ ...form, data_validade: e.target.value })} required /></div>
        </div>
        <div><Label>Instrutor</Label><Input className="mt-1" value={form.instrutor} onChange={(e) => setForm({ ...form, instrutor: e.target.value })} /></div>
        <div><Label>Carga horária (h)</Label><Input className="mt-1" type="number" value={form.carga_horaria} onChange={(e) => setForm({ ...form, carga_horaria: e.target.value })} /></div>
        {erro && <p className="text-sm text-red-600">{erro}</p>}
        <div className="flex justify-end gap-2 pt-2"><Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button><Button type="submit" className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button></div>
      </form>
    </div>
  );
}

function DetalheTreinamento({ sel, podeEditar, onClose, onSaved }) {
  const { func, treinamento, nr } = sel;
  const [uploading, setUploading] = useState(false);
  const rec = treinamento;

  const uploadCert = async (file) => {
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      await base44.entities.Treinamentos.update(rec.id, { certificado_url: file_url });
      onSaved();
    } catch (e) { /* ignore */ }
    setUploading(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">{func.nome}</h3><button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <p className="text-sm text-slate-500">{nr}</p>
        {!rec ? (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-800">Sem treinamento registrado para esta NR. Use "Novo" para cadastrar.</div>
        ) : (
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">Realização</span><span className="text-[#0b2545] font-medium">{fmt(rec.data_realizacao)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Validade</span><span className="text-[#0b2545] font-medium">{fmt(rec.data_validade)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Status</span><span className="font-medium">{getStatus(rec.data_validade)}</span></div>
            {rec.instrutor && <div className="flex justify-between"><span className="text-slate-500">Instrutor</span><span>{rec.instrutor}</span></div>}
            {rec.carga_horaria != null && <div className="flex justify-between"><span className="text-slate-500">Carga horária</span><span>{rec.carga_horaria}h</span></div>}
            <div className="pt-2 border-t border-slate-100">
              <Label className="text-xs">Certificado (PDF)</Label>
              {rec.certificado_url ? (
                <div className="flex items-center gap-2 mt-1">
                  <a href={rec.certificado_url} target="_blank" rel="noreferrer" className="text-sm text-blue-600 underline truncate">Ver certificado</a>
                  {podeEditar && <label className="text-xs text-amber-600 underline cursor-pointer">Trocar<input type="file" accept=".pdf" className="hidden" onChange={(e) => uploadCert(e.target.files[0])} /></label>}
                </div>
              ) : podeEditar ? (
                <label className="mt-1 flex items-center gap-2 min-h-[44px] px-3 rounded-lg border border-dashed border-slate-300 cursor-pointer hover:bg-slate-50">
                  <Upload className="w-4 h-4 text-slate-400" /><span className="text-sm text-slate-500">{uploading ? 'Enviando...' : 'Anexar certificado'}</span>
                  <input type="file" accept=".pdf" className="hidden" onChange={(e) => uploadCert(e.target.files[0])} />
                </label>
              ) : (
                <p className="text-xs text-slate-400 mt-1">Sem certificado.</p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}