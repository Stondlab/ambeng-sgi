import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { usePermissoes } from '@/lib/PermissoesContext';
import { podeAcessar } from '@/lib/permissoes';
import { nomeUsuario } from '@/lib/usuarioNome';
import MeuDia from '@/components/operacoes/MeuDia';
import ChecklistDoDia from '@/components/operacoes/ChecklistDoDia';
import PainelPrioridades from '@/components/dashboard/PainelPrioridades';
import PainelAnalytics from '@/components/dashboard/PainelAnalytics';
import useDemandasQuery from '@/hooks/useDemandasQuery';
import { BarChart3, Building2, Plus, Rocket, Users, Wallet } from 'lucide-react';

const TABS = [{ id: 'hoje', label: 'Hoje' }, { id: 'prioridades', label: 'Prioridades' }, { id: 'analytics', label: 'Analytics' }];
const ATALHOS = [{ to: '/painel/quadro', label: 'Central de Operações', icon: Rocket }, { to: '/funcionarios', label: 'Pessoas', icon: Users }, { to: '/obras', label: 'Obras', icon: Building2 }, { to: '/dashboards/financeiro', label: 'Financeiro', icon: Wallet }];

export default function Dashboard() {
  const [tab, setTab] = useState('hoje');
  const { user } = useAuth();
  const { perfilEfetivo } = usePermissoes();
  const { demandas, refresh } = useDemandasQuery();
  const hora = new Date().getHours();
  const saudacao = hora < 12 ? 'Bom dia' : hora < 18 ? 'Boa tarde' : 'Boa noite';
  return <div className="space-y-6">
    <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><div><h1 className="text-3xl font-bold tracking-tight text-foreground">{saudacao}, {nomeUsuario(user)}</h1><p className="mt-1 text-sm text-muted-foreground">Foque no que precisa da sua atenção agora.</p></div><Link to="/painel/quadro" className="inline-flex min-h-11 items-center justify-center gap-2 rounded-md bg-primary px-6 text-sm font-semibold text-primary-foreground"><Plus className="h-5 w-5" />Nova Ação</Link></header>
    <nav className="flex gap-2 overflow-x-auto border-b border-border">{TABS.map((item) => <button key={item.id} onClick={() => setTab(item.id)} className={`min-h-11 border-b-2 px-4 text-sm font-medium ${tab === item.id ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>{item.label}</button>)}</nav>
    {tab === 'hoje' && <div className="space-y-6"><MeuDia demands={demandas} user={user} /><ChecklistDoDia demands={demandas} user={user} onUpdated={refresh} /></div>}
    {tab === 'prioridades' && <PainelPrioridades demandas={demandas} />}
    {tab === 'analytics' && <PainelAnalytics demandas={demandas} />}
    <section><h2 className="mb-4 text-lg font-semibold text-foreground">Atalhos rápidos</h2><div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{ATALHOS.filter(({ to }) => podeAcessar(perfilEfetivo, to)).map(({ to, label, icon: Icon }) => <Link key={to} to={to} className="flex min-h-20 items-center gap-3 rounded-lg border border-border bg-card p-4 text-sm font-semibold text-foreground shadow-card hover:bg-muted"><span className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary"><Icon className="h-6 w-6" /></span>{label}</Link>)}</div></section>
    <Link to="/dashboards/executivo" className="inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-primary"><BarChart3 className="h-5 w-5" />Ver Dashboard Executivo</Link>
  </div>;
}