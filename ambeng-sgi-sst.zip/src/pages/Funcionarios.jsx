import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Image } from '@/components/ui/image';
import { Plus, Trash2, User, Search, Pause } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import AssistenteCadastro from '@/components/funcionario/AssistenteCadastro';
import PessoasResumo from '@/components/funcionario/PessoasResumo';
import PessoasEmptyState from '@/components/funcionario/PessoasEmptyState';
import { useSstData, refreshSstData } from '@/hooks/useSstEntitiesData';
import { getStatus, classificarColaborador } from '@/lib/sst';
import { usePerm } from '@/hooks/usePerm';
import { checklistLiberacao } from '@/lib/liberacao';
import TecnicoFuncionarioCard from '@/components/funcionario/TecnicoFuncionarioCard';

const FILTROS = [
  { key: 'ativa', label: 'Ativa Hoje' },
  { key: 'inativos', label: 'Inativos' },
  { key: 'incompletos', label: 'Incompletos' },
  { key: 'pendencias', label: 'Com Pendências' },
];

const PEND_LIB = ['Cadastro Incompleto', 'Pendente de Liberação'];

export default function Funcionarios() {
  const [showAssistente, setShowAssistente] = useState(false);
  const [busca, setBusca] = useState('');
  const [filtro, setFiltro] = useState('ativa');
  const [gerando, setGerando] = useState(false);
  const data = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis', 'integracoes', 'dds', 'ocorrencias', 'documentos', 'pendencias']);
  const permColab = usePerm('colaboradores');
  const { podeCriar: podeCriarFunc, podeEditar: podeEditarFunc, podeExcluir: podeExcluirFunc } = permColab;
  const tecnico = permColab.perfil === 'Técnico';

  const semMatricula = (data?.funcionarios || []).filter((f) => !f.matricula);
  const gerarFaltantes = async () => {
    if (!semMatricula.length || gerando) return;
    setGerando(true);
    for (const f of semMatricula) {
      try {
        const res = await base44.functions.invoke('gerarMatricula', { empresa: f.empresa || '' });
        const m = res.data?.matricula;
        if (m) await base44.entities.Funcionarios.update(f.id, { matricula: m });
      } catch {}
    }
    refreshSstData();
    setGerando(false);
  };

  const list = data?.funcionarios || [];
  const byFunc = useMemo(() => {
    const m = {};
    list.forEach((f) => { m[f.id] = { asos: [], treinamentos: [], epis: [], integracoes: [], dds: [], ocorrencias: [], documentos: [] }; });
    (data?.asos || []).forEach((a) => { if (m[a.funcionario_id]) m[a.funcionario_id].asos.push(a); });
    (data?.treinamentos || []).forEach((t) => { if (m[t.funcionario_id]) m[t.funcionario_id].treinamentos.push(t); });
    (data?.epis || []).forEach((e) => { if (m[e.funcionario_id]) m[e.funcionario_id].epis.push(e); });
    (data?.integracoes || []).forEach((i) => { if (m[i.funcionario_id]) m[i.funcionario_id].integracoes.push(i); });
    (data?.dds || []).forEach((d) => { if (m[d.funcionario_id]) m[d.funcionario_id].dds.push(d); });
    (data?.ocorrencias || []).forEach((o) => { if (m[o.funcionario_id]) m[o.funcionario_id].ocorrencias.push(o); });
    (data?.documentos || []).forEach((doc) => { if (m[doc.funcionario_id]) m[doc.funcionario_id].documentos.push(doc); });
    return m;
  }, [data, list]);

  const asoVenc = (f) => (byFunc[f.id]?.asos || []).some((a) => getStatus(a.data_validade) === 'Vencido');
  const treVenc = (f) => (byFunc[f.id]?.treinamentos || []).some((t) => getStatus(t.data_validade) === 'Vencido');
  const semEpi = (f) => (byFunc[f.id]?.epis || []).length === 0;
  const semInt = (f) => (byFunc[f.id]?.integracoes || []).length === 0;
  const comOco = (f) => (byFunc[f.id]?.ocorrencias || []).some((o) => o.situacao !== 'Encerrada');
  const comNC = (f) => (byFunc[f.id]?.ocorrencias || []).some((o) => o.tipo === 'Não Conformidade' && o.situacao !== 'Encerrada');
  const comPend = (f) => asoVenc(f) || treVenc(f) || semEpi(f) || semInt(f) || comOco(f);
  const emDia = (f) => !comPend(f);

  const alertas = useMemo(() => {
    if (!data) return [];
    const a = [];
    const asoVencCount = (data.asos || []).filter((x) => getStatus(x.data_validade) === 'Vencido').length;
    const asoAVencCount = (data.asos || []).filter((x) => getStatus(x.data_validade) === 'A vencer').length;
    const treVencCount = (data.treinamentos || []).filter((x) => getStatus(x.data_validade) === 'Vencido').length;
    const treAVencCount = (data.treinamentos || []).filter((x) => getStatus(x.data_validade) === 'A vencer').length;
    const semIntCount = list.filter((f) => semInt(f)).length;
    const semEpiCount = list.filter((f) => semEpi(f)).length;
    const ocoAbertas = (data.ocorrencias || []).filter((o) => o.situacao !== 'Encerrada').length;
    const pendCount = (data.pendencias || []).filter((p) => p.status !== 'Concluída').length;
    if (asoVencCount) a.push({ tone: 'red', text: `${asoVencCount} ASO(s) vencido(s)` });
    if (asoAVencCount) a.push({ tone: 'amber', text: `${asoAVencCount} ASO(s) a vencer` });
    if (treVencCount) a.push({ tone: 'red', text: `${treVencCount} treinamento(s) vencido(s)` });
    if (treAVencCount) a.push({ tone: 'amber', text: `${treAVencCount} treinamento(s) a vencer` });
    if (semIntCount) a.push({ tone: 'amber', text: `${semIntCount} sem integração` });
    if (semEpiCount) a.push({ tone: 'amber', text: `${semEpiCount} sem EPI` });
    if (ocoAbertas) a.push({ tone: 'amber', text: `${ocoAbertas} ocorrência(s) aberta(s)` });
    if (pendCount) a.push({ tone: 'amber', text: `${pendCount} pendência(s)` });
    return a;
  }, [data, list]);

  const q = busca.trim().toLowerCase();
  const filtrada = list.filter((f) => {
    const campos = (tecnico ? [f.nome, f.matricula, f.funcao, f.empresa, f.obra] : [f.nome, f.cpf, f.matricula, f.funcao, f.empresa, f.obra, f.telefone, f.email, f.cnh_numero]).map((v) => (v || '').toLowerCase());
    if (q && !campos.some((v) => v.includes(q))) return false;
    if (tecnico) return true;
    if (filtro === 'ativa') return f.status === 'Ativo' && emDia(f);
    if (filtro === 'inativos') return f.status === 'Inativo';
    if (filtro === 'pendencias') return comPend(f);
    if (filtro === 'incompletos') return PEND_LIB.includes(f.status_liberacao) || f.status_liberacao !== 'Liberado para Trabalho';
    const cls = classificarColaborador(f, byFunc[f.id] || { ocorrencias: [] }).classe;
    if (filtro === 'regular') return cls === 'Regular';
    if (filtro === 'atencao') return cls === 'Atenção';
    if (filtro === 'critico') return cls === 'Crítico';
    return true;
  });

  return (
    <div>
      <PageHeader title="Pessoas" subtitle={tecnico ? 'Visão simplificada de funcionários e conformidade de segurança' : 'Funcionários, Prontuário 360° e conformidade'} action={
        <div className="flex items-center gap-2">
          {podeCriarFunc && semMatricula.length > 0 && (
            <Button onClick={gerarFaltantes} disabled={gerando} variant="outline">
              {gerando ? 'Gerando...' : `Gerar matrículas (${semMatricula.length})`}
            </Button>
          )}
          {podeCriarFunc && (
            <Button onClick={() => setShowAssistente(true)} className="font-semibold">
              <Plus className="w-4 h-4 mr-1" /> Novo Colaborador
            </Button>
          )}
        </div>
      } />

      <AssistenteCadastro open={showAssistente} onClose={() => setShowAssistente(false)} onConcluido={() => {}} />

      {!tecnico && <PessoasResumo
        counts={{
          regular: list.filter((f) => classificarColaborador(f, byFunc[f.id] || { ocorrencias: [] }).classe === 'Regular').length,
          atencao: list.filter((f) => classificarColaborador(f, byFunc[f.id] || { ocorrencias: [] }).classe === 'Atenção').length,
          critico: list.filter((f) => classificarColaborador(f, byFunc[f.id] || { ocorrencias: [] }).classe === 'Crítico').length,
        }}
        alertas={alertas}
        filtro={filtro}
        onFiltro={setFiltro}
      />}

      <div className="bg-card border border-border rounded-lg p-4 my-6 flex flex-col sm:flex-row gap-3 shadow-card">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <Input className="pl-9" placeholder={tecnico ? 'Pesquisar por nome, matrícula, função, empresa ou obra...' : 'Pesquisar por nome, CPF, matrícula, cargo, empresa, obra, telefone, e-mail, CNH...'} value={busca} onChange={(e) => setBusca(e.target.value)} />
        </div>
        {!tecnico && <div className="flex gap-1.5 flex-wrap">
          {FILTROS.map((f) => (
            <button key={f.key} onClick={() => setFiltro(f.key)} className={`min-h-10 text-xs px-3 py-1.5 rounded-md border transition ${filtro === f.key ? 'bg-primary text-primary-foreground border-primary' : 'bg-card text-muted-foreground border-border hover:bg-muted'}`}>{f.label}</button>
          ))}
        </div>}
      </div>

      {!data && <p className="text-muted-foreground">Carregando...</p>}
      {data && list.length === 0 && <PessoasEmptyState canCreate={podeCriarFunc} onCreate={() => setShowAssistente(true)} />}
      {data && list.length > 0 && filtrada.length === 0 && <p className="py-8 text-center text-muted-foreground">Nenhum colaborador encontrado com estes filtros.</p>}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {filtrada.map((f) => {
          if (tecnico) return <TecnicoFuncionarioCard key={f.id} funcionario={f} dados={byFunc[f.id]} />;
          const pendencia = comPend(f);
          const cl = checklistLiberacao(f, byFunc[f.id] || {});
          const okCount = cl.filter((i) => i.ok).length;
          const pendentes = cl.filter((i) => !i.ok).map((i) => i.label);
          const statusBadge = f.status === 'Demitido'
            ? { label: 'Desligado', style: 'bg-slate-200 text-slate-600 border-slate-300', tooltip: '' }
            : f.status_liberacao === 'Liberado para Trabalho'
            ? { label: 'Liberado', style: 'bg-emerald-100 text-emerald-700 border-emerald-200', tooltip: '' }
            : { label: `Incompleto (${okCount}/11)`, style: 'bg-amber-50 text-amber-700 border-amber-200', tooltip: `Faltam: ${pendentes.join(', ')}` };
          return (
            <div key={f.id} className="bg-card border border-border rounded-lg p-4 hover:shadow-card-hover hover:border-primary/30 transition-all">
              <Link to={`/prontuario/${f.id}`} className="block">
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center shrink-0 overflow-hidden">
                    {f.foto_url ? <Image src={f.foto_url} fittingType="fill" className="w-full h-full" /> : <User className="w-6 h-6" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-foreground truncate">{f.nome}</p>
                      {pendencia && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-red-100 text-red-700 border border-red-200 shrink-0">Pendência</span>}
                    </div>
                    <p className="text-sm text-muted-foreground">{f.funcao || '—'}</p>
                    <span title={statusBadge.tooltip} className={`inline-block mt-1.5 text-[10px] font-semibold px-1.5 py-0.5 rounded border cursor-help ${statusBadge.style}`}>{statusBadge.label}</span>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {f.status === 'Ativo' && podeEditarFunc && (
                      <button onClick={async (e) => { e.preventDefault(); e.stopPropagation(); await base44.entities.Funcionarios.update(f.id, { status: 'Inativo', data_desligamento: new Date().toISOString().slice(0, 10) }); refreshSstData(); }} className="flex min-h-10 min-w-10 items-center justify-center text-muted-foreground hover:text-warning transition-colors" title="Desativar">
                        <Pause className="w-4 h-4" />
                      </button>
                    )}
                    {podeExcluirFunc && (
                      <button onClick={async (e) => {
                        e.preventDefault(); e.stopPropagation();
                        if (window.confirm('Tem certeza? Esta ação é irreversível.')) {
                          await base44.entities.Funcionarios.delete(f.id);
                          refreshSstData();
                        }
                      }} className="flex min-h-10 min-w-10 items-center justify-center text-muted-foreground hover:text-destructive transition-colors" title="Excluir">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </Link>
            </div>
          );
        })}
      </div>
    </div>
  );
}