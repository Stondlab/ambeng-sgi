import React, { useEffect, useMemo, useState } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import PageHeader from '@/components/PageHeader';
import useSaudeObrasData from '@/hooks/useSaudeObrasData';
import { periodRange } from '@/lib/dashboardFinanceiro';
import { analisarSaudeObras } from '@/lib/saudeObras';
import SaudeObrasFiltros from '@/components/saude-obras/SaudeObrasFiltros';
import ObraSaudeCard from '@/components/saude-obras/ObraSaudeCard';
import DetalhamentoSaudeObra from '@/components/saude-obras/DetalhamentoSaudeObra';

export default function SaudeObras({ embedded = false }) {
  const { id } = useParams();
  const location = useLocation();
  const qs = new URLSearchParams(location.search);
  const [periodo, setPeriodo] = useState(qs.get('periodo') || 'ano');
  const [custom, setCustom] = useState({ inicio: qs.get('inicio') || new Date().toISOString().slice(0, 7) + '-01', fim: qs.get('fim') || new Date().toISOString().slice(0, 10) });
  const [obraSel, setObraSel] = useState(qs.get('obra') || 'todas');
  const { data, loading } = useSaudeObrasData();
  const range = useMemo(() => {
    if (periodo !== 'mes') return periodRange(periodo, custom);
    const mes = custom.inicio.slice(0, 7);
    const [ano, numeroMes] = mes.split('-').map(Number);
    return { inicio: `${mes}-01`, fim: `${mes}-${String(new Date(ano, numeroMes, 0).getDate()).padStart(2, '0')}` };
  }, [periodo, custom]);
  const analise = useMemo(() => analisarSaudeObras(data, range.inicio, range.fim, false), [data, range.inicio, range.fim]);
  useEffect(() => { if (obraSel !== 'todas' && !analise.stats.some((o) => o.id === obraSel)) setObraSel('todas'); }, [analise.stats, obraSel]);
  const stats = obraSel === 'todas' ? analise.stats : analise.stats.filter((o) => o.id === obraSel);
  const search = `?periodo=${periodo}&inicio=${range.inicio}&fim=${range.fim}&obra=${obraSel}`;
  if (loading) return <div className="py-24 text-center text-sm text-muted-foreground">Carregando saúde das obras...</div>;
  if (id) { const obra = analise.stats.find((o) => o.id === id); return obra ? <DetalhamentoSaudeObra obra={obra} analise={analise} search={search} range={range} /> : <div className="py-24 text-center text-sm text-muted-foreground">Esta obra não está disponível no período selecionado.</div>; }
  return <div className="space-y-5">{!embedded && <PageHeader title="Saúde das Obras" subtitle="Como está financeiramente cada obra e o que está formando seu custo." />}<SaudeObrasFiltros periodo={periodo} setPeriodo={setPeriodo} custom={custom} setCustom={setCustom} obra={obraSel} setObra={setObraSel} obras={analise.stats} /><div className="grid gap-4 lg:grid-cols-2">{stats.map((obra) => <ObraSaudeCard key={obra.id} obra={obra} search={search} />)}{!stats.length && <p className="py-12 text-center text-sm text-muted-foreground lg:col-span-2">Nenhuma obra esteve ativa no período selecionado.</p>}</div></div>;
}