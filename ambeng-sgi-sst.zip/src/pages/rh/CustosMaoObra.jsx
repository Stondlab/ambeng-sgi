import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import PageHeader from '@/components/PageHeader';
import { custoGeral, evolucaoCusto, vigenciaAtiva, recorteCustoObra } from '@/lib/custoMO';
import CustosKpis from '@/components/rh/custos/CustosKpis';
import CustoPorObraChart from '@/components/rh/custos/CustoPorObraChart';
import EvolucaoCustoChart from '@/components/rh/custos/EvolucaoCustoChart';
import RankingObrasCusto from '@/components/rh/custos/RankingObrasCusto';
import RelatoriosCusto from '@/components/rh/custos/RelatoriosCusto';
import DrillDownCusto from '@/components/rh/custos/DrillDownCusto';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Filter, Settings2 } from 'lucide-react';

function ultimosMeses(anoMesAlvo, n = 6) {
  const [y, m] = anoMesAlvo.split('-').map(Number);
  const arr = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(y, m - 1 - i, 1);
    arr.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  }
  return arr;
}

// Custos de Mão de Obra 360° — dashboard único. Consulta o mesmo motor (custoMO)
// usado por RH, Obras e Financeiro. Dados reais: Funcionarios, Apontamentos,
// Ponto, HorasExtras, ParametrosCustoMO (fallback EncargosVigencias).
export default function CustosMaoObra() {
  const [funcs, setFuncs] = useState([]);
  const [aps, setAps] = useState([]);
  const [ponto, setPonto] = useState([]);
  const [vigencias, setVigencias] = useState([]);
  const [params, setParams] = useState([]);
  const [horasExtras, setHorasExtras] = useState([]);
  const [obras, setObras] = useState([]);
  const [anoMesSel, setAnoMesSel] = useState(new Date().toISOString().slice(0, 7));
  const [obraSel, setObraSel] = useState('todas');
  const [funcSel, setFuncSel] = useState('todos');
  const [statusSel, setStatusSel] = useState('todos');
  const [drillObra, setDrillObra] = useState(null);

  useEffect(() => {
    (async () => {
      const [f, a, p, v, pr, he, o] = await Promise.all([
        base44.entities.Funcionarios.list('-created_date', 1000).catch(() => []),
        base44.entities.Apontamentos.list('-data', 3000).catch(() => []),
        base44.entities.Ponto.list('-data', 3000).catch(() => []),
        base44.entities.EncargosVigencias.list('-data_inicio', 500).catch(() => []),
        base44.entities.ParametrosCustoMO.list('data_inicio', 500).catch(() => []),
        base44.entities.HorasExtras.list('-data', 3000).catch(() => []),
        base44.entities.Obras.list('nome', 500).catch(() => []),
      ]);
      setFuncs(f); setAps(a); setPonto(p); setVigencias(v); setParams(pr); setHorasExtras(he); setObras(o);
    })();
  }, []);

  const encPct = useMemo(() => vigenciaAtiva(vigencias, anoMesSel), [vigencias, anoMesSel]);

  const funcsFiltrados = useMemo(() => funcs.filter((f) => {
    if (statusSel !== 'todos' && f.status !== statusSel) return false;
    if (funcSel !== 'todos' && f.id !== funcSel) return false;
    return true;
  }), [funcs, statusSel, funcSel]);

  const geralBase = useMemo(() => custoGeral(funcsFiltrados, aps, encPct, anoMesSel, ponto, horasExtras, params), [funcsFiltrados, aps, encPct, anoMesSel, ponto, horasExtras, params]);
  const geral = useMemo(() => recorteCustoObra(geralBase, obraSel === '__sem__' ? 'Sem obra' : obraSel), [geralBase, obraSel]);
  const meses = useMemo(() => ultimosMeses(anoMesSel, 6), [anoMesSel]);
  const evoBase = useMemo(() => evolucaoCusto(funcsFiltrados, aps, encPct, meses, ponto, horasExtras, params), [funcsFiltrados, aps, encPct, meses, ponto, horasExtras, params]);
  const evo = useMemo(() => obraSel === 'todas' ? evoBase : evoBase.map((item) => ({ ...item, porObra: { [obraSel]: item.porObra[obraSel] || 0 }, porObraConf: { [obraSel]: item.porObraConf[obraSel] || 0 }, porObraPend: { [obraSel]: item.porObraPend[obraSel] || 0 } })), [evoBase, obraSel]);

  const obrasList = useMemo(() => Object.keys(geral.porObra), [geral]);

  return (
    <div>
      <div className="flex items-start justify-between gap-3">
        <PageHeader title="Custos de Mão de Obra" subtitle="Análise 360° integrada ao RH — Ponto, Apontamento Diário, Encargos e Horas Extras. Custo conferido vs pendente, apropriado por obra conforme horas." />
        <Button asChild variant="outline" size="sm"><Link to="/rh/parametros-custo"><Settings2 className="w-4 h-4" />Parâmetros de Custo</Link></Button>
      </div>

      <section className="bg-white border border-slate-200 rounded-xl p-4 mb-4">
        <div className="flex items-center gap-2 mb-3"><Filter className="w-4 h-4 text-[#0b2545]" /><h3 className="text-sm font-semibold text-[#0b2545]">Filtros</h3></div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div>
            <Label>Mês / Período</Label>
            <input type="month" value={anoMesSel} onChange={(e) => setAnoMesSel(e.target.value)} className="mt-1 h-11 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm" />
          </div>
          <div>
            <Label>Obra</Label>
            <Select value={obraSel} onValueChange={setObraSel}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas as obras</SelectItem>
                <SelectItem value="__sem__">Sem obra vinculada</SelectItem>
                {obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Funcionário</Label>
            <Select value={funcSel} onValueChange={setFuncSel}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                {funcs.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Status</Label>
            <Select value={statusSel} onValueChange={setStatusSel}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                <SelectItem value="Ativo">Ativo</SelectItem>
                <SelectItem value="Afastado">Afastado</SelectItem>
                <SelectItem value="Demitido">Demitido</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      <CustosKpis geral={geral} onConferido={() => setDrillObra('__conf__')} onPendente={() => setDrillObra('__pend__')} />

      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        <CustoPorObraChart porObra={geral.porObra} />
        <EvolucaoCustoChart evo={evo} />
      </div>
      <div className="mt-4"><RankingObrasCusto porObra={geral.porObra} onSelect={(o) => setDrillObra(o)} /></div>
      <div className="mt-4"><RelatoriosCusto geral={geral} obrasList={obrasList} /></div>

      <DrillDownCusto obra={drillObra} anoMes={anoMesSel} geral={geralBase} aps={aps} ponto={ponto} onClose={() => setDrillObra(null)} />
    </div>
  );
}