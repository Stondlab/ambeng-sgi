import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import { BarChart3, Calculator, ClipboardList, AlertTriangle, Siren } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import { alertasJornada } from '@/lib/ponto';
import { catPendente } from '@/lib/sst';
import DashboardConformidadeRh from '@/components/rh/DashboardConformidadeRh';

export default function RhDashboard() {
  const navigate = useNavigate();
  const [data, setData] = useState({ funcionarios: [], apontamentos: [], ponto: [], ferias: [], ocorrencias: [] });
  const [aba, setAba] = useState('conformidade');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [f, a, p, fer, oco] = await Promise.all([
          base44.entities.Funcionarios.list('nome', 1000).catch(() => []),
          base44.entities.Apontamentos.list('-data', 3000).catch(() => []),
          base44.entities.Ponto.list('-data', 3000).catch(() => []),
          base44.entities.Ferias.list('-created_date', 500).catch(() => []),
          base44.entities.Ocorrencias.list('-data', 1000).catch(() => []),
        ]);
        setData({ funcionarios: f, apontamentos: a, ponto: p, ferias: fer, ocorrencias: oco });
      } catch (e) {
        console.error('Erro ao carregar dados RH', e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const alertasJornadaCount = useMemo(() => (data.ponto || []).reduce((s, p) => s + alertasJornada(p).length, 0), [data.ponto]);
  const catsPendentes = useMemo(() => (data.ocorrencias || []).filter(catPendente), [data.ocorrencias]);

  if (loading) return <div className="p-6 text-sm text-slate-400">Carregando RH...</div>;

  return (
    <div className="p-6 space-y-6">
      <PageHeader title="RH — Gestão e Conformidade" subtitle="Legislação trabalhista, FGTS, férias, jornada CLT e apontamentos" icon={BarChart3} />

      {alertasJornadaCount > 0 && (
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 flex items-center gap-3">
          <AlertTriangle className="w-6 h-6 text-rose-600 shrink-0" />
          <div className="min-w-0">
            <div className="font-semibold text-rose-700">{alertasJornadaCount} alerta(s) de jornada pendente(s) de tratativa</div>
            <div className="text-xs text-rose-600">Intervalo intrajornada &lt; 1h ou jornada &gt; 10h. Verifique no Controle de Ponto.</div>
          </div>
          <Button variant="outline" className="ml-auto shrink-0" onClick={() => navigate('/colaboradores/ponto')}>Ver ponto</Button>
        </div>
      )}

      {catsPendentes.length > 0 && (
        <div className="bg-red-600 text-white rounded-xl p-4 flex items-center gap-3 animate-blink border-2 border-red-800">
          <Siren className="w-7 h-7 shrink-0" />
          <div className="min-w-0">
            <div className="font-bold text-lg">{catsPendentes.length} CAT pendente(s) — prazo legal de 24h vencido</div>
            <div className="text-sm text-red-100">Ocorrências de gravidade Alta sem CAT emitida. Pendência crítica criada automaticamente no RH.</div>
          </div>
          <Button variant="outline" className="ml-auto shrink-0 bg-white" onClick={() => navigate('/ocorrencias')}>Ver ocorrências</Button>
        </div>
      )}

      <Tabs value={aba} onValueChange={setAba} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="conformidade"><AlertTriangle className="w-4 h-4 mr-2" />Conformidade</TabsTrigger>
          <TabsTrigger value="apontamentos"><ClipboardList className="w-4 h-4 mr-2" />Apontamentos</TabsTrigger>
          <TabsTrigger value="fechamento"><Calculator className="w-4 h-4 mr-2" />Fechamento</TabsTrigger>
        </TabsList>

        <TabsContent value="conformidade">
          <DashboardConformidadeRh data={data} apontamentos={data.apontamentos} />
          <div className="bg-white border border-slate-200 rounded-xl p-5">
            <h3 className="font-semibold text-[#0b2545] mb-3">Atalhos Rápidos</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <button onClick={() => navigate('/rh/apontamentos')} className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 text-center text-sm font-semibold text-[#0b2545]">
                📅 Apontamento Diário
              </button>
              <button onClick={() => navigate('/rh/fechamento')} className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 text-center text-sm font-semibold text-[#0b2545]">
                💼 Fechamento Mensal
              </button>
              <button onClick={() => navigate('/rh/encargos')} className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 text-center text-sm font-semibold text-[#0b2545]">
                📊 Encargos Sociais
              </button>
              <button onClick={() => navigate('/relatorios')} className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 text-center text-sm font-semibold text-[#0b2545]">
                📈 Relatórios
              </button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="apontamentos">
          <div className="bg-white border border-slate-200 rounded-xl p-5 text-center py-12">
            <p className="text-slate-500 mb-4">Apontamento Diário em construção...</p>
            <button onClick={() => navigate('/rh/apontamentos')} className="px-4 py-2 bg-[#0b2545] text-white rounded-lg hover:bg-[#0b2545]/90">
              Ir para Apontamentos
            </button>
          </div>
        </TabsContent>

        <TabsContent value="fechamento">
          <div className="bg-white border border-slate-200 rounded-xl p-5 text-center py-12">
            <p className="text-slate-500 mb-4">Fechamento Mensal em construção...</p>
            <button onClick={() => navigate('/rh/fechamento')} className="px-4 py-2 bg-[#0b2545] text-white rounded-lg hover:bg-[#0b2545]/90">
              Ir para Fechamento
            </button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}