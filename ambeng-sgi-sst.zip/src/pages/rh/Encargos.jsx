import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import PageHeader from '@/components/PageHeader';
import { Plus, Pencil, Trash2, BadgeCheck } from 'lucide-react';
import { fmt } from '@/lib/sst';
import VigenciaForm from '@/components/rh/encargos/VigenciaForm';

const COLS = [
  { k: 'inss_patronal', l: 'INSS Patronal' },
  { k: 'fgts', l: 'FGTS' },
  { k: 'ferias_terco', l: 'Férias + 1/3' },
  { k: 'decimo_terceiro', l: '13º Salário' },
  { k: 'rat_sistema_s', l: 'RAT + Sistema S' },
  { k: 'total', l: 'Total' },
];

export default function Encargos() {
  const [items, setItems] = useState([]);
  const [edit, setEdit] = useState(null);

  const load = async () => { let v = []; try { v = await base44.entities.EncargosVigencias.list('-data_inicio', 500); } catch {} setItems(v); };
  useEffect(() => { load(); }, []);

  const save = async (form, id) => {
    const payload = { ...form };
    COLS.forEach((c) => { payload[c.k] = (payload[c.k] === '' || payload[c.k] == null) ? null : Number(payload[c.k]); });
    if (id) await base44.entities.EncargosVigencias.update(id, payload);
    else await base44.entities.EncargosVigencias.create(payload);
    setEdit(null); load();
  };
  const del = async (id) => { await base44.entities.EncargosVigencias.delete(id); load(); };

  return (
    <div>
      <PageHeader title="Parâmetros de Encargos" subtitle="Encargos sociais por vigência — todos provisionados" action={
        <Button onClick={() => setEdit({})} className="bg-amber-400 text-[#0b2545] hover:bg-amber-300 min-h-[44px]"><Plus className="w-4 h-4 mr-1" />Nova Vigência</Button>
      } />
      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <table className="w-full text-sm min-w-[860px]">
          <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
            <tr>
              <th className="text-left px-4 py-3">Vigência</th>
              {COLS.map((c) => <th key={c.k} className="text-right px-4 py-3">{c.l}</th>)}
              <th className="text-center px-4 py-3">Status</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {items.length === 0 && <tr><td colSpan={9} className="px-4 py-10 text-center text-slate-400">Nenhuma vigência cadastrada.</td></tr>}
            {items.map((v) => (
              <tr key={v.id}>
                <td className="px-4 py-3"><p className="font-medium text-[#0b2545]">{v.nome || '—'}</p><p className="text-xs text-slate-400">{fmt(v.data_inicio)} a {v.data_fim ? fmt(v.data_fim) : 'vigente'}</p></td>
                {COLS.map((c) => <td key={c.k} className="px-4 py-3 text-right text-slate-700">{(v[c.k] ?? 0)}%</td>)}
                <td className="px-4 py-3 text-center"><span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700"><BadgeCheck className="w-3 h-3" />Provisionado</span></td>
                <td className="px-4 py-3 text-right whitespace-nowrap">
                  <button onClick={() => setEdit(v)} className="p-1.5 text-slate-400 hover:text-[#0b2545]"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => del(v.id)} className="p-1.5 text-slate-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {edit && <VigenciaForm record={edit} onClose={() => setEdit(null)} onSave={save} />}
    </div>
  );
}