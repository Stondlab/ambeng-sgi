import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import PageHeader from '@/components/PageHeader';
import { FileDown, FileSpreadsheet, Calculator } from 'lucide-react';
import { calcularFechamento, fmtMoeda, gerarCsvFechamento } from '@/lib/fechamentoMensal';
import { useToast } from '@/components/ui/use-toast';

const MESES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

export default function FechamentoMensal() {
  const { toast } = useToast();
  const hoje = new Date();
  const [ano, setAno] = useState(hoje.getFullYear());
  const [mes, setMes] = useState(hoje.getMonth() + 1);
  const [obraFiltro, setObraFiltro] = useState('');
  const [loading, setLoading] = useState(true);
  const [dados, setDados] = useState({ funcionarios: [], ponto: [], horasExtras: [], ferias: [], afastamentos: [], obras: [], vigencia: null });

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const [funcionarios, ponto, horasExtras, ferias, afastamentos, obras, vigencias] = await Promise.all([
          base44.entities.Funcionarios.list('nome', 500),
          base44.entities.Ponto.list('-data', 1000),
          base44.entities.HorasExtras.list('-data', 1000),
          base44.entities.Ferias.list('-created_date', 500),
          base44.entities.Afastamentos.list('-created_date', 500),
          base44.entities.Obras.list('nome', 500),
          base44.entities.EncargosVigencias.list('-data_inicio', 50),
        ]);
        const vigencia = (vigencias || []).find((v) => v.ativa) || (vigencias || [])[0] || null;
        setDados({ funcionarios, ponto, horasExtras, ferias, afastamentos, obras, vigencia });
      } catch (e) {
        toast({ title: 'Erro ao carregar dados', description: String(e.message || e), variant: 'destructive' });
      } finally { setLoading(false); }
    })();
  }, []);

  const resultado = useMemo(() => calcularFechamento({
    funcionarios: dados.funcionarios, ponto: dados.ponto, horasExtras: dados.horasExtras,
    ferias: dados.ferias, afastamentos: dados.afastamentos, vigencia: dados.vigencia,
    ano, mes, obraFiltro: obraFiltro || null,
  }), [dados, ano, mes, obraFiltro]);

  const exportarExcel = () => {
    const csv = gerarCsvFechamento(resultado);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fechamento-rh-${resultado.mesRef.replace('/', '-')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportarPdf = async () => {
    const { jsPDF } = await import('jspdf');
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
    const W = doc.internal.pageSize.getWidth();
    doc.setFontSize(14); doc.text(`Fechamento Mensal de RH — ${resultado.mesRef}`, 14, 14);
    doc.setFontSize(9);
    doc.text(`Colaboradores: ${resultado.linhas.length}  ·  Dias úteis: ${resultado.uteis}  ·  Encargo vigente: ${resultado.encargoPct.toFixed(2)}%`, 14, 20);
    const cols = ['Colaborador', 'Função', 'D.Trab', 'Faltas', 'Atras', 'Atest', 'Férias', 'Afast', 'H.Extra', 'Custo Base', 'Encargos', 'Custo Total'];
    const widths = [44, 30, 14, 12, 12, 12, 12, 12, 14, 24, 22, 26];
    let x = 14, y = 28;
    doc.setFillColor(11, 37, 69); doc.setTextColor(255, 255, 255);
    doc.rect(x, y - 5, W - 28, 7, 'F');
    doc.setFontSize(8);
    cols.forEach((c, i) => { doc.text(c, x + 1, y - 0.5); x += widths[i]; });
    doc.setTextColor(40, 40, 40);
    y += 4;
    resultado.linhas.forEach((l, idx) => {
      if (y > 190) { doc.addPage(); y = 20; }
      x = 14;
      if (idx % 2 === 0) { doc.setFillColor(245, 247, 250); doc.rect(x, y - 4, W - 28, 6, 'F'); }
      const cells = [l.nome?.slice(0, 28) || '', l.funcao?.slice(0, 18) || '', String(l.diasTrab), String(l.faltas), String(l.atrasos), String(l.atestados), String(l.feriasDias), String(l.afastDias), l.horasEx.toFixed(1), fmtMoeda(l.custoBase), fmtMoeda(l.encargos), fmtMoeda(l.custoTotal)];
      cells.forEach((c, i) => { doc.text(String(c), x + 1, y); x += widths[i]; });
      y += 6;
    });
    y += 2;
    doc.setDrawColor(11, 37, 69); doc.line(14, y, W - 14, y); y += 5;
    doc.setFontSize(9); doc.setTextColor(11, 37, 69);
    doc.text(`TOTAL — Custo base: ${fmtMoeda(resultado.totais.custoBase)}  |  Encargos: ${fmtMoeda(resultado.totais.encargos)}  |  Custo total: ${fmtMoeda(resultado.totais.custoTotal)}`, 14, y);
    doc.save(`fechamento-rh-${resultado.mesRef.replace('/', '-')}.pdf`);
  };

  return (
    <div>
      <PageHeader title="Fechamento Mensal de RH" subtitle="Consolidação de ponto, horas, férias, afastamentos e custos de mão de obra por período." />

      <div className="bg-white border border-slate-200 rounded-xl p-4 mb-4 flex flex-wrap items-end gap-3">
        <div>
          <label className="text-xs font-medium text-slate-500 block mb-1">Mês</label>
          <Select value={String(mes)} onValueChange={(v) => setMes(Number(v))}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>{MESES.map((m, i) => <SelectItem key={i} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500 block mb-1">Ano</label>
          <Select value={String(ano)} onValueChange={(v) => setAno(Number(v))}>
            <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
            <SelectContent>{[hoje.getFullYear(), hoje.getFullYear() - 1, hoje.getFullYear() + 1].map((a) => <SelectItem key={a} value={String(a)}>{a}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="flex-1 min-w-[180px]">
          <label className="text-xs font-medium text-slate-500 block mb-1">Obra (filtro opcional)</label>
          <Select value={obraFiltro || 'todas'} onValueChange={(v) => setObraFiltro(v === 'todas' ? '' : v)}>
            <SelectTrigger><SelectValue placeholder="Todas as obras" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas as obras</SelectItem>
              {dados.obras.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <Button variant="outline" onClick={exportarExcel} disabled={loading || !resultado.linhas.length}><FileSpreadsheet className="w-4 h-4 mr-1.5" />Excel</Button>
        <Button onClick={exportarPdf} disabled={loading || !resultado.linhas.length} className="bg-[#0b2545] hover:bg-[#16365f]"><FileDown className="w-4 h-4 mr-1.5" />PDF</Button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20"><div className="w-8 h-8 border-4 border-slate-200 border-t-[#0b2545] rounded-full animate-spin" /></div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
            <div className="bg-white border border-slate-200 rounded-lg p-3"><p className="text-xl font-heading font-bold text-[#0b2545]">{resultado.linhas.length}</p><p className="text-xs text-slate-500">Colaboradores</p></div>
            <div className="bg-white border border-slate-200 rounded-lg p-3"><p className="text-xl font-heading font-bold text-[#0b2545]">{resultado.uteis}</p><p className="text-xs text-slate-500">Dias úteis no mês</p></div>
            <div className="bg-white border border-slate-200 rounded-lg p-3"><p className="text-xl font-heading font-bold text-info">{resultado.totais.horasEx.toFixed(1)}h</p><p className="text-xs text-slate-500">Horas extras</p></div>
            <div className="bg-white border border-slate-200 rounded-lg p-3"><p className="text-xl font-heading font-bold text-success">{fmtMoeda(resultado.totais.custoTotal)}</p><p className="text-xs text-slate-500">Custo total de MO</p></div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 text-slate-500 text-xs">
                  <tr>
                    <th className="text-left px-3 py-2.5 font-medium">Colaborador</th>
                    <th className="text-left px-3 py-2.5 font-medium">Função</th>
                    <th className="text-center px-2 py-2.5 font-medium">D.Trab</th>
                    <th className="text-center px-2 py-2.5 font-medium">Faltas</th>
                    <th className="text-center px-2 py-2.5 font-medium">Atrasos</th>
                    <th className="text-center px-2 py-2.5 font-medium">Atest</th>
                    <th className="text-center px-2 py-2.5 font-medium">Férias</th>
                    <th className="text-center px-2 py-2.5 font-medium">Afast</th>
                    <th className="text-center px-2 py-2.5 font-medium">H.Extra</th>
                    <th className="text-right px-3 py-2.5 font-medium">Custo base</th>
                    <th className="text-right px-3 py-2.5 font-medium">Encargos</th>
                    <th className="text-right px-3 py-2.5 font-medium">Custo total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {resultado.linhas.length === 0 && (
                    <tr><td colSpan={12} className="text-center text-slate-400 py-8"><Calculator className="w-8 h-8 mx-auto mb-2 opacity-40" />Sem colaboradores ou registros de ponto para o período selecionado.</td></tr>
                  )}
                  {resultado.linhas.map((l) => (
                    <tr key={l.id} className="hover:bg-slate-50/60">
                      <td className="px-3 py-2.5">
                        <p className="font-medium text-[#0b2545]">{l.nome}</p>
                        <p className="text-xs text-slate-400">{l.matricula || '—'}{l.obra ? ` · ${l.obra}` : ''}</p>
                      </td>
                      <td className="px-3 py-2.5 text-slate-600">{l.funcao || '—'}</td>
                      <td className="text-center px-2 py-2.5 text-slate-600">{l.diasTrab}</td>
                      <td className="text-center px-2 py-2.5">{l.faltas ? <span className="text-red-600 font-medium">{l.faltas}</span> : '0'}</td>
                      <td className="text-center px-2 py-2.5">{l.atrasos ? <span className="text-amber-600 font-medium">{l.atrasos}</span> : '0'}</td>
                      <td className="text-center px-2 py-2.5 text-slate-600">{l.atestados}</td>
                      <td className="text-center px-2 py-2.5 text-slate-600">{l.feriasDias || '0'}</td>
                      <td className="text-center px-2 py-2.5 text-slate-600">{l.afastDias || '0'}</td>
                      <td className="text-center px-2 py-2.5 text-slate-600">{l.horasEx.toFixed(1)}</td>
                      <td className="text-right px-3 py-2.5 text-slate-600">{fmtMoeda(l.custoBase)}</td>
                      <td className="text-right px-3 py-2.5 text-slate-500">{fmtMoeda(l.encargos)}</td>
                      <td className="text-right px-3 py-2.5 font-semibold text-[#0b2545]">{fmtMoeda(l.custoTotal)}</td>
                    </tr>
                  ))}
                </tbody>
                {resultado.linhas.length > 0 && (
                  <tfoot className="bg-slate-50 font-medium">
                    <tr>
                      <td colSpan={2} className="px-3 py-3 text-[#0b2545]">TOTAL</td>
                      <td className="text-center px-2 py-3">{resultado.totais.diasTrab}</td>
                      <td className="text-center px-2 py-3 text-red-600">{resultado.totais.faltas}</td>
                      <td className="text-center px-2 py-3 text-amber-600">{resultado.totais.atrasos}</td>
                      <td className="text-center px-2 py-3">{resultado.totais.atestados}</td>
                      <td className="text-center px-2 py-3">{resultado.totais.feriasDias}</td>
                      <td className="text-center px-2 py-3">{resultado.totais.afastDias}</td>
                      <td className="text-center px-2 py-3 text-info">{resultado.totais.horasEx.toFixed(1)}h</td>
                      <td className="text-right px-3 py-3 text-[#0b2545]">{fmtMoeda(resultado.totais.custoBase)}</td>
                      <td className="text-right px-3 py-3 text-slate-500">{fmtMoeda(resultado.totais.encargos)}</td>
                      <td className="text-right px-3 py-3 font-bold text-[#0b2545]">{fmtMoeda(resultado.totais.custoTotal)}</td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}