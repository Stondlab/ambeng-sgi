import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Check, Clock, AlertTriangle } from 'lucide-react';
import ApontamentoGrid from '@/components/rh/apontamento/ApontamentoGrid';
import ApontamentoModal from '@/components/rh/apontamento/ApontamentoModal';
import ApontamentoResumoFunc from '@/components/rh/apontamento/ApontamentoResumoFunc';
import { usePerm } from '@/hooks/usePerm';
import { parseHoras } from '@/lib/apontamento';
import { alertasJornada } from '@/lib/ponto';
import { incluirObraVinculada, obrasAtivasParaLancamento, obrasDisponiveisNoPeriodo } from '@/lib/obraDisponibilidade';

// Apontamento Diário — grid visual FUNCIONÁRIO × DIA × OBRA × STATUS.
// Ponto = fonte efetiva das horas; jornada = referência. Motor de custo intacto.
export default function ApontamentoDiario() {
  const { readOnly } = usePerm('apontamento');
  const [funcs, setFuncs] = useState([]);
  const [obras, setObras] = useState([]);
  const [aps, setAps] = useState([]);
  const [ponto, setPonto] = useState([]);
  const [user, setUser] = useState(null);
  const [anoMes, setAnoMes] = useState(new Date().toISOString().slice(0, 7));
  const [empresaSel, setEmpresaSel] = useState('todas');
  const [obraSel, setObraSel] = useState('todas');
  const [funcSel, setFuncSel] = useState('todos');
  const [statusSel, setStatusSel] = useState('todos');
  const [cellModal, setCellModal] = useState(null);
  const [resumoFunc, setResumoFunc] = useState(null);

  useEffect(() => {
    (async () => {
      let f = [], o = [];
      try { f = await base44.entities.Funcionarios.list('nome', 1000); } catch {}
      try { o = await base44.entities.Obras.list('nome', 500); } catch {}
      setFuncs(f); setObras(o);
      try { setUser(await base44.auth.me()); } catch {}
    })();
  }, []);

  const reload = async () => {
    let a = [], p = [];
    try { a = await base44.entities.Apontamentos.list('-data', 3000); } catch {}
    try { p = await base44.entities.Ponto.list('-data', 3000); } catch {}
    setAps(a.filter((x) => (x.data || '').slice(0, 7) === anoMes));
    setPonto(p.filter((x) => (x.data || '').slice(0, 7) === anoMes));
  };
  useEffect(() => { reload(); }, [anoMes]);

  const empresas = useMemo(() => [...new Set(funcs.map((f) => f.empresa).filter(Boolean))], [funcs]);
  const obrasPeriodo = useMemo(() => {
    const [ano, mes] = anoMes.split('-').map(Number);
    return obrasDisponiveisNoPeriodo(obras, `${anoMes}-01`, `${anoMes}-${String(new Date(ano, mes, 0).getDate()).padStart(2, '0')}`);
  }, [obras, anoMes]);
  const obrasLancamento = useMemo(() => {
    const ativas = obrasAtivasParaLancamento(obras);
    const vinculadas = cellModal ? aps.filter((ap) => ap.funcionario_id === cellModal.func.id && ap.data === cellModal.data) : [];
    return vinculadas.reduce((lista, ap) => incluirObraVinculada(lista, obras, ap.obra), ativas);
  }, [obras, aps, cellModal]);
  const days = useMemo(() => {
    const [y, mo] = anoMes.split('-').map(Number);
    const t = new Date(y, mo, 0).getDate();
    return Array.from({ length: t }, (_, i) => `${anoMes}-${String(i + 1).padStart(2, '0')}`);
  }, [anoMes]);

  const apsMap = useMemo(() => { const m = {}; aps.forEach((a) => { (m[`${a.funcionario_id}|${a.data}`] = m[`${a.funcionario_id}|${a.data}`] || []).push(a); }); return m; }, [aps]);
  const pMap = useMemo(() => { const m = {}; ponto.forEach((p) => { m[`${p.funcionario_id}|${p.data}`] = p; }); return m; }, [ponto]);

  const statusDe = (apDay, p) => {
    if (!apDay?.length) return 'sem';
    const ap = apDay.filter((a) => a.tipo !== 'Atestado').reduce((s, a) => s + (Number(a.horas) || 0), 0);
    if (!p) return 'pendente';
    return Math.abs(ap - parseHoras(p.total_horas)) < 0.05 ? 'conferido' : 'divergencia';
  };

  const idsComAp = useMemo(() => new Set(aps.map((a) => a.funcionario_id)), [aps]);
  const funcsVisiveis = useMemo(() => funcs.filter((f) => f.status === 'Ativo' || idsComAp.has(f.id)), [funcs, idsComAp]);

  const funcsFiltrados = useMemo(() => funcsVisiveis.filter((f) => {
    if (empresaSel !== 'todas' && f.empresa !== empresaSel) return false;
    if (funcSel !== 'todos' && f.id !== funcSel) return false;
    if (obraSel !== 'todas' && !aps.some((a) => a.funcionario_id === f.id && a.obra === obraSel)) return false;
    if (statusSel === 'sem') { if (aps.some((a) => a.funcionario_id === f.id)) return false; }
    else if (statusSel !== 'todos') { const tem = days.some((ds) => statusDe(apsMap[`${f.id}|${ds}`], pMap[`${f.id}|${ds}`]) === statusSel); if (!tem) return false; }
    return true;
  }), [funcsVisiveis, empresaSel, funcSel, obraSel, statusSel, aps, days, apsMap, pMap]);

  // Indicadores do mês (sobre os funcionários filtrados).
  const counts = useMemo(() => {
    let conferidos = 0, pendentes = 0, divergencias = 0, apontados = 0, alertas = 0;
    funcsFiltrados.forEach((f) => {
      const datas = new Set();
      days.forEach((ds) => {
        const st = statusDe(apsMap[`${f.id}|${ds}`], pMap[`${f.id}|${ds}`]);
        if (st === 'conferido') conferidos++;
        else if (st === 'pendente') pendentes++;
        else if (st === 'divergencia') divergencias++;
        alertas += alertasJornada(pMap[`${f.id}|${ds}`]).length;
        if (st !== 'sem') datas.add(ds);
      });
      apontados += datas.size;
    });
    return { funcionarios: funcsFiltrados.length, apontamentos: apontados, conferidos, pendentes, divergencias, alertas };
  }, [funcsFiltrados, days, apsMap, pMap]);

  const shiftMes = (delta) => {
    const [y, m] = anoMes.split('-').map(Number);
    const d = new Date(y, m - 1 + delta, 1);
    setAnoMes(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  };
  const mesLabel = useMemo(() => {
    const [y, m] = anoMes.split('-').map(Number);
    const nm = new Date(y, m - 1, 1).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
    return nm.charAt(0).toUpperCase() + nm.slice(1);
  }, [anoMes]);

  // Obra padrão do funcionário = obra mais frequente no histórico de apontamentos.
  const obraPadraoOf = useMemo(() => {
    const map = {};
    aps.forEach((a) => {
      if (!a.obra) return;
      if (!map[a.funcionario_id]) map[a.funcionario_id] = {};
      map[a.funcionario_id][a.obra] = (map[a.funcionario_id][a.obra] || 0) + 1;
    });
    const result = {};
    Object.keys(map).forEach((fid) => {
      const sorted = Object.entries(map[fid]).sort((a, b) => b[1] - a[1]);
      result[fid] = sorted.length ? sorted[0][0] : '';
    });
    return result;
  }, [aps]);

  const apsDia = cellModal ? aps.filter((a) => a.funcionario_id === cellModal.func.id && a.data === cellModal.data) : [];
  const pontoDia = cellModal ? (ponto.find((p) => p.funcionario_id === cellModal.func.id && p.data === cellModal.data) || null) : null;

  const Indicador = ({ label, value, tone }) => (
    <div className="bg-white border border-slate-200 rounded-xl p-3 flex-1 min-w-[120px]">
      <div className="text-[11px] uppercase tracking-wide text-slate-500">{label}</div>
      <div className={`text-2xl font-bold ${tone || 'text-[#0b2545]'}`}>{value}</div>
    </div>
  );

  return (
    <div>
      <div className="mb-4">
        <h1 className="text-xl font-bold text-[#0b2545] tracking-tight">APONTAMENTO DIÁRIO</h1>
        <p className="text-sm text-slate-500 mt-0.5">Marque em qual obra cada funcionário trabalhou por dia.</p>
      </div>

      <div className="flex items-center justify-center gap-3 mb-4">
        <Button variant="outline" size="icon" onClick={() => shiftMes(-1)} aria-label="Mês anterior"><ChevronLeft className="w-4 h-4" /></Button>
        <div className="px-6 py-2 rounded-lg bg-white border border-slate-200 min-w-[180px] text-center">
          <span className="text-sm font-semibold text-[#0b2545]">{mesLabel}</span>
        </div>
        <Button variant="outline" size="icon" onClick={() => shiftMes(1)} aria-label="Próximo mês"><ChevronRight className="w-4 h-4" /></Button>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        <Indicador label="Funcionários" value={counts.funcionarios} />
        <Indicador label="Apontamentos" value={counts.apontamentos} />
        <Indicador label="Conferidos" value={counts.conferidos} tone="text-emerald-600" />
        <Indicador label="Pendentes" value={counts.pendentes} tone="text-amber-600" />
        <Indicador label="Divergências" value={counts.divergencias} tone="text-rose-600" />
        {counts.alertas > 0 && <Indicador label="Alertas de jornada" value={counts.alertas} tone="text-rose-600" />}
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-3 mb-4 grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div>
          <Label>Empresa</Label>
          <Select value={empresaSel} onValueChange={setEmpresaSel}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="todas">Todas</SelectItem>{empresas.map((e) => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent></Select>
        </div>
        <div>
          <Label>Funcionário</Label>
          <Select value={funcSel} onValueChange={setFuncSel}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="todos">Todos</SelectItem>{funcsVisiveis.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}</SelectContent></Select>
        </div>
        <div>
          <Label>Obra</Label>
          <Select value={obraSel} onValueChange={setObraSel}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="todas">Todas</SelectItem>{obrasPeriodo.map((o) => <SelectItem key={o.id} value={o.nome}>{o.nome}</SelectItem>)}</SelectContent></Select>
        </div>
        <div>
          <Label>Status de conferência</Label>
          <Select value={statusSel} onValueChange={setStatusSel}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="conferido">Conferido</SelectItem>
            <SelectItem value="pendente">Pendente de conferência</SelectItem>
            <SelectItem value="divergencia">Divergência</SelectItem>
            <SelectItem value="sem">Sem apontamento</SelectItem>
          </SelectContent></Select>
        </div>
      </div>

      {readOnly && <div className="mb-3 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">Seu perfil permite apenas visualização.</div>}

      {funcsFiltrados.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-400">Nenhum funcionário para os filtros selecionados nesta competência.</div>
      ) : (
        <ApontamentoGrid funcs={funcsFiltrados} aps={aps} ponto={ponto} anoMes={anoMes} obras={obras} onCellClick={(f, ds) => setCellModal({ func: f, data: ds })} onFuncClick={(f) => setResumoFunc(f)} readOnly={readOnly} />
      )}

      {/* Legenda — cor da célula = obra; ícone = status de conferência */}
      <div className="mt-3 bg-white border border-slate-200 rounded-xl p-3">
        <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-2">Legenda</div>
        <div className="flex flex-wrap gap-x-5 gap-y-2 text-xs text-slate-700">
          <span className="inline-flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-emerald-600" />Conferido</span>
          <span className="inline-flex items-center gap-1.5"><Clock className="w-3.5 h-3.5 text-amber-600" />Pendente de conferência</span>
          <span className="inline-flex items-center gap-1.5"><AlertTriangle className="w-3.5 h-3.5 text-rose-600" />Divergência</span>
          <span className="inline-flex items-center gap-1.5"><span className="w-3.5 h-3.5 rounded bg-white border border-slate-300 flex items-center justify-center text-[9px] text-slate-400">-</span>Sem apontamento</span>
          <span className="inline-flex items-center gap-1.5 text-slate-500"><span className="w-3.5 h-3.5 rounded bg-blue-500" />Cor de fundo = obra</span>
        </div>
      </div>

      {cellModal && (
        <ApontamentoModal
          func={cellModal.func}
          data={cellModal.data}
          apsDia={apsDia}
          ponto={pontoDia}
          obras={obrasLancamento}
          obraPadrao={obraPadraoOf[cellModal.func.id] || ''}
          user={user}
          onClose={() => setCellModal(null)}
          onSaved={() => { setCellModal(null); reload(); }}
        />
      )}
      {resumoFunc && (
        <ApontamentoResumoFunc func={resumoFunc} aps={aps} ponto={ponto} onClose={() => setResumoFunc(null)} />
      )}
    </div>
  );
}