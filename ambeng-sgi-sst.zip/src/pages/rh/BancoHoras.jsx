import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Plus, Clock, History, CalendarClock } from 'lucide-react';
import { fmt } from '@/lib/sst';
import { saldoMinutos, fmtMinutos, diasParaExpirar, estaExpirado } from '@/lib/bancoHoras';
import BancoHorasModal from '@/components/rh/bancohoras/BancoHorasModal';

export default function BancoHoras() {
  const [funcs, setFuncs] = useState([]);
  const [lancs, setLancs] = useState([]);
  const [funcSel, setFuncSel] = useState('');
  const [modal, setModal] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => { base44.entities.Funcionarios.list('nome', 1000).then(setFuncs).catch(() => setFuncs([])); }, []);

  const reload = async (fid) => {
    if (!fid) { setLancs([]); return; }
    setLoading(true);
    try { const all = await base44.entities.BancoHoras.list('-data', 2000); setLancs(all.filter((l) => l.funcionario_id === fid)); }
    catch { setLancs([]); }
    finally { setLoading(false); }
  };
  useEffect(() => { reload(funcSel); }, [funcSel]);

  const func = useMemo(() => funcs.find((f) => f.id === funcSel) || null, [funcs, funcSel]);
  const ativos = useMemo(() => lancs.filter((l) => l.status === 'Ativo'), [lancs]);
  const saldo = useMemo(() => saldoMinutos(lancs), [lancs]);
  const expirando = useMemo(() => ativos.filter((l) => { const d = diasParaExpirar(l.data_expiracao); return d != null && d <= 30 && !estaExpirado(l); }), [ativos]);
  const expirados = useMemo(() => ativos.filter(estaExpirado), [ativos]);
  const ordenados = useMemo(() => [...lancs].sort((a, b) => new Date(b.data || '') - new Date(a.data || '')), [lancs]);

  return (
    <div>
      <div className="flex items-start justify-between gap-3 mb-4">
        <div>
          <h1 className="text-xl font-bold text-[#0b2545] tracking-tight">BANCO DE HORAS</h1>
          <p className="text-sm text-slate-500 mt-0.5">Créditos, compensações e expiração (6 meses por lançamento).</p>
        </div>
        {func && <Button className="bg-[#0b2545] hover:bg-[#16365f]" onClick={() => setModal(true)}><Plus className="w-4 h-4 mr-1.5" />Novo lançamento</Button>}
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-3 mb-4 max-w-xs">
        <Label>Funcionário</Label>
        <Select value={funcSel} onValueChange={setFuncSel}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione..." /></SelectTrigger><SelectContent>{funcs.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}</SelectContent></Select>
      </div>

      {!func ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-400">Selecione um funcionário para visualizar o banco de horas.</div>
      ) : (
        <>
          {/* SEÇÃO 1 — Saldo Total */}
          <div className="mb-4">
            <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-2 flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" />Saldo Total</div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className={`rounded-xl border-2 p-4 ${saldo > 0 ? 'bg-emerald-50 border-emerald-200' : saldo < 0 ? 'bg-rose-50 border-rose-200' : 'bg-slate-50 border-slate-200'}`}>
                <div className="text-[11px] uppercase tracking-wide text-slate-500">Saldo atual</div>
                <div className={`text-3xl font-bold ${saldo > 0 ? 'text-emerald-700' : saldo < 0 ? 'text-rose-700' : 'text-slate-600'}`}>{fmtMinutos(saldo)}</div>
                <div className="text-xs text-slate-400">{ativos.length} lançamento(s) ativo(s)</div>
              </div>
              <div className="rounded-xl border-2 border-amber-200 bg-amber-50 p-4">
                <div className="text-[11px] uppercase tracking-wide text-slate-500">Expirando (≤30d)</div>
                <div className="text-3xl font-bold text-amber-700">{expirando.length}</div>
                <div className="text-xs text-slate-400">compensar antes de expirar</div>
              </div>
              <div className="rounded-xl border-2 border-rose-200 bg-rose-50 p-4">
                <div className="text-[11px] uppercase tracking-wide text-slate-500">Expirados</div>
                <div className="text-3xl font-bold text-rose-700">{expirados.length}</div>
                <div className="text-xs text-slate-400">marcar como expirado</div>
              </div>
            </div>
          </div>

          {/* SEÇÃO 2 — Histórico de Acúmulo/Compensação */}
          <div className="mb-4">
            <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-2 flex items-center gap-1.5"><History className="w-3.5 h-3.5" />Histórico de Acúmulo/Compensação</div>
            {loading ? <p className="text-sm text-slate-400">Carregando lançamentos...</p> : (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 text-xs text-slate-500 uppercase">
                  <tr>
                    <th className="text-left px-3 py-2">Data</th>
                    <th className="text-left px-3 py-2">Tipo</th>
                    <th className="text-right px-3 py-2">Horas</th>
                    <th className="text-left px-3 py-2">Descrição</th>
                    <th className="text-left px-3 py-2">Expira em</th>
                    <th className="text-left px-3 py-2">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {ordenados.length === 0 ? <tr><td colSpan={6} className="text-center py-8 text-slate-400">Nenhum lançamento.</td></tr> :
                  ordenados.map((l) => {
                    const exp = diasParaExpirar(l.data_expiracao);
                    const vencido = estaExpirado(l);
                    const proximo = exp != null && exp <= 30 && !vencido;
                    return (
                      <tr key={l.id} className="border-t border-slate-100">
                        <td className="px-3 py-2">{fmt(l.data)}</td>
                        <td className="px-3 py-2">{l.tipo === 'Credito' ? 'Crédito' : 'Compensação'}</td>
                        <td className={`px-3 py-2 text-right font-mono font-semibold ${l.minutos < 0 ? 'text-rose-600' : 'text-emerald-600'}`}>{fmtMinutos(l.minutos)}</td>
                        <td className="px-3 py-2 text-slate-600">{l.descricao || '—'}</td>
                        <td className={`px-3 py-2 ${vencido ? 'text-rose-600 font-semibold' : proximo ? 'text-amber-600 font-semibold' : 'text-slate-500'}`}>{fmt(l.data_expiracao)}{vencido ? ' (expirado)' : proximo ? ` (${exp}d)` : ''}</td>
                        <td className="px-3 py-2">{l.status}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            )}
          </div>

          {/* SEÇÃO 3 — Data de Expiração (6 meses) */}
          <div className="mb-4">
            <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-2 flex items-center gap-1.5"><CalendarClock className="w-3.5 h-3.5" />Data de Expiração (6 meses)</div>
            <div className="bg-white border border-slate-200 rounded-xl p-3 text-xs text-slate-600">
              Cada lançamento de crédito expira em <strong>6 meses</strong> após a data de origem, conforme legislação. Lançamentos próximos do vencimento aparecem em <span className="text-amber-600 font-semibold">âmbar</span> e os já vencidos em <span className="text-rose-600 font-semibold">vermelho</span> na tabela acima.
            </div>
          </div>
        </>
      )}

      {modal && func && <BancoHorasModal func={func} onClose={() => setModal(false)} onSaved={() => { setModal(false); reload(func.id); }} />}
    </div>
  );
}