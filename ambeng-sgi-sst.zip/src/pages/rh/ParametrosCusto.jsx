import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { usePerm } from '@/hooks/usePerm';
import { Plus, Pencil, Trash2, Settings2 } from 'lucide-react';
import { Link } from 'react-router-dom';

const COMPONENTES = [
  { v: 'Jornada', label: 'Jornada mensal' },
  { v: 'Remuneracao', label: 'Remuneração' },
  { v: 'Beneficio', label: 'Benefício' },
  { v: 'Encargo', label: 'Encargo' },
  { v: 'Provisao', label: 'Provisão' },
];
const TONE = {
  Jornada: 'bg-slate-100 text-slate-700 border-slate-200',
  Encargo: 'bg-amber-50 text-amber-700 border-amber-200',
  Provisao: 'bg-violet-50 text-violet-700 border-violet-200',
  Beneficio: 'bg-sky-50 text-sky-700 border-sky-200',
  Remuneracao: 'bg-emerald-50 text-emerald-700 border-emerald-200',
};

export default function ParametrosCusto() {
  const { podeEditar, podeCriar, podeExcluir } = usePerm('parametros_custo');
  const { toast } = useToast();
  const [params, setParams] = useState([]);
  const [edit, setEdit] = useState(null); // objeto em edição (null fechado)

  const load = async () => {
    try { const l = await base44.entities.ParametrosCustoMO.list('data_inicio', 500); setParams(l); } catch {}
  };
  useEffect(() => { load(); }, []);

  const novo = () => setEdit({ nome: '', componente: 'Encargo', tipo: 'Percentual', percentual: 0, valor: 0, base_aplicacao: 'Salario', data_inicio: '', data_fim: '', ativo: true, observacao: '' });
  const salvar = async () => {
    if (!edit.nome || !edit.data_inicio) { toast({ title: 'Informe nome e início da vigência', variant: 'destructive' }); return; }
    try {
      if (edit.id) await base44.entities.ParametrosCustoMO.update(edit.id, edit);
      else { const { id, ...rest } = edit; await base44.entities.ParametrosCustoMO.create(rest); }
      toast({ title: 'Parâmetro salvo', variant: 'success' });
      setEdit(null); load();
    } catch (e) { toast({ title: 'Erro ao salvar', description: String(e?.message || e), variant: 'destructive' }); }
  };
  const excluir = async (p) => {
    if (!confirm(`Excluir o parâmetro "${p.nome}"?`)) return;
    await base44.entities.ParametrosCustoMO.delete(p.id); load();
  };

  return (
    <div>
      <PageHeader title="Parâmetros de Custo de Mão de Obra" subtitle="Componentes do custo gerencial (encargos, provisões, benefícios). Configuráveis por vigência — os cálculos históricos usam os parâmetros válidos em cada competência." />
      <div className="flex items-center justify-between mb-3">
        <Link to="/financeiro/mao-de-obra" className="text-sm text-slate-500 hover:text-[#0b2545]">← Custos de Mão de Obra</Link>
        {podeCriar && <Button size="sm" onClick={novo}><Plus className="w-4 h-4" />Novo parâmetro</Button>}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {params.length === 0 && <p className="text-slate-400 text-sm col-span-full">Nenhum parâmetro cadastrado.</p>}
        {params.map((p) => (
          <div key={p.id} className="bg-white border border-slate-200 rounded-xl p-4">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="font-semibold text-[#0b2545] truncate">{p.nome}</div>
                <span className={`inline-block mt-1 text-[11px] px-2 py-0.5 rounded-full border ${TONE[p.componente] || ''}`}>{COMPONENTES.find((c) => c.v === p.componente)?.label}</span>
              </div>
              {podeEditar && <button onClick={() => setEdit(p)} className="text-slate-400 hover:text-[#0b2545]"><Pencil className="w-4 h-4" /></button>}
            </div>
            <div className="mt-2 text-xs text-slate-600 space-y-0.5">
              <div>{p.componente === 'Jornada' ? `${Number(p.valor) || 220} horas/mês` : p.tipo === 'Percentual' ? `${(Number(p.percentual) || 0).toLocaleString('pt-BR')}% sobre ${p.base_aplicacao}` : `R$ ${(Number(p.valor) || 0).toFixed(2)}`}</div>
              <div className="text-slate-400">Vigência: {p.data_inicio}{p.data_fim ? ` até ${p.data_fim}` : ' em aberto'}</div>
              <div className={p.ativo !== false ? 'text-emerald-600' : 'text-slate-400'}>{p.ativo !== false ? '● Ativo' : '○ Inativo'}</div>
            </div>
            {podeExcluir && <button onClick={() => excluir(p)} className="mt-2 text-xs text-rose-500 hover:text-rose-600 inline-flex items-center gap-1"><Trash2 className="w-3.5 h-3.5" />Excluir</button>}
          </div>
        ))}
      </div>

      <Dialog open={!!edit} onOpenChange={(o) => !o && setEdit(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Settings2 className="w-4 h-4" />Parâmetro de custo</DialogTitle></DialogHeader>
          {edit && (
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><Label>Nome</Label><Input className="mt-1" value={edit.nome} onChange={(e) => setEdit({ ...edit, nome: e.target.value })} placeholder="ex.: FGTS" /></div>
              <div><Label>Componente</Label><Select value={edit.componente} onValueChange={(v) => setEdit({ ...edit, componente: v, tipo: v === 'Jornada' ? 'Valor' : edit.tipo, valor: v === 'Jornada' && !edit.valor ? 220 : edit.valor })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{COMPONENTES.map((c) => <SelectItem key={c.v} value={c.v}>{c.label}</SelectItem>)}</SelectContent></Select></div>
              <div><Label>Tipo</Label><Select disabled={edit.componente === 'Jornada'} value={edit.tipo} onValueChange={(v) => setEdit({ ...edit, tipo: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Percentual">Percentual (%)</SelectItem><SelectItem value="Valor">Valor fixo (R$)</SelectItem></SelectContent></Select></div>
              {edit.tipo === 'Percentual' ? (
                <>
                  <div><Label>Percentual (%)</Label><Input type="number" step="0.01" className="mt-1" value={edit.percentual} onChange={(e) => setEdit({ ...edit, percentual: Number(e.target.value) })} /></div>
                  <div><Label>Base de aplicação</Label><Select value={edit.base_aplicacao} onValueChange={(v) => setEdit({ ...edit, base_aplicacao: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Salario">Salário</SelectItem><SelectItem value="Remuneracao">Remuneração</SelectItem></SelectContent></Select></div>
                </>
              ) : (
                <div className="col-span-2"><Label>{edit.componente === 'Jornada' ? 'Jornada mensal (horas)' : 'Valor (R$)'}</Label><Input type="number" step={edit.componente === 'Jornada' ? '1' : '0.01'} className="mt-1" value={edit.valor} onChange={(e) => setEdit({ ...edit, valor: Number(e.target.value) })} /></div>
              )}
              <div><Label>Início da vigência</Label><Input type="date" className="mt-1" value={edit.data_inicio} onChange={(e) => setEdit({ ...edit, data_inicio: e.target.value })} /></div>
              <div><Label>Fim da vigência (opcional)</Label><Input type="date" className="mt-1" value={edit.data_fim} onChange={(e) => setEdit({ ...edit, data_fim: e.target.value })} /></div>
              <div className="col-span-2 flex items-center gap-2"><input type="checkbox" id="ativo" checked={edit.ativo !== false} onChange={(e) => setEdit({ ...edit, ativo: e.target.checked })} /><Label htmlFor="ativo" className="cursor-pointer">Ativo</Label></div>
              <div className="col-span-2"><Label>Observação</Label><Textarea className="mt-1" rows={2} value={edit.observacao} onChange={(e) => setEdit({ ...edit, observacao: e.target.value })} /></div>
            </div>
          )}
          <DialogFooter><Button variant="outline" onClick={() => setEdit(null)}>Cancelar</Button><Button onClick={salvar}>Salvar</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}