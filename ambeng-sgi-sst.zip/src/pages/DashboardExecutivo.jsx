import React, { lazy, Suspense, useState } from 'react';
import DashboardExecutivoResumo from '@/components/dashboard/DashboardExecutivoResumo';

const DashboardAnaliseExecutiva = lazy(() => import('@/components/dashboard/DashboardAnaliseExecutiva'));

export default function DashboardExecutivo() {
  const [view, setView] = useState('resumo');
  return <div>
    <div className="mb-4">
      <h1 className="text-3xl font-bold tracking-tight text-foreground">Dashboard Executivo</h1>
      <p className="text-sm text-muted-foreground">Indicadores críticos imediatos e análise gerencial sob demanda.</p>
    </div>
    <div className="mb-4 grid grid-cols-2 rounded-xl border border-border bg-muted p-1">
      <button onClick={() => setView('resumo')} className={`min-h-11 rounded-lg text-sm font-medium ${view === 'resumo' ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground'}`}>Resumo</button>
      <button onClick={() => setView('analise')} className={`min-h-11 rounded-lg text-sm font-medium ${view === 'analise' ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground'}`}>Análise Detalhada</button>
    </div>
    {view === 'resumo'
      ? <DashboardExecutivoResumo onDetalhes={() => setView('analise')} />
      : <Suspense fallback={<p className="py-10 text-center text-sm text-muted-foreground">Carregando análise detalhada…</p>}><DashboardAnaliseExecutiva /></Suspense>}
  </div>;
}