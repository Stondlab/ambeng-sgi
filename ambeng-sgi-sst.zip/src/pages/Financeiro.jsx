import React from 'react';
import { useLocation } from 'react-router-dom';
import PageHeader from '@/components/PageHeader';
import { FiltrosFinanceiroProvider } from '@/lib/FiltrosFinanceiroContext';
import FiltroGlobalBar from '@/components/financeiro/FiltroGlobalBar';
import FinDashboard from '@/components/financeiro/FinDashboard';
import DespesasTab from '@/components/financeiro/DespesasTab';
import ReceitasTab from '@/components/financeiro/ReceitasTab';
import ObrasTab from '@/components/financeiro/ObrasTab';
import CartoesTab from '@/components/financeiro/CartoesTab';
import FornecedoresTab from '@/components/financeiro/FornecedoresTab';

const SECTIONS = {
  dashboard: { title: 'Financeiro — Dashboard', subtitle: 'Visão geral e alertas de vencimento.', Comp: FinDashboard },
  despesas: { title: 'Despesas', subtitle: 'Central de controle de despesas, pagamentos e comprometimento.', Comp: DespesasTab },
  receitas: { title: 'Receitas', subtitle: 'Central de contas a receber, recebimentos e previsão de entradas.', Comp: ReceitasTab },
  obras: { title: 'Obras', subtitle: 'Visão financeira, custos, receitas e rentabilidade das obras.', Comp: ObrasTab },
  cartoes: { title: 'Cartões', subtitle: 'Cartões cadastrados e histórico de transações.', Comp: CartoesTab },
  fornecedores: { title: 'Fornecedores', subtitle: 'Cadastro de fornecedores.', Comp: FornecedoresTab },
};

export default function Financeiro() {
  const { pathname } = useLocation();
  const key = pathname === '/financeiro' ? 'dashboard' : (pathname.split('/')[2] || 'dashboard');
  const sec = SECTIONS[key] || SECTIONS.dashboard;
  const Comp = sec.Comp;
  return (
    <FiltrosFinanceiroProvider>
      <div>
        <PageHeader title={sec.title} subtitle={sec.subtitle} />
        {!['receitas', 'despesas'].includes(key) && <FiltroGlobalBar />}
        <Comp />
      </div>
    </FiltrosFinanceiroProvider>
  );
}