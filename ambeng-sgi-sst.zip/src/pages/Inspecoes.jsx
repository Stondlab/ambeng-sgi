import React, { useMemo, useState } from 'react';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PageHeader from '@/components/PageHeader';
import InspectionCard from '@/components/sst/InspectionCard';
import InspectionForm from '@/components/sst/InspectionForm';
import { refreshSstData, useSstData } from '@/hooks/useSstEntitiesData';
import { usePerm } from '@/hooks/usePerm';

export default function Inspecoes() {
  const data=useSstData(['inspecoes','obras']); const { podeCriar }=usePerm('formularios'); const [open,setOpen]=useState(false); const [obra,setObra]=useState('todas'); const rows=useMemo(()=>data ? data.inspecoes.filter((i)=>obra==='todas'||i.obra===obra).sort((a,b)=>(b.data||'').localeCompare(a.data||'')) : [],[data,obra]);
  if(!data) return <p className="text-muted-foreground">Carregando inspeções...</p>;
  return <div><PageHeader title="Inspeções" subtitle="Inspeção por obra, evidências, checklist e histórico." action={podeCriar ? <Button onClick={()=>setOpen(true)}><Plus />Nova inspeção</Button> : null} /><div className="mb-5 flex gap-2 overflow-x-auto"><button onClick={()=>setObra('todas')} className={`min-h-10 rounded-lg px-3 text-sm ${obra==='todas'?'bg-primary text-primary-foreground':'border bg-card'}`}>Todas</button>{data.obras.map((o)=><button key={o.id} onClick={()=>setObra(o.nome)} className={`min-h-10 whitespace-nowrap rounded-lg px-3 text-sm ${obra===o.nome?'bg-primary text-primary-foreground':'border bg-card'}`}>{o.nome}</button>)}</div><div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{rows.map((inspection)=><InspectionCard key={inspection.id} inspection={inspection} />)}{!rows.length && <p className="col-span-full rounded-xl border border-dashed p-10 text-center text-muted-foreground">Nenhuma inspeção registrada.</p>}</div>{open && <InspectionForm obras={data.obras} onClose={()=>setOpen(false)} onSaved={()=>{setOpen(false);refreshSstData();}} />}</div>;
}