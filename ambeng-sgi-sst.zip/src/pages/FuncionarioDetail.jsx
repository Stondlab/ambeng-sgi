import React, { useEffect, useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { AlertTriangle, BriefcaseBusiness, Clock3, FileText, HeartPulse, History, IdCard, UserX } from 'lucide-react';
import DadosPessoais from '@/components/funcionario/DadosPessoais';
import AlocacoesSection from '@/components/funcionario/AlocacoesSection';
import RelatedSection from '@/components/funcionario/RelatedSection';
import DdsSection from '@/components/funcionario/DdsSection';
import OcorrenciasSection from '@/components/funcionario/OcorrenciasSection';
import DocumentosSection from '@/components/funcionario/DocumentosSection';
import ColaboradorTimeline from '@/components/funcionario/ColaboradorTimeline';
import FichaIdentificacao from '@/components/funcionario/FichaIdentificacao';
import Resumo360Section from '@/components/funcionario/Resumo360Section';
import NovoRegistroDropdown from '@/components/funcionario/NovoRegistroDropdown';
import RhSection from '@/components/funcionario/RhSection';
import EquipamentosSection from '@/components/funcionario/EquipamentosSection';
import EditarCadastroModal from '@/components/funcionario/ficha360/EditarCadastroModal';
import { usePermissoes } from '@/lib/PermissoesContext';
import { usePerm } from '@/hooks/usePerm';
import { useSstData, refreshSstData } from '@/hooks/useSstEntitiesData';
import { Section, Resumo360 } from '@/components/Prontuario/SectionComponent';
import QuickActions from '@/components/Prontuario/QuickActions';
import PontoResumoFuncionario from '@/components/Prontuario/PontoResumoFuncionario';
import TecnicoFuncionarioDetail from '@/components/funcionario/TecnicoFuncionarioDetail';
import { ASO_FIELDS, TREIN_FIELDS, EPI_FIELDS, INTEGRACAO_FIELDS, INSP_FIELDS } from '@/lib/funcionarioSafetyFields';



export default function FuncionarioDetail() {
  const { id } = useParams();
  const data = useSstData(
    ['funcionarios', 'asos', 'treinamentos', 'epis', 'integracoes', 'dds', 'ocorrencias', 'documentos', 'pendencias', 'inspecoes', 'alocacoes'],
    false,
    { filters: {
      funcionarios: { id }, asos: { funcionario_id: id }, treinamentos: { funcionario_id: id }, epis: { funcionario_id: id },
      integracoes: { funcionario_id: id }, dds: { funcionario_id: id }, ocorrencias: { funcionario_id: id }, documentos: { funcionario_id: id },
      pendencias: { funcionario_id: id }, inspecoes: { funcionario_id: id }, alocacoes: { funcionario_id: id },
    }, limits: { funcionarios: 1, asos: 200, treinamentos: 200, epis: 200, integracoes: 200, dds: 200, ocorrencias: 200, documentos: 200, pendencias: 200, inspecoes: 200, alocacoes: 200 } }
  );
  const { perfilEfetivo } = usePermissoes();
  const perfil = perfilEfetivo || 'Administrativo';
  const permColab = usePerm('colaboradores');
  const permAsos = usePerm('asos');
  const permTrei = usePerm('treinamentos');
  const permEpi = usePerm('epis');
  const [openSecoes, setOpenSecoes] = useState({ identidade: true, conformidade: false, documentacao: false, ponto: false });
  const [openSubsecoes, setOpenSubsecoes] = useState({ cadastro: true, contrato: false, saude: true, treinamentos: false, epis: false, ocorrencias: false, documentos: true, historico: false });
  const [editando, setEditando] = useState(false);
  const [demandas, setDemandas] = useState([]);
  const [obras, setObras] = useState([]);

  const loadDemandas = async () => {
    try { setDemandas(await base44.entities.Demandas.filter({ funcionario_id: id }, '-created_date', 500)); }
    catch { setDemandas([]); }
  };
  useEffect(() => {
    loadDemandas();
    base44.entities.Obras.list('nome', 500).then(setObras).catch(() => setObras([]));
  }, [id]);

  const func = useMemo(() => (data?.funcionarios || []).find((f) => f.id === id), [data, id]);
  const fd = useMemo(() => {
    if (!data) return null;
    const by = (arr) => (arr || []).filter((r) => r.funcionario_id === id);
    return {
      asos: by(data.asos), treinamentos: by(data.treinamentos), epis: by(data.epis),
      integracoes: by(data.integracoes), dds: by(data.dds), ocorrencias: by(data.ocorrencias),
      documentos: by(data.documentos), pendencias: by(data.pendencias), inspecoes: by(data.inspecoes),
      alocacoes: by(data.alocacoes),
    };
  }, [data, id]);

  if (!data) return <p className="text-slate-400">Carregando ficha...</p>;
  if (!func) return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <UserX className="w-12 h-12 text-slate-300 mb-3" />
      <p className="text-slate-500 mb-1">Não foi possível carregar este colaborador.</p>
      <p className="text-sm text-slate-400 mb-4">O registro pode ter sido removido ou você não tem permissão para visualizá-lo.</p>
      <Link to="/funcionarios" className="inline-flex items-center gap-1 text-sm font-medium text-[#0b2545] bg-amber-100 hover:bg-amber-200 border border-amber-200 rounded-lg px-4 py-2">
        ← Voltar para a lista de colaboradores
      </Link>
    </div>
  );

  const reload = () => { refreshSstData(); loadDemandas(); };
  const toggleSecao = (key) => setOpenSecoes((prev) => ({ ...prev, [key]: !prev[key] }));
  const toggleSubsecao = (key) => setOpenSubsecoes((prev) => ({ ...prev, [key]: !prev[key] }));
  const abrirEm = (secaoId, subsecaoId) => {
    setOpenSecoes((prev) => ({ ...prev, [secaoId]: true }));
    if (subsecaoId) setOpenSubsecoes((prev) => ({ ...prev, [subsecaoId]: true }));
    setTimeout(() => document.getElementById(`prontuario-${subsecaoId || secaoId}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 0);
  };
  const navegarRegistro = (destino) => {
    const mapa = { saude: ['conformidade', 'saude'], treinamentos: ['conformidade', 'treinamentos'], epis: ['conformidade', 'epis'], ocorrencias: ['conformidade', 'ocorrencias'], documentos: ['documentacao', 'documentos'], historico: ['documentacao', 'historico'], rh: ['identidade', 'contrato'] };
    abrirEm(...(mapa[destino] || ['identidade', 'cadastro']));
  };

  const gerarNumeroEPI = async (values) => {
    const ano = new Date().getFullYear();
    try {
      const all = await base44.entities.EPIs.list('-created_date', 1000);
      const count = all.filter((e) => (e.numero_formulario || '').includes(`EPI-${ano}`)).length + 1;
      return { ...values, numero_formulario: `EPI-${ano}-${String(count).padStart(3, '0')}` };
    } catch {
      return { ...values, numero_formulario: `EPI-${ano}-001` };
    }
  };
  const podeVerRH = perfil === 'Administrador';
  const podeVerEquip = perfil !== 'Administrativo';

  if (perfil === 'Técnico') return <TecnicoFuncionarioDetail funcionario={func} dados={fd} reload={reload} beforeSaveEpi={gerarNumeroEPI} permissoes={{ asos: permAsos, treinamentos: permTrei, epis: permEpi, sst: permTrei }} />;

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex items-center justify-between gap-3">
        <Link to="/funcionarios" className="inline-flex min-h-11 items-center text-sm text-muted-foreground hover:text-primary">← Voltar aos colaboradores</Link>
        {permColab.podeEditar && <NovoRegistroDropdown onNav={navegarRegistro} podeCriar={permColab.podeEditar} />}
      </div>

      <FichaIdentificacao func={func} podeEditar={permColab.podeEditar} onEditar={() => setEditando(true)} onHistorico={() => navegarRegistro('historico')} />

      <Resumo360>
        <Resumo360Section func={func} fd={fd} demandas={demandas} podeVerRH={podeVerRH} onUpdated={reload} />
      </Resumo360>

      <div id="prontuario-identidade">
        <Section id="identidade" title="Identidade" icon={IdCard} open fixed>
          <div className="space-y-4">
            <div id="prontuario-cadastro"><Section id="cadastro" title="Cadastro pessoal" open={openSubsecoes.cadastro} onToggle={toggleSubsecao}><DadosPessoais funcionario={func} onSaved={reload} podeEditar={permColab.podeEditar} /></Section></div>
            <div id="prontuario-contrato"><Section id="contrato" title="Contrato e RH" icon={BriefcaseBusiness} open={openSubsecoes.contrato} onToggle={toggleSubsecao} badge={`${fd.integracoes.length} integração(ões)`}><div className="space-y-4">{podeVerRH && <RhSection funcionario_id={id} />}<RelatedSection title="Integrações" entityName="Integracoes" fields={INTEGRACAO_FIELDS} funcionario_id={id} items={fd.integracoes} reload={reload} addLabel="Nova integração" podeCriar={permColab.podeEditar} podeExcluir={permColab.podeEditar} /><AlocacoesSection funcionario={func} funcionario_id={id} podeEditar={permColab.podeEditar} obras={obras} />{podeVerEquip && <EquipamentosSection funcionario_id={id} func={func} />}</div></Section></div>
          </div>
        </Section>
      </div>

      <div id="prontuario-conformidade">
        <Section id="conformidade" title="Conformidade e Saúde" icon={HeartPulse} open={openSecoes.conformidade} onToggle={toggleSecao} badge="4 subseções">
          <div className="space-y-4">
            <div id="prontuario-saude"><Section id="saude" title="Saúde ocupacional" open={openSubsecoes.saude} onToggle={toggleSubsecao} badge={`${fd.asos.length} ASO(s)`}><RelatedSection title="Saúde Ocupacional — ASOs" entityName="ASOs" fields={ASO_FIELDS} funcionario_id={id} items={fd.asos} reload={reload} addLabel="Adicionar novo ASO" podeCriar={permAsos.podeCriar} podeExcluir={permAsos.podeExcluir} /></Section></div>
            <div id="prontuario-treinamentos"><Section id="treinamentos" title="Treinamentos" open={openSubsecoes.treinamentos} onToggle={toggleSubsecao} badge={`${fd.treinamentos.length} registro(s)`}><RelatedSection title="Treinamentos" entityName="Treinamentos" fields={TREIN_FIELDS} funcionario_id={id} items={fd.treinamentos} reload={reload} addLabel="Adicionar treinamento" podeCriar={permTrei.podeCriar} podeExcluir={permTrei.podeExcluir} /></Section></div>
            <div id="prontuario-epis"><Section id="epis" title="EPIs" open={openSubsecoes.epis} onToggle={toggleSubsecao} badge={`${fd.epis.length} entrega(s)`}><RelatedSection title="EPIs — entregas e reposições" entityName="EPIs" fields={EPI_FIELDS} funcionario_id={id} items={fd.epis} reload={reload} addLabel="Nova entrega" podeCriar={permEpi.podeCriar} podeExcluir={permEpi.podeExcluir} beforeSave={gerarNumeroEPI} /></Section></div>
            <div id="prontuario-ocorrencias"><Section id="ocorrencias" title="Ocorrências" icon={AlertTriangle} open={openSubsecoes.ocorrencias} onToggle={toggleSubsecao} badge={`${fd.ocorrencias.length} registro(s)`}><div className="space-y-4"><OcorrenciasSection funcionario_id={id} items={fd.ocorrencias} reload={reload} /><DdsSection funcionario_id={id} items={fd.dds} reload={reload} /><RelatedSection title="Inspeções" entityName="Inspecoes" fields={INSP_FIELDS} funcionario_id={id} items={fd.inspecoes} reload={reload} addLabel="Nova inspeção" podeCriar={permColab.podeEditar} podeExcluir={permColab.podeEditar} /></div></Section></div>
          </div>
        </Section>
      </div>

      <div id="prontuario-documentacao">
        <Section id="documentacao" title="Documentação" icon={FileText} open={openSecoes.documentacao} onToggle={toggleSecao} badge="2 subseções">
          <div className="space-y-4">
            <div id="prontuario-documentos"><Section id="documentos" title="Documentos" open={openSubsecoes.documentos} onToggle={toggleSubsecao} badge={`${fd.documentos.length} arquivo(s)`}><DocumentosSection funcionario_id={id} items={fd.documentos} reload={reload} /></Section></div>
            <div id="prontuario-historico"><Section id="historico" title="Histórico" icon={History} open={openSubsecoes.historico} onToggle={toggleSubsecao}><ColaboradorTimeline funcionario={func} funcionario_id={id} asos={fd.asos} treinamentos={fd.treinamentos} epis={fd.epis} dds={fd.dds} integracoes={fd.integracoes} ocorrencias={fd.ocorrencias} alocacoes={fd.alocacoes} podeVerRH={podeVerRH} podeVerEquip={podeVerEquip} /></Section></div>
          </div>
        </Section>
      </div>

      <div id="prontuario-ponto">
        <Section id="ponto" title="Ponto e Jornada" icon={Clock3} open={openSecoes.ponto} onToggle={toggleSecao}>
          <PontoResumoFuncionario funcionarioId={id} />
        </Section>
      </div>

      {permColab.podeEditar && <QuickActions onAction={abrirEm} />}

      {editando && (
        <EditarCadastroModal
          funcionario={func}
          podeEditar={permColab.podeEditar}
          onClose={() => setEditando(false)}
          onSaved={() => { setEditando(false); reload(); }}
        />
      )}
    </div>
  );
}