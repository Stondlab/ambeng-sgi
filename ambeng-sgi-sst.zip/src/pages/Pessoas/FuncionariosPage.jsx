import React from 'react';
import Funcionarios from '@/pages/Funcionarios';

export default function FuncionariosPage() {
  return <Funcionarios />;
}