import React from 'react';
import FuncionarioDetail from '@/pages/FuncionarioDetail';

export default function ProntuarioPage() {
  return <FuncionarioDetail />;
}