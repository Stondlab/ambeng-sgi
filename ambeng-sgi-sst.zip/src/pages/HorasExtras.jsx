import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, X, Timer, CheckCircle2, Pencil } from 'lucide-react';
import { fmt } from '@/lib/sst';
import { perfilUsuario } from '@/lib/permissoes';
import { useAuth } from '@/lib/AuthContext';
import { mensagemAmigavelErro, validarDataOpcional, validarNumeroOpcional } from '@/lib/validacao';

const TIPOS = ['Hora extra', 'Hora compensada', 'Saldo positivo', 'Saldo negativo'];

const STATUS_BADGE = {
  'Lançado': 'bg-amber-100 text-amber-700',
  'Processado': 'bg-emerald-100 text-emerald-700',
};

export default function HorasExtras() {
  const { user } = useAuth();
  const perfil = perfilUsuario(user);
  const [funcs, setFuncs] = useState([]);
  const [records, setRecords] = useState([]);
  const [selFunc, setSelFunc] = useState('todos');
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState(null);
  const [erro, setErro] = useState('');

  useEffect(() => {
    (async () => { try { setFuncs(await base44.entities.Funcionarios.list('nome', 1000)); } catch {} })();
  }, []);

  const load = async () => {
    setLoading(true);
    let all = [];
    try { all = await base44.entities.HorasExtras.list('-data', 1000); } catch { all = []; }
    setRecords(all);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const nomeOf = (id) => { const f = funcs.find((x) => x.id === id); return f ? f.nome : '—'; };
  const visiveis = selFunc === 'todos' ? records : records.filter((r) => r.funcionario_id === selFunc);

  const totalHoras = useMemo(() => visiveis.reduce((s, r) => s + (Number(r.quantidade) || 0), 0), [visiveis]);
  const totalLancado = useMemo(() => visiveis.filter((r) => (r.status || 'Lançado') === 'Lançado').length, [visiveis]);
  const totalProcessado = useMemo(() => visiveis.filter((r) => r.status === 'Processado').length, [visiveis]);

  const processar = async (r) => {
    await base44.entities.HorasExtras.update(r.id, { status: 'Processado' });
    load();
  };

  const salvarEdicao = async (id, dados) => {
    if (!validarNumeroOpcional(dados.quantidade)) return setErro('Informe uma quantidade de horas válida e não negativa.');
    setErro('');
    try { await base44.entities.HorasExtras.update(id, dados); setEditing(null); load(); }
    catch (error) { setErro(mensagemAmigavelErro(error)); }
  };

  if (perfil && perfil !== 'Administrador' && perfil !== 'Administrativo') {
    return (
      <div className="flex flex-col items-center justify-center text-center py-24 animate-fade-in">
        <h2 className="text-xl font-heading font-semibold text-primary">Acesso não autorizado</h2>
        <p className="text-sm text-slate-500 mt-2">Esta área é restrita a Administradores e perfil Administrativo.</p>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-start justify-between gap-3 mb-4">
        <div>
          <h1 className="text-xl font-bold text-[#0b2545] tracking-tight">HORAS EXTRAS</h1>
          <p className="text-sm text-slate-500 mt-0.5">Lançamento e acompanhamento de horas extras por colaborador.</p>
        </div>
        <Button onClick={() => setShowForm(true)} className="bg-amber-400 text-[#0b2545] hover:bg-amber-300 font-semibold min-h-[44px]"><Plus className="w-4 h-4 mr-1.5" />Novo registro</Button>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        <div className="bg-white border border-slate-200 rounded-xl p-3 flex-1 min-w-[120px]">
          <div className="text-[11px] uppercase tracking-wide text-slate-500">Registros</div>
          <div className="text-2xl font-bold text-[#0b2545]">{visiveis.length}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-3 flex-1 min-w-[120px]">
          <div className="text-[11px] uppercase tracking-wide text-slate-500 flex items-center gap-1"><Timer className="w-3 h-3" />Total de horas</div>
          <div className="text-2xl font-bold text-amber-600">{totalHoras.toFixed(1)}h</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-3 flex-1 min-w-[120px]">
          <div className="text-[11px] uppercase tracking-wide text-slate-500">Lançados</div>
          <div className="text-2xl font-bold text-amber-600">{totalLancado}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-3 flex-1 min-w-[120px]">
          <div className="text-[11px] uppercase tracking-wide text-slate-500">Processados</div>
          <div className="text-2xl font-bold text-emerald-600">{totalProcessado}</div>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-3 mb-4 flex flex-col sm:flex-row gap-3 sm:items-center">
        <Label className="text-xs text-slate-500 shrink-0">Colaborador</Label>
        <Select value={selFunc} onValueChange={setSelFunc}>
          <SelectTrigger className="sm:max-w-sm"><SelectValue placeholder="Todos os colaboradores" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os colaboradores</SelectItem>
            {funcs.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}
          </SelectContent>
        </Select>
        <span className="text-xs text-slate-400 sm:ml-auto">{visiveis.length} registro(s)</span>
      </div>

      {erro && <p className="mb-3 text-sm text-red-600">{erro}</p>}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
              <tr>
                <th className="text-left px-4 py-3">Colaborador</th>
                <th className="text-left px-4 py-3">Data</th>
                <th className="text-right px-4 py-3">Quantidade</th>
                <th className="text-left px-4 py-3">Tipo</th>
                <th className="text-left px-4 py-3">Motivo</th>
                <th className="text-left px-4 py-3">Status</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr><td colSpan={7} className="text-center py-10 text-slate-400">Carregando...</td></tr>
              ) : visiveis.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-10 text-slate-400">Nenhum registro.</td></tr>
              ) : visiveis.map((r) => {
                const st = r.status || 'Lançado';
                const isEditing = editing?.id === r.id;
                return (
                  <tr key={r.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-medium text-[#0b2545]">{nomeOf(r.funcionario_id)}</td>
                    <td className="px-4 py-3 text-slate-600">{fmt(r.data)}</td>
                    {isEditing ? (
                      <>
                        <td className="px-4 py-3"><Input type="number" step="0.5" value={editing.quantidade} onChange={(e) => setEditing({ ...editing, quantidade: e.target.value })} className="h-9 w-20" /></td>
                        <td className="px-4 py-3 text-slate-600">{r.tipo || '—'}</td>
                        <td className="px-4 py-3"><Input value={editing.motivo || ''} onChange={(e) => setEditing({ ...editing, motivo: e.target.value })} className="h-9" /></td>
                        <td className="px-4 py-3"><span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium ${STATUS_BADGE[st]}`}>{st}</span></td>
                        <td className="px-4 py-3 text-right whitespace-nowrap">
                          <button onClick={() => salvarEdicao(r.id, { quantidade: Number(editing.quantidade) || 0, motivo: editing.motivo || '' })} className="text-emerald-500 hover:text-emerald-700 transition-colors mr-2" title="Salvar"><CheckCircle2 className="w-4 h-4" /></button>
                          <button onClick={() => setEditing(null)} className="text-slate-300 hover:text-slate-500 transition-colors" title="Cancelar"><X className="w-4 h-4" /></button>
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="px-4 py-3 text-right font-mono font-semibold text-amber-600">{(Number(r.quantidade) || 0).toFixed(1)}h</td>
                        <td className="px-4 py-3 text-slate-600">{r.tipo || '—'}</td>
                        <td className="px-4 py-3 text-slate-600 max-w-[200px] truncate" title={r.motivo || ''}>{r.motivo || '—'}</td>
                        <td className="px-4 py-3"><span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium ${STATUS_BADGE[st]}`}>{st}</span></td>
                        <td className="px-4 py-3 text-right whitespace-nowrap">
                          {st === 'Lançado' && (
                            <>
                              <button onClick={() => setEditing({ id: r.id, quantidade: r.quantidade, motivo: r.motivo })} className="text-slate-400 hover:text-blue-500 transition-colors mr-2" title="Editar"><Pencil className="w-4 h-4" /></button>
                              <button onClick={() => processar(r)} className="text-slate-400 hover:text-emerald-500 transition-colors mr-2" title="Processar (enviar para folha)"><CheckCircle2 className="w-4 h-4" /></button>
                            </>
                          )}
                          <button onClick={async () => { await base44.entities.HorasExtras.delete(r.id); load(); }} className="text-slate-300 hover:text-red-500 transition-colors" title="Excluir"><Trash2 className="w-4 h-4" /></button>
                        </td>
                      </>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && <HorasExtrasForm funcs={funcs} onClose={() => setShowForm(false)} onSaved={() => { setShowForm(false); load(); }} />}
    </div>
  );
}

function HorasExtrasForm({ funcs, onClose, onSaved }) {
  const [form, setForm] = useState({ funcionario_id: '', data: new Date().toISOString().slice(0, 10), quantidade: '', tipo: 'Hora extra', motivo: '' });
  const [saving, setSaving] = useState(false);
  const [erro, setErro] = useState('');
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const save = async () => {
    if (!form.funcionario_id || !form.data) return setErro('Selecione o colaborador e informe a data.');
    if (!validarDataOpcional(form.data)) return setErro('Informe uma data válida.');
    if (!validarNumeroOpcional(form.quantidade)) return setErro('Informe uma quantidade de horas válida e não negativa.');
    setErro(''); setSaving(true);
    try {
      await base44.entities.HorasExtras.create({
        funcionario_id: form.funcionario_id,
        data: form.data,
        quantidade: Number(form.quantidade) || 0,
        tipo: form.tipo,
        motivo: form.motivo,
        status: 'Lançado',
      });
      onSaved();
    } catch (error) { setErro(mensagemAmigavelErro(error)); }
    finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">Novo registro de horas extras</h3><button type="button" onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div>
          <Label>Colaborador</Label>
          <Select value={form.funcionario_id} onValueChange={(v) => set('funcionario_id', v)}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione o colaborador" /></SelectTrigger><SelectContent>{funcs.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}</SelectContent></Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Data</Label>
            <Input className="mt-1" type="date" value={form.data} onChange={(e) => set('data', e.target.value)} />
          </div>
          <div>
            <Label>Quantidade (h)</Label>
            <Input className="mt-1" type="number" step="0.5" value={form.quantidade} onChange={(e) => set('quantidade', e.target.value)} />
          </div>
        </div>
        <div>
          <Label>Tipo</Label>
          <Select value={form.tipo} onValueChange={(v) => set('tipo', v)}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{TIPOS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select>
        </div>
        <div>
          <Label>Motivo</Label>
          <Input className="mt-1" value={form.motivo} onChange={(e) => set('motivo', e.target.value)} placeholder="Motivo das horas extras" />
        </div>
        {erro && <p className="text-sm text-red-600">{erro}</p>}
        <div className="flex justify-end gap-2 pt-2"><Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button><Button type="button" onClick={save} disabled={saving || !form.funcionario_id} className="bg-[#0b2545] hover:bg-[#16365f]">{saving ? 'Salvando...' : 'Salvar'}</Button></div>
      </div>
    </div>
  );
}