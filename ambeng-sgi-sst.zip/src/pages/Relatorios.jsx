import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { SearchCheck } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import PageHeader from '@/components/PageHeader';
import { useSstData } from '@/hooks/useSstEntitiesData';
import RelatoriosFavoritos from '@/components/relatorios/RelatoriosFavoritos';
import RelatorioOperacional from '@/components/relatorios/RelatorioOperacional';
import RelatoriosGerenciais from '@/components/relatorios/RelatoriosGerenciais';
import RelatorioExecutivo from '@/components/relatorios/RelatorioExecutivo';
import AuditoriaConformidade from '@/components/relatorios/AuditoriaConformidade';
import IndicadoresGerais from '@/components/relatorios/IndicadoresGerais';
import PendenciasRelatorio from '@/components/relatorios/PendenciasRelatorio';
import GeradorRelatorio from '@/components/relatorios/GeradorRelatorio';
import TemplatesMensais from '@/components/relatorios/TemplatesMensais';
import ColaboradoresPendentesLiberacao from '@/components/relatorios/ColaboradoresPendentesLiberacao';
import RelatorioFinanceiroConsolidado from '@/components/relatorios/RelatorioFinanceiroConsolidado';
import { obrasAtivasParaLancamento } from '@/lib/obraDisponibilidade';

export default function Relatorios() {
  const data = useSstData(['funcionarios', 'asos', 'treinamentos', 'epis', 'integracoes', 'documentos', 'dds', 'ocorrencias', 'obras', 'pendencias', 'inspecoes', 'alocacoes']);
  const [tab, setTab] = useState('operacionais');
  const [opSel, setOpSel] = useState(null);
  const dataAtual = useMemo(() => {
    if (!data) return null;
    const nomes = new Set(obrasAtivasParaLancamento(data.obras || []).map((obra) => obra.nome));
    const funcionarios = data.funcionarios.filter((funcionario) => !funcionario.obra || nomes.has(funcionario.obra));
    const ids = new Set(funcionarios.map((funcionario) => funcionario.id));
    const filtra = (lista) => (lista || []).filter((registro) => !registro.funcionario_id || ids.has(registro.funcionario_id));
    return {
      ...data, funcionarios,
      asos: filtra(data.asos), treinamentos: filtra(data.treinamentos), epis: filtra(data.epis),
      integracoes: filtra(data.integracoes), documentos: filtra(data.documentos), dds: filtra(data.dds),
      ocorrencias: filtra(data.ocorrencias), alocacoes: filtra(data.alocacoes),
      pendencias: (data.pendencias || []).filter((registro) => !registro.obra || nomes.has(registro.obra)),
      inspecoes: (data.inspecoes || []).filter((registro) => !registro.obra || nomes.has(registro.obra)),
    };
  }, [data]);

  const onNav = (t, key) => {
    setTab(t);
    if (t === 'operacionais' && key) setOpSel(key);
    setTimeout(() => {
      const el = document.getElementById('relatorios-detalhados');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 60);
  };

  if (!data) return <p className="text-slate-400">Carregando relatórios...</p>;

  return (
    <div>
      <PageHeader title="Relatórios" subtitle="Emissão de relatórios operacionais, gerenciais, executivos e de auditoria." action={
        <Link to="/relatorios/auditoria" className="inline-flex items-center gap-1.5 min-h-[44px] px-4 rounded-lg bg-[#0b2545] text-white text-sm font-medium hover:bg-[#16365f]"><SearchCheck className="w-4 h-4" />Auditoria & Evidências</Link>
      } />

      <RelatoriosFavoritos onNav={onNav} />

      <div className="mb-4">
        <TemplatesMensais data={dataAtual} />
      </div>

      <div id="relatorios-detalhados" className="border-t border-slate-200 pt-4 mt-4">
        <h2 className="text-lg font-semibold text-[#0b2545] mb-3">Relatórios Detalhados</h2>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="flex flex-wrap h-auto bg-slate-100 p-1 mb-4">
            <TabsTrigger value="operacionais">Operacionais</TabsTrigger>
            <TabsTrigger value="gerenciais">Gerenciais</TabsTrigger>
            <TabsTrigger value="executivos">Executivos</TabsTrigger>
            <TabsTrigger value="financeiro">Financeiro</TabsTrigger>
            <TabsTrigger value="auditorias">Auditorias</TabsTrigger>
            <TabsTrigger value="indicadores">Indicadores</TabsTrigger>
            <TabsTrigger value="pendencias">Pendências</TabsTrigger>
            <TabsTrigger value="liberacao">Liberação</TabsTrigger>
            <TabsTrigger value="personalizados">Personalizados</TabsTrigger>
          </TabsList>
          <TabsContent value="operacionais"><RelatorioOperacional data={dataAtual} sel={opSel} onSel={setOpSel} /></TabsContent>
          <TabsContent value="gerenciais"><RelatoriosGerenciais data={dataAtual} /></TabsContent>
          <TabsContent value="executivos"><RelatorioExecutivo data={dataAtual} /></TabsContent>
          <TabsContent value="financeiro"><RelatorioFinanceiroConsolidado /></TabsContent>
          <TabsContent value="auditorias"><AuditoriaConformidade data={dataAtual} /></TabsContent>
          <TabsContent value="indicadores"><IndicadoresGerais data={dataAtual} /></TabsContent>
          <TabsContent value="pendencias"><PendenciasRelatorio data={dataAtual} /></TabsContent>
          <TabsContent value="liberacao"><ColaboradoresPendentesLiberacao data={dataAtual} /></TabsContent>
          <TabsContent value="personalizados"><GeradorRelatorio data={data} /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}