import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useSstData, refreshSstData } from '@/hooks/useSstEntitiesData';
import PageHeader from '@/components/PageHeader';
import StatusBadge from '@/components/StatusBadge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { base44 } from '@/api/base44Client';
import { fmt } from '@/lib/sst';
import { Plus, X } from 'lucide-react';
import { usePerm } from '@/hooks/usePerm';

const TIPOS = ['Admissional', 'Periódico', 'Mudança de Função', 'Retorno ao Trabalho', 'Demissional'];

export default function AsosConsolidado() {
  const data = useSstData(['funcionarios', 'asos']);
  const [fFunc, setFFunc] = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [tipos, setTipos] = useState(TIPOS);
  const { podeCriar, podeExcluir } = usePerm('asos');
  useEffect(() => { (async () => { try { const t = await base44.entities.TiposASO.list('nome', 500); if (t && t.length) setTipos(t.map((x) => x.nome)); } catch {} })(); }, []);

  const nome = (id) => (data?.funcionarios || []).find((f) => f.id === id)?.nome || '—';
  const rows = useMemo(() => {
    if (!data) return [];
    return data.asos.filter((a) => fFunc === 'all' || a.funcionario_id === fFunc).sort((a, b) => (b.data_validade || '').localeCompare(a.data_validade || ''));
  }, [data, fFunc]);

  if (!data) return <p className="text-slate-400">Carregando ASOs...</p>;

  return (
    <div>
      <PageHeader title="ASOs" subtitle="Visão consolidada dos Atestados de Saúde Ocupacional da obra." action={
        podeCriar ? <Button onClick={() => setShowForm((s) => !s)} className="bg-amber-400 text-[#0b2545] hover:bg-amber-300 font-semibold min-h-[44px]"><Plus className="w-4 h-4 mr-1" />Novo ASO</Button> : null
      } />

      <div className="mb-4">
        <Select value={fFunc} onValueChange={setFFunc}>
          <SelectTrigger className="bg-white sm:w-64"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os funcionários</SelectItem>
            {data.funcionarios.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-500 text-xs uppercase">
            <tr><th className="text-left px-4 py-3">Funcionário</th><th className="text-left px-4 py-3">Tipo</th><th className="text-left px-4 py-3">Exame</th><th className="text-left px-4 py-3">Validade</th><th className="text-left px-4 py-3">Status</th><th className="text-left px-4 py-3">Arquivo</th><th className="px-4 py-3"></th></tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.length === 0 && <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-400">Nenhum ASO.</td></tr>}
            {rows.map((a) => (
              <tr key={a.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-[#0b2545]"><Link to={`/funcionarios/${a.funcionario_id}`} className="hover:underline">{nome(a.funcionario_id)}</Link></td>
                <td className="px-4 py-3 text-slate-600">{a.tipo}</td>
                <td className="px-4 py-3 text-slate-600">{fmt(a.data_exame)}</td>
                <td className="px-4 py-3 text-slate-600">{fmt(a.data_validade)}</td>
                <td className="px-4 py-3"><StatusBadge data_validade={a.data_validade} /></td>
                <td className="px-4 py-3">{a.arquivo_url ? <a href={a.arquivo_url} target="_blank" rel="noreferrer" className="text-blue-600 underline text-xs">Ver</a> : <span className="text-slate-300">—</span>}</td>
                <td className="px-4 py-3 text-right">{podeExcluir && <button onClick={async () => { await base44.entities.ASOs.delete(a.id); refreshSstData(); }} className="text-slate-300 hover:text-red-500"><X className="w-4 h-4" /></button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && <AsoForm funcionarios={data.funcionarios} tipos={tipos} onClose={() => setShowForm(false)} onSaved={() => { setShowForm(false); refreshSstData(); }} />}
    </div>
  );
}

function AsoForm({ funcionarios, tipos, onClose, onSaved }) {
  const [form, setForm] = useState({ funcionario_id: '', tipo: '', medico: '', clinica: '', data_exame: '', data_validade: '' });
  const save = async (e) => {
    e.preventDefault();
    await base44.entities.ASOs.create(form);
    onSaved();
  };
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <form onSubmit={save} className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">Novo ASO</h3><button type="button" onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div><Label>Funcionário</Label>
          <Select value={form.funcionario_id} onValueChange={(v) => setForm({ ...form, funcionario_id: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{funcionarios.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}</SelectContent></Select>
        </div>
        <div><Label>Tipo</Label>
          <Select value={form.tipo} onValueChange={(v) => setForm({ ...form, tipo: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{tipos.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Médico</Label><Input className="mt-1" value={form.medico} onChange={(e) => setForm({ ...form, medico: e.target.value })} /></div>
          <div><Label>Clínica</Label><Input className="mt-1" value={form.clinica} onChange={(e) => setForm({ ...form, clinica: e.target.value })} /></div>
          <div><Label>Data do exame</Label><Input className="mt-1" type="date" value={form.data_exame} onChange={(e) => setForm({ ...form, data_exame: e.target.value })} /></div>
          <div><Label>Validade</Label><Input className="mt-1" type="date" value={form.data_validade} onChange={(e) => setForm({ ...form, data_validade: e.target.value })} required /></div>
        </div>
        <div className="flex justify-end gap-2 pt-2"><Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button><Button type="submit" disabled={!form.funcionario_id || !form.tipo} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button></div>
      </form>
    </div>
  );
}