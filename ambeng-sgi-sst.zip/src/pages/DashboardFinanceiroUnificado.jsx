import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Building2, Wallet } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DashboardFinanceiro from '@/pages/DashboardFinanceiro';
import SaudeObras from '@/pages/SaudeObras';

const tabs = [
  { label: 'Visão Financeira', to: '/dashboards/financeiro', icon: Wallet },
  { label: 'Saúde das Obras', to: '/saude-obras', icon: Building2 },
];

export default function DashboardFinanceiroUnificado() {
  const { pathname } = useLocation();
  const abaObras = pathname.startsWith('/saude-obras');

  return (
    <div className="space-y-5">
      <PageHeader title="Dashboard Financeiro" subtitle="Visão financeira geral e saúde detalhada das obras." />
      <div className="flex gap-1 rounded-xl border border-border bg-card p-1 shadow-card" aria-label="Visões do dashboard financeiro">
        {tabs.map((tab, index) => {
          const active = abaObras ? index === 1 : index === 0;
          const Icon = tab.icon;
          return (
            <Link
              key={tab.to}
              to={tab.to}
              className={`flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-lg px-3 text-sm font-semibold transition-colors ${active ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}
            >
              <Icon className="h-4 w-4" />
              {tab.label}
            </Link>
          );
        })}
      </div>
      {abaObras ? <SaudeObras embedded /> : <DashboardFinanceiro embedded />}
    </div>
  );
}