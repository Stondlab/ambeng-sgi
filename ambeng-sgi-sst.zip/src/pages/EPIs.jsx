import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import PageHeader from '@/components/PageHeader';
import MatrizEPIs, { TIPOS } from '@/components/epis/MatrizEPIs';
import { refreshSstData, useSstData } from '@/hooks/useSstEntitiesData';
import { getStatus, fmt } from '@/lib/sst';
import { X, FileSignature } from 'lucide-react';
import { Link } from 'react-router-dom';
import { usePerm } from '@/hooks/usePerm';
import { mensagemAmigavelErro, validarDataOpcional } from '@/lib/validacao';

export default function EPIs() {
  const data = useSstData(['funcionarios', 'epis']);
  const { podeCriar } = usePerm('epis');
  const [sel, setSel] = useState(null);
  const [entrega, setEntrega] = useState(null);
  const [tipos, setTipos] = useState(TIPOS);
  useEffect(() => { (async () => { try { const t = await base44.entities.TiposEPI.list('nome', 500); if (t && t.length) setTipos(t.map((x) => x.nome)); } catch {} })(); }, []);

  if (!data) return <p className="text-slate-400">Carregando EPIs...</p>;

  return (
    <div>
      <PageHeader title="EPIs" subtitle="Estoque por obra, entregas, validade e histórico dos equipamentos." action={
        <Link to="/epis/almoxarifado" className="inline-flex items-center gap-1.5 min-h-[44px] px-4 rounded-lg bg-white border border-slate-200 text-sm font-medium text-[#0b2545] hover:bg-slate-50">Estoque e requisições</Link>
      } />
      <MatrizEPIs funcionarios={data.funcionarios} epis={data.epis} onSelect={setSel} onEntrega={podeCriar ? setEntrega : undefined} podeEntregar={podeCriar} />

      {sel && <DetalheEPI sel={sel} onClose={() => setSel(null)} onSaved={() => { setSel(null); refreshSstData(); }} />}
      {entrega && <EntregaForm func={entrega} tipos={tipos} onClose={() => setEntrega(null)} onSaved={() => { setEntrega(null); refreshSstData(); }} />}
    </div>
  );
}

function DetalheEPI({ sel, onClose, onSaved }) {
  const { func, epi, tipo } = sel;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-3">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">{func.nome}</h3><button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <p className="text-sm text-slate-500">{tipo}</p>
        {!epi ? (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-800">Sem registro de entrega deste EPI.</div>
        ) : (
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">CA</span><span className="text-[#0b2545] font-medium">{epi.certificado_aprovacao || '—'}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Entrega</span><span>{fmt(epi.data_entrega)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Validade</span><span>{fmt(epi.data_validade)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Status</span><span className="font-medium">{getStatus(epi.data_validade)}</span></div>
            <Button className="w-full mt-2 bg-[#0b2545] hover:bg-[#16365f] min-h-[44px]" onClick={() => gerarTermo(func, epi)}><FileSignature className="w-4 h-4 mr-2" />Gerar Termo de Responsabilidade</Button>
          </div>
        )}
      </div>
    </div>
  );
}

function EntregaForm({ func, tipos, onClose, onSaved }) {
  const [form, setForm] = useState({ item: '', certificado_aprovacao: '', data_entrega: '', data_validade: '' });
  const [rec, setRec] = useState(null);
  const [erro, setErro] = useState('');

  const save = async (e) => {
    e.preventDefault();
    if (!form.item || !form.certificado_aprovacao || !form.data_entrega || !form.data_validade) return setErro('Preencha equipamento, CA, entrega e validade.');
    if (!validarDataOpcional(form.data_entrega) || !validarDataOpcional(form.data_validade)) return setErro('Informe datas válidas.');
    if (form.data_validade < form.data_entrega) return setErro('A validade não pode ser anterior à entrega.');
    setErro('');
    try { setRec(await base44.entities.EPIs.create({ funcionario_id: func.id, ...form })); }
    catch (error) { setErro(mensagemAmigavelErro(error)); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">Entrega de EPI — {func.nome}</h3><button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        {rec ? (
          <div className="space-y-3">
            <p className="text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg p-3">Entrega registrada com sucesso!</p>
            <Button className="w-full bg-[#0b2545] hover:bg-[#16365f] min-h-[44px]" onClick={() => gerarTermo(func, rec)}><FileSignature className="w-4 h-4 mr-2" />Gerar Termo de Responsabilidade (PDF)</Button>
            <Button variant="outline" className="w-full min-h-[44px]" onClick={() => onSaved()}>Concluir</Button>
          </div>
        ) : (
          <form onSubmit={save} className="space-y-4">
            <div><Label>Equipamento</Label>
              <Select value={form.item} onValueChange={(v) => setForm({ ...form, item: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{tipos.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select>
            </div>
            <div><Label>CA (Certificado de Aprovação)</Label><Input className="mt-1" value={form.certificado_aprovacao} onChange={(e) => setForm({ ...form, certificado_aprovacao: e.target.value })} required /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Entrega</Label><Input className="mt-1" type="date" value={form.data_entrega} onChange={(e) => setForm({ ...form, data_entrega: e.target.value })} required /></div>
              <div><Label>Validade</Label><Input className="mt-1" type="date" value={form.data_validade} onChange={(e) => setForm({ ...form, data_validade: e.target.value })} required /></div>
            </div>
            {erro && <p className="text-sm text-red-600">{erro}</p>}
            <div className="flex justify-end gap-2 pt-2"><Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button><Button type="submit" className="bg-[#0b2545] hover:bg-[#16365f]">Registrar entrega</Button></div>
          </form>
        )}
      </div>
    </div>
  );
}

export function gerarTermo(func, epi) {
  const hoje = fmt(new Date().toISOString().slice(0, 10));
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Termo de Responsabilidade - EPI</title>
  <style>
    *{box-sizing:border-box} body{font-family:Arial,Helvetica,sans-serif;color:#1e293b;padding:32px;max-width:780px;margin:0 auto}
    h1{color:#0b2545;font-size:20px;margin:0 0 4px} .sub{color:#64748b;font-size:13px;margin-bottom:24px}
    table{width:100%;border-collapse:collapse;margin:16px 0;font-size:14px}
    td{padding:8px 12px;border:1px solid #e2e8f0} td.k{background:#f8fafc;font-weight:600;width:40%}
    .assinatura{margin-top:48px;display:flex;justify-content:space-between;gap:48px}
    .campo{flex:1;text-align:center} .linha{border-top:1px solid #475569;padding-top:6px;font-size:12px;color:#475569}
    .obs{background:#f8fafc;border-left:4px solid #0b2545;padding:12px 16px;font-size:12px;margin-top:24px}
  </style></head><body>
  <h1>TERMO DE RESPONSABILABILIDADE DE ENTREGA DE EPI</h1>
  <div class="sub">SGI SST — Gestão de Segurança do Trabalho</div>
  <p style="font-size:14px">Declaro para os devidos fins que recebi o Equipamento de Proteção Individual abaixo discriminado, em perfeitas condições de uso, comprometendo-me a utilizá-lo adequadamente e a comunicar qualquer defeito ou perda imediatamente.</p>
  <table>
    <tr><td class="k">Colaborador</td><td>${func.nome || '—'}</td></tr>
    <tr><td class="k">Matrícula</td><td>${func.matricula || '—'}</td></tr>
    <tr><td class="k">Função</td><td>${func.funcao || '—'}</td></tr>
    <tr><td class="k">Obra</td><td>${func.obra || '—'}</td></tr>
    <tr><td class="k">Equipamento (EPI)</td><td>${epi.item || '—'}</td></tr>
    <tr><td class="k">Certificado de Aprovação (CA)</td><td>${epi.certificado_aprovacao || '—'}</td></tr>
    <tr><td class="k">Data de Entrega</td><td>${fmt(epi.data_entrega)}</td></tr>
    <tr><td class="k">Validade</td><td>${fmt(epi.data_validade)}</td></tr>
  </table>
  <div class="obs">Este documento possui valor jurídico e comprobatório para auditorias e processos trabalhistas. Gerado automaticamente pelo SGI SST em ${hoje}.</div>
  <div class="assinatura">
    <div class="campo"><div class="linha">Colaborador — ${func.nome || ''}</div></div>
    <div class="campo"><div class="linha">Responsável pela Entrega</div></div>
  </div>
  <script>window.onload=function(){window.print()}</script>
  </body></html>`;
  const w = window.open('', '_blank');
  if (w) { w.document.write(html); w.document.close(); }
}