import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import PageHeader from '@/components/PageHeader';
import { fmt, catPendente } from '@/lib/sst';
import { Plus, X, FileText, AlertTriangle, Clock, RotateCw, Siren } from 'lucide-react';
import { differenceInCalendarDays, parseISO } from 'date-fns';
import { registrarAcao } from '@/lib/historico';
import { useAuth } from '@/lib/AuthContext';
import { usePerm } from '@/hooks/usePerm';
import { mensagemAmigavelErro, validarDataOpcional } from '@/lib/validacao';

const TIPOS = ['Quase Acidente', 'Acidente', 'Não Conformidade', 'Observação de Segurança'];
const GRAV = { 'Baixa': 'bg-emerald-100 text-emerald-700', 'Média': 'bg-amber-100 text-amber-800', 'Alta': 'bg-red-100 text-red-700' };
const SIT = { 'Aberta': 'bg-red-100 text-red-700', 'Em Andamento': 'bg-amber-100 text-amber-800', 'Resolvida': 'bg-emerald-100 text-emerald-700' };
const fotosDaOcorrencia = (value) => { try { const list = JSON.parse(value || '[]'); return Array.isArray(list) ? list : []; } catch { return []; } };

export default function Ocorrencias() {
  const [list, setList] = useState([]);
  const [funcionarios, setFuncionarios] = useState([]);
  const [obras, setObras] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [sel, setSel] = useState(null);
  const [tipos, setTipos] = useState(TIPOS);
  const { podeCriar, podeEditar } = usePerm('ocorrencias');

  const load = async () => {
    const [o, f, t, obrasList] = await Promise.all([
      base44.entities.Ocorrencias.list('-data', 500),
      base44.entities.Funcionarios.list('nome', 500),
      base44.entities.TiposOcorrencia.list('nome', 500).catch(() => []),
      base44.entities.Obras.list('nome', 500),
    ]);
    setList(o); setFuncionarios(f); setObras(obrasList);
    if (t && t.length) setTipos(t.map((x) => x.nome));
  };
  useEffect(() => { load(); }, []);

  const nome = (id) => funcionarios.find((f) => f.id === id)?.nome || '—';

  const stats = useMemo(() => {
    const now = new Date();
    const mes = list.filter((o) => o.data && new Date(o.data).getMonth() === now.getMonth() && new Date(o.data).getFullYear() === now.getFullYear());
    const porGrav = { Baixa: 0, Média: 0, Alta: 0 };
    list.forEach((o) => { if (porGrav[o.gravidade] != null) porGrav[o.gravidade]++; });
    const resolvidas = list.filter((o) => o.situacao === 'Resolvida' && o.data && o.data_encerramento);
    const tempos = resolvidas.map((o) => differenceInCalendarDays(parseISO(o.data_encerramento), parseISO(o.data))).filter((d) => d >= 0);
    const tempoMedio = tempos.length ? Math.round(tempos.reduce((a, b) => a + b, 0) / tempos.length) : 0;
    const porDesc = {};
    list.forEach((o) => { const k = o.descricao || o.tipo; porDesc[k] = (porDesc[k] || 0) + 1; });
    const reincidencias = Object.values(porDesc).filter((n) => n > 1).length;
    return { mes: mes.length, porGrav, tempoMedio, reincidencias };
  }, [list]);

  const catsPendentes = useMemo(() => list.filter(catPendente), [list]);

  return (
    <div>
      <PageHeader title="Ocorrências" subtitle="Registro e tratativa de ocorrências de segurança." action={
        podeCriar ? <Button onClick={() => setShowForm((s) => !s)} className="bg-amber-400 text-[#0b2545] hover:bg-amber-300 font-semibold min-h-[44px]"><Plus className="w-4 h-4 mr-1" />Registrar</Button> : null
      } />

      {/* Mini dashboard */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3"><AlertTriangle className="w-8 h-8 text-[#0b2545]" /><div><p className="text-2xl font-bold text-[#0b2545]">{stats.mes}</p><p className="text-xs text-slate-500">Ocorrências no mês</p></div></div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs text-slate-500 mb-2">Distribuição por gravidade</p>
          <div className="flex gap-2 text-xs">
            <span className="px-2 py-1 rounded bg-emerald-100 text-emerald-700">Baixa: {stats.porGrav.Baixa}</span>
            <span className="px-2 py-1 rounded bg-amber-100 text-amber-800">Média: {stats.porGrav.Média}</span>
            <span className="px-2 py-1 rounded bg-red-100 text-red-700">Alta: {stats.porGrav.Alta}</span>
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3"><Clock className="w-8 h-8 text-amber-500" /><div><p className="text-2xl font-bold text-amber-600">{stats.tempoMedio}d</p><p className="text-xs text-slate-500">Tempo médio de resolução</p></div></div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3"><RotateCw className="w-8 h-8 text-red-500" /><div><p className="text-2xl font-bold text-red-600">{stats.reincidencias}</p><p className="text-xs text-slate-500">Reincidências</p></div></div>
      </div>

      {catsPendentes.length > 0 && (
        <div className="mb-5 bg-red-600 text-white rounded-xl p-4 flex items-center gap-3 animate-blink border-2 border-red-800">
          <Siren className="w-7 h-7 shrink-0" />
          <div className="min-w-0">
            <div className="font-bold text-lg">{catsPendentes.length} CAT pendente(s) — prazo legal de 24h vencido</div>
            <div className="text-sm text-red-100">Ocorrências de gravidade Alta sem CAT emitida. Emita a CAT na tratativa da ocorrência.</div>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {list.length === 0 && <p className="text-slate-400">Nenhuma ocorrência registrada.</p>}
        {list.map((o) => {
          const tempo = o.data_encerramento ? differenceInCalendarDays(parseISO(o.data_encerramento), parseISO(o.data)) : null;
          const fotos = fotosDaOcorrencia(o.fotos);
          return (
            <div key={o.id} className={`bg-white border rounded-xl p-4 ${catPendente(o) ? 'border-red-500 ring-2 ring-red-500 animate-blink' : 'border-slate-200'}`}>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-semibold text-[#0b2545]">{fmt(o.data)}</span>
                <span className="text-sm text-slate-600">{o.tipo}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${GRAV[o.gravidade] || ''}`}>{o.gravidade}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${SIT[o.situacao] || ''}`}>{o.situacao}</span>
                <span className="text-xs text-slate-400">{nome(o.funcionario_id)}</span>
                {(o.obra || o.local) && <span className="text-xs text-primary">{[o.obra, o.local].filter(Boolean).join(' · ')}</span>}
                {o.tipo === 'Acidente' && <span className="text-xs px-2 py-0.5 rounded-full bg-red-700 text-white font-medium">Acidente</span>}
                {catPendente(o) && <span className="text-xs px-2 py-0.5 rounded-full bg-red-700 text-white font-semibold inline-flex items-center gap-1"><Siren className="w-3 h-3" />CAT pendente</span>}
                {tempo != null && <span className="text-xs text-slate-400 ml-auto">Resolvido em {tempo}d</span>}
                {podeEditar && <button onClick={() => setSel(o)} className="ml-auto text-[#0b2545] text-xs font-medium hover:underline min-h-[44px] px-2">Tratativa</button>}
              </div>
              <div className="mt-2 flex gap-3">{fotos[0] && <img src={fotos[0]} alt="Evidência da ocorrência" className="h-16 w-20 rounded-lg object-cover" />}<div>{o.descricao && <p className="text-sm text-slate-600 leading-relaxed">{o.descricao}</p>}{o.causa && <p className="mt-1 text-xs text-slate-500"><b>Causa:</b> {o.causa}</p>}</div></div>
            </div>
          );
        })}
      </div>

      {showForm && <OcorrenciaForm funcionarios={funcionarios} obras={obras} tipos={tipos} onClose={() => setShowForm(false)} onSaved={() => { setShowForm(false); load(); }} />}
      {sel && <TratativaPanel ocorrencia={sel} podeEditar={podeEditar} nome={nome(sel.funcionario_id)} onClose={() => setSel(null)} onSaved={() => { setSel(null); load(); }} />}
    </div>
  );
}

function OcorrenciaForm({ funcionarios, obras, tipos, onClose, onSaved }) {
  const [form, setForm] = useState({ data: '', data_hora: '', obra: '', local: '', tipo: '', gravidade: '', descricao: '', causa: '', funcionario_id: '' });
  const [foto, setFoto] = useState(null);
  const [saving, setSaving] = useState(false);
  const [erro, setErro] = useState('');
  const save = async (e) => {
    e.preventDefault();
    if (!form.data || !form.tipo || !form.gravidade) return setErro('Preencha data, tipo e gravidade.');
    if (!validarDataOpcional(form.data)) return setErro('Informe uma data válida.');
    setErro(''); setSaving(true);
    try {
      let fotos = '[]';
      if (foto) { const uploaded = await base44.integrations.Core.UploadFile({ file: foto }); fotos = JSON.stringify([uploaded.file_url]); }
      const created = await base44.entities.Ocorrencias.create({ ...form, fotos });
      registrarAcao('Ocorrência registrada', form.tipo || '', null, 'Ocorrência', created?.id || '');
      onSaved();
    } catch (error) { setErro(mensagemAmigavelErro(error)); setSaving(false); }
  };
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <form onSubmit={save} className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">Registrar Ocorrência</h3><button type="button" onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Data</Label><Input className="mt-1" type="date" value={form.data} onChange={(e) => setForm({ ...form, data: e.target.value })} required /></div>
          <div><Label>Hora</Label><Input className="mt-1" type="time" value={form.data_hora} onChange={(e) => setForm({ ...form, data_hora: e.target.value })} /></div>
          <div><Label>Obra</Label><Select value={form.obra} onValueChange={(v) => setForm({ ...form, obra: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{obras.map((obra) => <SelectItem key={obra.id} value={obra.nome}>{obra.nome}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Local</Label><Input className="mt-1" value={form.local} onChange={(e) => setForm({ ...form, local: e.target.value })} /></div>
          <div><Label>Pessoa envolvida</Label>
            <Select value={form.funcionario_id} onValueChange={(v) => setForm({ ...form, funcionario_id: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Opcional" /></SelectTrigger><SelectContent>{funcionarios.map((f) => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}</SelectContent></Select>
          </div>
          <div><Label>Tipo</Label>
            <Select value={form.tipo} onValueChange={(v) => setForm({ ...form, tipo: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{tipos.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select>
          </div>
          <div><Label>Gravidade</Label>
            <Select value={form.gravidade} onValueChange={(v) => setForm({ ...form, gravidade: v })}><SelectTrigger className="mt-1"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{['Baixa', 'Média', 'Alta'].map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent></Select>
          </div>
        </div>
        <div><Label>Descrição</Label><Textarea className="mt-1" rows={3} value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} /></div>
        <div><Label>Causa inicial</Label><Textarea className="mt-1" rows={2} value={form.causa} onChange={(e) => setForm({ ...form, causa: e.target.value })} /></div>
        <div><Label>Foto / evidência</Label><Input className="mt-1" type="file" accept="image/*" onChange={(e) => setFoto(e.target.files?.[0] || null)} /></div>
        {erro && <p className="text-sm text-red-600">{erro}</p>}
        <div className="flex justify-end gap-2 pt-2"><Button type="button" variant="ghost" onClick={onClose}>Cancelar</Button><Button type="submit" disabled={saving || !form.tipo || !form.gravidade || !form.data}>{saving ? 'Salvando...' : 'Salvar'}</Button></div>
      </form>
    </div>
  );
}

function TratativaPanel({ ocorrencia, nome, podeEditar, onClose, onSaved }) {
  const { user } = useAuth();
  const [form, setForm] = useState({
    situacao: ocorrencia.situacao || 'Aberta',
    acao_tomada: ocorrencia.acao_tomada || '',
    responsavel_tratativa: ocorrencia.responsavel_tratativa || '',
    prazo_tratativa: ocorrencia.prazo_tratativa || '',
    data_encerramento: ocorrencia.data_encerramento || '',
    responsavel_resolucao: ocorrencia.responsavel_resolucao || '',
    descricao_solucao: ocorrencia.descricao_solucao || '',
    anexos: ocorrencia.anexos || '',
    evidencias: ocorrencia.evidencias || '',
    investigacao: ocorrencia.investigacao || '',
    acoes_corretivas: ocorrencia.acoes_corretivas || '',
  });

  const save = async () => {
    const enc = {};
    if (form.situacao === 'Resolvida') {
      if (!form.data_encerramento) enc.data_encerramento = new Date().toISOString().slice(0, 10);
      if (!ocorrencia.data_resolucao) enc.data_resolucao = new Date().toISOString();
      if (!form.responsavel_resolucao) enc.responsavel_resolucao = user?.full_name || user?.email || '—';
    }
    await base44.entities.Ocorrencias.update(ocorrencia.id, { ...form, ...enc });
    registrarAcao(`Ocorrência ${form.situacao.toLowerCase()}`, ocorrencia.tipo || '', user, 'Ocorrência', ocorrencia.id);
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative w-full sm:max-w-lg bg-white rounded-t-2xl sm:rounded-2xl p-5 space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between"><h3 className="font-semibold text-[#0b2545]">Tratativa da Ocorrência</h3><button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button></div>
        <div className="text-sm text-slate-500 bg-slate-50 rounded-lg p-3">{ocorrencia.tipo} · {fmt(ocorrencia.data)} · {nome}</div>
        <div><Label>Status</Label>
          <Select value={form.situacao} onValueChange={(v) => setForm({ ...form, situacao: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{['Aberta', 'Em Andamento', 'Resolvida', 'Cancelada'].map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select>
        </div>
        <div><Label>Análise / investigação</Label><Textarea className="mt-1" rows={3} value={form.investigacao} onChange={(e) => setForm({ ...form, investigacao: e.target.value })} /></div>
        <div><Label>Medidas corretivas</Label><Textarea className="mt-1" rows={3} value={form.acoes_corretivas} onChange={(e) => setForm({ ...form, acoes_corretivas: e.target.value })} /></div>
        <div><Label>Ação tomada</Label><Textarea className="mt-1" rows={2} value={form.acao_tomada} onChange={(e) => setForm({ ...form, acao_tomada: e.target.value })} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Responsável</Label><Input className="mt-1" value={form.responsavel_tratativa} onChange={(e) => setForm({ ...form, responsavel_tratativa: e.target.value })} /></div>
          <div><Label>Prazo</Label><Input className="mt-1" type="date" value={form.prazo_tratativa} onChange={(e) => setForm({ ...form, prazo_tratativa: e.target.value })} /></div>
        </div>
        <div><Label>Data de encerramento</Label><Input className="mt-1" type="date" value={form.data_encerramento} onChange={(e) => setForm({ ...form, data_encerramento: e.target.value })} /></div>
        <div><Label>Responsável pela resolução</Label><Input className="mt-1" value={form.responsavel_resolucao} onChange={(e) => setForm({ ...form, responsavel_resolucao: e.target.value })} /></div>
        <div><Label>Descrição da solução</Label><Textarea className="mt-1" rows={2} value={form.descricao_solucao} onChange={(e) => setForm({ ...form, descricao_solucao: e.target.value })} /></div>
        <div><Label>Anexos / Evidências (URL)</Label><Input className="mt-1" value={form.anexos} onChange={(e) => setForm({ ...form, anexos: e.target.value })} placeholder="Link de fotos/evidências" /></div>
        <div className="flex gap-2">
          <Button className="flex-1 bg-[#0b2545] hover:bg-[#16365f] min-h-[44px]" onClick={save} disabled={!podeEditar}>Salvar tratativa</Button>
          {['Acidente', 'Quase Acidente'].includes(ocorrencia.tipo) && <Button variant="outline" className="flex-1 min-h-[44px]" onClick={() => gerarRelatorioOcorrencia(ocorrencia, nome)}><FileText className="w-4 h-4 mr-2" />Relatório</Button>}
          {ocorrencia.tipo === 'Acidente' && <Button className="flex-1 bg-red-700 hover:bg-red-800 min-h-[44px]" onClick={async () => { try { await base44.entities.Ocorrencias.update(ocorrencia.id, { cat_gerada: new Date().toISOString().slice(0, 10) }); } catch {} gerarCAT(ocorrencia, nome); onSaved(); }}><FileText className="w-4 h-4 mr-2" />Gerar CAT</Button>}
        </div>
      </div>
    </div>
  );
}

function gerarRelatorioOcorrencia(o, nome) {
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Relatório de Ocorrência</title><style>body{font-family:Arial;padding:32px;max-width:800px;margin:auto;color:#1e293b}h1{font-size:20px}section{margin:18px 0;padding:14px;border:1px solid #cbd5e1}b{display:block;margin-bottom:5px}</style></head><body><h1>RELATÓRIO DE ${String(o.tipo || 'OCORRÊNCIA').toUpperCase()}</h1><p>${fmt(o.data)} ${o.data_hora || ''} · ${o.obra || 'Sem obra'} · ${o.local || 'Sem local'}</p><section><b>Pessoa envolvida</b>${nome}</section><section><b>Descrição e causa</b>${o.descricao || '—'}<br/>${o.causa || '—'}</section><section><b>Investigação</b>${o.investigacao || '—'}</section><section><b>Medidas corretivas</b>${o.acoes_corretivas || '—'}</section><script>window.onload=function(){window.print()}</script></body></html>`; const w=window.open('', '_blank'); if(w){w.document.write(html);w.document.close();}
}

function gerarCAT(o, nome) {
  const hoje = fmt(new Date().toISOString().slice(0, 10));
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>CAT - Comunicação de Acidente de Trabalho</title>
  <style>*{box-sizing:border-box} body{font-family:Arial,Helvetica,sans-serif;padding:24px;max-width:800px;margin:0 auto;color:#1e293b}
  h1{color:#b91c1c;font-size:18px;text-align:center;margin-bottom:2px} .sub{text-align:center;color:#64748b;font-size:12px;margin-bottom:20px}
  table{width:100%;border-collapse:collapse;margin:12px 0;font-size:13px} td{padding:8px;border:1px solid #cbd5e1} td.k{background:#fee2e2;font-weight:600;width:35%}
  .obs{background:#fef2f2;border-left:4px solid #b91c1c;padding:10px 14px;font-size:12px;margin-top:16px}</style></head><body>
  <h1>COMUNICAÇÃO DE ACIDENTE DE TRABALHO — CAT</h1>
  <div class="sub">SGI SST — documento gerado em ${hoje}</div>
  <table>
    <tr><td class="k">Data do acidente</td><td>${fmt(o.data)}</td></tr>
    <tr><td class="k">Tipo</td><td>${o.tipo}</td></tr>
    <tr><td class="k">Gravidade</td><td>${o.gravidade}</td></tr>
    <tr><td class="k">Acidentado</td><td>${nome}</td></tr>
    <tr><td class="k">Descrição do acidente</td><td>${o.descricao || '—'}</td></tr>
    <tr><td class="k">Ação tomada</td><td>${o.acao_tomada || '—'}</td></tr>
    <tr><td class="k">Responsável pela tratativa</td><td>${o.responsavel_tratativa || '—'}</td></tr>
  </table>
  <div class="obs">A CAT deve ser emitida oficialmente pelo empregador à Previdência Social. Este documento é o registro interno no SGI SST para fins de rastreabilidade jurídica e auditoria.</div>
  <script>window.onload=function(){window.print()}</script></body></html>`;
  const w = window.open('', '_blank');
  if (w) { w.document.write(html); w.document.close(); }
}