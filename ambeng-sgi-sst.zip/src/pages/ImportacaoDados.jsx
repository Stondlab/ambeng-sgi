import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { UploadCloud, FileSpreadsheet, ArrowRight, ArrowLeft, Download, RefreshCw, AlertTriangle } from 'lucide-react';
import {
  ENTIDADES, getCfg, normalizeRows, missingRequiredCols, classifyRows, gerarModelo, gerarRelatorio,
} from '@/lib/importacaoDados';
import ImportPreviewTable from '@/components/importacao/ImportPreviewTable';
import ImportResultPanel from '@/components/importacao/ImportResultPanel';

const ST = { novo: 'bg-emerald-100 text-emerald-700', existente: 'bg-amber-100 text-amber-700', erro: 'bg-red-100 text-red-700' };
const STLBL = { novo: 'Novo', existente: 'Existente', erro: 'Com erro' };

export default function ImportacaoDados() {
  const [entityKey, setEntityKey] = useState('obras');
  const [file, setFile] = useState(null);
  const [fileUrl, setFileUrl] = useState('');
  const [uploading, setUploading] = useState(false);
  const [lendo, setLendo] = useState(false);
  const [rows, setRows] = useState([]);
  const [classificacao, setClassificacao] = useState([]);
  const [acao, setAcao] = useState('novos');
  const [executando, setExecutando] = useState(false);
  const [fase, setFase] = useState('');
  const [progresso, setProgresso] = useState(0);
  const [resultado, setResultado] = useState(null);
  const [erro, setErro] = useState('');
  const [drag, setDrag] = useState(false);
  const [step, setStep] = useState(1);

  const cfg = getCfg(entityKey);

  const onFile = async (f) => {
    if (!f) return;
    setFile(f); setUploading(true); setErro('');
    try { const { file_url } = await base44.integrations.Core.UploadFile({ file: f }); setFileUrl(file_url); }
    catch { setErro('Falha ao enviar arquivo.'); }
    setUploading(false);
  };

  const loadContext = async (key) => {
    const ctx = {};
    const needs = new Set();
    const c = getCfg(key);
    c.campos.forEach((f) => { if (f.type === 'rel') needs.add(f.relEntity); });
    if (needs.has('Obras')) { try { ctx.Obras = await base44.entities.Obras.list('-updated_date', 500); } catch { ctx.Obras = []; } }
    if (needs.has('Fornecedores')) { try { ctx.Fornecedores = await base44.entities.Fornecedores.list('-updated_date', 500); } catch { ctx.Fornecedores = []; } }
    if (needs.has('Cartoes')) { try { ctx.Cartoes = await base44.entities.Cartoes.list('-updated_date', 500); } catch { ctx.Cartoes = []; } }
    return ctx;
  };

  const ler = async () => {
    setLendo(true); setErro(''); setFase('Lendo arquivo...'); setProgresso(15);
    try {
      const schema = { type: 'object', properties: Object.fromEntries(cfg.campos.map((c) => [c.col, { type: 'string' }])) };
      const res = await base44.integrations.Core.ExtractDataFromUploadedFile({ file_url: fileUrl, json_schema: schema });
      const raw = Array.isArray(res.output) ? res.output : (res.output && res.output.rows) || [];
      if (!raw.length) { setErro('Nenhuma linha encontrada no arquivo.'); setLendo(false); return; }
      const faltando = missingRequiredCols(cfg, raw);
      if (faltando.length) { setErro(`Colunas obrigatórias ausentes: ${faltando.join(', ')}. Use o modelo para o layout correto.`); setLendo(false); return; }
      const norm = normalizeRows(cfg, raw);
      setRows(norm); setProgresso(40);
      const ctx = await loadContext(entityKey);
      setFase('Validando e conferindo duplicidades...'); setProgresso(60);
      let existing = [];
      try { existing = await base44.entities[cfg.entity].list('-updated_date', 500); } catch { existing = []; }
      const clas = classifyRows(cfg, norm, ctx, existing);
      setClassificacao(clas); setProgresso(100); setStep(2);
    } catch (e) { setErro('Não foi possível ler o arquivo.'); }
    setLendo(false);
  };

  const importar = async () => {
    setStep(3); setErro(''); setProgresso(0);
    const novos = classificacao.filter((r) => r.tipo === 'novo');
    const existentes = classificacao.filter((r) => r.tipo === 'existente' && r.existente);
    const comErro = classificacao.filter((r) => r.tipo === 'erro');
    let importados = 0, atualizados = 0, ignorados = 0;

    setFase('Criando registros novos...'); setProgresso(30);
    if (novos.length) {
      const payload = novos.map((r) => r.record);
      try { await base44.entities[cfg.entity].bulkCreate(payload); importados = payload.length; } catch { importados = 0; }
    }
    if (acao === 'atualizar' && existentes.length) {
      setFase('Atualizando existentes...'); setProgresso(70);
      for (const r of existentes) {
        try { await base44.entities[cfg.entity].update(r.existente.id, r.record); atualizados++; } catch {}
      }
    } else if (acao !== 'atualizar') {
      ignorados = existentes.length;
    }
    setFase('Finalizando...'); setProgresso(100);
    setResultado({
      analisados: classificacao.length,
      importados, atualizados,
      ignorados,
      comErro: comErro.length,
      detalhes: classificacao.map((r) => ({ idx: r.idx, errors: r.errors, record: r.record, tipo: r.tipo })),
    });
    setStep(4);
  };

  const reset = () => {
    setFile(null); setFileUrl(''); setRows([]); setClassificacao([]); setResultado(null); setProgresso(0); setStep(1); setErro('');
  };

  const counts = {
    total: classificacao.length,
    validos: classificacao.filter((r) => r.tipo !== 'erro' && !(r.warnings?.length)).length,
    aviso: classificacao.filter((r) => r.tipo !== 'erro' && (r.warnings?.length)).length,
    novos: classificacao.filter((r) => r.tipo === 'novo').length,
    existentes: classificacao.filter((r) => r.tipo === 'existente').length,
    erros: classificacao.filter((r) => r.tipo === 'erro').length,
  };

  return (
    <div>
      <PageHeader title="Importação de Dados" subtitle="Importação em massa via CSV — Obras, Fornecedores, Cartões, Receitas e Despesas." />

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-700 mb-4">
        <p className="font-medium mb-1">Ordem recomendada: 1) Obras · 2) Fornecedores · 3) Cartões · 4) Receitas · 5) Despesas</p>
        <p>Receitas e despesas relacionam obra, fornecedor (credor) e cartão por ID — importe-os antes.</p>
      </div>

      {erro && <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2 mb-4"><AlertTriangle className="w-4 h-4" />{erro}</div>}

      {/* Etapa 1 — Seleção */}
      {step === 1 && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-4">
            <Label className="text-sm text-slate-600 mb-2 block">Tipo de dado a importar</Label>
            <Select value={entityKey} onValueChange={(v) => { setEntityKey(v); reset(); }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {ENTIDADES.map((e) => <SelectItem key={e.key} value={e.key}>{e.ordem}. {e.label} — {e.descricao}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="flex justify-end mt-3">
              <Button variant="outline" size="sm" onClick={() => gerarModelo(cfg)}><Download className="w-4 h-4 mr-1" />Baixar modelo {cfg.arquivo}</Button>
            </div>
          </div>

          <div
            onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => { e.preventDefault(); setDrag(false); onFile(e.dataTransfer.files?.[0]); }}
            className={`border-2 border-dashed rounded-xl p-8 text-center transition ${drag ? 'border-amber-400 bg-amber-50' : 'border-slate-300 bg-slate-50'}`}
          >
            <UploadCloud className="w-10 h-10 text-slate-400 mx-auto mb-2" />
            <p className="text-sm text-slate-600 mb-2">Arraste o {cfg.arquivo} aqui ou selecione</p>
            <Label className="inline-block">
              <span className="inline-flex items-center gap-1 text-sm font-medium px-4 py-2 rounded-lg bg-[#0b2545] text-white cursor-pointer hover:bg-[#16365f]">
                <FileSpreadsheet className="w-4 h-4" /> Selecionar CSV
              </span>
              <input type="file" accept=".csv" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
            </Label>
            {uploading && <p className="text-xs text-slate-400 mt-2">Enviando...</p>}
            {file && !uploading && <p className="text-xs text-emerald-600 mt-2">{file.name}</p>}
          </div>

          <div className="flex justify-end">
            <Button onClick={ler} disabled={!fileUrl || lendo} className="bg-[#0b2545] hover:bg-[#16365f]">
              {lendo ? 'Lendo...' : 'Ler e validar'} <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
          {lendo && (
            <div className="max-w-md h-2 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-amber-400 transition-all" style={{ width: `${progresso}%` }} />
            </div>
          )}
        </div>
      )}

      {/* Etapa 2 — Prévia */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-center"><p className="text-2xl font-bold text-slate-700">{counts.total}</p><p className="text-xs text-slate-500">Total</p></div>
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-center"><p className="text-2xl font-bold text-emerald-700">{counts.validos}</p><p className="text-xs text-emerald-700">Válidas</p></div>
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-center"><p className="text-2xl font-bold text-amber-700">{counts.aviso}</p><p className="text-xs text-amber-700">Com credor não vinculado</p></div>
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-center"><p className="text-2xl font-bold text-red-700">{counts.erros}</p><p className="text-xs text-red-700">Com erro</p></div>
          </div>

          <ImportPreviewTable cfg={cfg} rows={classificacao} />

          {counts.existentes > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
              <p className="text-sm font-medium text-amber-800 mb-2">{counts.existentes} registro(s) já existem. O que deseja fazer?</p>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant={acao === 'novos' ? 'default' : 'outline'} className={acao === 'novos' ? 'bg-[#0b2545]' : ''} onClick={() => setAcao('novos')}>Importar somente novos</Button>
                <Button size="sm" variant={acao === 'atualizar' ? 'default' : 'outline'} className={acao === 'atualizar' ? 'bg-[#0b2545]' : ''} onClick={() => setAcao('atualizar')}>Atualizar existentes</Button>
                <Button size="sm" variant={acao === 'cancelar' ? 'destructive' : 'outline'} onClick={() => setAcao('cancelar')}>Cancelar</Button>
              </div>
            </div>
          )}

          <div className="flex justify-between">
            <Button variant="ghost" onClick={reset}><ArrowLeft className="w-4 h-4 mr-1" />Voltar</Button>
            <Button onClick={importar} disabled={acao === 'cancelar' || (counts.novos === 0 && !(acao === 'atualizar' && counts.existentes > 0))} className="bg-[#0b2545] hover:bg-[#16365f]">
              {acao === 'cancelar' ? 'Importação cancelada' : <>Importar {acao === 'atualizar' ? counts.novos + counts.existentes : counts.novos} registro(s) <ArrowRight className="w-4 h-4 ml-1" /></>}
            </Button>
          </div>
        </div>
      )}

      {/* Etapa 3 — Executando */}
      {step === 3 && (
        <div className="bg-white border border-slate-200 rounded-xl p-8 text-center">
          <RefreshCw className="w-8 h-8 text-[#0b2545] mx-auto mb-3 animate-spin" />
          <p className="text-sm text-slate-600 mb-3">{fase}</p>
          <div className="max-w-md mx-auto h-2 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-amber-400 transition-all" style={{ width: `${progresso}%` }} />
          </div>
          <p className="text-xs text-slate-400 mt-2">{progresso}%</p>
        </div>
      )}

      {/* Etapa 4 — Resultado */}
      {step === 4 && resultado && (
        <ImportResultPanel
          resultado={resultado}
          onAgain={reset}
          onDownload={() => gerarRelatorio(cfg, classificacao, acao)}
          onDownloadErrors={() => gerarRelatorio(cfg, classificacao.filter((r) => r.tipo === 'erro'), acao)}
        />
      )}
    </div>
  );
}