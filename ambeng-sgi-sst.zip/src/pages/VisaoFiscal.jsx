import React, { useEffect, useMemo, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { usePerm } from '@/hooks/usePerm';
import { LayoutDashboard, Receipt, Wallet, Calculator, Building2, BarChart3 } from 'lucide-react';
import TabVisaoGeral from '@/components/fiscal/TabVisaoGeral';
import TabNotas from '@/components/fiscal/TabNotas';
import TabRecebimentos from '@/components/fiscal/TabRecebimentos';
import TabApuracao from '@/components/fiscal/TabApuracao';
import TabCadastros from '@/components/fiscal/TabCadastros';
import TabRelatorios from '@/components/fiscal/TabRelatorios';

// VISÃO FISCAL — página única consolidando todo o módulo Fiscal em abas internas.
// Menu lateral: um único item "Fiscal" aponta para /financeiro/fiscal.
// Permissões por aba: Apuração/Relatórios só Admin; Lançar/Recebimentos/Cadastros Admin+Administrativo.
export default function VisaoFiscal() {
  const { podeVer: podeVerLancar } = usePerm('fis_lancar');
  const { podeVer: podeVerReceb } = usePerm('fis_recebimentos');
  const { podeVer: podeVerApuracao } = usePerm('fis_apuracao');
  const { podeVer: podeVerCadastros } = usePerm('fis_cadastros');
  const { podeVer: podeVerRelatorios } = usePerm('fis_relatorios');

  const [tab, setTab] = useState(() => new URLSearchParams(window.location.search).get('tab') || 'visao');
  const [notas, setNotas] = useState([]);
  const [parcelas, setParcelas] = useState([]);
  const [competencia, setCompetencia] = useState(new Date().toISOString().slice(0, 7));
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const [nf, pa] = await Promise.all([
      base44.entities.NotasFiscais.list('-data_emissao', 1000).catch(() => []),
      base44.entities.ParcelasNF.list('-data_prevista', 2000).catch(() => []),
    ]);
    setNotas(nf); setParcelas(pa); setLoading(false);
  };
  useEffect(() => { load(); }, []);

  // Notas/parcelas da competência selecionada (visão geral); as abas Notas/Recebimentos usam tudo.
  const notasComp = useMemo(() => notas.filter((n) => !competencia || (n.competencia || '') === competencia), [notas, competencia]);
  const parcelasComp = useMemo(() => {
    const ids = new Set(notasComp.map((n) => n.id));
    return parcelas.filter((p) => ids.has(p.nota_fiscal_id));
  }, [parcelas, notasComp]);

  const comps = useMemo(() => [...new Set(notas.map((n) => n.competencia).filter(Boolean))].sort().reverse(), [notas]);

  const tabs = [
    { id: 'visao', label: 'Visão Geral', icon: LayoutDashboard, visivel: podeVerApuracao },
    { id: 'notas', label: 'Notas', icon: Receipt, visivel: podeVerLancar },
    { id: 'recebimentos', label: 'Recebimentos', icon: Wallet, visivel: podeVerReceb },
    { id: 'apuracao', label: 'Apuração', icon: Calculator, visivel: podeVerApuracao },
    { id: 'cadastros', label: 'Cadastros', icon: Building2, visivel: podeVerCadastros },
    { id: 'relatorios', label: 'Relatórios', icon: BarChart3, visivel: podeVerRelatorios },
  ].filter((t) => t.visivel);

  useEffect(() => {
    if (!tabs.find((t) => t.id === tab)) setTab(tabs[0]?.id || 'visao');
  }, [tabs.map((t) => t.id).join(',')]);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-xl font-bold text-[#0b2545]">Fiscal</h1>
          <p className="text-sm text-slate-500">Notas fiscais, recebimentos, apuração e cadastros.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-slate-500">Competência</span>
          <Select value={competencia} onValueChange={setCompetencia}>
            <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              {comps.length === 0 && <SelectItem value={competencia}>{competencia}</SelectItem>}
              {comps.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="w-full justify-start overflow-x-auto h-auto">
          {tabs.map((t) => {
            const Icon = t.icon;
            return <TabsTrigger key={t.id} value={t.id} className="min-h-[44px] gap-2"><Icon className="w-4 h-4" />{t.label}</TabsTrigger>;
          })}
        </TabsList>

        <TabsContent value="visao" className="mt-5">
          {loading ? <Loading /> : <TabVisaoGeral notas={notasComp} parcelas={parcelasComp} podeApurar={podeVerApuracao} onTab={setTab} />}
        </TabsContent>
        <TabsContent value="notas" className="mt-5">
          {loading ? <Loading /> : <TabNotas notas={notas} parcelas={parcelas} onReload={load} />}
        </TabsContent>
        <TabsContent value="recebimentos" className="mt-5">
          {loading ? <Loading /> : <TabRecebimentos parcelas={parcelas} notas={notas} onReload={load} />}
        </TabsContent>
        <TabsContent value="apuracao" className="mt-5"><TabApuracao /></TabsContent>
        <TabsContent value="cadastros" className="mt-5"><TabCadastros /></TabsContent>
        <TabsContent value="relatorios" className="mt-5"><TabRelatorios /></TabsContent>
      </Tabs>
    </div>
  );
}

function Loading() { return <div className="py-20 text-center text-slate-400">Carregando…</div>; }