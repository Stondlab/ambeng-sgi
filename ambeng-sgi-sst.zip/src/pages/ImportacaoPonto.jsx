import React, { useEffect, useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Upload, FileSpreadsheet, CheckCircle2, XCircle, ArrowLeft, Copy } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import { Link } from 'react-router-dom';
import { nomeUsuario } from '@/lib/usuarioNome';
import { calcularHorasPonto } from '@/lib/ponto';

const SCHEMA = {
  type: 'object',
  properties: {
    colaborador: { type: 'string', description: 'Nome ou matrícula do colaborador' },
    data: { type: 'string', description: 'Data no formato DD/MM/AAAA ou AAAA-MM-DD' },
    entrada: { type: 'string' },
    saida: { type: 'string' },
    intervalo: { type: 'string' },
    total_horas: { type: 'string' },
    horas_extras: { type: 'string', description: 'Horas extras do dia (opcional)' },
    status: { type: 'string', description: 'Presente, Falta, Atrasado, Atestado, Folga' },
    observacao: { type: 'string' },
    identificador_original: { type: 'string', description: 'Identificador do registro no sistema oficial (opcional)' },
  },
};

const STATUS_OK = ['Presente', 'Falta', 'Atrasado', 'Atestado', 'Folga'];

function parseData(v) {
  if (!v) return null;
  const s = String(v).trim();
  const br = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (br) return `${br[3]}-${br[2]}-${br[1]}`;
  const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (iso) return s;
  return null;
}
function parseHoras(v) { if (v == null || v === '') return 0; const s = String(v).trim(); const m = s.match(/^(\d{1,2}):(\d{2})$/); if (m) return Number(m[1]) + Number(m[2]) / 60; const n = Number(s.replace(',', '.')); return isNaN(n) ? 0 : n; }

// Importação do Ponto Externo (spec §5). Valida antes de importar:
// registros válidos, duplicados, funcionários/matrículas não encontrados, datas/horas inválidas.
// Não duplica registros já importados. Registra a origem (importacao_id + matrícula).
export default function ImportacaoPonto({ embedded = false, onImported }) {
  const { toast } = useToast();
  const [funcionarios, setFuncionarios] = useState([]);
  const [pontoExistente, setPontoExistente] = useState([]);
  const [file, setFile] = useState(null);
  const [parsed, setParsed] = useState(null);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState(null);
  const [user, setUser] = useState(null);

  useEffect(() => {
    (async () => {
      try { setFuncionarios(await base44.entities.Funcionarios.list('nome', 1000)); } catch {}
      try { setPontoExistente(await base44.entities.Ponto.list('-data', 3000)); } catch {}
      try { setUser(await base44.auth.me()); } catch {}
    })();
  }, []);

  const findFunc = (query) => {
    if (!query) return null;
    const q = String(query).trim().toLowerCase();
    return funcionarios.find((f) =>
      (f.matricula && f.matricula.toLowerCase() === q) ||
      (f.nome && f.nome.toLowerCase() === q) ||
      (f.nome && f.nome.toLowerCase().includes(q))
    ) || null;
  };

  const preview = useMemo(() => {
    if (!parsed || !Array.isArray(parsed)) return null;
    const existKeys = new Set(pontoExistente.map((p) => `${p.funcionario_id}|${p.data}`));
    return parsed.map((row) => {
      const func = findFunc(row.colaborador || row.nome);
      const data = parseData(row.data);
      const statusOk = !row.status || STATUS_OK.includes(row.status);
      const valido = !!(func && data && statusOk);
      const duplicado = !!(func && data && existKeys.has(`${func.id}|${data}`));
      const erro = !func ? (row.colaborador || row.nome ? 'Colaborador/matricula nao encontrado' : 'Colaborador vazio')
        : !data ? 'Data invalida' : !statusOk ? 'Status invalido' : duplicado ? 'Duplicado (ja importado)' : null;
      return { ...row, registro_original_linha: row, funcionario_id: func?.id, funcionario_nome: func?.nome, matricula: func?.matricula || '', data_iso: data, horas_extras_num: parseHoras(row.horas_extras), statusOk, valido: valido && !duplicado, duplicado, erro };
    });
  }, [parsed, funcionarios, pontoExistente]);

  const validos = useMemo(() => preview?.filter((r) => r.valido) || [], [preview]);
  const duplicados = useMemo(() => preview?.filter((r) => r.duplicado) || [], [preview]);
  const invalidos = useMemo(() => preview?.filter((r) => !r.valido && !r.duplicado) || [], [preview]);

  const onFile = async (f) => {
    setFile(f); setParsed(null); setResult(null);
    if (!f) return;
    setLoading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: f });
      const res = await base44.integrations.Core.ExtractDataFromUploadedFile({ file_url, json_schema: SCHEMA });
      if (res.status === 'success' && res.output) {
        setParsed(Array.isArray(res.output) ? res.output : [res.output]);
      } else {
        toast({ title: 'Falha ao ler arquivo', description: res.details || 'Verifique o formato.', variant: 'destructive' });
      }
    } catch (e) {
      toast({ title: 'Erro no upload', description: String(e.message || e), variant: 'destructive' });
    } finally { setLoading(false); }
  };

  const importar = async () => {
    if (!validos.length) return;
    setImporting(true);
    try {
      // Registra a importação (rastreabilidade)
      const imp = await base44.entities.Importacoes.create({
        usuario: nomeUsuario(user), data_hora: new Date().toISOString(), arquivo: file?.name || '', tipo: file?.name?.endsWith('.csv') ? 'CSV' : 'Excel',
        total_importados: validos.length, total_rejeitados: invalidos.length, total_duplicados: duplicados.length,
        detalhes: JSON.stringify({ modulo: 'Ponto', fonte: 'Sistema de Ponto Externo', validos: validos.length, duplicados: duplicados.length, invalidos: invalidos.length }),
      });
      const dataImportacao = new Date().toISOString();
      const records = validos.map((r) => ({
        funcionario_id: r.funcionario_id, matricula: r.matricula, data: r.data_iso,
        entrada: r.entrada || '', saida: r.saida || '', intervalo: r.intervalo || '',
        total_horas: r.total_horas || calcularHorasPonto(r.entrada, r.saida, r.intervalo) || '', horas_extras: r.horas_extras_num || 0,
        status: r.status || 'Presente', observacao: r.observacao || '', importacao_id: imp.id,
        origem: 'Sistema de Ponto Externo', data_importacao: dataImportacao,
        identificador_original: r.identificador_original || `${r.matricula || r.funcionario_id}-${r.data_iso}`,
        registro_original: JSON.stringify(r.registro_original_linha || r),
      }));
      await base44.entities.Ponto.bulkCreate(records);
      const novaLista = [...pontoExistente, ...records];
      setPontoExistente(novaLista);
      const conferidos = records.filter((record) => !!calcularHorasPonto(record.entrada, record.saida, record.intervalo)).length;
      setResult({ ok: records.length, conferidos, duplicados: duplicados.length, falha: invalidos.length });
      toast({ title: 'Importação concluída', description: `${records.length} marcações importadas.`, variant: 'success' });
      setParsed(null); setFile(null);
      onImported?.();
    } catch (e) {
      toast({ title: 'Erro na importação', description: String(e.message || e), variant: 'destructive' });
    } finally { setImporting(false); }
  };

  const tipoErro = (r) => r.duplicado ? 'duplicado' : r.erro ? 'invalido' : null;

  return (
    <div>
      {!embedded && <Link to="/colaboradores/ponto" className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-[#0b2545] mb-3"><ArrowLeft className="w-4 h-4" />Voltar ao ponto</Link>}
      {!embedded && <PageHeader title="Importação de Ponto Externo" subtitle="Importe marcações do sistema externo. A Ambeng valida os dados e preserva o registro original." />}

      <div className="bg-white border border-slate-200 rounded-xl p-6 mb-4">
        <Label className="text-sm font-medium">Arquivo CSV ou Excel</Label>
        <div className="mt-2 flex items-center gap-3">
          <label className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-200 bg-white cursor-pointer hover:bg-slate-50 text-sm font-medium">
            <Upload className="w-4 h-4" />Selecionar arquivo
            <input type="file" accept=".csv,.xlsx,.xls" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
          </label>
          {file && <span className="text-sm text-slate-500 flex items-center gap-1"><FileSpreadsheet className="w-4 h-4" />{file.name}</span>}
        </div>
        {loading && <p className="text-xs text-slate-400 mt-2">Lendo arquivo e validando contra os registros já importados...</p>}
      </div>

      {result && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 mb-4 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <div>
            <p className="text-sm font-semibold text-emerald-800">✓ {result.ok} registros importados</p>
            <p className="text-xs text-emerald-700">✓ {result.conferidos} registros conferidos automaticamente</p>
            <p className="text-xs text-amber-700">⚠ {result.falha} registros precisam de revisão</p>
            {result.duplicados > 0 && <p className="text-xs text-slate-500">{result.duplicados} registros duplicados ignorados.</p>}
          </div>
        </div>
      )}

      {preview && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white border border-slate-200 rounded-lg p-3"><p className="text-2xl font-bold text-[#0b2545]">{preview.length}</p><p className="text-xs text-slate-500">Linhas lidas</p></div>
            <div className="bg-white border border-emerald-200 rounded-lg p-3"><p className="text-2xl font-bold text-emerald-600">{validos.length}</p><p className="text-xs text-slate-500">Válidas</p></div>
            <div className="bg-white border border-amber-200 rounded-lg p-3"><p className="text-2xl font-bold text-amber-600">{duplicados.length}</p><p className="text-xs text-slate-500">Duplicadas</p></div>
            <div className="bg-white border border-red-200 rounded-lg p-3"><p className="text-2xl font-bold text-red-600">{invalidos.length}</p><p className="text-xs text-slate-500">Com inconsistência</p></div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-semibold text-[#0b2545] text-sm">Pré-visualização e validação</h3>
              <Button size="sm" onClick={importar} disabled={importing || !validos.length} className="bg-[#0b2545] hover:bg-[#16365f]">
                {importing ? 'Importando...' : `Importar ${validos.length} válidas`}
              </Button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm min-w-[640px]">
                <thead className="bg-slate-50 text-slate-500 text-xs">
                  <tr>
                    <th className="text-left px-3 py-2 font-medium">Colaborador</th>
                    <th className="text-left px-3 py-2 font-medium">Vinculado a</th>
                    <th className="text-left px-3 py-2 font-medium">Data</th>
                    <th className="text-left px-3 py-2 font-medium">Total</th>
                    <th className="text-left px-3 py-2 font-medium">HE</th>
                    <th className="text-left px-3 py-2 font-medium">Status</th>
                    <th className="text-left px-3 py-2 font-medium">Validação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {preview.slice(0, 60).map((r, i) => {
                    const t = tipoErro(r);
                    return (
                      <tr key={i} className={t === 'duplicado' ? 'bg-amber-50/50' : t === 'invalido' ? 'bg-red-50/40' : ''}>
                        <td className="px-3 py-2 text-slate-600">{r.colaborador || r.nome || '—'}</td>
                        <td className="px-3 py-2 text-slate-600">{r.funcionario_nome || <span className="text-red-500">não encontrado</span>}</td>
                        <td className="px-3 py-2 text-slate-600">{r.data || '—'}</td>
                        <td className="px-3 py-2 text-slate-500">{r.total_horas || calcularHorasPonto(r.entrada, r.saida, r.intervalo) || '—'}</td>
                        <td className="px-3 py-2 text-slate-500">{r.horas_extras || '—'}</td>
                        <td className="px-3 py-2 text-slate-500">{r.status || '—'}</td>
                        <td className="px-3 py-2">
                          {r.valido ? <span className="inline-flex items-center gap-1 text-emerald-600 text-xs"><CheckCircle2 className="w-3.5 h-3.5" />OK</span>
                            : t === 'duplicado' ? <span className="inline-flex items-center gap-1 text-amber-600 text-xs"><Copy className="w-3.5 h-3.5" />Duplicado</span>
                            : <span className="inline-flex items-center gap-1 text-red-500 text-xs"><XCircle className="w-3.5 h-3.5" />{r.erro}</span>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {preview.length > 60 && <p className="px-4 py-2 text-xs text-slate-400 border-t border-slate-100">Mostrando as primeiras 60 linhas de {preview.length}.</p>}
          </div>
        </div>
      )}
    </div>
  );
}