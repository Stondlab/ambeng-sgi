import React from 'react';
import PageHeader from '@/components/PageHeader';
import { PERFIS, PERMISSOES } from '@/lib/permissoes';
import { ShieldCheck, ClipboardList, HardHat } from 'lucide-react';

const ICONS = {
  'Administrador': ShieldCheck,
  'Administrativo': ClipboardList,
  'Técnico': HardHat,
};
const COLORS = {
  'Administrador': 'text-[#0b2545] bg-[#0b2545]/10',
  'Administrativo': 'text-blue-600 bg-blue-100',
  'Técnico': 'text-amber-600 bg-amber-100',
};

export default function AdminPerfis() {
  return (
    <div>
      <PageHeader title="Configurações · Perfis de Acesso" subtitle="Os perfis de acesso do SGI SST." />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {PERFIS.map((nome) => {
          const Icon = ICONS[nome];
          const p = PERMISSOES[nome];
          return (
            <div key={nome} className="bg-white border border-slate-200 rounded-xl p-4">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${COLORS[nome]}`}><Icon className="w-5 h-5" /></div>
              <h3 className="font-semibold text-[#0b2545] text-sm">{nome}</h3>
              <p className="text-xs text-slate-500 mt-1">{p.descricao}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}