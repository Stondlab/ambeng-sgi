import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import PageHeader from '@/components/PageHeader';
import { PERFIS, normalizarPerfil } from '@/lib/permissoes';
import { registrarAcao } from '@/lib/historico';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { UserPlus, Pencil, Activity, History, ShieldCheck, Pause, Play, Copy, Check, Archive, RotateCcw, AlertCircle } from 'lucide-react';

const fmt = (d) => d ? new Date(d).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—';
const perfilOf = (u) => normalizarPerfil(u.perfil) || (u.role === 'admin' ? 'Administrador' : 'Não configurado');
const nomeDe = (u) => u.nome_exibicao || u.full_name || '—';

const gerarSenhaTemp = () => {
  const mai = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const min = 'abcdefghijkmnpqrstuvwxyz';
  const num = '23456789';
  const esp = '!@#$%';
  const pick = (s) => s[Math.floor(Math.random() * s.length)];
  let s = pick(mai) + pick(min) + pick(num) + pick(esp);
  const all = mai + min + num + esp;
  for (let i = 0; i < 6; i++) s += pick(all);
  return s.split('').sort(() => Math.random() - 0.5).join('');
};

const FILTROS_STATUS = [
  { key: 'ativos', label: 'Ativos' },
  { key: 'inativos', label: 'Inativos' },
  { key: 'arquivados', label: 'Arquivados' },
  { key: 'todos', label: 'Todos' },
];

export default function AdminUsuarios() {
  const { user: me } = useAuth();
  const [users, setUsers] = useState([]);
  const [historico, setHistorico] = useState([]);
  const [editing, setEditing] = useState(null);
  const [inviting, setInviting] = useState(false);
  const [form, setForm] = useState({});
  const [invite, setInvite] = useState({ email: '', perfil: 'Administrativo' });
  const [busca, setBusca] = useState('');
  const [filtroPerfil, setFiltroPerfil] = useState('todos');
  const [filtroStatus, setFiltroStatus] = useState('ativos');
  const [senhaGerada, setSenhaGerada] = useState('');
  const [copied, setCopied] = useState(false);
  const [inviteError, setInviteError] = useState('');
  const [inviteLoading, setInviteLoading] = useState(false);

  const registrarAuditoria = async (acao, tipo, alvo) => {
    try {
      const user = await base44.auth.me();
      const agora = new Date();
      await base44.entities.Auditoria.create({
        usuario: (user.nome_exibicao || user.full_name || '—').toUpperCase(),
        acao, tipo, alvo,
        data: agora.toISOString().slice(0, 10),
        hora: agora.toTimeString().slice(0, 5),
      });
    } catch {}
  };

  const load = async () => {
    try { setUsers(await base44.entities.User.list()); } catch { setUsers([]); }
    try { setHistorico(await base44.entities.HistoricoAcoes.list('-data_hora', 20)); } catch { setHistorico([]); }
  };
  useEffect(() => { load(); }, []);

  const openEdit = (u) => {
    setEditing(u);
    setForm({
      nome_exibicao: u.nome_exibicao || '',
      perfil: perfilOf(u),
      telefone: u.telefone || '',
      cargo: u.cargo || '',
      empresa: u.empresa || '',
      obra: u.obra || '',
      status: u.status || 'Ativo',
      observacoes: u.observacoes || '',
    });
  };

  const saveEdit = async () => {
    await base44.functions.invoke('atualizarUsuario', { userId: editing.id, ...form });
    registrarAcao('Editou usuário', editing.email || editing.full_name, me);
    registrarAuditoria('Editou', 'Usuário', editing.email || editing.full_name);
    setEditing(null);
    load();
  };

  const toggleStatus = async (u) => {
    const status = (u.status || 'Ativo') === 'Ativo' ? 'Inativo' : 'Ativo';
    await base44.entities.User.update(u.id, { status });
    registrarAcao(status === 'Ativo' ? 'Ativou usuário' : 'Desativou usuário', u.email || u.full_name, me);
    registrarAuditoria(status === 'Ativo' ? 'Reativou' : 'Desativou', 'Usuário', u.email || u.full_name);
    if (status === 'Inativo') {
      const agora = new Date();
      const dataHora = agora.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
      const adminNome = (me?.nome_exibicao || me?.full_name || 'Administrador').toUpperCase();
      try {
        await base44.integrations.Core.SendEmail({
          to: u.email,
          subject: 'Conta desativada — SGI SST',
          body: `Sua conta foi desativada em ${dataHora} por ${adminNome}.\n\nSe tem dúvidas, contate o administrador.\n\nEquipe SGI SST`,
        });
      } catch {}
    }
    load();
  };

  const excluirUsuario = async (u) => {
    if (u.id === me?.id) return;
    if (!window.confirm('Tem certeza? Esta ação é irreversível.')) return;
    await base44.entities.User.update(u.id, { status: 'Arquivado' });
    registrarAcao('Arquivou usuário', u.email || u.full_name, me);
    registrarAuditoria('Arquivou', 'Usuário', u.email || u.full_name);
    load();
  };

  const restaurarUsuario = async (u) => {
    await base44.entities.User.update(u.id, { status: 'Ativo' });
    registrarAcao('Restaurou usuário', u.email || u.full_name, me);
    registrarAuditoria('Restaurou', 'Usuário', u.email || u.full_name);
    load();
  };

  const sendInvite = async () => {
    setInviteError('');
    if (!invite.email) return;
    const existe = users.some((u) => (u.email || '').toLowerCase() === invite.email.toLowerCase());
    if (existe) {
      setInviteError('Email já cadastrado');
      return;
    }
    setInviteLoading(true);
    const senha = gerarSenhaTemp();
    const role = invite.perfil === 'Administrador' ? 'admin' : 'user';
    try {
      await base44.users.inviteUser(invite.email, role);
      try {
        await base44.integrations.Core.SendEmail({
          to: invite.email,
          subject: 'Bem-vindo ao SGI SST — Senha temporária',
          body: `Você foi cadastrado no SGI SST.\n\nSua senha temporária é: ${senha}\n\nAcesse o sistema e troque sua senha no primeiro login.\n\nEquipe SGI SST`,
        });
      } catch {}
      setSenhaGerada(senha);
      registrarAcao('Convidou usuário', invite.email, me);
      registrarAuditoria('Convidou', 'Usuário', invite.email);
    } catch (e) {
      setInviteError(e.message || 'Erro ao convidar usuário');
    } finally {
      setInviteLoading(false);
    }
  };

  const copiarSenha = () => {
    navigator.clipboard.writeText(senhaGerada);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const fecharInvite = () => {
    setInviting(false);
    setSenhaGerada('');
    setInviteError('');
    setInvite({ email: '', perfil: 'Administrativo' });
  };

  const ativos = users.filter((u) => (u.status || 'Ativo') === 'Ativo').length;
  const inativos = users.filter((u) => u.status === 'Inativo').length;
  const arquivados = users.filter((u) => u.status === 'Arquivado').length;
  const porPerfil = PERFIS.map((p) => ({ p, n: users.filter((u) => perfilOf(u) === p).length }));
  const empresas = [...new Set(users.map((u) => u.empresa).filter(Boolean))];
  const porEmpresa = empresas.map((e) => ({ e, n: users.filter((u) => u.empresa === e).length }));

  const usersFiltrados = users.filter((u) => {
    const matchBusca = !busca || nomeDe(u).toLowerCase().includes(busca.toLowerCase()) || (u.email || '').toLowerCase().includes(busca.toLowerCase());
    const matchPerfil = filtroPerfil === 'todos' || perfilOf(u) === filtroPerfil;
    const matchStatus = filtroStatus === 'todos' ? true :
      filtroStatus === 'ativos' ? (u.status || 'Ativo') === 'Ativo' :
      filtroStatus === 'inativos' ? u.status === 'Inativo' :
      filtroStatus === 'arquivados' ? u.status === 'Arquivado' : true;
    return matchBusca && matchPerfil && matchStatus;
  });

  return (
    <div>
      <PageHeader title="Configurações · Usuários" subtitle="Gestão de usuários, perfis, status e acessos." action={
        <Button onClick={() => { setInviting(true); setSenhaGerada(''); }} className="min-h-[44px] bg-[#0b2545] hover:bg-[#16365f]">
          <UserPlus className="w-4 h-4" />Convidar usuário
        </Button>
      } />

      {/* Indicadores */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <IndCard icon={ShieldCheck} label="Usuários ativos" value={ativos} tone="green" />
        <IndCard icon={Pause} label="Usuários inativos" value={inativos} tone="gray" />
        <IndCard icon={Archive} label="Arquivados" value={arquivados} tone="red" />
        <IndCard icon={Activity} label="Empresas" value={empresas.length} tone="amber" />
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mb-6">
        <section className="bg-white border border-slate-200 rounded-xl p-4">
          <h3 className="text-sm font-semibold text-[#0b2545] mb-3">Quantidade por perfil</h3>
          <div className="space-y-2">
            {porPerfil.map((x) => (
              <div key={x.p} className="flex items-center justify-between text-sm">
                <span className="text-slate-600">{x.p}</span>
                <span className="font-semibold text-[#0b2545]">{x.n}</span>
              </div>
            ))}
          </div>
        </section>
        <section className="bg-white border border-slate-200 rounded-xl p-4">
          <h3 className="text-sm font-semibold text-[#0b2545] mb-3">Quantidade por empresa</h3>
          {porEmpresa.length === 0 ? <p className="text-sm text-slate-400">Sem empresas cadastradas.</p> : (
            <div className="space-y-2">
              {porEmpresa.map((x) => (
                <div key={x.e} className="flex items-center justify-between text-sm">
                  <span className="text-slate-600 truncate">{x.e}</span>
                  <span className="font-semibold text-[#0b2545]">{x.n}</span>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Filtros */}
      <div className="flex flex-col sm:flex-row gap-2 mb-4">
        <Input placeholder="Buscar por nome ou e-mail..." value={busca} onChange={(e) => setBusca(e.target.value)} className="sm:max-w-xs" />
        <Select value={filtroPerfil} onValueChange={setFiltroPerfil}>
          <SelectTrigger className="sm:w-52"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os perfis</SelectItem>
            {PERFIS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="flex gap-1.5 flex-wrap">
          {FILTROS_STATUS.map((f) => (
            <button key={f.key} onClick={() => setFiltroStatus(f.key)} className={`text-xs px-3 py-1.5 rounded-full border transition ${filtroStatus === f.key ? 'bg-[#0b2545] text-white border-[#0b2545]' : 'bg-white text-slate-600 border-slate-200 hover:border-amber-400'}`}>{f.label}</button>
          ))}
        </div>
      </div>

      {/* Tabela de usuários */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden mb-6">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
              <tr>
                <th className="text-left px-4 py-3">Usuário</th>
                <th className="text-left px-4 py-3">Telefone</th>
                <th className="text-left px-4 py-3">Cargo</th>
                <th className="text-left px-4 py-3">Perfil</th>
                <th className="text-left px-4 py-3">Empresa</th>
                <th className="text-left px-4 py-3">Obra</th>
                <th className="text-left px-4 py-3">Status</th>
                <th className="text-left px-4 py-3">Último acesso</th>
                <th className="text-left px-4 py-3">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {usersFiltrados.map((u) => {
                const isArquivado = u.status === 'Arquivado';
                const statusColor = (u.status || 'Ativo') === 'Ativo' ? 'bg-emerald-500' : u.status === 'Inativo' ? 'bg-amber-500' : 'bg-slate-400';
                return (
                  <tr key={u.id} className={`hover:bg-slate-50 ${isArquivado ? 'opacity-60' : ''}`}>
                    <td className="px-4 py-3">
                      <p className="font-medium text-[#0b2545]">{nomeDe(u)}</p>
                      <p className="text-xs text-slate-400">{u.email}</p>
                    </td>
                    <td className="px-4 py-3 text-slate-600">{u.telefone || '—'}</td>
                    <td className="px-4 py-3 text-slate-600">{u.cargo || '—'}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${perfilOf(u) === 'Administrador' ? 'bg-[#0b2545] text-white' : 'bg-slate-100 text-slate-600'}`}>{perfilOf(u)}</span>
                    </td>
                    <td className="px-4 py-3 text-slate-600">{u.empresa || '—'}</td>
                    <td className="px-4 py-3 text-slate-600">{u.obra || '—'}</td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1 text-xs">
                        <span className={`w-2.5 h-2.5 rounded-full ${statusColor}`} />
                        {u.status || 'Ativo'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-500 whitespace-nowrap">{fmt(u.ultimo_acesso)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        {!isArquivado && (
                          <button onClick={() => openEdit(u)} className="p-2 min-w-[36px] min-h-[36px] rounded-md hover:bg-slate-100 text-[#0b2545]" title="Editar"><Pencil className="w-4 h-4" /></button>
                        )}
                        {!isArquivado && ((u.status || 'Ativo') === 'Ativo' ? (
                          <button onClick={() => toggleStatus(u)} className="p-2 min-w-[36px] min-h-[36px] rounded-md hover:bg-amber-50 text-slate-400 hover:text-amber-500" title="Desativar"><Pause className="w-4 h-4" /></button>
                        ) : (
                          <button onClick={() => toggleStatus(u)} className="p-2 min-w-[36px] min-h-[36px] rounded-md hover:bg-emerald-50 text-slate-400 hover:text-emerald-500" title="Reativar"><Play className="w-4 h-4" /></button>
                        ))}
                        {!isArquivado && (
                          <button onClick={() => excluirUsuario(u)} disabled={u.id === me?.id} className="p-2 min-w-[36px] min-h-[36px] rounded-md hover:bg-red-50 text-slate-300 hover:text-red-500 disabled:opacity-30 disabled:cursor-not-allowed" title="Excluir (arquivar)"><Archive className="w-4 h-4" /></button>
                        )}
                        {isArquivado && (
                          <button onClick={() => restaurarUsuario(u)} className="p-2 min-w-[36px] min-h-[36px] rounded-md hover:bg-emerald-50 text-slate-400 hover:text-emerald-500" title="Restaurar"><RotateCcw className="w-4 h-4" /></button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {users.length === 0 && (
                <tr><td colSpan={9} className="px-4 py-10 text-center text-slate-400">Nenhum usuário encontrado.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Histórico de ações */}
      <section className="bg-white border border-slate-200 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-3"><History className="w-5 h-5 text-[#0b2545]" /><h3 className="text-base font-semibold text-[#0b2545]">Histórico de Ações</h3></div>
        {historico.length === 0 ? <p className="text-sm text-slate-400">Nenhum registro.</p> : (
          <ul className="space-y-2 max-h-80 overflow-y-auto">
            {historico.map((h) => (
              <li key={h.id} className="border-l-2 border-amber-300 pl-3 py-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-[#0b2545]">{h.acao}</span>
                  <span className="text-[10px] text-slate-400">{fmt(h.data_hora)}</span>
                </div>
                <p className="text-xs text-slate-500">{h.usuario_nome || '—'} {h.detalhe ? `· ${h.detalhe}` : ''}</p>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Editar usuário */}
      <Dialog open={!!editing} onOpenChange={(v) => !v && setEditing(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar usuário — {editing ? (nomeDe(editing) !== '—' ? nomeDe(editing) : editing.email) : ''}</DialogTitle>
          </DialogHeader>
          {editing && (
            <div className="space-y-3">
              <div>
                <Label>Nome de exibição</Label>
                <Input value={form.nome_exibicao} onChange={(e) => setForm({ ...form, nome_exibicao: e.target.value })} placeholder="Nome que aparecerá no sistema" />
                <p className="text-xs text-slate-400 mt-1">O nome da conta ({editing?.full_name || '—'}) é controlado pela autenticação e não pode ser alterado. Use este campo para definir o nome exibido.</p>
              </div>
              <div>
                <Label>Perfil</Label>
                <Select value={form.perfil} onValueChange={(v) => setForm({ ...form, perfil: v })} disabled={editing.id === me?.id}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PERFIS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                </Select>
                {editing.id === me?.id && <p className="text-xs text-amber-600 mt-1">Você não pode alterar o próprio perfil.</p>}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Telefone</Label><Input value={form.telefone} onChange={(e) => setForm({ ...form, telefone: e.target.value })} /></div>
                <div><Label>Cargo</Label><Input value={form.cargo} onChange={(e) => setForm({ ...form, cargo: e.target.value })} /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Empresa</Label><Input value={form.empresa} onChange={(e) => setForm({ ...form, empresa: e.target.value })} /></div>
                <div><Label>Obra</Label><Input value={form.obra} onChange={(e) => setForm({ ...form, obra: e.target.value })} /></div>
              </div>
              <div>
                <Label>Status</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Ativo">Ativo</SelectItem>
                    <SelectItem value="Inativo">Inativo</SelectItem>
                    <SelectItem value="Arquivado">Arquivado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Observações</Label><Input value={form.observacoes} onChange={(e) => setForm({ ...form, observacoes: e.target.value })} /></div>
              <p className="text-xs text-slate-400">Redefinição de senha não é suportada no plano gratuito — o usuário pode usar a opção "Esqueci a senha" na tela de login.</p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancelar</Button>
            <Button onClick={saveEdit} className="bg-[#0b2545] hover:bg-[#16365f]">Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Convidar usuário */}
      <Dialog open={inviting} onOpenChange={(v) => !v && fecharInvite()}>
        <DialogContent>
          <DialogHeader><DialogTitle>Convidar usuário</DialogTitle></DialogHeader>
          {senhaGerada ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-emerald-600 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2 text-sm">
                <Check className="w-4 h-4" /> Convite enviado e email com senha temporária entregue.
              </div>
              <div>
                <Label>Senha temporária gerada</Label>
                <div className="flex items-center gap-2 mt-1">
                  <Input value={senhaGerada} readOnly className="font-mono text-lg" />
                  <Button onClick={copiarSenha} variant="outline" className="shrink-0">
                    {copied ? <><Check className="w-4 h-4" /> Copiado</> : <><Copy className="w-4 h-4" /> Copiar</>}
                  </Button>
                </div>
                <p className="text-xs text-amber-600 mt-2 flex items-center gap-1"><AlertCircle className="w-3.5 h-3.5" /> O usuário será obrigado a trocar a senha no primeiro login.</p>
              </div>
              <Button onClick={fecharInvite} className="w-full bg-[#0b2545] hover:bg-[#16365f]">Concluir</Button>
            </div>
          ) : (
            <div className="space-y-3">
              {inviteError && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" /> {inviteError}
                </div>
              )}
              <div><Label>E-mail</Label><Input type="email" value={invite.email} onChange={(e) => setInvite({ ...invite, email: e.target.value })} placeholder="nome@empresa.com" /></div>
              <div>
                <Label>Perfil inicial</Label>
                <Select value={invite.perfil} onValueChange={(v) => setInvite({ ...invite, perfil: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PERFIS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <p className="text-xs text-slate-400">O convite será enviado pelo Base44. Uma senha temporária será gerada e enviada por email.</p>
            </div>
          )}
          {!senhaGerada && (
            <DialogFooter>
              <Button variant="outline" onClick={fecharInvite}>Cancelar</Button>
              <Button onClick={sendInvite} disabled={inviteLoading} className="bg-[#0b2545] hover:bg-[#16365f]">{inviteLoading ? 'Enviando...' : 'Enviar convite'}</Button>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function IndCard({ icon: Icon, label, value, tone }) {
  const tones = {
    green: 'text-emerald-600 bg-emerald-50',
    gray: 'text-slate-500 bg-slate-100',
    red: 'text-red-600 bg-red-50',
    navy: 'text-[#0b2545] bg-[#0b2545]/10',
    amber: 'text-amber-600 bg-amber-100',
  };
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${tones[tone]}`}><Icon className="w-5 h-5" /></div>
      <div>
        <p className="text-2xl font-bold text-[#0b2545] leading-none">{value}</p>
        <p className="text-xs text-slate-500 mt-1">{label}</p>
      </div>
    </div>
  );
}