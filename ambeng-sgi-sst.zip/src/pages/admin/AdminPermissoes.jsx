import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { usePermissoes } from '@/lib/PermissoesContext';
import { MODULOS, PADRAO_PERMISSOES, ACOES } from '@/lib/modulosPermissao';
import { MATRIZ_PERMISSOES, GRUPOS_MATRIZ, permissoesDaLinha } from '@/lib/matrizPermissoes';
import { PERFIS, isAdministrador, normalizarPerfil } from '@/lib/permissoes';
import { registrarAcao } from '@/lib/historico';
import PageHeader from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { Eye, Plus, Pencil, Trash2, Save, RotateCcw, Lock } from 'lucide-react';

const ACAO_ICONE = { visualizar: Eye, criar: Plus, editar: Pencil, excluir: Trash2 };
const ACAO_LABEL = { visualizar: 'Visualizar', criar: 'Criar', editar: 'Editar', excluir: 'Excluir' };

function padraoClone() {
  return JSON.parse(JSON.stringify(PADRAO_PERMISSOES));
}

function configFromRecords(records) {
  const cfg = padraoClone();
  for (const r of records || []) {
    if (!cfg[r.perfil]?.[r.modulo]) continue;
    cfg[r.perfil][r.modulo] = {
      visualizar: !!r.visualizar,
      criar: !!r.criar,
      editar: !!r.editar,
      excluir: !!r.excluir,
      _id: r.id,
    };
  }
  return cfg;
}

function CelulaPermissoes({ perfil, moduloIds, valores, editable, onToggle }) {
  return (
    <div className="flex items-center gap-1.5 flex-wrap">
      {ACOES.map((a) => {
        const Icon = ACAO_ICONE[a];
        const on = !!valores?.[a];
        return (
          <button
            key={a}
            type="button"
            disabled={!editable}
            onClick={() => editable && onToggle(perfil, moduloIds, a)}
            title={ACAO_LABEL[a]}
            className={`flex items-center gap-1 h-7 px-2 rounded-md text-[11px] font-medium border transition-colors ${
              on ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-50 text-slate-400 border-slate-200'
            } ${editable ? 'hover:opacity-80 cursor-pointer' : 'cursor-not-allowed opacity-70'}`}
          >
            <Icon className="w-3.5 h-3.5" />
            <span>{ACAO_LABEL[a]}</span>
          </button>
        );
      })}
    </div>
  );
}

export default function AdminPermissoes() {
  const { user } = useAuth();
  const { perfilReal, simulando, simulacao, setSimulacaoPerfil, limparSimulacao, reload } = usePermissoes();
  const { toast } = useToast();
  const podeEditar = isAdministrador(perfilReal) && !simulando;

  const [config, setConfig] = useState(null);
  const [draft, setDraft] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [perfisCustom, setPerfisCustom] = useState([]);

  const carregar = useCallback(async () => {
    setLoading(true);
    try {
      const recs = await base44.entities.ConfigPermissoes.list();
      const cfg = configFromRecords(recs);
      setConfig(cfg);
      setDraft(JSON.parse(JSON.stringify(cfg)));
    } catch {
      const cfg = padraoClone();
      setConfig(cfg);
      setDraft(JSON.parse(JSON.stringify(cfg)));
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    carregar();
  }, [carregar]);

  useEffect(() => {
    (async () => {
      try {
        const us = await base44.entities.User.list('-created_date', 500);
        setPerfisCustom([...new Set(us.map((u) => u.perfil).filter(Boolean))]);
      } catch {}
    })();
  }, []);

  const toggle = (perfil, modulos, acao) => {
    if (!podeEditar) return;
    setDraft((d) => {
      const nd = { ...d, [perfil]: { ...d[perfil] } };
      const ativar = !modulos.every((modulo) => !!d[perfil][modulo]?.[acao]);
      modulos.forEach((modulo) => { nd[perfil][modulo] = { ...nd[perfil][modulo], [acao]: ativar }; });
      return nd;
    });
  };

  const dirty = !!config && !!draft && JSON.stringify(draft) !== JSON.stringify(config);

  const salvar = async () => {
    if (!dirty) return;
    if (!window.confirm('Você está alterando as permissões dos perfis. Deseja salvar?')) return;
    setSaving(true);
    try {
      const diffs = [];
      for (const perfil of PERFIS) {
        for (const m of MODULOS) {
          const ant = config[perfil][m.id];
          const novo = draft[perfil][m.id];
          for (const a of ACOES) {
            if (!!ant[a] !== !!novo[a]) {
              diffs.push({ perfil, modulo: m.id, moduloLabel: m.label, acao: a, ant: ant[a], novo: novo[a] });
            }
          }
        }
      }
      for (const perfil of PERFIS) {
        for (const m of MODULOS) {
          const v = draft[perfil][m.id];
          const ant = config[perfil][m.id];
          const changed = ACOES.some((a) => !!ant[a] !== !!v[a]);
          if (!changed) continue;
          const payload = {
            perfil,
            modulo: m.id,
            visualizar: !!v.visualizar,
            criar: !!v.criar,
            editar: !!v.editar,
            excluir: !!v.excluir,
          };
          if (ant._id) {
            await base44.entities.ConfigPermissoes.update(ant._id, payload);
          } else {
            const created = await base44.entities.ConfigPermissoes.create(payload);
            ant._id = created.id;
          }
        }
      }
      for (const d of diffs) {
        await registrarAcao(
          'Alteração de permissão',
          `Perfil: ${d.perfil} | Módulo: ${d.moduloLabel} | ${ACAO_LABEL[d.acao]}: ${d.ant ? 'Permitido' : 'Bloqueado'} → ${d.novo ? 'Permitido' : 'Bloqueado'}`,
          user,
          'Geral',
          `${d.perfil}/${d.modulo}`
        );
      }
      await reload();
      await carregar();
      toast({ title: 'Permissões atualizadas com sucesso.' });
    } catch (e) {
      toast({ title: 'Erro ao salvar permissões', description: e?.message, variant: 'destructive' });
    }
    setSaving(false);
  };

  const cancelar = () => {
    setDraft(JSON.parse(JSON.stringify(config)));
  };

  const PERFIS_BASE = ['Administrador', 'Administrativo', 'Técnico'];
  const opcoesPreview = PERFIS_BASE;

  const restaurarPadrao = async () => {
    if (!window.confirm('Restaurar as permissões padrão dos três perfis? Todas as alterações customizadas serão perdidas.')) return;
    setSaving(true);
    try {
      const padrao = padraoClone();
      for (const perfil of PERFIS) {
        for (const m of MODULOS) {
          const v = padrao[perfil][m.id];
          const existing = config[perfil][m.id];
          const payload = {
            perfil,
            modulo: m.id,
            visualizar: !!v.visualizar,
            criar: !!v.criar,
            editar: !!v.editar,
            excluir: !!v.excluir,
          };
          if (existing?._id) {
            await base44.entities.ConfigPermissoes.update(existing._id, payload);
          } else {
            const c = await base44.entities.ConfigPermissoes.create(payload);
            existing._id = c.id;
          }
        }
      }
      await registrarAcao('Restauração de permissões padrão', 'Permissões dos 3 perfis restauradas para a configuração padrão', user, 'Geral', 'sistema');
      await reload();
      await carregar();
      toast({ title: 'Permissões padrão restauradas.' });
    } catch (e) {
      toast({ title: 'Erro ao restaurar', description: e?.message, variant: 'destructive' });
    }
    setSaving(false);
  };

  return (
    <div>
      <PageHeader title="Configurações · Permissões" subtitle="Matriz de acesso por perfil e módulo." />

      {/* Pré-visualização de perfil */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 mb-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-semibold text-[#0b2545] flex items-center gap-2">
              <Eye className="w-4 h-4" /> Pré-visualização de perfil
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Visualize o sistema exatamente como o perfil selecionado enxerga. Modo somente leitura — nenhuma alteração é salva.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Select
              value={simulando ? (simulacao?.label || 'nenhum') : 'nenhum'}
              onValueChange={(v) => {
                if (v === 'nenhum') limparSimulacao();
                else setSimulacaoPerfil({ label: v, base: normalizarPerfil(v) });
              }}
            >
              <SelectTrigger className="w-60">
                <SelectValue placeholder="Selecionar perfil" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="nenhum">Selecionar perfil</SelectItem>
                {opcoesPreview.map((p) => (
                  <SelectItem key={p} value={p}>{p}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {simulando && (
              <Button variant="default" onClick={limparSimulacao}>
                Sair da pré-visualização
              </Button>
            )}
          </div>
        </div>
        {simulando && (
          <div className="mt-3 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
            Pré-visualização ativa: <strong>{simulacao?.label}</strong>. Você está visualizando o sistema exatamente como este perfil.
          </div>
        )}
      </div>

      {/* Matriz editável */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-4 py-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-[#0b2545]">Matriz de Permissões</h3>
            {!podeEditar && (
              <span className="inline-flex items-center gap-1 text-[11px] text-slate-500 bg-slate-100 px-2 py-1 rounded-md">
                <Lock className="w-3 h-3" /> Somente leitura
              </span>
            )}
          </div>
          {podeEditar && (
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={cancelar} disabled={!dirty || saving}>
                Cancelar
              </Button>
              <Button variant="outline" size="sm" onClick={restaurarPadrao} disabled={saving}>
                <RotateCcw className="w-4 h-4" /> Restaurar padrão
              </Button>
              <Button size="sm" onClick={salvar} disabled={!dirty || saving}>
                <Save className="w-4 h-4" /> {saving ? 'Salvando...' : 'Salvar alterações'}
              </Button>
            </div>
          )}
        </div>

        {loading || !draft ? (
          <div className="p-10 text-center text-slate-400 text-sm">Carregando permissões...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="text-left px-4 py-3 min-w-[200px]">Módulo</th>
                  {PERFIS.map((p) => (
                    <th key={p} className="px-3 py-3 text-center min-w-[230px]">{p}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {GRUPOS_MATRIZ.map((grupo) => <React.Fragment key={grupo}>
                  <tr className="bg-slate-100/70"><td colSpan={1 + PERFIS.length} className="px-4 py-2 text-[11px] font-semibold uppercase tracking-wide text-slate-500">{grupo}</td></tr>
                  {MATRIZ_PERMISSOES.filter((linha) => linha.grupo === grupo).map((linha) => <tr key={linha.id} className="hover:bg-slate-50/60">
                    <td className={`px-4 py-3 font-medium text-[#0b2545] ${linha.subitem ? 'pl-10' : 'pl-6'}`}>{linha.subitem && <span className="mr-2 text-slate-400">└─</span>}{linha.label}</td>
                    {PERFIS.map((perfil) => <td key={perfil} className="px-3 py-3"><CelulaPermissoes perfil={perfil} moduloIds={linha.modulos} valores={permissoesDaLinha(draft, perfil, linha)} editable={podeEditar} onToggle={toggle} /></td>)}
                  </tr>)}
                </React.Fragment>)}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}