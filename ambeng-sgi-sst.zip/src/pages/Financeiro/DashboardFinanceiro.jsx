import React, { useMemo, useState } from 'react';
import { localIso } from '@/lib/financeiroConsolidado';
import { calcularFinanceiro } from '@/lib/financeiroConsolidado';
import useFinanceiroDashboardData from '@/hooks/useFinanceiroDashboardData';
import { aplicarFiltrosDashboard } from '@/lib/dashboardFinancialFilters';
import DashboardGlobalFilters from '@/components/financeiro/dashboard/DashboardGlobalFilters';
import ExecutiveKpis from '@/components/financeiro/dashboard/ExecutiveKpis';
import CompanyHealthCard from '@/components/financeiro/CompanyHealthCard';
import CashEvolutionChart from '@/components/financeiro/dashboard/CashEvolutionChart';
import CompanyResultChart from '@/components/financeiro/dashboard/CompanyResultChart';
import ManagementAlerts from '@/components/financeiro/dashboard/ManagementAlerts';
import WorkHealthGrid from '@/components/financeiro/dashboard/WorkHealthGrid';
import WorkResultChart from '@/components/financeiro/dashboard/WorkResultChart';
import WorkMarginChart from '@/components/financeiro/dashboard/WorkMarginChart';
import RevenueCostChart from '@/components/financeiro/dashboard/RevenueCostChart';
import ReceiptsOverview from '@/components/financeiro/dashboard/ReceiptsOverview';
import BudgetOverview from '@/components/financeiro/dashboard/BudgetOverview';
import CompletedWorks from '@/components/financeiro/dashboard/CompletedWorks';
import DashboardPendingSummary from '@/components/financeiro/dashboard/DashboardPendingSummary';
import FinancialReconciliationNotice from '@/components/financeiro/FinancialReconciliationNotice';
import SaldoProjetadoDialog from '@/components/financeiro/SaldoProjetadoDialog';

const plusDays = (days) => { const d = new Date(); d.setDate(d.getDate()+days); return localIso(d); };
export default function DashboardFinanceiro() {
  const { data, loading } = useFinanceiroDashboardData();
  const [periodo,setPeriodo] = useState('ano'); const [custom,setCustom] = useState({ inicio:localIso(new Date(new Date().getFullYear(),0,1)), fim:localIso(new Date()) });
  const [filtros,setFiltros] = useState({ obraId:'', cliente:'', statusObra:'' }); const [situacao,setSituacao] = useState(''); const [projectionOpen,setProjectionOpen] = useState(false);
  const filtrados = useMemo(() => aplicarFiltrosDashboard(data,filtros), [data,filtros]);
  const resumo = useMemo(() => calcularFinanceiro(filtrados,periodo,custom,plusDays(90)), [filtrados,periodo,custom]);
  const clientes = useMemo(() => [...new Set(data.receitas.map((r) => r.cliente).concat(data.obras.map((o) => o.cliente)).filter(Boolean))].sort(), [data]);
  if (loading) return <div className="py-20 text-center text-sm text-muted-foreground">Consolidando dados financeiros...</div>;
  return <div className="space-y-6"><header><p className="text-xs font-semibold uppercase tracking-wider text-primary">Central gerencial</p><h1 className="text-2xl font-semibold">Dashboard Financeiro</h1><p className="text-sm text-muted-foreground">Saúde da empresa e das obras a partir dos lançamentos financeiros existentes.</p></header><DashboardGlobalFilters periodo={periodo} setPeriodo={setPeriodo} custom={custom} setCustom={setCustom} filtros={filtros} setFiltros={setFiltros} obras={data.obras} clientes={clientes} /><ExecutiveKpis resumo={resumo} /><CompanyHealthCard resumo={resumo} /><ManagementAlerts resumo={resumo} onSituation={(value) => { setSituacao(value); setTimeout(() => document.getElementById(value === 'concluida' ? 'obras-concluidas' : 'saude-obras-dashboard')?.scrollIntoView({ behavior:'smooth' }), 0); }} /><CashEvolutionChart resumo={resumo} onDetails={() => setProjectionOpen(true)} /><CompanyResultChart resumo={resumo} /><WorkHealthGrid obras={resumo.obras} periodo={periodo} situacao={situacao} onClear={() => setSituacao('')} /><RevenueCostChart obras={resumo.obras} /><div className="grid gap-4 xl:grid-cols-2"><WorkResultChart obras={resumo.obras} /><WorkMarginChart obras={resumo.obras} /></div><ReceiptsOverview resumo={resumo} /><BudgetOverview obras={resumo.obras} /><CompletedWorks obras={resumo.obras} periodo={periodo} /><DashboardPendingSummary resumo={resumo} /><FinancialReconciliationNotice conciliacao={resumo.conciliacao} cadastros={resumo.divergenciasIntegridade} /><SaldoProjetadoDialog open={projectionOpen} onOpenChange={setProjectionOpen} resumo={resumo} horizonte={90} dataFim={plusDays(90)} /></div>;
}