import React, { useMemo, useState } from 'react';
import useAuditoriaFinanceira from '@/hooks/useAuditoriaFinanceira';
import { calcularFinanceiro } from '@/lib/financeiroConsolidado';
import { filtrarAuditoria, montarAuditoriaFinanceira } from '@/lib/auditoriaFinanceira';
import AuditFilters from '@/components/auditoria-financeira/AuditFilters';
import AuditSummary from '@/components/auditoria-financeira/AuditSummary';
import AuditTable from '@/components/auditoria-financeira/AuditTable';

export default function AuditoriaIntegracaoFinanceira() {
  const [filtros, setFiltros] = useState({ busca: 'BRIDGESTONE', cliente: '', obra: '', id: '', valor: '', documento: '' });
  const { data, loading } = useAuditoriaFinanceira();
  const resumo = useMemo(() => calcularFinanceiro(data, 'custom', { inicio: '2000-01-01', fim: '2100-12-31' }, '2100-12-31'), [data]);
  const rows = useMemo(() => montarAuditoriaFinanceira(data, resumo), [data, resumo]);
  const filtrados = useMemo(() => filtrarAuditoria(rows, filtros), [rows, filtros]);
  if (loading) return <div className="py-16 text-center text-sm text-muted-foreground">Auditando integrações financeiras...</div>;
  return <div className="space-y-5"><header><p className="text-xs font-semibold uppercase tracking-wider text-primary">Ferramenta temporária · somente leitura</p><h1 className="text-2xl font-semibold">Auditoria de Integração Financeira</h1><p className="mt-1 text-sm text-muted-foreground">Rastreia o mesmo ID entre origem, Receitas, Dashboard, Obra e Relatórios, sem modificar lançamentos.</p></header><AuditFilters filtros={filtros} setFiltros={setFiltros} /><AuditSummary rows={filtrados} /><AuditTable rows={filtrados} /><p className="rounded-lg border bg-muted/40 p-3 text-xs text-muted-foreground">Contas a receber e Caixa não possuem base paralela: são visões calculadas a partir de Receitas e Despesas. Notas e parcelas só entram no Dashboard quando existe vínculo com o lançamento financeiro original.</p></div>;
}