// DESIGN SYSTEM AMBENG - Design Tokens
export const DESIGN_SYSTEM = {
  colors: {
    bg: { primary: '#FFFFFF', secondary: '#F5F5F5', tertiary: '#F9FAFB' },
    text: { primary: '#1E293B', secondary: '#4B5563', light: '#9CA3AF' },
    border: '#E5E7EB', borderLight: '#F3F4F6',
    status: {
      success: { main: '#10B981', light: '#ECFDF5', dark: '#065F46' },
      warning: { main: '#F59E0B', light: '#FFFBEB', dark: '#78350F' },
      error: { main: '#EF4444', light: '#FEE2E2', dark: '#7F1D1D' },
      info: { main: '#3B82F6', light: '#EFF6FF', dark: '#1E3A8A' },
      neutral: { main: '#9CA3AF', light: '#F9FAFB', dark: '#4B5563' },
    },
    primary: '#0079BF', primaryDark: '#0369A1', primaryLight: '#E0F2FE',
    success: '#10B981', warning: '#F59E0B', danger: '#EF4444', light: '#F5F5F5', white: '#FFFFFF', darkGray: '#1E293B', lightGray: '#F9FAFB',
    gray: { 50: '#F9FAFB', 100: '#F3F4F6', 200: '#E5E7EB', 300: '#D1D5DB', 400: '#9CA3AF', 500: '#6B7280', 600: '#4B5563', 700: '#374151', 800: '#1F2937', 900: '#111827' },
  },
  typography: {
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    fontSize: { xs: '11px', sm: '12px', base: '13px', lg: '14px', xl: '16px', '2xl': '18px', '3xl': '22px' },
    fontWeight: { regular: 400, medium: 500, semibold: 600, bold: 700 },
    h1: { fontSize: '22px', fontWeight: 700, lineHeight: 1.2, letterSpacing: '-0.3px' },
    h2: { fontSize: '18px', fontWeight: 600, lineHeight: 1.25, letterSpacing: '-0.2px' },
    h3: { fontSize: '16px', fontWeight: 600, lineHeight: 1.3, letterSpacing: '0px' },
    bodyLarge: { fontSize: '14px', fontWeight: 400, lineHeight: 1.5, letterSpacing: '0px' },
    body: { fontSize: '13px', fontWeight: 400, lineHeight: 1.5, letterSpacing: '0px' },
    bodySmall: { fontSize: '12px', fontWeight: 400, lineHeight: 1.4, letterSpacing: '0px' },
    label: { fontSize: '12px', fontWeight: 500, lineHeight: 1.2, letterSpacing: '0px' },
  },
  spacing: { xs: '4px', sm: '8px', md: '12px', lg: '16px', xl: '20px', '2xl': '24px', '3xl': '32px', '4xl': '48px' },
  shadows: { sm: '0 1px 3px rgba(0,0,0,0.05)', md: '0 4px 12px rgba(0,0,0,0.12)', lg: '0 8px 24px rgba(0,0,0,0.15)', xl: '0 10px 15px rgba(0,0,0,0.1)' },
  radius: { sm: '3px', md: '4px', lg: '6px', xl: '8px', full: '12px' },
  transitions: { fast: '0.15s ease', base: '0.2s ease', slow: '0.3s ease' },
};
export default DESIGN_SYSTEM;